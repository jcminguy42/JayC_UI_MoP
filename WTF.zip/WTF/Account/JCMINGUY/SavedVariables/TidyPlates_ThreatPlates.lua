
ThreatPlatesDB = {
	["char"] = {
		["Dmgur - Lotus"] = {
			["welcome"] = true,
			["specInfo"] = {
				{
					["name"] = "Retribution",
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [2]
			},
			["spec"] = {
				["primary"] = false,
			},
		},
		["Wafty - Mistblade"] = {
			["welcome"] = true,
			["spec"] = {
				["primary"] = false,
			},
			["specInfo"] = {
				{
					["name"] = "Enhancement",
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [2]
			},
		},
		["Gsea - Mistblade"] = {
			["specInfo"] = {
				{
					["name"] = "Guardian",
					["role"] = "TANK",
				}, -- [1]
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [2]
			},
			["spec"] = {
				["secondary"] = true,
			},
			["welcome"] = true,
		},
		["Lotusprep - [EN] Evermoon"] = {
			["welcome"] = true,
			["specInfo"] = {
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [2]
			},
			["spec"] = {
				["primary"] = false,
			},
		},
		["Dmgurx - Lotus"] = {
			["welcome"] = true,
			["specInfo"] = {
				{
					["name"] = "Enhancement",
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["name"] = "Unknown",
					["role"] = "DAMAGER",
				}, -- [2]
			},
			["spec"] = {
				["primary"] = false,
			},
		},
	},
	["profileKeys"] = {
		["Dmgur - Lotus"] = "Default",
		["Dmgurx - Lotus"] = "Default",
		["Gsea - Mistblade"] = "Default",
		["Lotusprep - [EN] Evermoon"] = "Default",
		["Wafty - Mistblade"] = "Default",
	},
	["global"] = {
		["version"] = "6.008",
	},
	["profiles"] = {
		["Default"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
			},
			["allowClass"] = true,
			["uniqueSettings"] = {
				[33] = {
				},
				[34] = {
				},
				[38] = {
				},
				[40] = {
				},
				[41] = {
				},
				[42] = {
				},
				[48] = {
				},
				[49] = {
				},
				[50] = {
				},
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"Canal Crab", -- [31]
					"Muddy Crawfish", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["totemWidget"] = {
				["ON"] = false,
			},
			["threat"] = {
				["tank"] = {
					["scale"] = {
						["HIGH"] = 0.7000000000000001,
					},
					["alpha"] = {
						["HIGH"] = 0.8,
					},
				},
			},
			["cache"] = {
			},
			["settings"] = {
				["eliteicon"] = {
					["show"] = false,
				},
				["spelltext"] = {
					["typeface"] = "Arial Narrow",
					["flags"] = "OUTLINE",
					["size"] = 10,
				},
				["level"] = {
					["show"] = false,
				},
				["name"] = {
					["shadow"] = false,
					["typeface"] = "Arial Narrow",
					["flags"] = "OUTLINE",
					["size"] = 8,
				},
				["customtext"] = {
					["show"] = false,
				},
			},
			["targetWidget"] = {
				["r"] = 0,
				["g"] = 0,
				["b"] = 0,
			},
			["classWidget"] = {
				["ON"] = false,
			},
			["friendlyClass"] = true,
		},
	},
}
