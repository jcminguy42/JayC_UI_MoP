
AtlasLootDB = {
	["namespaces"] = {
		["WishList"] = {
		},
		["AtlasLootPanel"] = {
		},
		["DefaultFrame"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["instance"] = "BlackwingLair",
					["NEWpoint"] = {
						nil, -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						-5.856088638305664, -- [4]
						35.97388076782227, -- [5]
					},
					["module"] = "AtlasLootClassicWoW",
				},
				["Dmgur - Lotus"] = {
					["module"] = "AtlasLootMoP",
					["NEWpoint"] = {
						"BOTTOM", -- [1]
						nil, -- [2]
						"BOTTOM", -- [3]
						-113.7776870727539, -- [4]
						-0, -- [5]
					},
					["instance"] = "HeartofFear",
				},
			},
		},
		["Filter"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["filterSlots"] = {
						["Stats"] = {
							["PARRY_RATING"] = false,
							["DODGE_RATING"] = false,
							["INTELLECT"] = false,
							["SPIRIT"] = false,
							["STRENGTH"] = false,
							["SPELL_POWER"] = false,
						},
						["Armor"] = {
							["#a2#"] = false,
							["#a4#"] = false,
							["#a1#"] = false,
						},
						["WeaponsMeeleTwoHand"] = {
							["#w6#"] = false,
							["#w1#"] = false,
							["#w10#"] = false,
						},
						["WeaponsMeele"] = {
							["#w9#"] = false,
							["#w8#"] = false,
							["#w7#"] = false,
							["#s15#"] = false,
							["#w10#"] = false,
						},
						["WeaponsRanged"] = {
							["#w3#"] = false,
							["#w2#"] = false,
							["#w5#"] = false,
							["#w12#"] = false,
						},
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Wafty - Mistblade",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
	},
	["showWarning"] = true,
	["profiles"] = {
		["Wafty - Mistblade"] = {
			["LootTableType"] = "25Man",
		},
		["Lotusprep - [EN] Evermoon"] = {
		},
		["Dmgur - Lotus"] = {
			["EquipCompare"] = true,
		},
		["Dmgurx - Lotus"] = {
		},
	},
}
