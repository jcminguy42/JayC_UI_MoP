
ReforgeLiteDB = {
	["windowHeight"] = 564,
	["activeWindowTitle"] = {
		0.8, -- [1]
		0, -- [2]
		0, -- [3]
	},
	["windowY"] = 898.5753173828125,
	["reforgeCheat"] = 5,
	["profiles"] = {
		["Dmgurx - Lotus"] = {
			["method"] = {
				["items"] = {
					{
						["dst"] = 6,
						["src"] = 7,
						["reforge"] = 48,
						["amount"] = 262,
					}, -- [1]
					{
					}, -- [2]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 260,
					}, -- [3]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 187,
					}, -- [4]
					{
						["dst"] = 4,
						["src"] = 7,
						["reforge"] = 46,
						["amount"] = 254,
					}, -- [5]
					{
					}, -- [6]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 218,
					}, -- [7]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 214,
					}, -- [8]
					{
						["dst"] = 8,
						["src"] = 6,
						["reforge"] = 42,
						["amount"] = 356,
					}, -- [9]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 223,
					}, -- [10]
					{
						["dst"] = 4,
						["src"] = 7,
						["reforge"] = 46,
						["amount"] = 155,
					}, -- [11]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 189,
					}, -- [12]
					{
					}, -- [13]
					{
					}, -- [14]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 157,
					}, -- [15]
					{
					}, -- [16]
				},
				["stats"] = {
					251, -- [1]
					0, -- [2]
					0, -- [3]
					2564, -- [4]
					1450, -- [5]
					4077, -- [6]
					2274, -- [7]
					9631, -- [8]
				},
			},
			["weights"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				200, -- [4]
				120, -- [5]
				140, -- [6]
				180, -- [7]
				160, -- [8]
			},
			["caps"] = {
				{
					["stat"] = 4,
					["points"] = {
						{
							["value"] = 2550,
							["preset"] = 2,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [1]
				{
					["stat"] = 7,
					["points"] = {
						{
							["value"] = 2210,
							["preset"] = 5,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [2]
			},
			["ilvlCap"] = 0,
			["targetLevel"] = 3,
			["prio"] = {
				{
					["value"] = 2550,
					["preset"] = 2,
					["stat"] = 4,
					["capped"] = true,
				}, -- [1]
				{
					["value"] = 2210,
					["preset"] = 5,
					["stat"] = 7,
					["capped"] = true,
				}, -- [2]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 8,
				}, -- [3]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 6,
				}, -- [4]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 5,
				}, -- [5]
			},
			["buffs"] = {
			},
			["itemsLocked"] = {
			},
			["customMethodPresets"] = {
			},
		},
		["Wafty - Mistblade"] = {
			["method"] = {
				["items"] = {
					{
						["src"] = 5,
						["reforge"] = 33,
						["dst"] = 6,
						["amount"] = 212,
					}, -- [1]
					{
						["src"] = 5,
						["reforge"] = 33,
						["dst"] = 6,
						["amount"] = 170,
					}, -- [2]
					{
						["src"] = 5,
						["reforge"] = 32,
						["dst"] = 4,
						["amount"] = 144,
					}, -- [3]
					{
						["src"] = 5,
						["reforge"] = 33,
						["dst"] = 6,
						["amount"] = 152,
					}, -- [4]
					{
						["src"] = 8,
						["reforge"] = 55,
						["dst"] = 6,
						["amount"] = 217,
					}, -- [5]
					{
						["src"] = 8,
						["reforge"] = 53,
						["dst"] = 4,
						["amount"] = 194,
					}, -- [6]
					{
						["src"] = 5,
						["reforge"] = 34,
						["dst"] = 7,
						["amount"] = 196,
					}, -- [7]
					{
						["src"] = 5,
						["reforge"] = 32,
						["dst"] = 4,
						["amount"] = 180,
					}, -- [8]
					{
						["src"] = 8,
						["reforge"] = 55,
						["dst"] = 6,
						["amount"] = 257,
					}, -- [9]
					{
						["src"] = 5,
						["reforge"] = 32,
						["dst"] = 4,
						["amount"] = 204,
					}, -- [10]
					{
					}, -- [11]
					{
						["src"] = 5,
						["reforge"] = 32,
						["dst"] = 4,
						["amount"] = 139,
					}, -- [12]
					{
						["src"] = 8,
						["reforge"] = 55,
						["dst"] = 6,
						["amount"] = 431,
					}, -- [13]
					{
						["src"] = 4,
						["reforge"] = 27,
						["dst"] = 7,
						["amount"] = 338,
					}, -- [14]
					{
						["src"] = 4,
						["reforge"] = 26,
						["dst"] = 6,
						["amount"] = 102,
					}, -- [15]
					{
						["src"] = 8,
						["reforge"] = 55,
						["dst"] = 6,
						["amount"] = 111,
					}, -- [16]
				},
				["stats"] = {
					251, -- [1]
					0, -- [2]
					0, -- [3]
					2552, -- [4]
					2369, -- [5]
					3561, -- [6]
					2230, -- [7]
					6667, -- [8]
				},
			},
			["weights"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				200, -- [4]
				120, -- [5]
				160, -- [6]
				180, -- [7]
				140, -- [8]
			},
			["caps"] = {
				{
					["stat"] = 4,
					["points"] = {
						{
							["value"] = 2550,
							["preset"] = 2,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [1]
				{
					["stat"] = 7,
					["points"] = {
						{
							["value"] = 2210,
							["preset"] = 5,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [2]
			},
			["ilvlCap"] = 0,
			["targetLevel"] = 3,
			["customMethodPresets"] = {
			},
			["buffs"] = {
			},
			["itemsLocked"] = {
			},
			["prio"] = {
				{
					["value"] = 2550,
					["preset"] = 2,
					["stat"] = 4,
					["capped"] = true,
				}, -- [1]
				{
					["value"] = 2210,
					["preset"] = 5,
					["stat"] = 7,
					["capped"] = true,
				}, -- [2]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 6,
				}, -- [3]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 8,
				}, -- [4]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 5,
				}, -- [5]
			},
		},
	},
	["windowWidth"] = 800,
	["itemSize"] = 24,
	["openOnReforge"] = true,
	["windowX"] = 332.0260620117188,
	["customPresets"] = {
	},
	["inactiveWindowTitle"] = {
		0.5, -- [1]
		0.5, -- [2]
		0.5, -- [3]
	},
}
