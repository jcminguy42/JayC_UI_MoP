
VExRT = {
	["Note"] = {
		["Height"] = 100,
		["Black"] = {
		},
		["Width"] = 200,
	},
	["Addon"] = {
		["Timer"] = 0.1,
		["IconMiniMapHide"] = true,
		["Version"] = 2567,
		["PreVersion"] = 2567,
	},
	["InviteTool"] = {
		["Words"] = "инв inv byd штм 123",
		["OnlyGuild"] = true,
		["InvByChat"] = true,
		["PromoteNames"] = "",
		["PromoteRank"] = 3,
		["Rank"] = 1,
	},
	["BossWatcher"] = {
		["autoSegments"] = {
		},
	},
	["Timers"] = {
	},
	["RaidCheck"] = {
		["ReadyCheckFrameTimerFade"] = 4,
	},
	["Coins"] = {
		["list"] = {
			"7132172Nagaroth1642196056", -- [1]
			"B132173Bugforever1642197510", -- [2]
			"7132174Nagaroth1642199245", -- [3]
			"!786133Nagaroth1642199245", -- [4]
			"B132174Bugforever1642199259", -- [5]
			"3132174Minmaxer1642199260", -- [6]
			"7132174Wafty1642199285", -- [7]
			"!786132Wafty1642199285", -- [8]
			"7132175Pohmas1642200460", -- [9]
			"3132175Minmaxer1642200460", -- [10]
			"!386142Minmaxer1642200460", -- [11]
			"7132175Wafty1642200505", -- [12]
			"!789820Wafty1642200505", -- [13]
		},
	},
	["ExCD2"] = {
		["enabled"] = true,
		["gnGUIDs"] = {
			["Fertilelio"] = 255,
			["Wafty"] = 263,
			["Plaguecry"] = 250,
			["Vo"] = 256,
			["Anciano"] = 71,
			["Zadee"] = 255,
			["Lichitung"] = 250,
			["Spagx"] = 252,
			["Dreiu"] = 71,
			["Minmaxer"] = 255,
			["Bloker"] = 260,
			["Sheckleborg"] = 260,
			["Justyn"] = 255,
			["Gammygam"] = 64,
			["Samxarius"] = 267,
			["Galadis"] = 256,
			["Pwg"] = 265,
			["Goblean"] = 62,
			["Demon"] = 264,
			["Ritto"] = 70,
			["Hcl"] = 102,
			["Suffering"] = 103,
			["Capsizer"] = 71,
			["Tauranosorus"] = 263,
			["Bdub"] = 70,
			["Friadk"] = 250,
			["Whowasthat"] = 267,
			["Hyperr"] = 263,
			["Smog"] = 103,
			["Elgrandex"] = 269,
			["Tazanian"] = 71,
			["Tydodk"] = 252,
			["Prototip"] = 71,
			["Rzk"] = 255,
			["Unplugged"] = 267,
			["Skana"] = 255,
			["Dontkekwme"] = 270,
			["Monkaw"] = 269,
			["Donald"] = 66,
			["Rhahum"] = 270,
			["Winterfang"] = 71,
			["Kogron"] = 264,
			["Dampfhammer"] = 104,
			["Fugrin"] = 266,
			["Gsea"] = 0,
			["Gantera"] = 71,
			["Imerik"] = 71,
			["Icysong"] = 64,
			["Ktz"] = 255,
			["Brainon"] = 71,
			["Betaperry"] = 268,
			["Astiz"] = 262,
			["Anhora"] = 263,
			["Lexxy"] = 268,
			["Nellith"] = 268,
			["Fugaza"] = 267,
			["Maam"] = 256,
			["Treefiddy"] = 105,
			["Tanukida"] = 258,
			["Obea"] = 73,
			["Rune Weapon"] = 250,
			["Dagr"] = 259,
			["Podank"] = 267,
			["Destia"] = 65,
			["Ahegao"] = 255,
			["Tauranus"] = 103,
			["Svagbrud"] = 264,
			["Prometheus"] = 71,
			["Seanie"] = 263,
			["Ascendance"] = 262,
			["Juodasvaikas"] = 262,
			["Smadrer"] = 71,
		},
		["Save"] = {
		},
		["CDECol"] = {
		},
		["Top"] = 901.7977294921875,
		["userDB"] = {
		},
		["lock"] = true,
		["colSet"] = {
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["fontShadow"] = false,
				["fontOutline"] = true,
				["iconGeneral"] = true,
				["posX"] = 662.333251953125,
				["fontGeneral"] = true,
				["posY"] = 644.0000610351563,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [1]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["fontShadow"] = false,
				["fontOutline"] = true,
				["iconGeneral"] = true,
				["posX"] = 920.9998168945313,
				["fontGeneral"] = true,
				["posY"] = 635.111083984375,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [2]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [3]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [4]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [5]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [6]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [7]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [8]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [9]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["fontShadow"] = false,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [10]
			{
				["textureColorTextCastR"] = 1,
				["textureColorBackgroundActiveR"] = 0,
				["textureColorTextDefaultB"] = 1,
				["frameBetweenLines"] = 3,
				["textureColorTextCooldownR"] = 1,
				["methodsStyleAnimation"] = 1,
				["textureColorBackgroundCastR"] = 0,
				["frameBlackBack"] = 0,
				["textureColorTimeLineActiveB"] = 1,
				["textureColorBackgroundActiveG"] = 0,
				["textureColorTimeLineDefaultG"] = 0.44,
				["textTemplateCenter"] = "",
				["textureColorTimeLineCooldownR"] = 0.24,
				["textureColorBackgroundDefaultR"] = 0,
				["iconSize"] = 22,
				["textureColorTimeLineCastR"] = 1,
				["textureColorBackgroundCooldownB"] = 0,
				["textureColorTimeLineCastG"] = 0.46,
				["textureColorBackgroundCastB"] = 0,
				["textureColorTextActiveG"] = 1,
				["frameAlpha"] = 100,
				["textureColorTextDefaultG"] = 1,
				["fontLeftSize"] = 12,
				["textureColorTextDefaultR"] = 1,
				["textureColorBackgroundActiveB"] = 0,
				["textureColorTimeLineActiveR"] = 1,
				["textureColorBackgroundCooldownR"] = 0,
				["textureColorTextCooldownB"] = 1,
				["fontOutline"] = true,
				["textureColorTextCastB"] = 1,
				["textureColorBackgroundDefaultG"] = 0,
				["frameLines"] = 5,
				["textureFile"] = "Interface\\AddOns\\ExRT\\media\\bar16.tga",
				["textureColorTimeLineCooldownG"] = 0.44,
				["textureColorTextActiveB"] = 1,
				["fontName"] = "Fonts\\ARIALN.TTF",
				["textureColorTimeLineDefaultB"] = 1,
				["textureAlphaBackground"] = 0.3,
				["frameWidth"] = 104,
				["textureClassTimeLine"] = true,
				["textureColorTextCastG"] = 1,
				["fontSize"] = 9,
				["iconGray"] = true,
				["textureColorTextCooldownG"] = 1,
				["textureColorTimeLineCastB"] = 0.1,
				["frameColumns"] = 1,
				["frameScale"] = 100,
				["textureColorBackgroundDefaultB"] = 0,
				["iconPosition"] = 1,
				["textureAlphaTimeLine"] = 0.9,
				["textureColorTextActiveR"] = 1,
				["methodsTimeLineAnimation"] = 2,
				["textureColorBackgroundCooldownG"] = 0,
				["textureClassText"] = false,
				["textureColorTimeLineDefaultR"] = 0.24,
				["textureAnimation"] = true,
				["textureColorTimeLineCooldownB"] = 1,
				["textureColorTimeLineActiveG"] = 0.37,
				["textureClassBackground"] = false,
				["textureBorderColorA"] = 1,
				["textTemplateLeft"] = "%stime%",
				["textTemplateRight"] = "%name%",
				["textureColorBackgroundCastG"] = 0,
				["methodsIconTooltip"] = true,
				["textureBorderSize"] = 1,
				["textureAlphaCooldown"] = 1,
			}, -- [11]
		},
		["Priority"] = {
		},
		["CDE"] = {
			[740] = true,
			[76577] = true,
			[64843] = true,
			[1022] = true,
			[98008] = true,
			[51052] = true,
			[115310] = true,
			[20707] = true,
			[31821] = true,
			[61999] = true,
			[97462] = true,
			[33206] = true,
			[106898] = true,
			[114030] = true,
			[108281] = true,
			[114203] = true,
			[15286] = true,
			[6940] = true,
			[62618] = true,
			[47788] = true,
			[115213] = true,
			[108280] = true,
			[20484] = true,
			[116849] = true,
		},
		["Left"] = 2.163119792938232,
	},
	["Bossmods"] = {
	},
	["MarksBar"] = {
		["Show"] = {
			true, -- [1]
			true, -- [2]
			true, -- [3]
			true, -- [4]
		},
		["pulltimer"] = 10,
	},
	["InspectViewer"] = {
	},
	["Encounter"] = {
		["list"] = {
			["Wafty"] = {
				"57321642194582101110", -- [1]
				"56E2164219500516C110Tellios", -- [2]
				"59A21642195767112110", -- [3]
				"59C2164219626701F010Wafty", -- [4]
				"59C216421964581CC010Smashval", -- [5]
				"59C21642197048184110", -- [6]
				"5DC2164219829413E010Wafty", -- [7]
				"5DC216421987331F7110Tellios", -- [8]
				"57F216421995880D2010Wafty", -- [9]
				"57F2164219992620C110", -- [10]
			},
			["Dmgur"] = {
			},
			["Gsea"] = {
			},
			["Lotusprep"] = {
			},
			["Dmgurx"] = {
			},
		},
		["names"] = {
			[1436] = "The Spirit Kings",
			[1395] = "The Stone Guard",
			[1434] = "Gara'jal the Spiritbinder",
			[1407] = "Will of the Emperor",
			[1390] = "Feng the Accursed",
			[1500] = "Elegon",
		},
	},
}
