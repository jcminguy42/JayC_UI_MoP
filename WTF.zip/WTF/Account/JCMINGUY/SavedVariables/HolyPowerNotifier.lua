
HolyPowerCount = 3
Counter = nil
HideBlizzardFrame = nil
