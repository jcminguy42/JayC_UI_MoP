
AUCTIONATOR_SAVEDVARS = {
	["_50000"] = 500,
	["_2000"] = 100,
	["_10000"] = 200,
	["_500"] = 5,
	["_1000000"] = 2500,
	["_200000"] = 1000,
	["STARTING_DISCOUNT"] = 5,
	["LOG_DE_DATA_X"] = true,
	["_5000000"] = 10000,
}
AUCTIONATOR_PRICING_HISTORY = {
	["Embersilk Cloth"] = {
		["is"] = "53010:0",
		["7072764"] = "2700:20",
	},
	["Windwool Cloth"] = {
		["7072763"] = "1945:20",
		["is"] = "72988:0",
		["7072764"] = "1945:20",
	},
}
AUCTIONATOR_SHOPPING_LISTS = {
	{
		["items"] = {
			"Virmen", -- [1]
			"flask", -- [2]
			"Tangy Yogurt", -- [3]
			"Glorious Stat", -- [4]
		},
		["isRecents"] = 1,
		["name"] = "Recent Searches",
	}, -- [1]
	{
		["items"] = {
			"Greater Cosmic Essence", -- [1]
			"Infinite Dust", -- [2]
			"Dream Shard", -- [3]
			"Abyss Crystal", -- [4]
		},
		["name"] = "Sample Shopping List #1",
		["isSorted"] = false,
	}, -- [2]
}
AUCTIONATOR_PRICE_DATABASE = {
	["__dbversion"] = 4,
	["[EN] Evermoon_Horde"] = {
	},
	["Lotus_Horde"] = {
	},
	["Mistblade_Alliance"] = {
	},
	["Mistblade_Horde"] = {
		["Lesser Flask of Toughness"] = {
			["mr"] = 105500,
			["cc"] = 4,
			["id"] = "40079",
			["H4077"] = 105500,
			["sc"] = 4,
		},
		["Windwool Cloth"] = {
			["mr"] = 1945,
			["cc"] = 6,
			["id"] = "72988",
			["H4075"] = 1950,
			["L4075"] = 1945,
			["sc"] = 2,
		},
		["Tangy Yogurt"] = {
			["mr"] = 38600,
			["cc"] = 4,
			["id"] = "81409",
			["H4077"] = 38600,
			["sc"] = 1,
		},
		["Bolt of Embersilk Cloth"] = {
			["mr"] = 65500,
			["cc"] = 6,
			["id"] = "53643",
			["H4075"] = 65500,
			["sc"] = 2,
		},
		["Flask of Falling Leaves"] = {
			["mr"] = 1242500,
			["cc"] = 4,
			["id"] = "76086",
			["H4077"] = 1242500,
			["sc"] = 4,
		},
		["Virmen's Bite"] = {
			["mr"] = 63000,
			["cc"] = 4,
			["id"] = "76089",
			["H4077"] = 63000,
			["sc"] = 2,
		},
		["Flask of the Earth"] = {
			["mr"] = 1842500,
			["cc"] = 4,
			["id"] = "76087",
			["H4077"] = 1842500,
			["sc"] = 4,
		},
		["Flask of the Warm Sun"] = {
			["mr"] = 999000,
			["cc"] = 4,
			["id"] = "76085",
			["H4077"] = 999000,
			["sc"] = 4,
		},
		["Enchant Chest - Glorious Stats"] = {
			["mr"] = 1899990,
			["cc"] = 4,
			["id"] = "74708",
			["H4077"] = 1899990,
			["sc"] = 6,
		},
		["Flask of Spring Blossoms"] = {
			["mr"] = 1357500,
			["cc"] = 4,
			["id"] = "76084",
			["H4077"] = 1357500,
			["sc"] = 4,
		},
		["Embersilk Cloth"] = {
			["mr"] = 2800,
			["cc"] = 6,
			["id"] = "53010",
			["H4075"] = 2800,
			["sc"] = 2,
		},
		["Flask of Winter's Bite"] = {
			["mr"] = 1127499,
			["cc"] = 4,
			["id"] = "76088",
			["H4077"] = 1127499,
			["sc"] = 4,
		},
		["Bolt of Windwool Cloth"] = {
			["mr"] = 67500,
			["cc"] = 6,
			["id"] = "82441",
			["H4075"] = 67500,
			["sc"] = 2,
		},
	},
}
AUCTIONATOR_LAST_SCAN_TIME = nil
AUCTIONATOR_TOONS = {
	["Wafty"] = {
		["firstSeen"] = 1641581123,
		["firstVersion"] = "3.1.5",
	},
	["Dmgur"] = {
		["firstSeen"] = 1638558472,
		["firstVersion"] = "3.1.5",
	},
	["Gsea"] = {
		["firstSeen"] = 1642648442,
		["guid"] = "0x0102000000015AB4",
		["firstVersion"] = "3.1.5",
	},
	["Lotusprep"] = {
		["firstSeen"] = 1638469926,
		["guid"] = "0x01090000001414BE",
		["firstVersion"] = "3.1.5",
	},
	["Dmgurx"] = {
		["firstSeen"] = 1638590708,
		["firstVersion"] = "3.1.5",
		["guid"] = "0x07000000000007BA",
	},
}
AUCTIONATOR_STACKING_PREFS = {
}
AUCTIONATOR_SCAN_MINLEVEL = 1
AUCTIONATOR_DB_MAXITEM_AGE = 180
AUCTIONATOR_DB_MAXHIST_AGE = -1
AUCTIONATOR_DB_MAXHIST_DAYS = 5
AUCTIONATOR_DC_PAUSE = nil
AUCTIONATOR_DE_DATA = nil
AUCTIONATOR_DE_DATA_BAK = nil
