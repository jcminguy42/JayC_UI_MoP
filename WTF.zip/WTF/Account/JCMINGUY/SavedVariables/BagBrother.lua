
BrotherBags = {
	["[EN] Evermoon"] = {
		["Lotusprep"] = {
			[0] = {
				"6948", -- [1]
			},
			["race"] = "BloodElf",
			["sex"] = 3,
			["money"] = 0,
			["class"] = "PALADIN",
			["equip"] = {
				[7] = "24145",
				[8] = "24146",
				[5] = "58237",
				[16] = "23346",
			},
		},
	},
}
