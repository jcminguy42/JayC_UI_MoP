
MiniMainBarDB = {
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["StanceBarHidden"] = true,
			["MainMenuBarGryphonsHidden"] = true,
			["BagsBarHidden"] = true,
			["PetBarPoint"] = {
				["RelativePoint"] = "BOTTOM",
				["XOffset"] = -81.15033721923828,
				["Point"] = "BOTTOM",
				["YOffset"] = 151.5229034423828,
			},
		},
	},
}
