
Postal3DB = {
	["profileKeys"] = {
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
		["Gsea - Mistblade"] = "Gsea - Mistblade",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Dmgurx|Lotus|Horde|90|SHAMAN", -- [1]
				"Dmgur|Lotus|Horde|90|PALADIN", -- [2]
				"Gsea|Mistblade|Alliance|21|DRUID", -- [3]
				"Lotusprep|[EN] Evermoon|Horde|1|PALADIN", -- [4]
				"Wafty|Mistblade|Horde|90|SHAMAN", -- [5]
			},
		},
	},
	["profiles"] = {
		["Dmgur - Lotus"] = {
		},
		["Dmgurx - Lotus"] = {
		},
		["Gsea - Mistblade"] = {
		},
		["Lotusprep - [EN] Evermoon"] = {
		},
		["Wafty - Mistblade"] = {
			["BlackBook"] = {
				["recent"] = {
					"Eleny|Mistblade|Horde", -- [1]
					"Caries|Mistblade|Horde", -- [2]
				},
			},
		},
	},
}
