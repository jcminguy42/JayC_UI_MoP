
_detalhes_global = {
	["got_first_run"] = true,
	["tutorial"] = {
		["unlock_button"] = 4,
		["main_help_button"] = 292,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["logons"] = 292,
		["version_announce"] = 0,
		["ATTRIBUTE_SELECT_TUTORIAL1"] = true,
		["bookmark_tutorial"] = true,
		["feedback_window1"] = true,
		["TIME_ATTACK_TUTORIAL1"] = true,
	},
	["savedStyles"] = {
	},
	["report_pos"] = {
		1, -- [1]
		1, -- [2]
	},
	["realm_sync"] = true,
	["lastUpdateWarning"] = 1641917360,
	["__profiles"] = {
		["Lotusprep-[EN] Evermoon"] = {
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = false,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["use_row_animations"] = true,
			["segments_amount"] = 12,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["skin"] = "Default Skin",
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["report_to_who"] = "",
			["overall_flag"] = 13,
			["clear_ungrouped"] = true,
			["minimum_combat_time"] = 5,
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["anchor_relative"] = "top",
				["abbreviation"] = 5,
				["anchored_to"] = 1,
				["fontsize"] = 10,
				["background"] = {
					0.45, -- [1]
					0.45, -- [2]
					0.45, -- [3]
					0.28, -- [4]
				},
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Blizzard Tooltip",
				["border_size"] = 16,
				["fontshadow"] = true,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["show_amount"] = false,
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["maximize_method"] = 1,
			},
			["new_window_size"] = {
				["height"] = 130,
				["width"] = 320,
			},
			["memory_threshold"] = 3,
			["default_bg_alpha"] = 0.5,
			["update_speed"] = 0.7000000476837158,
			["ps_abbreviation"] = 6,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["animate_scroll"] = false,
			["disable_window_groups"] = false,
			["remove_realm_from_name"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["overall_clear_newchallenge"] = true,
			["clear_graphic"] = true,
			["trash_auto_remove"] = true,
			["segments_auto_erase"] = 1,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["segments_amount_to_save"] = 5,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 291.4916609447588,
				["text_format"] = 3,
				["hide"] = true,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["time_type"] = 2,
			["only_pvp_frags"] = false,
			["default_bg_color"] = 0.0941,
			["use_scroll"] = false,
			["report_lines"] = 23,
			["trash_concatenate"] = false,
			["segments_panic_mode"] = true,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["report_heal_links"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["cloud_capture"] = true,
			["standard_skin"] = {
				["show_statusbar"] = false,
				["desaturated_menu2"] = true,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menu_anchor"] = {
					-34, -- [1]
					0, -- [2]
					["side"] = 2,
				},
				["menu2_icons"] = {
					true, -- [1]
					true, -- [2]
					true, -- [3]
				},
				["bg_r"] = 0.3294117647058824,
				["skin"] = "ElvUI Frame Style",
				["bg_alpha"] = 0.5,
				["following"] = {
					["bar_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["enabled"] = true,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["color_buttons"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["switch_healer"] = false,
				["bars_sort_direction"] = 1,
				["version"] = 3,
				["hide_out_of_combat"] = false,
				["auto_hide_menu"] = {
					["left"] = false,
					["right"] = false,
				},
				["menu2_icons_size"] = 1.100000023841858,
				["tooltip"] = {
					["n_abilities"] = 3,
					["n_enemies"] = 3,
				},
				["total_bar"] = {
					["enabled"] = false,
					["only_in_group"] = true,
					["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["backdrop_texture"] = "Details Ground",
				["switch_all_roles_in_combat"] = false,
				["switch_tank_in_combat"] = false,
				["name"] = "",
				["attribute_text"] = {
					["enabled"] = true,
					["shadow"] = true,
					["side"] = 1,
					["text_size"] = 12,
					["anchor"] = {
						-20, -- [1]
						4, -- [2]
					},
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0.7, -- [4]
					},
					["text_face"] = "Friz Quadrata TT",
				},
				["closebutton_config"] = {
					["pushed_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
					["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
					["anchor"] = {
						1, -- [1]
						2, -- [2]
					},
					["normal_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
					["alpha"] = 0.6,
					["size"] = {
						20, -- [1]
						20, -- [2]
					},
				},
				["menu_alpha"] = {
					["enabled"] = false,
					["onenter"] = 1,
					["iconstoo"] = true,
					["ignorebars"] = false,
					["onleave"] = 1,
				},
				["hide_in_combat_type"] = 1,
				["menu2_anchor_down"] = {
					32, -- [1]
					3, -- [2]
				},
				["micro_displays_side"] = 2,
				["strata"] = "LOW",
				["row_show_animation"] = {
					["anim"] = "Fade",
					["options"] = {
					},
				},
				["resetbutton_config"] = {
					["anchor"] = {
						4, -- [1]
						0, -- [2]
					},
					["normal_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
					["highlight_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
					["normal_texcoord"] = {
						0, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["highlight_vertexcolor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["highlight_texcoord"] = {
						0, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["normal_vertexcolor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["size"] = {
						12, -- [1]
						12, -- [2]
					},
				},
				["switch_tank"] = false,
				["hide_in_combat_alpha"] = 1,
				["switch_all_roles_after_wipe"] = false,
				["menu_icons"] = {
					false, -- [1]
					true, -- [2]
					false, -- [3]
					true, -- [4]
				},
				["switch_damager"] = false,
				["statusbar_info"] = {
					["alpha"] = 1,
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["menu_anchor_down"] = {
					-60, -- [1]
					0, -- [2]
				},
				["bars_grow_direction"] = 1,
				["hide_icon"] = true,
				["instancebutton_config"] = {
					["textcolor"] = {
						0.7, -- [1]
						0.7, -- [2]
						0.7, -- [3]
						1, -- [4]
					},
					["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
					["size"] = {
						20, -- [1]
						16, -- [2]
					},
					["anchor"] = {
						8, -- [1]
						0, -- [2]
					},
					["textsize"] = 10,
					["textfont"] = "Friz Quadrata TT",
					["textshadow"] = false,
				},
				["grab_on_top"] = false,
				["switch_damager_in_combat"] = false,
				["menu_icons_size"] = 0.8,
				["menu2_anchor"] = {
					32, -- [1]
					3, -- [2]
				},
				["auto_current"] = true,
				["toolbar_side"] = 1,
				["bg_g"] = 0.3294117647058824,
				["window_scale"] = 1,
				["hide_in_combat"] = false,
				["show_sidebars"] = true,
				["desaturated_menu"] = true,
				["plugins_grow_direction"] = 1,
				["wallpaper"] = {
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					["texcoord"] = {
						0.0478515625, -- [1]
						0.2978515625, -- [2]
						0.630859375, -- [3]
						0.755859375, -- [4]
					},
					["enabled"] = true,
					["anchor"] = "all",
					["height"] = 128,
					["alpha"] = 0.8,
					["width"] = 256,
				},
				["stretch_button_side"] = 1,
				["switch_healer_in_combat"] = false,
				["instance_button_anchor"] = {
					-27, -- [1]
					1, -- [2]
				},
				["row_info"] = {
					["textR_outline"] = true,
					["textL_outline"] = true,
					["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
					["textL_enable_custom_text"] = false,
					["texture_background_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
					["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
					["textR_enable_custom_text"] = true,
					["texture_background_class_color"] = false,
					["fixed_texture_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["textL_show_number"] = true,
					["space"] = {
						["right"] = -2,
						["left"] = 1,
						["between"] = 1,
					},
					["fixed_texture_background_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.471, -- [4]
					},
					["textR_custom_text"] = "{data1} ({data2})",
					["start_after_icon"] = false,
					["font_face_file"] = "Fonts\\ARIALN.TTF",
					["fixed_text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["textL_custom_text"] = "{data1}. {data3}{data2}",
					["texture_background"] = "Blizzard Raid Bar",
					["alpha"] = 0.8,
					["textL_class_colors"] = false,
					["backdrop"] = {
						["enabled"] = true,
						["size"] = 4,
						["color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture"] = "Details BarBorder 2",
					},
					["no_icon"] = false,
					["font_size"] = 12,
					["textR_class_colors"] = false,
					["font_face"] = "Arial Narrow",
					["texture_class_colors"] = true,
					["height"] = 18,
					["texture_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
					["texture"] = "Blizzard Raid Bar",
					["percent_type"] = 1,
				},
				["bg_b"] = 0.3294117647058824,
			},
			["overall_clear_newboss"] = true,
			["memory_ram"] = 64,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_ALLY"] = {
					0.2, -- [1]
					1, -- [2]
					0.2, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_ENEMY"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
			},
			["total_abbreviation"] = 2,
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_segments_locked"] = false,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["deadlog_limit"] = 12,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -404.146900177002,
							["x"] = 618.2974243164063,
							["w"] = 205.7057189941406,
							["h"] = 95.23549652099609,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.8,
					["menu_anchor"] = {
						-34, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["menu2_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["bg_r"] = 0.3294117647058824,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["row_info"] = {
						["textR_outline"] = true,
						["textL_outline"] = true,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["percent_type"] = 1,
						["start_after_icon"] = false,
						["texture_background_file"] = "Interface\\AddOns\\Gladius\\Images\\Minimalist",
						["textR_enable_custom_text"] = true,
						["textR_custom_text"] = "{data1} ({data2})",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["space"] = {
							["right"] = -2,
							["left"] = 1,
							["between"] = 1,
						},
						["texture"] = "Minimalist",
						["texture_background_class_color"] = false,
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.471, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["backdrop"] = {
							["enabled"] = true,
							["texture"] = "Details BarBorder 2",
							["color"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["size"] = 4,
						},
						["textL_class_colors"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_class_colors"] = false,
						["alpha"] = 0.8,
						["no_icon"] = false,
						["font_size"] = 12,
						["texture_background"] = "Minimalist",
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["height"] = 18,
						["texture_file"] = "Interface\\AddOns\\Gladius\\Images\\Minimalist",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textL_enable_custom_text"] = false,
					},
					["closebutton_config"] = {
						["pushed_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["anchor"] = {
							1, -- [1]
							2, -- [2]
						},
						["normal_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
						["alpha"] = 0.6,
						["size"] = {
							20, -- [1]
							20, -- [2]
						},
					},
					["resetbutton_config"] = {
						["highlight_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							4, -- [1]
							0, -- [2]
						},
						["highlight_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["normal_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["normal_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["highlight_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["normal_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["size"] = {
							12, -- [1]
							12, -- [2]
						},
					},
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["desaturated_menu"] = true,
					["show_sidebars"] = true,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.3294117647058824,
					["bg_b"] = 0.3294117647058824,
					["switch_healer_in_combat"] = false,
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["skin"] = "ElvUI Frame Style",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["menu2_icons_size"] = 1.100000023841858,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 0,
								["textXMod"] = 0,
								["textFace"] = "Arial Narrow",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 11,
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PATTRIBUTE"] = {
								["isHidden"] = false,
								["textStyle"] = 2,
								["textYMod"] = 0,
								["segmentType"] = 2,
								["textXMod"] = 0,
								["textFace"] = "Arial Narrow",
								["textAlign"] = 0,
								["textSize"] = 11,
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
								["textStyle"] = 2,
								["textFace"] = "Arial Narrow",
								["textAlign"] = 0,
								["textXMod"] = 6,
								["timeType"] = 1,
								["textSize"] = 11,
								["textYMod"] = 0,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PATTRIBUTE",
					},
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0.5,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["strata"] = "LOW",
					["__snapV"] = true,
					["__snap"] = {
						[4] = 2,
					},
					["__snapH"] = false,
					["hide_in_combat_alpha"] = 1,
					["show_statusbar"] = false,
					["menu2_anchor"] = {
						32, -- [1]
						3, -- [2]
					},
					["menu2_anchor_down"] = {
						32, -- [1]
						3, -- [2]
					},
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["__was_opened"] = true,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["menu_anchor_down"] = {
						-60, -- [1]
						0, -- [2]
					},
					["grab_on_top"] = false,
					["version"] = 3,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["auto_current"] = true,
					["instancebutton_config"] = {
						["textcolor"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["textshadow"] = false,
						["anchor"] = {
							8, -- [1]
							0, -- [2]
						},
						["textfont"] = "Friz Quadrata TT",
						["textsize"] = 10,
						["size"] = {
							20, -- [1]
							16, -- [2]
						},
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = true,
						["side"] = 1,
						["text_size"] = 12,
						["anchor"] = {
							-20, -- [1]
							4, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.7, -- [4]
						},
						["text_face"] = "Friz Quadrata TT",
					},
					["switch_damager_in_combat"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -404.146900177002,
							["x"] = 618.2974243164063,
							["w"] = 205.7057189941406,
							["h"] = 95.23549652099609,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["backdrop_texture"] = "Details Ground",
					["plugins_grow_direction"] = 1,
					["wallpaper"] = {
						["enabled"] = true,
						["width"] = 256,
						["texcoord"] = {
							0.0478515625, -- [1]
							0.2978515625, -- [2]
							0.630859375, -- [3]
							0.755859375, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["anchor"] = "all",
						["height"] = 128,
						["alpha"] = 0.8,
						["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					},
					["stretch_button_side"] = 1,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["bars_grow_direction"] = 1,
					["desaturated_menu2"] = true,
				}, -- [1]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -288.9114227294922,
							["x"] = 618.2974243164063,
							["w"] = 205.7057189941406,
							["h"] = 95.23548889160156,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["desaturated_menu2"] = true,
					["menu_anchor"] = {
						-34, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["menu2_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["bg_r"] = 0.3294117647058824,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["row_info"] = {
						["textR_outline"] = true,
						["textL_outline"] = true,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["percent_type"] = 1,
						["texture"] = "Blizzard Raid Bar",
						["texture_background_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["textR_enable_custom_text"] = true,
						["textR_custom_text"] = "{data1} ({data2})",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["space"] = {
							["right"] = -2,
							["left"] = 1,
							["between"] = 1,
						},
						["start_after_icon"] = false,
						["texture_background_class_color"] = false,
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.471, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["alpha"] = 0.8,
						["textR_class_colors"] = false,
						["backdrop"] = {
							["enabled"] = true,
							["texture"] = "Details BarBorder 2",
							["color"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["size"] = 4,
						},
						["texture_background"] = "Blizzard Raid Bar",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["no_icon"] = false,
						["font_size"] = 12,
						["textL_class_colors"] = false,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["height"] = 18,
						["texture_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textL_enable_custom_text"] = false,
					},
					["closebutton_config"] = {
						["pushed_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["anchor"] = {
							1, -- [1]
							2, -- [2]
						},
						["normal_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
						["alpha"] = 0.6,
						["size"] = {
							20, -- [1]
							20, -- [2]
						},
					},
					["resetbutton_config"] = {
						["highlight_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["normal_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["normal_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							4, -- [1]
							0, -- [2]
						},
						["normal_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["highlight_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["size"] = {
							12, -- [1]
							12, -- [2]
						},
					},
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["desaturated_menu"] = true,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.3294117647058824,
					["bg_b"] = 0.3294117647058824,
					["switch_healer_in_combat"] = false,
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["skin"] = "ElvUI Frame Style",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["menu2_icons_size"] = 1.100000023841858,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Arial Narrow",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 11,
								["textYMod"] = 0,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Arial Narrow",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 11,
								["textYMod"] = 0,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
								["textXMod"] = 6,
								["textFace"] = "Arial Narrow",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["timeType"] = 1,
								["textSize"] = 11,
								["textYMod"] = 0,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["strata"] = "LOW",
					["__snapV"] = true,
					["__snap"] = {
						[2] = 1,
					},
					["__snapH"] = false,
					["hide_in_combat_alpha"] = 1,
					["show_statusbar"] = false,
					["backdrop_texture"] = "Details Ground",
					["menu2_anchor_down"] = {
						32, -- [1]
						3, -- [2]
					},
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["__was_opened"] = true,
					["bars_grow_direction"] = 1,
					["switch_damager"] = false,
					["switch_damager_in_combat"] = false,
					["stretch_button_side"] = 1,
					["grab_on_top"] = false,
					["menu2_anchor"] = {
						32, -- [1]
						3, -- [2]
					},
					["bg_alpha"] = 0.5,
					["auto_current"] = true,
					["instancebutton_config"] = {
						["textcolor"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["textshadow"] = false,
						["anchor"] = {
							8, -- [1]
							0, -- [2]
						},
						["textfont"] = "Friz Quadrata TT",
						["textsize"] = 10,
						["size"] = {
							20, -- [1]
							16, -- [2]
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = true,
						["side"] = 1,
						["text_size"] = 12,
						["anchor"] = {
							-20, -- [1]
							4, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.7, -- [4]
						},
						["text_face"] = "Friz Quadrata TT",
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -288.9114227294922,
							["x"] = 618.2974243164063,
							["w"] = 205.7057189941406,
							["h"] = 95.23548889160156,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["menu_icons_size"] = 0.8,
					["wallpaper"] = {
						["enabled"] = true,
						["width"] = 256,
						["texcoord"] = {
							0.0478515625, -- [1]
							0.2978515625, -- [2]
							0.630859375, -- [3]
							0.755859375, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["anchor"] = "all",
						["height"] = 128,
						["alpha"] = 0.8,
						["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["menu_anchor_down"] = {
						-60, -- [1]
						0, -- [2]
					},
					["switch_all_roles_after_wipe"] = false,
					["show_sidebars"] = true,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
				}, -- [2]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 0,
							["x"] = 6.103515625e-005,
							["w"] = 320.0001525878906,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300.0000610351563,
							["h"] = 299.9999694824219,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.8,
					["menu_anchor"] = {
						-34, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["menu2_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["bg_r"] = 0.3294117647058824,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["row_info"] = {
						["textR_outline"] = true,
						["textL_outline"] = true,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["percent_type"] = 1,
						["texture"] = "Blizzard Raid Bar",
						["texture_background_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["textR_enable_custom_text"] = true,
						["textR_custom_text"] = "{data1} ({data2})",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["space"] = {
							["right"] = -2,
							["left"] = 1,
							["between"] = 1,
						},
						["start_after_icon"] = false,
						["texture_background_class_color"] = false,
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.471, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["alpha"] = 0.8,
						["textR_class_colors"] = false,
						["backdrop"] = {
							["enabled"] = true,
							["texture"] = "Details BarBorder 2",
							["color"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["size"] = 4,
						},
						["texture_background"] = "Blizzard Raid Bar",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["no_icon"] = false,
						["font_size"] = 12,
						["textL_class_colors"] = false,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["height"] = 18,
						["texture_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textL_enable_custom_text"] = false,
					},
					["closebutton_config"] = {
						["pushed_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["anchor"] = {
							1, -- [1]
							2, -- [2]
						},
						["normal_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
						["alpha"] = 0.6,
						["size"] = {
							20, -- [1]
							20, -- [2]
						},
					},
					["resetbutton_config"] = {
						["highlight_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["normal_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["normal_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							4, -- [1]
							0, -- [2]
						},
						["normal_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["highlight_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["size"] = {
							12, -- [1]
							12, -- [2]
						},
					},
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["desaturated_menu"] = true,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.3294117647058824,
					["bg_b"] = 0.3294117647058824,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["skin"] = "ElvUI Frame Style",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["menu2_icons_size"] = 1.100000023841858,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 0,
								["textXMod"] = 0,
								["textFace"] = "Arial Narrow",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 11,
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 0,
								["segmentType"] = 2,
								["textFace"] = "Arial Narrow",
								["textXMod"] = 0,
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 11,
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 0,
								["textFace"] = "Arial Narrow",
								["textXMod"] = 6,
								["timeType"] = 1,
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 11,
								["textColor"] = {
									0.52549, -- [1]
									0.52549, -- [2]
									0.52549, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["strata"] = "LOW",
					["__snapV"] = false,
					["__snap"] = {
					},
					["__snapH"] = false,
					["hide_in_combat_alpha"] = 1,
					["show_statusbar"] = false,
					["desaturated_menu2"] = true,
					["menu2_anchor_down"] = {
						32, -- [1]
						3, -- [2]
					},
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["__was_opened"] = false,
					["bars_grow_direction"] = 1,
					["switch_healer_in_combat"] = false,
					["micro_displays_side"] = 2,
					["switch_damager_in_combat"] = false,
					["grab_on_top"] = false,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["bg_alpha"] = 0.5,
					["auto_current"] = true,
					["instancebutton_config"] = {
						["textcolor"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["textshadow"] = false,
						["anchor"] = {
							8, -- [1]
							0, -- [2]
						},
						["textfont"] = "Friz Quadrata TT",
						["textsize"] = 10,
						["size"] = {
							20, -- [1]
							16, -- [2]
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = true,
						["side"] = 1,
						["text_size"] = 12,
						["anchor"] = {
							-20, -- [1]
							4, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.7, -- [4]
						},
						["text_face"] = "Friz Quadrata TT",
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 0,
							["x"] = 6.103515625e-005,
							["w"] = 320.0001525878906,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300.0000610351563,
							["h"] = 299.9999694824219,
						},
					},
					["menu2_anchor"] = {
						32, -- [1]
						3, -- [2]
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["wallpaper"] = {
						["enabled"] = true,
						["width"] = 256,
						["texcoord"] = {
							0.0478515625, -- [1]
							0.2978515625, -- [2]
							0.630859375, -- [3]
							0.755859375, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["anchor"] = "all",
						["height"] = 128,
						["alpha"] = 0.8,
						["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					},
					["stretch_button_side"] = 1,
					["switch_all_roles_after_wipe"] = false,
					["switch_damager"] = false,
					["show_sidebars"] = true,
					["menu_anchor_down"] = {
						-60, -- [1]
						0, -- [2]
					},
				}, -- [3]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 0,
							["x"] = 6.103515625e-005,
							["w"] = 320.0001525878906,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.8,
					["menu_anchor"] = {
						-34, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["menu2_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["bg_r"] = 0.3294117647058824,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["row_info"] = {
						["textR_outline"] = true,
						["textL_outline"] = true,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["texture"] = "Blizzard Raid Bar",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_enable_custom_text"] = true,
						["textR_custom_text"] = "{data1} ({data2})",
						["textL_enable_custom_text"] = false,
						["textL_show_number"] = true,
						["space"] = {
							["right"] = -2,
							["left"] = 1,
							["between"] = 1,
						},
						["start_after_icon"] = false,
						["texture_background_class_color"] = false,
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.471, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["alpha"] = 0.8,
						["textR_class_colors"] = false,
						["backdrop"] = {
							["enabled"] = true,
							["texture"] = "Details BarBorder 2",
							["color"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["size"] = 4,
						},
						["texture_background"] = "Blizzard Raid Bar",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["no_icon"] = false,
						["font_size"] = 12,
						["textL_class_colors"] = false,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["height"] = 18,
						["texture_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["texture_background_file"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
						["percent_type"] = 1,
					},
					["closebutton_config"] = {
						["pushed_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["anchor"] = {
							1, -- [1]
							2, -- [2]
						},
						["normal_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
						["alpha"] = 0.6,
						["size"] = {
							20, -- [1]
							20, -- [2]
						},
					},
					["resetbutton_config"] = {
						["highlight_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["normal_vertexcolor"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["normal_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							4, -- [1]
							0, -- [2]
						},
						["normal_texture"] = "Interface\\Addons\\Details\\Images\\reset_button2",
						["highlight_texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["size"] = {
							12, -- [1]
							12, -- [2]
						},
					},
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["desaturated_menu"] = true,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.3294117647058824,
					["bg_b"] = 0.3294117647058824,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["skin"] = "ElvUI Frame Style",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["menu2_icons_size"] = 1.100000023841858,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Friz Quadrata TT",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textYMod"] = 0,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Friz Quadrata TT",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textYMod"] = 0,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 6,
								["textFace"] = "Friz Quadrata TT",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 0,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["strata"] = "LOW",
					["__snapV"] = false,
					["__snap"] = {
					},
					["__snapH"] = false,
					["hide_in_combat_alpha"] = 1,
					["show_statusbar"] = false,
					["desaturated_menu2"] = true,
					["menu2_anchor_down"] = {
						32, -- [1]
						3, -- [2]
					},
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["__was_opened"] = false,
					["bars_grow_direction"] = 1,
					["switch_healer_in_combat"] = false,
					["micro_displays_side"] = 2,
					["switch_damager_in_combat"] = false,
					["grab_on_top"] = false,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["bg_alpha"] = 0.5,
					["auto_current"] = true,
					["instancebutton_config"] = {
						["textcolor"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							1, -- [4]
						},
						["highlight_texture"] = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
						["textshadow"] = false,
						["anchor"] = {
							8, -- [1]
							0, -- [2]
						},
						["textfont"] = "Friz Quadrata TT",
						["textsize"] = 10,
						["size"] = {
							20, -- [1]
							16, -- [2]
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = true,
						["side"] = 1,
						["text_size"] = 12,
						["anchor"] = {
							-20, -- [1]
							4, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.7, -- [4]
						},
						["text_face"] = "Friz Quadrata TT",
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 0,
							["x"] = 6.103515625e-005,
							["w"] = 320.0001525878906,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu2_anchor"] = {
						32, -- [1]
						3, -- [2]
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["wallpaper"] = {
						["enabled"] = true,
						["width"] = 256,
						["texcoord"] = {
							0.0478515625, -- [1]
							0.2978515625, -- [2]
							0.630859375, -- [3]
							0.755859375, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["anchor"] = "all",
						["height"] = 128,
						["alpha"] = 0.8,
						["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					},
					["stretch_button_side"] = 1,
					["switch_all_roles_after_wipe"] = false,
					["switch_damager"] = false,
					["show_sidebars"] = true,
					["menu_anchor_down"] = {
						-60, -- [1]
						0, -- [2]
					},
				}, -- [4]
			},
		},
	},
	["switchSaved"] = {
		["slots"] = 8,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
			{
				["atributo"] = 1,
				["sub_atributo"] = 3,
			}, -- [5]
			{
				["atributo"] = 1,
				["sub_atributo"] = 4,
			}, -- [6]
			{
				["atributo"] = 4,
				["sub_atributo"] = 1,
			}, -- [7]
			{
				["atributo"] = 4,
				["sub_atributo"] = 3,
			}, -- [8]
			{
				["atributo"] = 4,
				["sub_atributo"] = 4,
			}, -- [9]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [10]
			{
				["atributo"] = 4,
				["sub_atributo"] = 6,
			}, -- [11]
			{
				["atributo"] = 5,
				["sub_atributo"] = 2,
			}, -- [12]
		},
	},
	["custom"] = {
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["icon"] = "Interface\\ICONS\\Trade_Alchemy_PotionD4",
			["name"] = "Potion Used",
			["attribute"] = false,
			["target"] = false,
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local misc_container = combat:GetActorList ( DETAILS_ATTRIBUTE_MISC )\n\n				--do the loop:\n				for _, player in ipairs ( misc_container ) do \n				    \n				    --only player in group\n				    if (player:IsGroupPlayer()) then\n					\n					local found_potion = false\n					\n					--get the spell debuff uptime container\n					local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spell_tables and player.debuff_uptime_spell_tables._ActorTable\n					if (debuff_uptime_container) then\n					    --potion of focus (can't use as pre-potion, so, its amount is always 1\n					    local focus_potion = debuff_uptime_container [105701]\n					    if (focus_potion) then\n						total = total + 1\n						found_potion = true\n						if (top < 1) then\n						    top = 1\n						end\n						--add amount to the player \n						instance_container:AddValue (player, 1)\n					    end\n					end\n					\n					--get the spell buff uptime container\n					local buff_uptime_container = player.buff_uptime and player.buff_uptime_spell_tables and player.buff_uptime_spell_tables._ActorTable\n					if (buff_uptime_container) then\n					    \n					    --potion of the jade serpent\n					    local jade_serpent_potion = buff_uptime_container [105702]\n					    if (jade_serpent_potion) then\n						local used = jade_serpent_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --potion of mogu power\n					    local mogu_power_potion = buff_uptime_container [105706]\n					    if (mogu_power_potion) then\n						local used = mogu_power_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --virmen's bite\n					    local virmens_bite_potion = buff_uptime_container [105697]\n					    if (virmens_bite_potion) then\n						local used = virmens_bite_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --potion of the mountains\n					    local mountains_potion = buff_uptime_container [105698]\n					    if (mountains_potion) then\n						local used = mountains_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					end\n					\n					if (found_potion) then\n					    amount = amount + 1\n					end    \n				    end\n				end\n\n				--return:\n				return total, top, amount\n				",
			["spellid"] = false,
			["tooltip"] = "			--init:\n			local player, combat, instance = ...\n\n			--get the debuff container for potion of focus\n			local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spell_tables and player.debuff_uptime_spell_tables._ActorTable\n			if (debuff_uptime_container) then\n			    local focus_potion = debuff_uptime_container [105701]\n			    if (focus_potion) then\n				local name, _, icon = GetSpellInfo (105701)\n				GameCooltip:AddLine (name, 1) --> can use only 1 focus potion (can't be pre-potion)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			end\n\n			--get the buff container for all the others potions\n			local buff_uptime_container = player.buff_uptime and player.buff_uptime_spell_tables and player.buff_uptime_spell_tables._ActorTable\n			if (buff_uptime_container) then\n			    --potion of the jade serpent\n			    local jade_serpent_potion = buff_uptime_container [105702]\n			    if (jade_serpent_potion) then\n				local name, _, icon = GetSpellInfo (105702)\n				GameCooltip:AddLine (name, jade_serpent_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --potion of mogu power\n			    local mogu_power_potion = buff_uptime_container [105706]\n			    if (mogu_power_potion) then\n				local name, _, icon = GetSpellInfo (105706)\n				GameCooltip:AddLine (name, mogu_power_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --virmen's bite\n			    local virmens_bite_potion = buff_uptime_container [105697]\n			    if (virmens_bite_potion) then\n				local name, _, icon = GetSpellInfo (105697)\n				GameCooltip:AddLine (name, virmens_bite_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --potion of the mountains\n			    local mountains_potion = buff_uptime_container [105698]\n			    if (mountains_potion) then\n				local name, _, icon = GetSpellInfo (105698)\n				GameCooltip:AddLine (name, mountains_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			end\n		",
		}, -- [1]
		{
			["source"] = "[raid]",
			["author"] = "Details!",
			["desc"] = "Show who in your raid group used the healthstone.",
			["icon"] = "Interface\\ICONS\\warlock_ healthstone",
			["name"] = "Healthstone Used",
			["attribute"] = "healdone",
			["target"] = "[raid]",
			["script"] = false,
			["spellid"] = 6262,
			["tooltip"] = false,
		}, -- [2]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing damage.",
			["icon"] = "Interface\\ICONS\\Achievement_PVP_H_06",
			["attribute"] = false,
			["name"] = "Damage Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, amount = 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["spellid"] = false,
			["tooltip"] = "				\n			",
		}, -- [3]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing healing.",
			["icon"] = "Interface\\ICONS\\Achievement_PVP_G_06",
			["attribute"] = false,
			["name"] = "Healing Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_HEAL )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["spellid"] = false,
			["tooltip"] = "				\n			",
		}, -- [4]
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["report_where"] = "SAY",
	["savedTimeCaptures"] = {
	},
	["savedCustomSpells"] = {
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\AddOns\\Details\\images\\melee.tga", -- [3]
		}, -- [1]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\AddOns\\Details\\images\\autoshot.tga", -- [3]
		}, -- [2]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [3]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [4]
		{
			140816, -- [1]
			"Power Word: Solace (critical)", -- [2]
			"Interface\\Icons\\ability_priest_flashoflight", -- [3]
		}, -- [5]
		{
			77451, -- [1]
			"Lava Burst (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shaman_LavaBurst", -- [3]
		}, -- [6]
		{
			94472, -- [1]
			"Atonement (critical)", -- [2]
			"Interface\\Icons\\Spell_Holy_CircleOfRenewal", -- [3]
		}, -- [7]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [8]
		{
			131079, -- [1]
			"Frostbolt (Icy Veins)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBolt02", -- [3]
		}, -- [9]
		{
			124465, -- [1]
			"Vampiric Touch (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Holy_Stoicism", -- [3]
		}, -- [10]
		{
			114654, -- [1]
			"Incinerate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\spell_fire_ragnaros_lavabolt", -- [3]
		}, -- [11]
		{
			3, -- [1]
			"Environment (falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [12]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [13]
		{
			131080, -- [1]
			"Ice Lance (Icy Veins)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBlast", -- [3]
		}, -- [14]
		{
			45297, -- [1]
			"Chain Lightning (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Nature_ChainLightning", -- [3]
		}, -- [15]
		{
			108685, -- [1]
			"Conflagrate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\spell_fire_ragnaros_molteninferno", -- [3]
		}, -- [16]
		{
			108686, -- [1]
			"Immolate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\Ability_Mage_WorldInFlames", -- [3]
		}, -- [17]
		{
			120761, -- [1]
			"Glaive Toss (Glaive #2)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [18]
		{
			121414, -- [1]
			"Glaive Toss (Glaive #1)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [19]
		{
			45284, -- [1]
			"Lightning Bolt (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Nature_Lightning", -- [3]
		}, -- [20]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [21]
		{
			131081, -- [1]
			"Frostfire Bolt (Icy Veins)", -- [2]
			"Interface\\Icons\\Ability_Mage_FrostFireBolt", -- [3]
		}, -- [22]
		{
			33778, -- [1]
			"Lifebloom (bloom)", -- [2]
			"Interface\\Icons\\Spell_Nature_HealingTouch", -- [3]
		}, -- [23]
		{
			124469, -- [1]
			"Mind Sear (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_MindShear", -- [3]
		}, -- [24]
		{
			124464, -- [1]
			"Shadow Word: Pain (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_ShadowWordPain", -- [3]
		}, -- [25]
		{
			124468, -- [1]
			"Mind Flay (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_SiphonMana", -- [3]
		}, -- [26]
	},
	["always_use_profile"] = "Lotusprep-[EN] Evermoon",
}
