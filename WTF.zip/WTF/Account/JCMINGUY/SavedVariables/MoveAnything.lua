
MADB = {
	["characters"] = {
	},
	["frameListRows"] = 18,
	["tooltips"] = 1,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
				["PlayerDebuffsMover"] = {
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						1246.620971679688, -- [4]
						647.549072265625, -- [5]
					},
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"ConsolidatedBuffs", -- [2]
						"BOTTOMRIGHT", -- [3]
						0, -- [4]
						-60, -- [5]
					},
					["name"] = "PlayerDebuffsMover",
					["forcedLock"] = true,
				},
				["PlayerBuffsMover"] = {
					["pos"] = {
						"TOPRIGHT", -- [1]
						"UIParent", -- [2]
						"TOPRIGHT", -- [3]
						-329.6534423828125, -- [4]
						-131.79736328125, -- [5]
					},
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"UIParent", -- [2]
						"TOPRIGHT", -- [3]
						-205, -- [4]
						-13, -- [5]
					},
					["name"] = "PlayerBuffsMover",
					["forcedLock"] = true,
				},
				["MainMenuBar"] = {
					["orgPos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "MainMenuBar",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						-4.57763671875e-005, -- [4]
						0, -- [5]
					},
				},
				["ConsolidatedBuffs"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"BuffFrame", -- [2]
						"TOPRIGHT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "ConsolidatedBuffs",
					["pos"] = {
						"TOPRIGHT", -- [1]
						"PlayerBuffsMover", -- [2]
						"TOPRIGHT", -- [3]
						0.8365478515625, -- [4]
						0, -- [5]
					},
				},
			},
		},
	},
}
