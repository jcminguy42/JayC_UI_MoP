
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Dmgur - Lotus"] = "Default",
		["Lotusprep - [EN] Evermoon"] = "Default",
		["Dmgurx - Lotus"] = "Default",
		["Wafty - Mistblade"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Preload"] = true,
			["Groups"] = {
				["Bartender4_4"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_BagBar"] = {
					["Colors"] = {
						["Normal"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
					["Inherit"] = false,
					["Backdrop"] = true,
				},
				["Bartender4_StanceBar"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["WeakAuras_totem"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_Vehicle"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_1"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_5"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_PetBar"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_3"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_6"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Bartender4_2"] = {
					["Colors"] = {
						["Normal"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
					["Inherit"] = false,
					["Backdrop"] = true,
				},
				["Bartender4_MicroMenu"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["WeakAuras"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
				["Masque"] = {
					["Colors"] = {
						["Normal"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Backdrop"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
				},
			},
		},
	},
}
