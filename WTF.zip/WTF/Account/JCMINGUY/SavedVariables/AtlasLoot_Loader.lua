
AtlasLootLoaderDB = {
	["MiniMapButton"] = {
		["minimapPos"] = 310.6677251634922,
		["hide"] = true,
	},
}
