
TidyPlatesOptions = {
	["WelcomeShown"] = true,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["EnableCastWatcher"] = true,
	["secondary"] = "Threat Plates",
}
