
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/elvui", -- [1]
	},
	["ChatHistoryLog"] = {
	},
}
