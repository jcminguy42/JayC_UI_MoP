
_detalhes_database = {
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Lotusprep-[EN] Evermoon",
	["last_realversion"] = 28,
	["combat_counter"] = 3892,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 1,
			["animate"] = false,
			["useplayercolor"] = false,
			["enabled"] = true,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["showamount"] = false,
		},
		["DETAILS_PLUGIN_DPS_TUNING"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
			["SpellBarsShowType"] = 1,
		},
		["DETAILS_PLUGIN_DAMAGE_RANK"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
			["enabled"] = true,
			["captures"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["author"] = "Details! Team",
			["last_encounter_hash"] = false,
			["showing_type"] = 1,
			["last_segment"] = false,
			["last_combat_id"] = 614,
			["show_icon"] = 1,
			["last_boss"] = false,
			["last_player"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["opened"] = 0,
			["author"] = "Details! Team",
			["show_icon"] = 5,
			["hide_on_combat"] = false,
			["max_emote_segments"] = 3,
		},
		["DETAILS_PLUGIN_TIME_ATTACK"] = {
			["enabled"] = true,
			["realm_last_shown"] = 40,
			["saved_as_anonymous"] = true,
			["recently_as_anonymous"] = true,
			["dps"] = 0,
			["disable_sharing"] = false,
			["history"] = {
			},
			["time"] = 40,
			["history_lastindex"] = 0,
			["author"] = "Details! Team",
			["realm_history"] = {
			},
			["realm_lastamt"] = 0,
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_YANP"] = {
			["enabled"] = true,
			["rightclick_closed"] = false,
			["auto_open"] = true,
			["author"] = "Details! Team",
			["hide_on_combat"] = true,
			["deaths_table"] = {
				{
					"Armsmaster Harlan", -- [1]
					120, -- [2]
					{
						1641953376.294, -- [1]
						108271, -- [2]
					}, -- [3]
					{
						{
							true, -- [1]
							111215, -- [2]
							70417, -- [3]
							1641953386.647, -- [4]
							1, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [1]
						{
							true, -- [1]
							111215, -- [2]
							84970, -- [3]
							1641953385.673, -- [4]
							13452, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [2]
						{
							false, -- [1]
							137808, -- [2]
							1951, -- [3]
							1641953385.391, -- [4]
							98422, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [3]
						{
							false, -- [1]
							61295, -- [2]
							7691, -- [3]
							1641953384.837, -- [4]
							94933, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [4]
						{
							true, -- [1]
							111215, -- [2]
							81659, -- [3]
							1641953384.565, -- [4]
							87242, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [5]
						{
							false, -- [1]
							137808, -- [2]
							1951, -- [3]
							1641953384.124, -- [4]
							168901, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [6]
						{
							false, -- [1]
							137808, -- [2]
							3904, -- [3]
							1641953384.124, -- [4]
							166950, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [7]
						{
							false, -- [1]
							137808, -- [2]
							1951, -- [3]
							1641953384.124, -- [4]
							163046, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [8]
						{
							false, -- [1]
							137808, -- [2]
							1952, -- [3]
							1641953383.312, -- [4]
							161095, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [9]
						{
							false, -- [1]
							137808, -- [2]
							1951, -- [3]
							1641953382.749, -- [4]
							159143, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [10]
						{
							false, -- [1]
							61295, -- [2]
							15208, -- [3]
							1641953382.031, -- [4]
							154152, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [11]
						{
							false, -- [1]
							137808, -- [2]
							3904, -- [3]
							1641953381.482, -- [4]
							138944, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [12]
						{
							false, -- [1]
							137808, -- [2]
							1170, -- [3]
							1641953381.482, -- [4]
							135040, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [13]
						{
							false, -- [1]
							137808, -- [2]
							1951, -- [3]
							1641953381.482, -- [4]
							133870, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [14]
						{
							false, -- [1]
							137808, -- [2]
							1952, -- [3]
							1641953380.769, -- [4]
							131919, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [15]
						{
							true, -- [1]
							1, -- [2]
							17535, -- [3]
							1641953380.489, -- [4]
							147502, -- [5]
							"Scarlet Defender", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [16]
					}, -- [4]
					344787, -- [5]
					1641953386.647, -- [6]
				}, -- [1]
				{
					"Armsmaster Harlan", -- [1]
					67, -- [2]
					nil, -- [3]
					{
						{
							true, -- [1]
							111215, -- [2]
							53383, -- [3]
							1641953333.88, -- [4]
							1, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [1]
						{
							true, -- [1]
							111215, -- [2]
							62163, -- [3]
							1641953332.78, -- [4]
							45751, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [2]
						{
							false, -- [1]
							77472, -- [2]
							71345, -- [3]
							1641953332.222, -- [4]
							83964, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [3]
						{
							true, -- [1]
							111215, -- [2]
							56021, -- [3]
							1641953331.657, -- [4]
							12619, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [4]
						{
							true, -- [1]
							111215, -- [2]
							57207, -- [3]
							1641953330.54, -- [4]
							68640, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [5]
						{
							false, -- [1]
							77472, -- [2]
							70969, -- [3]
							1641953329.838, -- [4]
							125847, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [6]
						{
							true, -- [1]
							111215, -- [2]
							73134, -- [3]
							1641953329.539, -- [4]
							54878, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [7]
						{
							true, -- [1]
							111215, -- [2]
							69254, -- [3]
							1641953328.573, -- [4]
							128012, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [8]
						{
							false, -- [1]
							114942, -- [2]
							31767, -- [3]
							1641953328.155, -- [4]
							197266, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [9]
						{
							true, -- [1]
							111215, -- [2]
							59135, -- [3]
							1641953327.445, -- [4]
							165499, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [10]
						{
							false, -- [1]
							77472, -- [2]
							143016, -- [3]
							1641953327.297, -- [4]
							204887, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [11]
						{
							false, -- [1]
							52752, -- [2]
							45049, -- [3]
							1641953327.297, -- [4]
							61871, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [12]
						{
							true, -- [1]
							111215, -- [2]
							56762, -- [3]
							1641953326.32, -- [4]
							16822, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [13]
						{
							false, -- [1]
							114942, -- [2]
							37015, -- [3]
							1641953326.174, -- [4]
							63400, -- [5]
							"Taintedtotem", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [14]
						{
							true, -- [1]
							111215, -- [2]
							63567, -- [3]
							1641953325.204, -- [4]
							26385, -- [5]
							"Armsmaster Harlan", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [15]
						{
							false, -- [1]
							137808, -- [2]
							1875, -- [3]
							1641953325.063, -- [4]
							89952, -- [5]
							"Wafty", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [16]
					}, -- [4]
					344787, -- [5]
					1641953333.88, -- [6]
				}, -- [2]
			},
			["shown_time"] = 30,
		},
	},
	["character_data"] = {
		["logons"] = 218,
	},
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 614,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["serial"] = "0x010200000000F0DA",
							["on_hold"] = false,
							["damage_from"] = {
								["Vigilant Watchman"] = true,
								["Starving Hound"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Starving Hound",
										["total"] = 1091,
									}, -- [1]
								},
							},
							["end_time"] = 1642654909,
							["pets"] = {
							},
							["colocacao"] = 1,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 1091.00325,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["dps_started"] = false,
							["total"] = 1091.00325,
							["classe"] = "MONK",
							["nome"] = "Ruhty",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 92,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Starving Hound",
													["total"] = 252,
												}, -- [1]
											},
										},
										["n_dmg"] = 252,
										["n_min"] = 74,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 252,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[124335] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 69,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Starving Hound",
													["total"] = 69,
												}, -- [1]
											},
										},
										["n_dmg"] = 69,
										["n_min"] = 69,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 69,
										["c_max"] = 0,
										["id"] = 124335,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 389,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Starving Hound",
													["total"] = 602,
												}, -- [1]
											},
										},
										["n_dmg"] = 602,
										["n_min"] = 213,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 602,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[108557] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 88,
										["g_amt"] = 0,
										["n_max"] = 43,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Starving Hound",
													["total"] = 168,
												}, -- [1]
											},
										},
										["n_dmg"] = 80,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 168,
										["c_max"] = 88,
										["id"] = 108557,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 88,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 109.100325,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2204.00325,
							["start_time"] = 1642654902,
							["delay"] = 0,
							["last_event"] = 1642654907,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["serial"] = "0x01020000000152F7",
							["on_hold"] = false,
							["damage_from"] = {
								["Vigilant Watchman"] = true,
								["Starving Hound"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Starving Hound",
										["total"] = 44,
									}, -- [1]
								},
							},
							["end_time"] = 1642654909,
							["pets"] = {
							},
							["colocacao"] = 2,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 44.006377,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["dps_started"] = false,
							["total"] = 44.006377,
							["classe"] = "DRUID",
							["nome"] = "Felyx",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[8921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 44,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Starving Hound",
													["total"] = 44,
												}, -- [1]
											},
										},
										["n_dmg"] = 44,
										["n_min"] = 44,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 44,
										["c_max"] = 0,
										["id"] = 8921,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 4.4006377,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1317.006377,
							["start_time"] = 1642654907,
							["delay"] = 0,
							["last_event"] = 1642654907,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Starving Hound"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["isTank"] = true,
							["on_hold"] = false,
							["classe"] = "DRUID",
							["end_time"] = 1642654909,
							["total_without_pet"] = 0.003403,
							["colocacao"] = 3,
							["dps_started"] = false,
							["total"] = 0.003403,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 12,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 12,
									["HITS"] = 12,
									["FULL_HIT_AMT"] = 1514,
								},
								["Starving Hound"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 12,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 12,
									["HITS"] = 12,
									["FULL_HIT_AMT"] = 1514,
								},
							},
							["friendlyfire_total"] = 0,
							["nome"] = "Gsea",
							["serial"] = "0x0102000000015AB4",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 0.0003403,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 1514.003403,
							["start_time"] = 1642654909,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["serial"] = "0x0102000000015A98",
							["damage_from"] = {
								["Starving Hound"] = true,
								["Vigilant Watchman"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["end_time"] = 1642654909,
							["colocacao"] = 4,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 0.00199,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["dps_started"] = false,
							["total"] = 0.00199,
							["classe"] = "PRIEST",
							["nome"] = "Troudcul",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0.000199,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1056.00199,
							["start_time"] = 1642654909,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 614,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["last_hps"] = 0,
							["healing_from"] = {
								["Ruhty"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 0,
										["total"] = 239,
										["nome"] = "Ruhty",
										["absorbed"] = 0,
									}, -- [1]
									{
										["overheal"] = 0,
										["total"] = 19,
										["nome"] = "Felyx",
										["absorbed"] = 0,
									}, -- [2]
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["totalabsorb"] = 0.008238000000000001,
							["classe"] = "MONK",
							["totalover"] = 0.008238000000000001,
							["total_without_pet"] = 258.008238,
							["last_event"] = 1642654908,
							["fight_component"] = true,
							["total"] = 258.008238,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1642654909,
							["nome"] = "Ruhty",
							["totalover_without_pet"] = 0.008238000000000001,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[126890] = {
										["c_curado"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 22,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 22,
													["nome"] = "Ruhty",
													["absorbed"] = 0,
												}, -- [1]
												{
													["overheal"] = 0,
													["total"] = 19,
													["nome"] = "Felyx",
													["absorbed"] = 0,
												}, -- [2]
											},
										},
										["n_min"] = 19,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 41,
										["c_max"] = 0,
										["id"] = 126890,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 41,
										["absorbed"] = 0,
									},
									[115175] = {
										["c_curado"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 217,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 217,
													["nome"] = "Ruhty",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 217,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 217,
										["c_max"] = 0,
										["id"] = 115175,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 217,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["healing_taken"] = 239.008238,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654904,
							["delay"] = 0,
							["serial"] = "0x010200000000F0DA",
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.008291,
							["last_hps"] = 0,
							["healing_from"] = {
								["Ruhty"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.008291,
							["total_without_pet"] = 0.008291,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.008291,
							["heal_enemy_amt"] = 0,
							["totalover_without_pet"] = 0.008291,
							["nome"] = "Felyx",
							["end_time"] = 1642654909,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["healing_taken"] = 19.008291,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654909,
							["delay"] = 0,
							["serial"] = "0x01020000000152F7",
						}, -- [2]
					},
				}, -- [2]
				{
					["combatId"] = 614,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 614,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[8921] = {
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 8921,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 0,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[2479] = {
										["activedamt"] = 1,
										["id"] = 2479,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["fight_component"] = true,
							["debuff_uptime"] = 2,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654907,
							["nome"] = "Felyx",
							["pets"] = {
							},
							["serial"] = "0x01020000000152F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[116189] = {
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 116189,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 3,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[139597] = {
										["activedamt"] = 2,
										["id"] = 139597,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654906,
										["uptime"] = 2,
										["actived"] = true,
										["counter"] = 0,
									},
									[121125] = {
										["activedamt"] = 1,
										["id"] = 121125,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654902,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[2479] = {
										["activedamt"] = 1,
										["id"] = 2479,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[103985] = {
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = 103985,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[117666] = {
										["activedamt"] = 1,
										["id"] = 117666,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[130283] = {
										["activedamt"] = 1,
										["id"] = 130283,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[115175] = {
										["activedamt"] = 1,
										["id"] = 115175,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654908,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[115070] = {
										["activedamt"] = 1,
										["id"] = 115070,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654907,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[126896] = {
										["activedamt"] = 1,
										["id"] = 126896,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[127722] = {
										["activedamt"] = 1,
										["id"] = 127722,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654905,
										["uptime"] = 1,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["debuff_uptime"] = 3,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654908,
							["nome"] = "Ruhty",
							["pets"] = {
							},
							["serial"] = "0x010200000000F0DA",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["classe"] = "PRIEST",
							["nome"] = "Troudcul",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[2479] = {
										["activedamt"] = 1,
										["id"] = 2479,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[128164] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 128164,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[588] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 588,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[21562] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 21562,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["buff_uptime"] = 3,
							["serial"] = "0x0102000000015A98",
							["last_event"] = 1642654900,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["classe"] = "PALADIN",
							["nome"] = "Alxnder",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[93795] = {
										["activedamt"] = 1,
										["id"] = 93795,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[25780] = {
										["activedamt"] = 1,
										["id"] = 25780,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[2479] = {
										["activedamt"] = 1,
										["id"] = 2479,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654899,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["buff_uptime"] = 0,
							["serial"] = "0x010200000000BB24",
							["last_event"] = 1642654899,
						}, -- [4]
						{
							["flag_original"] = 1047,
							["nome"] = "Gsea",
							["grupo"] = true,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime"] = 22,
							["pets"] = {
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[2479] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 2479,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[128164] = {
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 128164,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[5487] = {
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 5487,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[132365] = {
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 132365,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["last_event"] = 1642654909,
							["isTank"] = true,
							["serial"] = "0x0102000000015AB4",
							["tipo"] = 4,
						}, -- [5]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 614,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Felyx"] = true,
					["Troudcul"] = true,
					["Gsea"] = true,
					["Ruhty"] = true,
					["Alxnder"] = true,
				},
				["last_events_tables"] = {
					{
						{
							{
								true, -- [1]
								1, -- [2]
								127, -- [3]
								1642654902.002, -- [4]
								1486, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [1]
							{
								true, -- [1]
								1, -- [2]
								107, -- [3]
								1642654902.002, -- [4]
								1486, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [2]
							{
								true, -- [1]
								1, -- [2]
								123, -- [3]
								1642654902.31, -- [4]
								1252, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [3]
							{
								true, -- [1]
								1, -- [2]
								123, -- [3]
								1642654902.325, -- [4]
								1252, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [4]
							{
								true, -- [1]
								1, -- [2]
								93, -- [3]
								1642654903.035, -- [4]
								1006, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [5]
							{
								true, -- [1]
								1, -- [2]
								105, -- [3]
								1642654903.035, -- [4]
								1006, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [6]
							{
								true, -- [1]
								1, -- [2]
								149, -- [3]
								1642654903.316, -- [4]
								808, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [7]
							{
								true, -- [1]
								1, -- [2]
								152, -- [3]
								1642654903.325, -- [4]
								808, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [8]
							{
								true, -- [1]
								1, -- [2]
								123, -- [3]
								1642654904.077, -- [4]
								507, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [9]
							{
								true, -- [1]
								1, -- [2]
								152, -- [3]
								1642654904.077, -- [4]
								507, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [10]
							{
								true, -- [1]
								1, -- [2]
								136, -- [3]
								1642654904.355, -- [4]
								232, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [11]
							{
								true, -- [1]
								1, -- [2]
								124, -- [3]
								1642654905.116, -- [4]
								96, -- [5]
								"Starving Hound", -- [6]
								nil, -- [7]
								1, -- [8]
							}, -- [12]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"Gsea", -- [6]
							}, -- [13]
						}, -- [1]
						1642654905.116, -- [2]
						"Gsea", -- [3]
						"DRUID", -- [4]
						1418, -- [5]
						"0m 5s", -- [6]
						["dead_at"] = 5,
						["dead"] = true,
					}, -- [1]
				},
				["enemy"] = "Vigilant Watchman",
				["combat_counter"] = 3892,
				["totals"] = {
					1134.990231, -- [1]
					258, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["__call"] = {
				},
				["data_inicio"] = "00:01:40",
				["end_time"] = 1642654909,
				["combat_id"] = 614,
				["instance_type"] = "none",
				["frags"] = {
				},
				["data_fim"] = "00:01:51",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					1135, -- [1]
					258, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
				},
				["start_time"] = 1642654899,
				["contra"] = "Vigilant Watchman",
				["TimeData"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 613,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Troudcul"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "DRUID",
							["isTank"] = true,
							["total_without_pet"] = 0.006734,
							["on_hold"] = false,
							["end_time"] = 1642654794,
							["dps_started"] = false,
							["total"] = 0.006734,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 69,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 69,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 1792,
								},
								["Troudcul"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 69,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 69,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 1792,
								},
							},
							["friendlyfire_total"] = 2728,
							["nome"] = "Gsea",
							["serial"] = "0x0102000000015AB4",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["ABSORB"] = 15,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[33876] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 33876,
										["r_dmg"] = 0,
										["ABSORB"] = 4,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[33878] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 33878,
										["r_dmg"] = 0,
										["ABSORB"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6807,
										["r_dmg"] = 0,
										["ABSORB"] = 2,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 8921,
										["r_dmg"] = 0,
										["ABSORB"] = 3,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[779] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 779,
										["r_dmg"] = 0,
										["ABSORB"] = 3,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1822] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 1822,
										["r_dmg"] = 0,
										["ABSORB"] = 3,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
									{
										["total"] = 2728,
										["classe"] = "PRIEST",
										["nome"] = "Troudcul",
										["__index"] = {
										},
										["spell_tables"] = {
											["_ActorTable"] = {
												{
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 13,
													["total"] = 389,
													["c_max"] = 0,
													["id"] = 1,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												}, -- [1]
												[1079] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 8,
													["total"] = 862,
													["c_max"] = 0,
													["id"] = 1079,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[102795] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 2,
													["total"] = 138,
													["c_max"] = 0,
													["id"] = 102795,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[779] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 3,
													["total"] = 85,
													["c_max"] = 0,
													["id"] = 779,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[33878] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 4,
													["total"] = 361,
													["c_max"] = 0,
													["id"] = 33878,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[6807] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 3,
													["total"] = 130,
													["c_max"] = 0,
													["id"] = 6807,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[1822] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 8,
													["total"] = 318,
													["c_max"] = 0,
													["id"] = 1822,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[8921] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 13,
													["total"] = 156,
													["c_max"] = 0,
													["id"] = 8921,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
												[33876] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 4,
													["total"] = 289,
													["c_max"] = 0,
													["id"] = 33876,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
											},
											["tipo"] = 2,
										},
									}, -- [1]
								},
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1642654788,
							["damage_taken"] = 1792.006734,
							["start_time"] = 1642654754,
							["delay"] = 1642654753,
							["tipo"] = 1,
						}, -- [1]
					},
				}, -- [1]
				{
					["combatId"] = 613,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.002721,
							["last_hps"] = 0,
							["healing_from"] = {
								["Gsea"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 0,
										["total"] = 1400,
										["nome"] = "Gsea",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["isTank"] = true,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.002721,
							["healing_taken"] = 1400.002721,
							["totalover"] = 0.002721,
							["total_without_pet"] = 1400.002721,
							["iniciar_hps"] = false,
							["fight_component"] = true,
							["total"] = 1400.002721,
							["heal_enemy_amt"] = 0,
							["classe"] = "DRUID",
							["nome"] = "Gsea",
							["end_time"] = 1642654794,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[774] = {
										["c_curado"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 140,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 1400,
													["nome"] = "Gsea",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 140,
										["counter"] = 10,
										["overheal"] = 0,
										["total"] = 1400,
										["c_max"] = 0,
										["id"] = 774,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 10,
										["n_curado"] = 1400,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["custom"] = 0,
							["last_event"] = 1642654777,
							["on_hold"] = false,
							["start_time"] = 1642654769,
							["delay"] = 1642654777,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 613,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 613,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[6788] = {
										["activedamt"] = 0,
										["uptime"] = 53,
										["id"] = 6788,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[14914] = {
										["activedamt"] = -1,
										["uptime"] = 61,
										["id"] = 14914,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[589] = {
										["activedamt"] = -1,
										["uptime"] = 55,
										["id"] = 589,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 183,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[586] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 586,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[588] = {
										["activedamt"] = 1,
										["uptime"] = 69,
										["id"] = 588,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[21562] = {
										["activedamt"] = 1,
										["uptime"] = 69,
										["id"] = 21562,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[47753] = {
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 47753,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[17] = {
										["uptime"] = 31,
										["activedamt"] = 4,
										["id"] = 17,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "PRIEST",
							["fight_component"] = true,
							["debuff_uptime"] = 169,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654794,
							["nome"] = "Troudcul",
							["pets"] = {
							},
							["serial"] = "0x0102000000015A98",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[102795] = {
										["activedamt"] = 0,
										["uptime"] = 3,
										["id"] = 102795,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[8921] = {
										["activedamt"] = 0,
										["uptime"] = 42,
										["id"] = 8921,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[1079] = {
										["uptime"] = 32,
										["activedamt"] = 0,
										["id"] = 1079,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[1822] = {
										["activedamt"] = 0,
										["uptime"] = 42,
										["id"] = 1822,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 85,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[774] = {
										["activedamt"] = 2,
										["uptime"] = 24,
										["id"] = 774,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[768] = {
										["activedamt"] = 5,
										["uptime"] = 27,
										["id"] = 768,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[5487] = {
										["uptime"] = 34,
										["activedamt"] = 3,
										["id"] = 5487,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["fight_component"] = true,
							["debuff_uptime"] = 119,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654794,
							["nome"] = "Gsea",
							["pets"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 613,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Troudcul"] = true,
					["Gsea"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Unknown",
				["combat_counter"] = 3891,
				["totals"] = {
					-0.02130799999997811, -- [1]
					1399.997974, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["__call"] = {
				},
				["data_inicio"] = "23:58:46",
				["end_time"] = 1642654794,
				["combat_id"] = 613,
				["instance_type"] = "none",
				["frags"] = {
					["Mangy Wolf"] = 1,
				},
				["data_fim"] = "23:59:55",
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					2728, -- [1]
					1400, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 1642654725,
				["contra"] = "Troudcul",
				["pvp"] = false,
			}, -- [2]
			{
				{
					["combatId"] = 612,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Mutanus the Devourer"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 3841,
									}, -- [1]
								},
							},
							["pets"] = {
								"Searing Totem <Skullbeard>", -- [1]
							},
							["end_time"] = 1642654546,
							["on_hold"] = false,
							["classe"] = "SHAMAN",
							["boss_fight_component"] = true,
							["total_without_pet"] = 3451.006243,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 3841.006243,
							["friendlyfire_total"] = 0,
							["nome"] = "Skullbeard",
							["serial"] = "0x0102000000013EA9",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 122,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 557,
												}, -- [1]
											},
										},
										["n_dmg"] = 435,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 30,
										["total"] = 557,
										["c_max"] = 98,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 7,
										["a_dmg"] = 0,
										["c_min"] = 24,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 21,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[73899] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 74,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 269,
												}, -- [1]
											},
										},
										["n_dmg"] = 269,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 269,
										["c_max"] = 0,
										["id"] = 73899,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 173,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 668,
												}, -- [1]
											},
										},
										["n_dmg"] = 668,
										["n_min"] = 164,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 668,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[10444] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 136,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 888,
												}, -- [1]
											},
										},
										["n_dmg"] = 752,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 30,
										["total"] = 888,
										["c_max"] = 76,
										["id"] = 10444,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 60,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 28,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8050] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 278,
										["g_amt"] = 0,
										["n_max"] = 102,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 787,
												}, -- [1]
											},
										},
										["n_dmg"] = 509,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 787,
										["c_max"] = 204,
										["id"] = 8050,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 74,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[60103] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 134,
										["g_amt"] = 0,
										["n_max"] = 76,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 282,
												}, -- [1]
											},
										},
										["n_dmg"] = 148,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 282,
										["c_max"] = 134,
										["id"] = 60103,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 134,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 101.0791116578947,
							["custom"] = 0,
							["last_event"] = 1642654546,
							["damage_taken"] = 196.006243,
							["start_time"] = 1642654510,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Troudcul"] = true,
								["Mutanus the Devourer"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 2840,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["end_time"] = 1642654546,
							["on_hold"] = false,
							["classe"] = "DRUID",
							["boss_fight_component"] = true,
							["total_without_pet"] = 2840.006997,
							["colocacao"] = 2,
							["dps_started"] = false,
							["total"] = 2840.006997,
							["friendlyfire_total"] = 61,
							["nome"] = "Gsea",
							["serial"] = "0x0102000000015AB4",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 56,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 774,
												}, -- [1]
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [2]
											},
										},
										["n_dmg"] = 774,
										["n_min"] = 48,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 774,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["ABSORB"] = 3,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 15,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[33878] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 304,
										["g_amt"] = 0,
										["n_max"] = 157,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 1184,
												}, -- [1]
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [2]
											},
										},
										["n_dmg"] = 880,
										["n_min"] = 128,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 1184,
										["c_max"] = 304,
										["id"] = 33878,
										["r_dmg"] = 0,
										["ABSORB"] = 2,
										["a_dmg"] = 0,
										["c_min"] = 304,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 60,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 450,
												}, -- [1]
											},
										},
										["n_dmg"] = 450,
										["n_min"] = 52,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 450,
										["c_max"] = 0,
										["id"] = 6807,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[779] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 41,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 432,
												}, -- [1]
												{
													["nome"] = "Troudcul",
													["total"] = 0,
												}, -- [2]
											},
										},
										["n_dmg"] = 432,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 432,
										["c_max"] = 0,
										["id"] = 779,
										["r_dmg"] = 0,
										["ABSORB"] = 2,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
									{
										["total"] = 23,
										["classe"] = "WARRIOR",
										["nome"] = "Bladeknight",
										["__index"] = {
										},
										["spell_tables"] = {
											["_ActorTable"] = {
												[779] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 1,
													["total"] = 23,
													["c_max"] = 0,
													["id"] = 779,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
											},
											["tipo"] = 2,
										},
									}, -- [1]
									{
										["total"] = 38,
										["classe"] = "SHAMAN",
										["nome"] = "Tuly",
										["__index"] = {
										},
										["spell_tables"] = {
											["_ActorTable"] = {
												[779] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 1,
													["total"] = 38,
													["c_max"] = 0,
													["id"] = 779,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
											},
											["tipo"] = 2,
										},
									}, -- [2]
								},
							},
							["last_dps"] = 74.7370262368421,
							["custom"] = 0,
							["last_event"] = 1642654546,
							["damage_taken"] = 237.006997,
							["start_time"] = 1642654508,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 2588,
									}, -- [1]
								},
							},
							["colocacao"] = 3,
							["pets"] = {
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
									{
										["total"] = 38,
										["classe"] = "DRUID",
										["nome"] = "Gsea",
										["__index"] = {
										},
										["spell_tables"] = {
											["_ActorTable"] = {
												[589] = {
													["c_amt"] = 0,
													["b_amt"] = 0,
													["c_dmg"] = 0,
													["g_amt"] = 0,
													["n_max"] = 0,
													["targets"] = {
														["tipo"] = 6,
														["_ActorTable"] = {
														},
													},
													["n_dmg"] = 0,
													["n_min"] = 0,
													["g_dmg"] = 0,
													["counter"] = 2,
													["total"] = 38,
													["c_max"] = 0,
													["id"] = 589,
													["r_dmg"] = 0,
													["a_dmg"] = 0,
													["c_min"] = 0,
													["successful_casted"] = 0,
													["a_amt"] = 0,
													["n_amt"] = 0,
													["b_dmg"] = 0,
													["r_amt"] = 0,
												},
											},
											["tipo"] = 2,
										},
									}, -- [1]
								},
							},
							["boss_fight_component"] = true,
							["classe"] = "PRIEST",
							["end_time"] = 1642654725,
							["total_without_pet"] = 2588.007317,
							["dps_started"] = false,
							["total"] = 2588.007317,
							["friendlyfire_total"] = 38,
							["serial"] = "0x0102000000015A98",
							["nome"] = "Troudcul",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[47666] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 102,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 899,
												}, -- [1]
											},
										},
										["n_dmg"] = 899,
										["n_min"] = 97,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 899,
										["c_max"] = 0,
										["id"] = 47666,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[589] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 42,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 504,
												}, -- [1]
											},
										},
										["n_dmg"] = 504,
										["n_min"] = 42,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 504,
										["c_max"] = 0,
										["id"] = 589,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[14914] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 16,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 367,
												}, -- [1]
											},
										},
										["n_dmg"] = 351,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 367,
										["c_max"] = 8,
										["id"] = 14914,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 8,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 16,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[585] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 276,
										["g_amt"] = 0,
										["n_max"] = 137,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 818,
												}, -- [1]
											},
										},
										["n_dmg"] = 542,
										["n_min"] = 133,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 818,
										["c_max"] = 276,
										["id"] = 585,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 276,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["last_dps"] = 68.10545571052631,
							["custom"] = 0,
							["last_event"] = 1642654724,
							["damage_taken"] = 0.007317,
							["start_time"] = 1642654513,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Gsea"] = true,
								["Mutanus the Devourer"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 1876,
									}, -- [1]
								},
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["end_time"] = 1642654546,
							["classe"] = "WARRIOR",
							["colocacao"] = 4,
							["total_without_pet"] = 1876.004239,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 4,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 4,
									["HITS"] = 2,
									["FULL_HIT_AMT"] = 193,
								},
								["Mutanus the Devourer"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 4,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 4,
									["HITS"] = 2,
									["FULL_HIT_AMT"] = 193,
								},
							},
							["dps_started"] = false,
							["total"] = 1876.004239,
							["serial"] = "0x01020000000119C5",
							["isTank"] = true,
							["nome"] = "Bladeknight",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 4,
										["n_max"] = 37,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 457,
												}, -- [1]
											},
										},
										["n_dmg"] = 319,
										["n_min"] = 33,
										["g_dmg"] = 138,
										["counter"] = 13,
										["total"] = 457,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[5308] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 5308,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[23922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 434,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 1263,
												}, -- [1]
											},
										},
										["n_dmg"] = 1263,
										["n_min"] = 413,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1263,
										["c_max"] = 0,
										["id"] = 23922,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 81,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 156,
												}, -- [1]
											},
										},
										["n_dmg"] = 156,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 156,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["last_dps"] = 49.36853260526316,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 216.004239,
							["start_time"] = 1642654512,
							["delay"] = 0,
							["last_event"] = 1642654545,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Gsea"] = true,
								["Mutanus the Devourer"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 1047,
									}, -- [1]
								},
							},
							["pets"] = {
								"Searing Totem <Tuly>", -- [1]
							},
							["end_time"] = 1642654546,
							["on_hold"] = false,
							["classe"] = "SHAMAN",
							["boss_fight_component"] = true,
							["total_without_pet"] = 1037.002838,
							["colocacao"] = 5,
							["dps_started"] = false,
							["total"] = 1047.002838,
							["friendlyfire_total"] = 0,
							["nome"] = "Tuly",
							["serial"] = "0x01020000000158AD",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 98,
												}, -- [1]
											},
										},
										["n_dmg"] = 98,
										["n_min"] = 28,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[73899] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 56,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 111,
												}, -- [1]
											},
										},
										["n_dmg"] = 111,
										["n_min"] = 55,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 111,
										["c_max"] = 0,
										["id"] = 73899,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 294,
												}, -- [1]
											},
										},
										["n_dmg"] = 294,
										["n_min"] = 95,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 294,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[107079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 107079,
										["r_dmg"] = 0,
										["IMMUNE"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[88767] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 64,
												}, -- [1]
											},
										},
										["n_dmg"] = 64,
										["n_min"] = 32,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 64,
										["c_max"] = 0,
										["id"] = 88767,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[403] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 120,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 470,
												}, -- [1]
											},
										},
										["n_dmg"] = 470,
										["n_min"] = 114,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 470,
										["c_max"] = 0,
										["id"] = 403,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 27.55270626315789,
							["custom"] = 0,
							["last_event"] = 1642654544,
							["damage_taken"] = 134.002838,
							["start_time"] = 1642654514,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["damage_from"] = {
								["Tuly"] = true,
								["Troudcul"] = true,
								["Gsea"] = true,
								["Searing Totem <Skullbeard>"] = true,
								["Bladeknight"] = true,
								["Skullbeard"] = true,
								["Searing Totem"] = true,
								["Searing Totem <Tuly>"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Bladeknight",
										["total"] = 193,
									}, -- [1]
									{
										["nome"] = "Skullbeard",
										["total"] = 196,
									}, -- [2]
									{
										["nome"] = "Gsea",
										["total"] = 199,
									}, -- [3]
									{
										["nome"] = "Tuly",
										["total"] = 96,
									}, -- [4]
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 684.0072789999999,
							["serial"] = "0xF5300E4600000040",
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 684.0072789999999,
							["boss_fight_component"] = true,
							["end_time"] = 1642654546,
							["nome"] = "Mutanus the Devourer",
							["friendlyfire_total"] = 0,
							["monster"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Gsea",
													["total"] = 128,
												}, -- [1]
												{
													["nome"] = "Bladeknight",
													["total"] = 48,
												}, -- [2]
											},
										},
										["n_dmg"] = 176,
										["n_min"] = 22,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 176,
										["c_max"] = 0,
										["MISS"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["ABSORB"] = 3,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[7967] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 7967,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8150] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Gsea",
													["total"] = 71,
												}, -- [1]
												{
													["nome"] = "Skullbeard",
													["total"] = 196,
												}, -- [2]
												{
													["nome"] = "Bladeknight",
													["total"] = 145,
												}, -- [3]
												{
													["nome"] = "Tuly",
													["total"] = 96,
												}, -- [4]
											},
										},
										["n_dmg"] = 508,
										["n_min"] = 71,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 508,
										["c_max"] = 0,
										["id"] = 8150,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1642654546,
							["damage_taken"] = 12192.007279,
							["start_time"] = 1642654531,
							["delay"] = 1642654519,
							["tipo"] = 1,
						}, -- [6]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 390,
									}, -- [1]
								},
							},
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["end_time"] = 1642654546,
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB00000041",
							["total_without_pet"] = 390.00342,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 390.00342,
							["on_hold"] = false,
							["ownerName"] = "Skullbeard",
							["nome"] = "Searing Totem <Skullbeard>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 120,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 390,
												}, -- [1]
											},
										},
										["n_dmg"] = 270,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 22,
										["total"] = 390,
										["c_max"] = 30,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 30,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 18,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.00342,
							["start_time"] = 1642654513,
							["delay"] = 0,
							["last_event"] = 1642654546,
						}, -- [7]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Mutanus the Devourer",
										["total"] = 10,
									}, -- [1]
								},
							},
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["end_time"] = 1642654546,
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB00000039",
							["total_without_pet"] = 10.005683,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 10.005683,
							["on_hold"] = false,
							["ownerName"] = "Tuly",
							["nome"] = "Searing Totem <Tuly>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Mutanus the Devourer",
													["total"] = 10,
												}, -- [1]
											},
										},
										["n_dmg"] = 10,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005683,
							["start_time"] = 1642654543,
							["delay"] = 1642654517,
							["last_event"] = 1642654517,
						}, -- [8]
					},
				}, -- [1]
				{
					["combatId"] = 612,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 797,
										["total"] = 50,
										["nome"] = "Gsea",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["totalabsorb"] = 50.003585,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["serial"] = "0x0102000000015A98",
							["classe"] = "PRIEST",
							["totalover"] = 797.003585,
							["total_without_pet"] = 50.003585,
							["boss_fight_component"] = true,
							["end_time"] = 1642654546,
							["total"] = 50.003585,
							["totalover_without_pet"] = 0.003585,
							["healing_taken"] = 0.003585,
							["nome"] = "Troudcul",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[17] = {
										["c_curado"] = 0,
										["totalabsorb"] = 50,
										["n_max"] = 50,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 797,
													["total"] = 50,
													["nome"] = "Gsea",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 50,
										["counter"] = 1,
										["overheal"] = 797,
										["total"] = 50,
										["c_max"] = 0,
										["id"] = 17,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 50,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654545,
							["delay"] = 1642654535,
							["last_event"] = 1642654535,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["last_hps"] = 0,
							["healing_from"] = {
								["Troudcul"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["totalabsorb"] = 0.008031999999999999,
							["classe"] = "DRUID",
							["totalover"] = 0.008031999999999999,
							["total_without_pet"] = 0.008031999999999999,
							["last_event"] = 0,
							["boss_fight_component"] = true,
							["total"] = 0.008031999999999999,
							["totalover_without_pet"] = 0.008031999999999999,
							["end_time"] = 1642654546,
							["nome"] = "Gsea",
							["healing_taken"] = 50.008032,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654546,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [2]
					},
				}, -- [2]
				{
					["combatId"] = 612,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 612,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[115798] = {
										["activedamt"] = 0,
										["uptime"] = 12,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 38,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "SHAMAN",
							["debuff_uptime"] = 12,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654546,
							["nome"] = "Tuly",
							["pets"] = {
							},
							["serial"] = "0x01020000000158AD",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[8050] = {
										["activedamt"] = 0,
										["uptime"] = 36,
										["id"] = 8050,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[115798] = {
										["uptime"] = 20,
										["activedamt"] = 0,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 87,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[16278] = {
										["uptime"] = 11,
										["activedamt"] = 3,
										["id"] = 16278,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[8091] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 8091,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "SHAMAN",
							["debuff_uptime"] = 56,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654546,
							["nome"] = "Skullbeard",
							["pets"] = {
							},
							["serial"] = "0x0102000000013EA9",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[355] = {
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = 355,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[113746] = {
										["activedamt"] = 0,
										["uptime"] = 24,
										["id"] = 113746,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 41,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[132365] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 132365,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[32216] = {
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 32216,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "WARRIOR",
							["debuff_uptime"] = 30,
							["boss_fight_component"] = true,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["nome"] = "Bladeknight",
							["tipo"] = 4,
							["pets"] = {
							},
							["isTank"] = true,
							["serial"] = "0x01020000000119C5",
							["last_event"] = 1642654546,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[589] = {
										["activedamt"] = 0,
										["uptime"] = 30,
										["id"] = 589,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[14914] = {
										["uptime"] = 15,
										["activedamt"] = 0,
										["id"] = 14914,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[6788] = {
										["activedamt"] = -1,
										["uptime"] = 36,
										["id"] = 6788,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 38,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[21562] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 21562,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "PRIEST",
							["debuff_uptime"] = 81,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654546,
							["nome"] = "Troudcul",
							["pets"] = {
							},
							["serial"] = "0x0102000000015A98",
							["tipo"] = 4,
						}, -- [4]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[6795] = {
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = 6795,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 76,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[5487] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 5487,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[132365] = {
										["activedamt"] = 1,
										["uptime"] = 38,
										["id"] = 132365,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["debuff_uptime"] = 6,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654546,
							["nome"] = "Gsea",
							["pets"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 27,
							["spellschool"] = 8,
							["nome"] = "Thundercrack",
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 11,
								["_ActorTable"] = {
									{
										["total"] = 0,
										["uptime"] = 6,
										["activedamt"] = 0,
										["nome"] = "Skullbeard",
										["actived"] = false,
									}, -- [1]
									{
										["total"] = 0,
										["uptime"] = 6,
										["activedamt"] = 0,
										["nome"] = "Bladeknight",
										["actived"] = false,
									}, -- [2]
									{
										["total"] = 0,
										["uptime"] = 6,
										["activedamt"] = 0,
										["nome"] = "Troudcul",
										["actived"] = false,
									}, -- [3]
									{
										["total"] = 0,
										["uptime"] = 6,
										["activedamt"] = 0,
										["nome"] = "Tuly",
										["actived"] = false,
									}, -- [4]
									{
										["total"] = 0,
										["uptime"] = 3,
										["activedamt"] = 0,
										["nome"] = "Gsea",
										["actived"] = false,
									}, -- [5]
								},
							},
							["tipo"] = 4,
							["damage_twin"] = "Mutanus the Devourer",
							["damage_spellid"] = 8150,
							["serial"] = "0xF5300E4600000040",
							["last_event"] = 1642654540,
						}, -- [6]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 2,
							["spellschool"] = 32,
							["nome"] = "Naralex's Nightmare",
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["tipo"] = 11,
								["_ActorTable"] = {
									{
										["total"] = 0,
										["uptime"] = 1,
										["activedamt"] = 0,
										["nome"] = "Bladeknight",
										["actived"] = false,
									}, -- [1]
									{
										["total"] = 0,
										["uptime"] = 1,
										["activedamt"] = 0,
										["nome"] = "Tuly",
										["actived"] = false,
									}, -- [2]
								},
							},
							["tipo"] = 4,
							["damage_twin"] = "Mutanus the Devourer",
							["damage_spellid"] = 7967,
							["serial"] = "0xF5300E4600000040",
							["last_event"] = 1642654542,
						}, -- [7]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 612,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Tuly"] = true,
					["Bladeknight"] = true,
					["Skullbeard"] = true,
					["Gsea"] = true,
					["Troudcul"] = true,
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["combat_counter"] = 3890,
				["totals"] = {
					12875.990003, -- [1]
					50, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Gsea"] = {
						{
							true, -- [1]
							589, -- [2]
							19, -- [3]
							1642654723.069, -- [4]
							1285, -- [5]
							"Troudcul", -- [6]
							nil, -- [7]
							32, -- [8]
							true, -- [9]
						}, -- [1]
						{
							true, -- [1]
							589, -- [2]
							19, -- [3]
							1642654726.031, -- [4]
							1266, -- [5]
							"Troudcul", -- [6]
							nil, -- [7]
							32, -- [8]
							true, -- [9]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = false,
				["__call"] = {
				},
				["data_inicio"] = "23:55:09",
				["end_time"] = 1642654546,
				["combat_id"] = 612,
				["instance_type"] = "party",
				["is_boss"] = {
					["mapid"] = 43,
					["diff_string"] = "Normal",
					["name"] = "Mutanus the Devourer",
					["zone"] = "Wailing Caverns",
					["encounter"] = "Mutanus the Devourer",
					["diff"] = 1,
					["ej_instance_id"] = 240,
					["killed"] = true,
				},
				["frags"] = {
				},
				["data_fim"] = "23:55:47",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					11891, -- [1]
					50, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 1642654508,
				["contra"] = "Mutanus the Devourer",
				["TimeData"] = {
				},
			}, -- [3]
			{
				{
					["combatId"] = 605,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Lord Serpentis"] = true,
								["Verdan the Everliving"] = true,
								["Deviate Dreadfang"] = true,
								["Druid of the Fang"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 2612,
									}, -- [1]
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 580,
									}, -- [2]
									{
										["nome"] = "Verdan the Everliving",
										["total"] = 745,
									}, -- [3]
									{
										["nome"] = "Druid of the Fang",
										["total"] = 506,
									}, -- [4]
									{
										["nome"] = "Snake",
										["total"] = 53,
									}, -- [5]
								},
							},
							["pets"] = {
							},
							["classe"] = "DRUID",
							["serial"] = "0x0102000000015AB4",
							["total_without_pet"] = 4496.005596999999,
							["on_hold"] = false,
							["end_time"] = 1642654161,
							["dps_started"] = false,
							["total"] = 4496.005596999999,
							["colocacao"] = 1,
							["nome"] = "Gsea",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 56,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 565,
												}, -- [1]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 159,
												}, -- [2]
											},
										},
										["n_dmg"] = 724,
										["n_min"] = 48,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 724,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 14,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[779] = {
										["c_amt"] = 7,
										["b_amt"] = 1,
										["c_dmg"] = 592,
										["g_amt"] = 0,
										["n_max"] = 53,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 580,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 538,
												}, -- [2]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 533,
												}, -- [3]
												{
													["nome"] = "Druid of the Fang",
													["total"] = 506,
												}, -- [4]
												{
													["nome"] = "Snake",
													["total"] = 53,
												}, -- [5]
											},
										},
										["n_dmg"] = 1618,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 46,
										["total"] = 2210,
										["c_max"] = 88,
										["id"] = 779,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 79,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 39,
										["b_dmg"] = 29,
										["r_amt"] = 0,
									},
									[6807] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 229,
										["g_amt"] = 0,
										["n_max"] = 61,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 53,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 469,
												}, -- [2]
											},
										},
										["n_dmg"] = 293,
										["n_min"] = 53,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 522,
										["c_max"] = 115,
										["id"] = 6807,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 114,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[33878] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 311,
										["g_amt"] = 0,
										["n_max"] = 157,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 1040,
												}, -- [1]
											},
										},
										["n_dmg"] = 729,
										["n_min"] = 132,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1040,
										["c_max"] = 311,
										["id"] = 33878,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 311,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 121.5136647837838,
							["custom"] = 0,
							["last_event"] = 1642654159,
							["damage_taken"] = 845.005597,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Verdan the Everliving"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 3453,
									}, -- [1]
									{
										["nome"] = "Druid of the Fang",
										["total"] = 350,
									}, -- [2]
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 280,
									}, -- [3]
									{
										["nome"] = "Verdan the Everliving",
										["total"] = 280,
									}, -- [4]
								},
							},
							["pets"] = {
								"Searing Totem <Skullbeard>", -- [1]
							},
							["classe"] = "SHAMAN",
							["serial"] = "0x0102000000013EA9",
							["total_without_pet"] = 4013.002451,
							["on_hold"] = false,
							["end_time"] = 1642654161,
							["dps_started"] = false,
							["total"] = 4363.002451,
							["colocacao"] = 2,
							["nome"] = "Skullbeard",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 112,
										["g_amt"] = 0,
										["n_max"] = 52,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 679,
												}, -- [1]
											},
										},
										["n_dmg"] = 567,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 679,
										["c_max"] = 90,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 5,
										["a_dmg"] = 0,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 25,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[60103] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 134,
										["g_amt"] = 0,
										["n_max"] = 81,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 277,
												}, -- [1]
											},
										},
										["n_dmg"] = 143,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 277,
										["c_max"] = 134,
										["id"] = 60103,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 134,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 161,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 480,
												}, -- [1]
											},
										},
										["n_dmg"] = 480,
										["n_min"] = 158,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 480,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[10444] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 120,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 911,
												}, -- [1]
											},
										},
										["n_dmg"] = 791,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 911,
										["c_max"] = 64,
										["id"] = 10444,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 56,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 30,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8050] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 99,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 350,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 618,
												}, -- [2]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 280,
												}, -- [3]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 280,
												}, -- [4]
											},
										},
										["n_dmg"] = 1528,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 40,
										["total"] = 1528,
										["c_max"] = 0,
										["id"] = 8050,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 40,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[73899] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 71,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 138,
												}, -- [1]
											},
										},
										["n_dmg"] = 138,
										["n_min"] = 67,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 138,
										["c_max"] = 0,
										["id"] = 73899,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 117.9189851621622,
							["custom"] = 0,
							["last_event"] = 1642654160,
							["damage_taken"] = 196.002451,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 830,
									}, -- [1]
									{
										["nome"] = "Druid of the Fang",
										["total"] = 351,
									}, -- [2]
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 1122,
									}, -- [3]
									{
										["nome"] = "Verdan the Everliving",
										["total"] = 1028,
									}, -- [4]
								},
							},
							["pets"] = {
							},
							["classe"] = "PRIEST",
							["serial"] = "0x0102000000015A98",
							["total_without_pet"] = 3331.00681,
							["on_hold"] = false,
							["end_time"] = 1642654161,
							["dps_started"] = false,
							["total"] = 3331.00681,
							["colocacao"] = 3,
							["nome"] = "Troudcul",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[47666] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 95,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 186,
												}, -- [1]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 283,
												}, -- [2]
											},
										},
										["n_dmg"] = 469,
										["n_min"] = 92,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 469,
										["c_max"] = 0,
										["id"] = 47666,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[589] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 390,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 351,
												}, -- [1]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 312,
												}, -- [2]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 429,
												}, -- [3]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 507,
												}, -- [4]
											},
										},
										["n_dmg"] = 1209,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 36,
										["total"] = 1599,
										["c_max"] = 78,
										["id"] = 589,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 78,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 31,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[14914] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 97,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 24,
												}, -- [1]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 125,
												}, -- [2]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 117,
												}, -- [3]
											},
										},
										["n_dmg"] = 266,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 21,
										["total"] = 266,
										["c_max"] = 0,
										["id"] = 14914,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 21,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[585] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 252,
										["g_amt"] = 0,
										["n_max"] = 127,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 377,
												}, -- [1]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 499,
												}, -- [2]
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 121,
												}, -- [3]
											},
										},
										["n_dmg"] = 745,
										["n_min"] = 121,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 997,
										["c_max"] = 252,
										["id"] = 585,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 252,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 90.02721108108108,
							["custom"] = 0,
							["last_event"] = 1642654160,
							["damage_taken"] = 0.00681,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Druid of the Fang",
										["total"] = 50,
									}, -- [1]
									{
										["nome"] = "Lord Serpentis",
										["total"] = 1445,
									}, -- [2]
								},
							},
							["pets"] = {
								"Searing Totem <Tuly>", -- [1]
							},
							["classe"] = "SHAMAN",
							["serial"] = "0x01020000000158AD",
							["total_without_pet"] = 1368.006608,
							["on_hold"] = false,
							["end_time"] = 1642654161,
							["dps_started"] = false,
							["total"] = 1495.006608,
							["colocacao"] = 4,
							["nome"] = "Tuly",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[8050] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 50,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 148,
												}, -- [1]
											},
										},
										["n_dmg"] = 148,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 148,
										["c_max"] = 0,
										["id"] = 8050,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 97,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 194,
												}, -- [1]
											},
										},
										["n_dmg"] = 194,
										["n_min"] = 97,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 194,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[403] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 118,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 1026,
												}, -- [1]
											},
										},
										["n_dmg"] = 1026,
										["n_min"] = 108,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 1026,
										["c_max"] = 0,
										["id"] = 403,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 40.40558400000001,
							["custom"] = 0,
							["last_event"] = 1642654161,
							["damage_taken"] = 0.006608,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Verdan the Everliving",
										["total"] = 36,
									}, -- [1]
								},
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["colocacao"] = 5,
							["classe"] = "WARRIOR",
							["total_without_pet"] = 36.001735,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1642654161,
							["serial"] = "0x01020000000119C5",
							["isTank"] = true,
							["nome"] = "Bladeknight",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Verdan the Everliving",
													["total"] = 36,
												}, -- [1]
											},
										},
										["n_dmg"] = 36,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["total"] = 36.001735,
							["last_dps"] = 0.9730198648648648,
							["custom"] = 0,
							["last_event"] = 1642654161,
							["damage_taken"] = 0.001735,
							["start_time"] = 1642654161,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [5]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 350,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["end_time"] = 1642654161,
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB0000002A",
							["total_without_pet"] = 350.00681,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 350.00681,
							["on_hold"] = false,
							["ownerName"] = "Skullbeard",
							["nome"] = "Searing Totem <Skullbeard>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 28,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 350,
												}, -- [1]
											},
										},
										["n_dmg"] = 322,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 24,
										["total"] = 350,
										["c_max"] = 28,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 28,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 23,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.00681,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["last_event"] = 1642654160,
						}, -- [6]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Druid of the Fang",
										["total"] = 50,
									}, -- [1]
									{
										["nome"] = "Lord Serpentis",
										["total"] = 77,
									}, -- [2]
								},
							},
							["pets"] = {
							},
							["end_time"] = 1642654161,
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB0000002B",
							["total_without_pet"] = 127.003207,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 127.003207,
							["on_hold"] = false,
							["ownerName"] = "Tuly",
							["nome"] = "Searing Totem <Tuly>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 50,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 77,
												}, -- [2]
											},
										},
										["n_dmg"] = 115,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 24,
										["total"] = 127,
										["c_max"] = 12,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 23,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.003207,
							["start_time"] = 1642654124,
							["delay"] = 0,
							["last_event"] = 1642654161,
						}, -- [7]
					},
				}, -- [1]
				{
					["combatId"] = 605,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 395,
										["total"] = 2662,
										["nome"] = "Gsea",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PRIEST",
							["totalover"] = 395.00395,
							["total_without_pet"] = 2662.00395,
							["totalabsorb"] = 2334.00395,
							["last_event"] = 1642654153,
							["total"] = 2662.00395,
							["end_time"] = 1642654161,
							["totalover_without_pet"] = 0.00395,
							["nome"] = "Troudcul",
							["healing_taken"] = 0.00395,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[17] = {
										["c_curado"] = 0,
										["totalabsorb"] = 2334,
										["n_max"] = 778,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 2334,
													["nome"] = "Gsea",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 778,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 2334,
										["c_max"] = 0,
										["id"] = 17,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 2334,
										["absorbed"] = 0,
									},
									[2061] = {
										["c_curado"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 328,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 395,
													["total"] = 328,
													["nome"] = "Gsea",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 328,
										["counter"] = 1,
										["overheal"] = 395,
										["total"] = 328,
										["c_max"] = 0,
										["id"] = 2061,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 328,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["serial"] = "0x0102000000015A98",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654141,
							["delay"] = 1642654126,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.005354,
							["last_hps"] = 0,
							["healing_from"] = {
								["Troudcul"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.005354,
							["total_without_pet"] = 0.005354,
							["last_event"] = 0,
							["total"] = 0.005354,
							["totalover_without_pet"] = 0.005354,
							["end_time"] = 1642654161,
							["nome"] = "Gsea",
							["healing_taken"] = 2662.005354,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654161,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [2]
					},
				}, -- [2]
				{
					["combatId"] = 605,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 605,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 51,
							["classe"] = "SHAMAN",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[8050] = {
										["activedamt"] = 0,
										["uptime"] = 24,
										["id"] = 8050,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[51490] = {
										["activedamt"] = -1,
										["id"] = 51490,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1642654125,
										["uptime"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 0,
										["uptime"] = 26,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Tuly",
							["buff_uptime"] = 37,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x01020000000158AD",
							["last_event"] = 1642654161,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[8050] = {
										["activedamt"] = 3,
										["uptime"] = 37,
										["id"] = 8050,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 0,
										["uptime"] = 25,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 53,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[16278] = {
										["activedamt"] = 2,
										["uptime"] = 16,
										["id"] = 16278,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "SHAMAN",
							["interrompeu_oque"] = {
								[12167] = 2,
							},
							["debuff_uptime"] = 62,
							["interrupt_spell_tables"] = {
								["_ActorTable"] = {
									[57994] = {
										["id"] = 57994,
										["interrompeu_oque"] = {
											[12167] = 2,
										},
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 2,
												}, -- [1]
											},
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["interrupt_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 2,
									}, -- [1]
								},
							},
							["grupo"] = true,
							["interrupt"] = 2.002084,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654161,
							["nome"] = "Skullbeard",
							["pets"] = {
							},
							["serial"] = "0x0102000000013EA9",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 80,
							["classe"] = "PRIEST",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[589] = {
										["activedamt"] = 2,
										["uptime"] = 27,
										["id"] = 589,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[14914] = {
										["uptime"] = 19,
										["activedamt"] = 1,
										["id"] = 14914,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[6788] = {
										["activedamt"] = -1,
										["uptime"] = 34,
										["id"] = 6788,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Troudcul",
							["buff_uptime"] = 37,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[21562] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 21562,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x0102000000015A98",
							["last_event"] = 1642654161,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 2,
							["classe"] = "DRUID",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[6795] = {
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 6795,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Gsea",
							["buff_uptime"] = 74,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[5487] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 5487,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[132365] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 132365,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["last_event"] = 1642654161,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime"] = 2,
							["nome"] = "Bladeknight",
							["grupo"] = true,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[105771] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 105771,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[137637] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 137637,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "WARRIOR",
							["last_event"] = 1642654160,
							["isTank"] = true,
							["serial"] = "0x01020000000119C5",
							["tipo"] = 4,
						}, -- [5]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 605,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Tuly"] = true,
					["Bladeknight"] = true,
					["Skullbeard"] = true,
					["Gsea"] = true,
					["Troudcul"] = true,
				},
				["last_events_tables"] = {
				},
				["combat_counter"] = 3883,
				["totals"] = {
					13720.980983, -- [1]
					2662, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 2,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["__call"] = {
				},
				["data_inicio"] = "23:48:44",
				["end_time"] = 1642654161,
				["combat_id"] = 605,
				["instance_type"] = "party",
				["is_boss"] = {
					["mapid"] = 43,
					["diff_string"] = "Normal",
					["name"] = "Verdan the Everliving",
					["zone"] = "Wailing Caverns",
					["encounter"] = "Verdan the Everliving",
					["diff"] = 1,
					["ej_instance_id"] = 240,
					["killed"] = true,
				},
				["frags"] = {
					["Snake"] = 1,
				},
				["data_fim"] = "23:49:21",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					13244, -- [1]
					2662, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 2,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 1642654124,
				["contra"] = "Lord Serpentis",
				["TimeData"] = {
				},
			}, -- [4]
			{
				{
					["combatId"] = 604,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 1365,
									}, -- [1]
									{
										["nome"] = "Druid of the Fang",
										["total"] = 140,
									}, -- [2]
								},
							},
							["pets"] = {
								"Searing Totem <Skullbeard>", -- [1]
							},
							["classe"] = "SHAMAN",
							["serial"] = "0x0102000000013EA9",
							["total_without_pet"] = 1421.0068,
							["on_hold"] = false,
							["end_time"] = 1642654124,
							["dps_started"] = false,
							["total"] = 1505.0068,
							["colocacao"] = 1,
							["nome"] = "Skullbeard",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 53,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 249,
												}, -- [1]
											},
										},
										["n_dmg"] = 249,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 249,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 2,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[60103] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 67,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 129,
												}, -- [1]
											},
										},
										["n_dmg"] = 129,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 129,
										["c_max"] = 0,
										["id"] = 60103,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 167,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 334,
												}, -- [1]
											},
										},
										["n_dmg"] = 334,
										["n_min"] = 167,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 334,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[10444] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 291,
												}, -- [1]
											},
										},
										["n_dmg"] = 291,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 291,
										["c_max"] = 0,
										["id"] = 10444,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8050] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 35,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 210,
												}, -- [1]
												{
													["nome"] = "Druid of the Fang",
													["total"] = 140,
												}, -- [2]
											},
										},
										["n_dmg"] = 350,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 350,
										["c_max"] = 0,
										["id"] = 8050,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[73899] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 68,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 68,
												}, -- [1]
											},
										},
										["n_dmg"] = 68,
										["n_min"] = 68,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 68,
										["c_max"] = 0,
										["id"] = 73899,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 86.47098823529413,
							["custom"] = 0,
							["last_event"] = 1642654123,
							["damage_taken"] = 0.0068,
							["start_time"] = 1642654108,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Druid of the Fang"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Druid of the Fang",
										["total"] = 320,
									}, -- [1]
									{
										["nome"] = "Lord Serpentis",
										["total"] = 451,
									}, -- [2]
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 214,
									}, -- [3]
								},
							},
							["pets"] = {
							},
							["classe"] = "DRUID",
							["serial"] = "0x0102000000015AB4",
							["total_without_pet"] = 985.001321,
							["on_hold"] = false,
							["end_time"] = 1642654123,
							["dps_started"] = false,
							["total"] = 985.001321,
							["colocacao"] = 2,
							["nome"] = "Gsea",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 51,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 47,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 194,
												}, -- [2]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 48,
												}, -- [3]
											},
										},
										["n_dmg"] = 289,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 289,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[779] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 149,
												}, -- [1]
												{
													["nome"] = "Druid of the Fang",
													["total"] = 150,
												}, -- [2]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 77,
												}, -- [3]
											},
										},
										["n_dmg"] = 376,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 376,
										["c_max"] = 0,
										["id"] = 779,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 108,
												}, -- [1]
											},
										},
										["n_dmg"] = 108,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 108,
										["c_max"] = 0,
										["id"] = 6807,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[33878] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 123,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 123,
												}, -- [1]
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 89,
												}, -- [2]
											},
										},
										["n_dmg"] = 212,
										["n_min"] = 89,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 212,
										["c_max"] = 0,
										["id"] = 33878,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 89,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 57.94125417647059,
							["custom"] = 0,
							["last_event"] = 1642654121,
							["damage_taken"] = 68.00132099999999,
							["start_time"] = 1642654106,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 156,
									}, -- [1]
									{
										["nome"] = "Druid of the Fang",
										["total"] = 117,
									}, -- [2]
									{
										["nome"] = "Lord Serpentis",
										["total"] = 491,
									}, -- [3]
								},
							},
							["pets"] = {
							},
							["classe"] = "PRIEST",
							["serial"] = "0x0102000000015A98",
							["total_without_pet"] = 764.0014209999999,
							["on_hold"] = false,
							["end_time"] = 1642654124,
							["dps_started"] = false,
							["total"] = 764.0014209999999,
							["colocacao"] = 3,
							["nome"] = "Troudcul",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[47666] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 94,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 280,
												}, -- [1]
											},
										},
										["n_dmg"] = 280,
										["n_min"] = 93,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 280,
										["c_max"] = 0,
										["id"] = 47666,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[589] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 156,
												}, -- [1]
												{
													["nome"] = "Druid of the Fang",
													["total"] = 117,
												}, -- [2]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 117,
												}, -- [3]
											},
										},
										["n_dmg"] = 390,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 390,
										["c_max"] = 0,
										["id"] = 589,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[14914] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 90,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 94,
												}, -- [1]
											},
										},
										["n_dmg"] = 94,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 94,
										["c_max"] = 0,
										["id"] = 14914,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 40.11773064705882,
							["custom"] = 0,
							["last_event"] = 1642654123,
							["damage_taken"] = 0.001421,
							["start_time"] = 1642654114,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Druid of the Fang"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Druid of the Fang",
										["total"] = 322,
									}, -- [1]
									{
										["nome"] = "Deviate Dreadfang",
										["total"] = 80,
									}, -- [2]
									{
										["nome"] = "Lord Serpentis",
										["total"] = 80,
									}, -- [3]
								},
							},
							["pets"] = {
								"Searing Totem <Tuly>", -- [1]
							},
							["classe"] = "SHAMAN",
							["serial"] = "0x01020000000158AD",
							["total_without_pet"] = 450.001989,
							["on_hold"] = false,
							["end_time"] = 1642654123,
							["dps_started"] = false,
							["total"] = 482.001989,
							["colocacao"] = 4,
							["nome"] = "Tuly",
							["friendlyfire_total"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[8042] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 96,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 96,
												}, -- [1]
											},
										},
										["n_dmg"] = 96,
										["n_min"] = 96,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 96,
										["c_max"] = 0,
										["id"] = 8042,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[403] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 114,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 114,
												}, -- [1]
											},
										},
										["n_dmg"] = 114,
										["n_min"] = 114,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 114,
										["c_max"] = 0,
										["id"] = 403,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[51490] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Deviate Dreadfang",
													["total"] = 80,
												}, -- [1]
												{
													["nome"] = "Lord Serpentis",
													["total"] = 80,
												}, -- [2]
												{
													["nome"] = "Druid of the Fang",
													["total"] = 80,
												}, -- [3]
											},
										},
										["n_dmg"] = 240,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 240,
										["c_max"] = 0,
										["id"] = 51490,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 28.35305817647059,
							["custom"] = 0,
							["last_event"] = 1642654123,
							["damage_taken"] = 52.001989,
							["start_time"] = 1642654108,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 84,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB0000002A",
							["total_without_pet"] = 84.002865,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 84.002865,
							["on_hold"] = false,
							["ownerName"] = "Skullbeard",
							["nome"] = "Searing Totem <Skullbeard>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 84,
												}, -- [1]
											},
										},
										["n_dmg"] = 84,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 84,
										["c_max"] = 0,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1642654123,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002865,
							["start_time"] = 1642654114,
							["delay"] = 0,
							["last_event"] = 1642654122,
						}, -- [5]
						{
							["flag_original"] = 4370,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Druid of the Fang",
										["total"] = 32,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["serial"] = "0xF13009DB0000002B",
							["total_without_pet"] = 32.003332,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 32.003332,
							["on_hold"] = false,
							["ownerName"] = "Tuly",
							["nome"] = "Searing Totem <Tuly>",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["spell_tables"] = {
								["_ActorTable"] = {
									[3606] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Druid of the Fang",
													["total"] = 32,
												}, -- [1]
											},
										},
										["n_dmg"] = 20,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 32,
										["c_max"] = 12,
										["id"] = 3606,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1642654123,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.003332,
							["start_time"] = 1642654115,
							["delay"] = 0,
							["last_event"] = 1642654123,
						}, -- [6]
					},
				}, -- [1]
				{
					["combatId"] = 604,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 197.001682,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 581,
										["total"] = 197,
										["nome"] = "Gsea",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PRIEST",
							["totalover"] = 581.001682,
							["total_without_pet"] = 197.001682,
							["last_event"] = 1642654107,
							["end_time"] = 1642654123,
							["totalover_without_pet"] = 0.001682,
							["healing_taken"] = 0.001682,
							["nome"] = "Troudcul",
							["serial"] = "0x0102000000015A98",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									[17] = {
										["c_curado"] = 0,
										["totalabsorb"] = 197,
										["n_max"] = 197,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 581,
													["total"] = 197,
													["nome"] = "Gsea",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 197,
										["counter"] = 1,
										["overheal"] = 581,
										["total"] = 197,
										["c_max"] = 0,
										["id"] = 17,
										["c_min"] = 0,
										["c_amt"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 197,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654122,
							["delay"] = 1642654107,
							["total"] = 197.001682,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.005075,
							["last_hps"] = 0,
							["healing_from"] = {
								["Troudcul"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.005075,
							["total_without_pet"] = 0.005075,
							["last_event"] = 0,
							["end_time"] = 1642654123,
							["totalover_without_pet"] = 0.005075,
							["healing_taken"] = 197.005075,
							["nome"] = "Gsea",
							["serial"] = "0x0102000000015AB4",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1642654123,
							["delay"] = 0,
							["total"] = 0.005075,
						}, -- [2]
					},
				}, -- [2]
				{
					["combatId"] = 604,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 604,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 18,
							["classe"] = "SHAMAN",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[115798] = {
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[51490] = {
										["activedamt"] = 3,
										["uptime"] = 3,
										["id"] = 51490,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Tuly",
							["buff_uptime"] = 17,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x01020000000158AD",
							["last_event"] = 1642654123,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[8050] = {
										["activedamt"] = 2,
										["uptime"] = 17,
										["id"] = 8050,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 17,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 324,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "SHAMAN",
							["interrompeu_oque"] = {
								[12167] = 1,
							},
							["debuff_uptime"] = 26,
							["interrupt_spell_tables"] = {
								["_ActorTable"] = {
									[57994] = {
										["id"] = 57994,
										["interrompeu_oque"] = {
											[12167] = 1,
										},
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Lord Serpentis",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["interrupt_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Lord Serpentis",
										["total"] = 1,
									}, -- [1]
								},
							},
							["grupo"] = true,
							["interrupt"] = 1.006605,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654123,
							["nome"] = "Skullbeard",
							["pets"] = {
							},
							["serial"] = "0x0102000000013EA9",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[589] = {
										["activedamt"] = 3,
										["uptime"] = 9,
										["id"] = 589,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[14914] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 14914,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[6788] = {
										["activedamt"] = 0,
										["uptime"] = 16,
										["id"] = 6788,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["dispell"] = 1.004376,
							["buff_uptime"] = 17,
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[21562] = {
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 21562,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "PRIEST",
							["dispell_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Gsea",
										["total"] = 1,
									}, -- [1]
								},
							},
							["dispell_spell_tables"] = {
								["_ActorTable"] = {
									[527] = {
										["dispell"] = 1,
										["id"] = 527,
										["dispell_oque"] = {
											[8040] = 1,
										},
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Gsea",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 26,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["dispell_oque"] = {
								[8040] = 1,
							},
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["last_event"] = 1642654123,
							["nome"] = "Troudcul",
							["pets"] = {
							},
							["serial"] = "0x0102000000015A98",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 8,
							["classe"] = "DRUID",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[6795] = {
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = 6795,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[45334] = {
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = 45334,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Gsea",
							["buff_uptime"] = 34,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[5487] = {
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 5487,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[132365] = {
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 132365,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x0102000000015AB4",
							["last_event"] = 1642654123,
						}, -- [4]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 604,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Tuly"] = true,
					["Bladeknight"] = true,
					["Skullbeard"] = true,
					["Gsea"] = true,
					["Troudcul"] = true,
				},
				["last_events_tables"] = {
				},
				["combat_counter"] = 3882,
				["totals"] = {
					3735.984914, -- [1]
					196.998138, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 1,
						["dispell"] = 1,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["__call"] = {
				},
				["data_inicio"] = "23:48:27",
				["end_time"] = 1642654123,
				["combat_id"] = 604,
				["instance_type"] = "party",
				["is_boss"] = {
					["mapid"] = 43,
					["diff_string"] = "Normal",
					["name"] = "Lord Serpentis",
					["zone"] = "Wailing Caverns",
					["encounter"] = "Lord Serpentis",
					["ej_instance_id"] = 240,
					["diff"] = 1,
				},
				["frags"] = {
				},
				["data_fim"] = "23:48:43",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3620, -- [1]
					197, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 1,
						["dispell"] = 1,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 1642654106,
				["contra"] = "Druid of the Fang",
				["TimeData"] = {
				},
			}, -- [5]
		},
	},
	["tabela_instancias"] = {
	},
	["combat_id"] = 614,
	["savedStyles"] = {
	},
	["savedbuffs"] = {
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["SoloTablesSaved"] = {
		["LastSelected"] = "DETAILS_PLUGIN_DAMAGE_RANK",
		["Mode"] = 1,
	},
	["last_version"] = "v1.29.3",
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = true,
			["is_open"] = true,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				5, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[4] = 2,
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -404.146900177002,
					["x"] = 618.2974243164063,
					["w"] = 205.7057189941406,
					["h"] = 95.23549652099609,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = true,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = true,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[2] = 1,
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -288.9114227294922,
					["x"] = 618.2974243164063,
					["w"] = 205.7057189941406,
					["h"] = 95.23548889160156,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-005,
					["w"] = 320.0001525878906,
					["h"] = 129.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300.0000610351563,
					["h"] = 299.9999694824219,
				},
			},
		}, -- [3]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-005,
					["w"] = 320.0001525878906,
					["h"] = 129.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [4]
	},
	["last_instance_time"] = 1642654884,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1643590781,
		["last_version"] = 6,
	},
	["last_instance_id"] = 1001,
}
