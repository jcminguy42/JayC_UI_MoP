
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0,
	["position"] = {
		["y"] = 264.3072509765625,
		["x"] = 1130.679565429688,
	},
	["showPlayers"] = true,
}
