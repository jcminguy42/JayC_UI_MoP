
EncounterDetailsDB = {
	["emotes"] = {
		{
			["boss"] = "Mutanus the Devourer",
		}, -- [1]
		{
			["boss"] = "Verdan the Everliving",
		}, -- [2]
		{
			["boss"] = "Lord Serpentis",
		}, -- [3]
	},
}
