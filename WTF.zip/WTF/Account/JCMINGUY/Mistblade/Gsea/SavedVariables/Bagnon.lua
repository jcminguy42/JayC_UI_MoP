
BagnonFrameSettings = {
	["version"] = "5.4.15",
	["frames"] = {
		["inventory"] = {
			["frameBorderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
			},
			["y"] = 150.0000152587891,
		},
	},
}
