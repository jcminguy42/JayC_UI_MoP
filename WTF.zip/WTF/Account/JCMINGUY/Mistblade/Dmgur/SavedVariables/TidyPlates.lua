
TidyPlatesOptions = {
	["EnableCastWatcher"] = true,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["WelcomeShown"] = true,
	["secondary"] = "Threat Plates",
}
