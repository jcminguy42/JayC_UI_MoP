
_detalhes_database = {
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Lotusprep-[EN] Evermoon",
	["last_realversion"] = 28,
	["combat_counter"] = 208,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 1,
			["animate"] = false,
			["useplayercolor"] = false,
			["enabled"] = true,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["showamount"] = false,
		},
		["DETAILS_PLUGIN_DPS_TUNING"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
			["SpellBarsShowType"] = 1,
		},
		["DETAILS_PLUGIN_DAMAGE_RANK"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
			["enabled"] = true,
			["captures"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["author"] = "Details! Team",
			["last_encounter_hash"] = false,
			["showing_type"] = 1,
			["last_segment"] = false,
			["last_combat_id"] = 57,
			["show_icon"] = 1,
			["last_boss"] = false,
			["last_player"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["opened"] = 0,
			["author"] = "Details! Team",
			["show_icon"] = 5,
			["hide_on_combat"] = false,
			["max_emote_segments"] = 3,
		},
		["DETAILS_PLUGIN_TIME_ATTACK"] = {
			["enabled"] = true,
			["realm_last_shown"] = 40,
			["saved_as_anonymous"] = true,
			["recently_as_anonymous"] = true,
			["dps"] = 0,
			["disable_sharing"] = false,
			["history"] = {
			},
			["time"] = 40,
			["history_lastindex"] = 0,
			["author"] = "Details! Team",
			["realm_history"] = {
			},
			["realm_lastamt"] = 0,
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_YANP"] = {
			["enabled"] = true,
			["rightclick_closed"] = false,
			["auto_open"] = true,
			["author"] = "Details! Team",
			["hide_on_combat"] = true,
			["deaths_table"] = {
			},
			["shown_time"] = 30,
		},
	},
	["character_data"] = {
		["logons"] = 74,
	},
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 57,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["serial"] = "0x0700000000000469",
							["on_hold"] = false,
							["damage_from"] = {
								["Environment (falling)"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Raider's Training Dummy",
										["total"] = 7381682,
									}, -- [1]
								},
							},
							["end_time"] = 1638595450,
							["pets"] = {
							},
							["colocacao"] = 1,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 7381682.006558999,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["dps_started"] = false,
							["total"] = 7381682.006558999,
							["classe"] = "PALADIN",
							["nome"] = "Dmgur",
							["grupo"] = true,
							["spell_tables"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 4,
										["c_dmg"] = 202442,
										["g_amt"] = 9,
										["n_max"] = 26429,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 716550,
												}, -- [1]
											},
										},
										["n_dmg"] = 369324,
										["n_min"] = 15678,
										["g_dmg"] = 144784,
										["counter"] = 31,
										["total"] = 716550,
										["c_max"] = 49882,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 32379,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 17,
										["b_dmg"] = 97333,
										["r_amt"] = 0,
									}, -- [1]
									[85256] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 578397,
										["g_amt"] = 0,
										["n_max"] = 84871,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 1442297,
												}, -- [1]
											},
										},
										["n_dmg"] = 863900,
										["n_min"] = 64786,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 1442297,
										["c_max"] = 161444,
										["id"] = 85256,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 128055,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[42463] = {
										["c_amt"] = 20,
										["b_amt"] = 0,
										["c_dmg"] = 214711,
										["g_amt"] = 0,
										["n_max"] = 6113,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 562526,
												}, -- [1]
											},
										},
										["n_dmg"] = 347815,
										["n_min"] = 3956,
										["g_dmg"] = 0,
										["counter"] = 90,
										["total"] = 562526,
										["c_max"] = 12189,
										["id"] = 42463,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 8610,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 70,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[35395] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 189466,
										["g_amt"] = 0,
										["n_max"] = 33830,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 832974,
												}, -- [1]
											},
										},
										["n_dmg"] = 643508,
										["n_min"] = 23691,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 832974,
										["c_max"] = 64616,
										["id"] = 35395,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 62045,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 23,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[879] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 258730,
										["g_amt"] = 0,
										["n_max"] = 50304,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 561316,
												}, -- [1]
											},
										},
										["n_dmg"] = 302586,
										["n_min"] = 33782,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 561316,
										["c_max"] = 103784,
										["id"] = 879,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 76745,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[20271] = {
										["c_amt"] = 8,
										["b_amt"] = 0,
										["c_dmg"] = 712394,
										["g_amt"] = 0,
										["n_max"] = 49315,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 1086535,
												}, -- [1]
											},
										},
										["n_dmg"] = 374141,
										["n_min"] = 37254,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 1086535,
										["c_max"] = 109561,
										["id"] = 20271,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 76743,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[114916] = {
										["c_amt"] = 7,
										["b_amt"] = 0,
										["c_dmg"] = 305062,
										["g_amt"] = 0,
										["n_max"] = 86736,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 534670,
												}, -- [1]
											},
										},
										["n_dmg"] = 229608,
										["n_min"] = 7453,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 534670,
										["c_max"] = 164649,
										["id"] = 114916,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 16661,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 13,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[96172] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 71875,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 1010150,
												}, -- [1]
											},
										},
										["n_dmg"] = 1010150,
										["n_min"] = 9238,
										["g_dmg"] = 0,
										["counter"] = 42,
										["total"] = 1010150,
										["c_max"] = 0,
										["id"] = 96172,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 42,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[31803] = {
										["c_amt"] = 9,
										["b_amt"] = 0,
										["c_dmg"] = 224293,
										["g_amt"] = 0,
										["n_max"] = 14921,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 634664,
												}, -- [1]
											},
										},
										["n_dmg"] = 410371,
										["n_min"] = 5929,
										["g_dmg"] = 0,
										["counter"] = 44,
										["total"] = 634664,
										["c_max"] = 30737,
										["id"] = 31803,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 21763,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 35,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 64188.53918746956,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 156082.006559,
							["start_time"] = 1638595335,
							["delay"] = 0,
							["last_event"] = 1638595447,
						}, -- [1]
					},
				}, -- [1]
				{
					["combatId"] = 57,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 57,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 57,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 364,
							["classe"] = "PALADIN",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["debuff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[114916] = {
										["activedamt"] = 0,
										["uptime"] = 19,
										["id"] = 114916,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[31803] = {
										["activedamt"] = 0,
										["uptime"] = 115,
										["id"] = 31803,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[81326] = {
										["activedamt"] = 0,
										["uptime"] = 115,
										["id"] = 81326,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 0,
										["uptime"] = 115,
										["id"] = 115798,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["grupo"] = true,
							["nome"] = "Dmgur",
							["buff_uptime"] = 486,
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["buff_uptime_spell_tables"] = {
								["_ActorTable"] = {
									[126657] = {
										["activedamt"] = 1,
										["uptime"] = 20,
										["id"] = 126657,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[19740] = {
										["activedamt"] = 1,
										["uptime"] = 115,
										["id"] = 19740,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[125489] = {
										["activedamt"] = 2,
										["uptime"] = 30,
										["id"] = 125489,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[120032] = {
										["activedamt"] = 1,
										["id"] = 120032,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638595335,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[84963] = {
										["activedamt"] = 1,
										["uptime"] = 106,
										["id"] = 84963,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[87173] = {
										["activedamt"] = 18,
										["uptime"] = 53,
										["id"] = 87173,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[114250] = {
										["activedamt"] = 1,
										["uptime"] = 115,
										["id"] = 114250,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[59578] = {
										["activedamt"] = 5,
										["uptime"] = 7,
										["id"] = 59578,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
									[126582] = {
										["activedamt"] = 2,
										["uptime"] = 40,
										["id"] = 126582,
										["actived"] = false,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "0x0700000000000469",
							["last_event"] = 1638595450,
						}, -- [1]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["funcao_de_criacao"] = nil --[[ skipped inline function ]],
					["combatId"] = 57,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Dmgur"] = true,
					["Nydan"] = true,
					["Dampfhammer"] = true,
					["Taintedtotem"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Raider's Training Dummy",
				["combat_counter"] = 208,
				["totals"] = {
					7381681.952329, -- [1]
					-0.03567899993892759, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = -0.01080099999999984,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["__call"] = {
				},
				["data_inicio"] = "00:22:16",
				["end_time"] = 1638595450,
				["combat_id"] = 57,
				["instance_type"] = "none",
				["frags"] = {
				},
				["data_fim"] = "00:24:11",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					7381682, -- [1]
					0, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 1638595335,
				["TimeData"] = {
				},
				["pvp"] = false,
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 56,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["classe"] = "PALADIN",
							["damage_from"] = {
								["Beast <Bigshootings>"] = true,
								["Bigshootings"] = true,
								["Decapisbad"] = true,
								["Unknown"] = true,
								["Beast"] = true,
								["Symbolik"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Decapisbad",
										["total"] = 171497,
									}, -- [1]
									{
										["nome"] = "Bigshootings",
										["total"] = 805769,
									}, -- [2]
									{
										["nome"] = "Thokdok",
										["total"] = 128820,
									}, -- [3]
									{
										["nome"] = "Symbolik",
										["total"] = 515400,
									}, -- [4]
									{
										["nome"] = "Wild Mature Swine",
										["total"] = 58018,
									}, -- [5]
									{
										["nome"] = "Raider's Training Dummy",
										["total"] = 32727,
									}, -- [6]
								},
							},
							["pets"] = {
								"Guardian of Ancient Kings <Dmgur>", -- [1]
							},
							["last_event"] = 1638595334,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 1564625.008909,
							["delay"] = 1638590392,
							["dps_started"] = false,
							["end_time"] = 1638595335,
							["total"] = 1712231.008909,
							["damage_taken"] = 1221055.008909,
							["nome"] = "Dmgur",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 70767,
										["g_amt"] = 0,
										["n_max"] = 9686,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 100781,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 11495,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 32935,
												}, -- [3]
											},
										},
										["n_dmg"] = 74444,
										["n_min"] = 5686,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 145211,
										["c_max"] = 20448,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 14481,
										["successful_casted"] = 0,
										["a_amt"] = 3,
										["n_amt"] = 10,
										["a_dmg"] = 32935,
										["MISS"] = 1,
									}, -- [1]
									[114916] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3337,
										["g_amt"] = 0,
										["n_max"] = 16734,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 33734,
												}, -- [1]
												{
													["nome"] = "Symbolik",
													["total"] = 31305,
												}, -- [2]
											},
										},
										["n_dmg"] = 61702,
										["n_min"] = 1217,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 65039,
										["c_max"] = 3337,
										["id"] = 114916,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 3337,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["a_amt"] = 10,
										["a_dmg"] = 31305,
									},
									[24275] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29698,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 110871,
												}, -- [1]
												{
													["nome"] = "Symbolik",
													["total"] = 57363,
												}, -- [2]
											},
										},
										["n_dmg"] = 168234,
										["n_min"] = 22424,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 168234,
										["c_max"] = 0,
										["id"] = 24275,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 2,
										["a_dmg"] = 57363,
									},
									[35395] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 51461,
										["g_amt"] = 0,
										["n_max"] = 14315,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 61805,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 43891,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 8528,
												}, -- [3]
											},
										},
										["n_dmg"] = 62763,
										["n_min"] = 6652,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 114224,
										["c_max"] = 21461,
										["id"] = 35395,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 13877,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 1,
										["a_dmg"] = 8528,
									},
									[879] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 26759,
										["g_amt"] = 0,
										["n_max"] = 31327,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 53108,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 11402,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 8080,
												}, -- [3]
												{
													["nome"] = "Wild Mature Swine",
													["total"] = 31327,
												}, -- [4]
											},
										},
										["n_dmg"] = 77158,
										["n_min"] = 8080,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 103917,
										["c_max"] = 26759,
										["id"] = 879,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 26759,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 1,
										["a_dmg"] = 8080,
									},
									[96172] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11885,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 79671,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 16947,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 37080,
												}, -- [3]
											},
										},
										["n_dmg"] = 133698,
										["n_min"] = 2047,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 133698,
										["c_max"] = 0,
										["id"] = 96172,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["a_amt"] = 5,
										["a_dmg"] = 37080,
									},
									[20271] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 112275,
										["g_amt"] = 0,
										["n_max"] = 28657,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 126551,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 8728,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 110854,
												}, -- [3]
												{
													["nome"] = "Wild Mature Swine",
													["total"] = 26691,
												}, -- [4]
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 28657,
												}, -- [5]
											},
										},
										["n_dmg"] = 189206,
										["n_min"] = 6852,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 301481,
										["c_max"] = 42794,
										["id"] = 20271,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 19048,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["a_amt"] = 5,
										["a_dmg"] = 110854,
									},
									[85256] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26412,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 26412,
												}, -- [1]
												{
													["nome"] = "Symbolik",
													["total"] = 49924,
												}, -- [2]
											},
										},
										["n_dmg"] = 76336,
										["n_min"] = 24632,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 76336,
										["c_max"] = 0,
										["id"] = 85256,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 2,
										["a_dmg"] = 49924,
									},
									[42463] = {
										["c_amt"] = 10,
										["b_amt"] = 0,
										["c_dmg"] = 35629,
										["g_amt"] = 0,
										["n_max"] = 4070,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 52445,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 12230,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 19901,
												}, -- [3]
												{
													["nome"] = "Raider's Training Dummy",
													["total"] = 4070,
												}, -- [4]
											},
										},
										["n_dmg"] = 53017,
										["n_min"] = 880,
										["g_dmg"] = 0,
										["counter"] = 42,
										["total"] = 88646,
										["c_max"] = 4275,
										["id"] = 42463,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 3174,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 32,
										["a_amt"] = 10,
										["a_dmg"] = 19901,
									},
									[108446] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10698,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Thokdok",
													["total"] = 99304,
												}, -- [1]
											},
										},
										["n_dmg"] = 99304,
										["n_min"] = 107,
										["g_dmg"] = 0,
										["counter"] = 48,
										["total"] = 99304,
										["c_max"] = 0,
										["id"] = 108446,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 48,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[31803] = {
										["c_amt"] = 15,
										["b_amt"] = 0,
										["c_dmg"] = 100566,
										["g_amt"] = 0,
										["n_max"] = 5123,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Decapisbad",
													["total"] = 66804,
												}, -- [1]
												{
													["nome"] = "Bigshootings",
													["total"] = 160391,
												}, -- [2]
												{
													["nome"] = "Symbolik",
													["total"] = 41340,
												}, -- [3]
											},
										},
										["n_dmg"] = 167969,
										["n_min"] = 432,
										["g_dmg"] = 0,
										["counter"] = 67,
										["total"] = 268535,
										["c_max"] = 10554,
										["id"] = 31803,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 2943,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 52,
										["a_amt"] = 9,
										["a_dmg"] = 41340,
									},
								},
							},
							["custom"] = 0,
							["last_dps"] = 4248.712180915633,
							["colocacao"] = 1,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590484,
							["serial"] = "0x0700000000000469",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Spiiro"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Spiiro",
										["total"] = 635204,
									}, -- [1]
									{
										["nome"] = "Skull Banner <Spiiro>",
										["total"] = 4348,
									}, -- [2]
								},
							},
							["pets"] = {
							},
							["last_dps"] = 1586.977671183623,
							["friendlyfire_total"] = 0,
							["start_time"] = 1638590311,
							["total_without_pet"] = 639552.001487,
							["tipo"] = 1,
							["classe"] = "WARRIOR",
							["dps_started"] = false,
							["total"] = 639552.001487,
							["delay"] = 0,
							["damage_taken"] = 857252.001487,
							["nome"] = "Dampfhammer",
							["end_time"] = 1638590614,
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 6,
										["b_amt"] = 25,
										["c_dmg"] = 13736,
										["g_amt"] = 0,
										["n_max"] = 1597,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 89728,
												}, -- [1]
											},
										},
										["n_dmg"] = 75992,
										["n_min"] = 113,
										["g_dmg"] = 0,
										["counter"] = 81,
										["total"] = 89728,
										["c_max"] = 3283,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 677,
										["successful_casted"] = 0,
										["b_dmg"] = 17912,
										["n_amt"] = 75,
										["a_amt"] = 9,
										["a_dmg"] = 8211,
									}, -- [1]
									[115767] = {
										["c_amt"] = 13,
										["b_amt"] = 0,
										["c_dmg"] = 48364,
										["g_amt"] = 0,
										["n_max"] = 2103,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 155537,
												}, -- [1]
											},
										},
										["n_dmg"] = 107173,
										["n_min"] = 1051,
										["g_dmg"] = 0,
										["counter"] = 75,
										["total"] = 155537,
										["c_max"] = 3855,
										["id"] = 115767,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 2804,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 62,
										["a_amt"] = 13,
										["a_dmg"] = 19628,
									},
									[6572] = {
										["c_amt"] = 3,
										["b_amt"] = 4,
										["c_dmg"] = 14726,
										["g_amt"] = 0,
										["n_max"] = 4348,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 39979,
												}, -- [1]
												{
													["nome"] = "Skull Banner <Spiiro>",
													["total"] = 4348,
												}, -- [2]
											},
										},
										["n_dmg"] = 29601,
										["n_min"] = 855,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 44327,
										["c_max"] = 6929,
										["id"] = 6572,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 2395,
										["successful_casted"] = 0,
										["b_dmg"] = 7996,
										["n_amt"] = 12,
										["a_amt"] = 4,
										["a_dmg"] = 11373,
									},
									[1715] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 1715,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["BLOCK"] = 1,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["a_dmg"] = 0,
									},
									[20243] = {
										["c_amt"] = 3,
										["b_amt"] = 8,
										["c_dmg"] = 14082,
										["g_amt"] = 0,
										["n_max"] = 3688,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 87039,
												}, -- [1]
											},
										},
										["n_dmg"] = 72957,
										["n_min"] = 1176,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 87039,
										["c_max"] = 6118,
										["id"] = 20243,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 2160,
										["successful_casted"] = 0,
										["b_dmg"] = 14997,
										["n_amt"] = 29,
										["a_amt"] = 3,
										["a_dmg"] = 7160,
									},
									[23922] = {
										["c_amt"] = 8,
										["b_amt"] = 9,
										["c_dmg"] = 71758,
										["g_amt"] = 0,
										["n_max"] = 5325,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 155956,
												}, -- [1]
											},
										},
										["n_dmg"] = 84198,
										["n_min"] = 1739,
										["g_dmg"] = 0,
										["counter"] = 29,
										["total"] = 155956,
										["c_max"] = 13085,
										["id"] = 23922,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 5241,
										["successful_casted"] = 0,
										["b_dmg"] = 30889,
										["n_amt"] = 21,
										["a_amt"] = 2,
										["a_dmg"] = 7794,
									},
									[78] = {
										["c_amt"] = 6,
										["b_amt"] = 1,
										["c_dmg"] = 28039,
										["g_amt"] = 0,
										["n_max"] = 2142,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 34448,
												}, -- [1]
											},
										},
										["n_dmg"] = 6409,
										["n_min"] = 1176,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 34448,
										["c_max"] = 5130,
										["id"] = 78,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 4186,
										["successful_casted"] = 0,
										["b_dmg"] = 1176,
										["n_amt"] = 4,
										["a_amt"] = 3,
										["a_dmg"] = 4267,
									},
									[845] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1844,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 1844,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1844,
										["c_max"] = 1844,
										["id"] = 845,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 1844,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[5246] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 0,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 5246,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["IMMUNE"] = 1,
									},
									[6343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1316,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 2226,
												}, -- [1]
											},
										},
										["n_dmg"] = 2226,
										["n_min"] = 910,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2226,
										["c_max"] = 0,
										["id"] = 6343,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[118000] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 66929,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 66929,
												}, -- [1]
											},
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 66929,
										["c_max"] = 15720,
										["id"] = 118000,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 11909,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[57755] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 802,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spiiro",
													["total"] = 1518,
												}, -- [1]
											},
										},
										["n_dmg"] = 1518,
										["n_min"] = 716,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1518,
										["c_max"] = 0,
										["id"] = 57755,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
							},
							["custom"] = 0,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["colocacao"] = 2,
							["last_event"] = 1638590613,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 10,
									["FULL_ABSORB_AMT"] = 157247,
									["FULL_ABSORBED"] = 62,
									["ALL"] = 401,
									["PARTIAL_ABSORBED"] = 38,
									["PARRY"] = 16,
									["PARTIAL_ABSORB_AMT"] = 18085,
									["ABSORB"] = 100,
									["ABSORB_AMT"] = 175332,
									["FULL_HIT"] = 301,
									["HITS"] = 80,
									["FULL_HIT_AMT"] = 784823,
								},
								["Spiiro"] = {
									["DODGE"] = 10,
									["FULL_ABSORB_AMT"] = 157247,
									["FULL_ABSORBED"] = 62,
									["ALL"] = 401,
									["PARTIAL_ABSORBED"] = 38,
									["PARRY"] = 16,
									["PARTIAL_ABSORB_AMT"] = 18085,
									["ABSORB"] = 100,
									["ABSORB_AMT"] = 175332,
									["FULL_HIT"] = 301,
									["HITS"] = 80,
									["FULL_HIT_AMT"] = 784823,
								},
							},
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 8465,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Thokdok",
										["total"] = 29516,
									}, -- [1]
									{
										["nome"] = "Symbolik",
										["total"] = 118090,
									}, -- [2]
								},
							},
							["pets"] = {
							},
							["total"] = 147606.004462,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 147606.004462,
							["last_event"] = 1638590353,
							["dps_started"] = false,
							["end_time"] = 1638590614,
							["delay"] = 1638590353,
							["ownerName"] = "Dmgur",
							["nome"] = "Guardian of Ancient Kings <Dmgur>",
							["damage_taken"] = 0.004462,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 31736,
										["g_amt"] = 0,
										["n_max"] = 10795,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Symbolik",
													["total"] = 118090,
												}, -- [1]
											},
										},
										["n_dmg"] = 86354,
										["n_min"] = 7759,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 118090,
										["c_max"] = 16101,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 15635,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_amt"] = 11,
										["a_dmg"] = 118090,
									}, -- [1]
									[108446] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4025,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Thokdok",
													["total"] = 29516,
												}, -- [1]
											},
										},
										["n_dmg"] = 29516,
										["n_min"] = 1939,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 29516,
										["c_max"] = 0,
										["id"] = 108446,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590590,
							["serial"] = "0xF130B5AA000E5AA8",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 56,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.006907,
							["last_hps"] = 0,
							["healing_from"] = {
								["Dmgur"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 16605,
										["total"] = 952916,
										["nome"] = "Dmgur",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["totalover_without_pet"] = 0.006907,
							["heal_enemy_amt"] = 0,
							["totalover"] = 16605.006907,
							["total_without_pet"] = 952916.006907,
							["healing_taken"] = 952916.006907,
							["fight_component"] = true,
							["end_time"] = 1638590614,
							["iniciar_hps"] = false,
							["classe"] = "PALADIN",
							["nome"] = "Dmgur",
							["serial"] = "0x0700000000000469",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[115547] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 3369,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 16605,
													["total"] = 50007,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 3321,
										["counter"] = 20,
										["overheal"] = 16605,
										["total"] = 50007,
										["c_max"] = 0,
										["id"] = 115547,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 15,
										["n_curado"] = 50007,
										["absorbed"] = 0,
									},
									[130551] = {
										["c_amt"] = 3,
										["totalabsorb"] = 0,
										["n_max"] = 66351,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 902909,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 36879,
										["counter"] = 14,
										["overheal"] = 0,
										["total"] = 902909,
										["c_max"] = 151220,
										["id"] = 130551,
										["c_min"] = 74326,
										["c_curado"] = 359211,
										["n_amt"] = 11,
										["n_curado"] = 543698,
										["absorbed"] = 0,
									},
								},
							},
							["heal_enemy"] = {
							},
							["total"] = 952916.006907,
							["custom"] = 0,
							["last_event"] = 1638590362,
							["on_hold"] = false,
							["start_time"] = 1638590539,
							["delay"] = 1638590362,
							["tipo"] = 2,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 188123.006317,
							["last_hps"] = 0,
							["healing_from"] = {
								["Dampfhammer"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 259519,
										["total"] = 734157,
										["nome"] = "Dampfhammer",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["totalover_without_pet"] = 0.006317,
							["classe"] = "WARRIOR",
							["totalover"] = 259519.006317,
							["total_without_pet"] = 734157.006317,
							["total"] = 734157.006317,
							["iniciar_hps"] = false,
							["fight_component"] = true,
							["end_time"] = 1638590614,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["nome"] = "Dampfhammer",
							["healing_taken"] = 734157.006317,
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[55694] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 77647,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 546034,
													["nome"] = "Dampfhammer",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 7245,
										["counter"] = 30,
										["overheal"] = 0,
										["total"] = 546034,
										["c_max"] = 0,
										["id"] = 55694,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 30,
										["n_curado"] = 546034,
										["absorbed"] = 0,
									},
									[112048] = {
										["c_amt"] = 0,
										["totalabsorb"] = 188123,
										["n_max"] = 26694,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 259519,
													["total"] = 188123,
													["nome"] = "Dampfhammer",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 8841,
										["counter"] = 10,
										["overheal"] = 259519,
										["total"] = 188123,
										["c_max"] = 0,
										["id"] = 112048,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 10,
										["n_curado"] = 188123,
										["absorbed"] = 0,
									},
								},
							},
							["heal_enemy"] = {
							},
							["delay"] = 1638590575,
							["custom"] = 0,
							["last_event"] = 1638590607,
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["start_time"] = 1638590571,
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 56,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 56,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 0,
							["nome"] = "Taintedtotem",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638590211,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[51470] = {
										["activedamt"] = 1,
										["id"] = 51470,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590211,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[324] = {
										["activedamt"] = 1,
										["id"] = 324,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590211,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[77747] = {
										["activedamt"] = 1,
										["id"] = 77747,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590211,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[116956] = {
										["activedamt"] = 1,
										["id"] = 116956,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590211,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "SHAMAN",
							["tipo"] = 4,
							["serial"] = "0x0700000000000721",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[81326] = {
										["activedamt"] = -1,
										["uptime"] = 368,
										["id"] = 81326,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31803] = {
										["activedamt"] = -1,
										["uptime"] = 348,
										["id"] = 31803,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105421] = {
										["activedamt"] = -5,
										["id"] = 105421,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590211,
										["uptime"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[105593] = {
										["activedamt"] = 0,
										["uptime"] = 18,
										["id"] = 105593,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = -1,
										["uptime"] = 345,
										["id"] = 115798,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114916] = {
										["activedamt"] = 0,
										["uptime"] = 20,
										["id"] = 114916,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["cooldowns_defensive"] = 2.007162,
							["buff_uptime"] = 714,
							["last_cooldown"] = {
								1638590261.514, -- [1]
								498, -- [2]
							},
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[131634] = {
										["activedamt"] = 8,
										["uptime"] = 58,
										["id"] = 131634,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105809] = {
										["activedamt"] = 2,
										["uptime"] = 36,
										["id"] = 105809,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1044] = {
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 1044,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[126679] = {
										["activedamt"] = 2,
										["uptime"] = 40,
										["id"] = 126679,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115547] = {
										["activedamt"] = 2,
										["uptime"] = 40,
										["id"] = 115547,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[84963] = {
										["activedamt"] = 3,
										["uptime"] = 147,
										["id"] = 84963,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31884] = {
										["activedamt"] = 2,
										["uptime"] = 40,
										["id"] = 31884,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[498] = {
										["activedamt"] = 2,
										["uptime"] = 20,
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86698] = {
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = 86698,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[96229] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 96229,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[87173] = {
										["uptime"] = 51,
										["activedamt"] = 17,
										["id"] = 87173,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[125489] = {
										["activedamt"] = 2,
										["uptime"] = 30,
										["id"] = 125489,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114250] = {
										["uptime"] = 134,
										["activedamt"] = 4,
										["id"] = 114250,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86700] = {
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = 86700,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[19740] = {
										["activedamt"] = 1,
										["uptime"] = 46,
										["id"] = 19740,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "PALADIN",
							["cooldowns_defensive_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Dmgur",
										["total"] = 2,
									}, -- [1]
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 1099,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["cooldowns_defensive_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[498] = {
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dmgur",
													["total"] = 2,
												}, -- [1]
											},
										},
										["counter"] = 2,
									},
								},
							},
							["tipo"] = 4,
							["last_event"] = 1638590614,
							["nome"] = "Dmgur",
							["pets"] = {
							},
							["serial"] = "0x0700000000000469",
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [2]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[115767] = {
										["activedamt"] = 1,
										["uptime"] = 229,
										["id"] = 115767,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[7922] = {
										["uptime"] = 8,
										["activedamt"] = 0,
										["id"] = 7922,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1160] = {
										["uptime"] = 29,
										["activedamt"] = 0,
										["id"] = 1160,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[676] = {
										["activedamt"] = 0,
										["uptime"] = 16,
										["id"] = 676,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[355] = {
										["activedamt"] = 0,
										["uptime"] = 3,
										["id"] = 355,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[118895] = {
										["uptime"] = 4,
										["activedamt"] = 0,
										["id"] = 118895,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[5246] = {
										["activedamt"] = 0,
										["uptime"] = 10,
										["id"] = 5246,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115798] = {
										["uptime"] = 60,
										["activedamt"] = 0,
										["id"] = 115798,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[113746] = {
										["activedamt"] = 1,
										["uptime"] = 297,
										["id"] = 113746,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1715] = {
										["uptime"] = 24,
										["activedamt"] = 0,
										["id"] = 1715,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[69179] = {
										["uptime"] = 4,
										["activedamt"] = 0,
										["id"] = 69179,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["cooldowns_defensive"] = 8.006097000000001,
							["buff_uptime"] = 827,
							["last_cooldown"] = {
								1638590582.696, -- [1]
								871, -- [2]
							},
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55694] = {
										["uptime"] = 25,
										["activedamt"] = 5,
										["id"] = 55694,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[126646] = {
										["uptime"] = 60,
										["activedamt"] = 3,
										["id"] = 126646,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[132404] = {
										["activedamt"] = 3,
										["uptime"] = 18,
										["id"] = 132404,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[12880] = {
										["activedamt"] = 15,
										["id"] = 12880,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590609,
										["uptime"] = 101,
										["actived"] = true,
										["counter"] = 0,
									},
									[122510] = {
										["activedamt"] = 8,
										["uptime"] = 34,
										["id"] = 122510,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[122016] = {
										["uptime"] = 29,
										["activedamt"] = 3,
										["id"] = 122016,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[107574] = {
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = 107574,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[12975] = {
										["activedamt"] = 1,
										["uptime"] = 20,
										["id"] = 12975,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[92049] = {
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 92049,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[50227] = {
										["uptime"] = 32,
										["activedamt"] = 9,
										["id"] = 50227,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[112048] = {
										["activedamt"] = 11,
										["id"] = 112048,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590610,
										["uptime"] = 60,
										["actived"] = true,
										["counter"] = 0,
									},
									[469] = {
										["activedamt"] = 1,
										["id"] = 469,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590453,
										["uptime"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[23920] = {
										["uptime"] = 15,
										["activedamt"] = 3,
										["id"] = 23920,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[84619] = {
										["activedamt"] = 12,
										["uptime"] = 45,
										["id"] = 84619,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[126533] = {
										["uptime"] = 99,
										["activedamt"] = 5,
										["id"] = 126533,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1719] = {
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 1719,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[18499] = {
										["uptime"] = 18,
										["activedamt"] = 3,
										["id"] = 18499,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[145674] = {
										["activedamt"] = 6,
										["id"] = 145674,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived_at"] = 1638590586,
										["uptime"] = 196,
										["actived"] = true,
										["counter"] = 0,
									},
									[97463] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 97463,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[871] = {
										["uptime"] = 23,
										["activedamt"] = 2,
										["id"] = 871,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "WARRIOR",
							["cooldowns_defensive_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Dampfhammer",
										["total"] = 6,
									}, -- [1]
									{
										["nome"] = "[*] raid wide cooldown",
										["total"] = 2,
									}, -- [2]
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 684,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["last_event"] = 1638590613,
							["cooldowns_defensive_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[23920] = {
										["id"] = 23920,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dampfhammer",
													["total"] = 3,
												}, -- [1]
											},
										},
										["counter"] = 3,
									},
									[97462] = {
										["id"] = 97462,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "[*] raid wide cooldown",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
									[12975] = {
										["id"] = 12975,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dampfhammer",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
									[871] = {
										["id"] = 871,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dampfhammer",
													["total"] = 2,
												}, -- [1]
											},
										},
										["counter"] = 2,
									},
									[114203] = {
										["id"] = 114203,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "[*] raid wide cooldown",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
								},
							},
							["nome"] = "Dampfhammer",
							["tipo"] = 4,
							["pets"] = {
							},
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [3]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["tipo"] = 2,
					["combatId"] = 56,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Dampfhammer"] = true,
					["Taintedtotem"] = true,
					["Weavil"] = true,
					["Nydan"] = true,
					["Dmgur"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Bigshootings",
				["combat_counter"] = 206,
				["totals"] = {
					2351782.916027001, -- [1]
					1687072.922058, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = -0.01942799999999978,
						["debuff_uptime"] = 0,
						["dispell"] = -0.008010000000000295,
						["cooldowns_defensive"] = 9.949111000000002,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["__call"] = {
				},
				["data_inicio"] = "22:56:52",
				["end_time"] = 1638590614,
				["combat_id"] = 56,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["frags"] = {
					["Wild Mushroom"] = 1,
					["Bigshootings"] = 7,
					["Wild Mature Swine"] = 3,
				},
				["data_fim"] = "23:03:35",
				["contra"] = "Beast",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					2204177, -- [1]
					1687073, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 10,
					}, -- [4]
				},
				["start_time"] = 1638590211,
				["TimeData"] = {
				},
				["pvp"] = false,
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 55,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Beast <Bigshootings>"] = true,
								["Bigshootings"] = true,
								["Decapisbad"] = true,
								["Unknown"] = true,
								["Beast"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Bigshootings",
										["total"] = 359422,
									}, -- [1]
									{
										["nome"] = "Decapisbad",
										["total"] = 38068,
									}, -- [2]
									{
										["nome"] = "Unknown",
										["total"] = 52459,
									}, -- [3]
									{
										["nome"] = "Beast <Bigshootings>",
										["total"] = 11739,
									}, -- [4]
								},
							},
							["pets"] = {
								"Guardian of Ancient Kings <Dmgur>", -- [1]
							},
							["end_time"] = 1638590211,
							["last_event"] = 1638590211,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 377536.00268,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 461688.00268,
							["classe"] = "PALADIN",
							["damage_taken"] = 451353.00268,
							["nome"] = "Dmgur",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 32966,
										["g_amt"] = 0,
										["n_max"] = 6675,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 39641,
												}, -- [1]
											},
										},
										["n_dmg"] = 6675,
										["n_min"] = 6675,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 39641,
										["c_max"] = 17836,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 15130,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									}, -- [1]
									[35395] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 16650,
										["g_amt"] = 0,
										["n_max"] = 9700,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 9700,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 16650,
												}, -- [2]
											},
										},
										["n_dmg"] = 9700,
										["n_min"] = 9700,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 26350,
										["c_max"] = 16650,
										["id"] = 35395,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 16650,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[42463] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 13384,
										["g_amt"] = 0,
										["n_max"] = 1833,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 21449,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 1833,
												}, -- [2]
												{
													["nome"] = "Unknown",
													["total"] = 1607,
												}, -- [3]
											},
										},
										["n_dmg"] = 11505,
										["n_min"] = 1245,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 24889,
										["c_max"] = 3609,
										["id"] = 42463,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 3080,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[31803] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 9233,
										["g_amt"] = 0,
										["n_max"] = 4482,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 53507,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 4902,
												}, -- [2]
												{
													["nome"] = "Unknown",
													["total"] = 2451,
												}, -- [3]
											},
										},
										["n_dmg"] = 51627,
										["n_min"] = 896,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 60860,
										["c_max"] = 9233,
										["id"] = 31803,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 9233,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[879] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15600,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 39177,
												}, -- [1]
											},
										},
										["n_dmg"] = 39177,
										["n_min"] = 10609,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 39177,
										["c_max"] = 0,
										["id"] = 879,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[20271] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14368,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 60912,
												}, -- [1]
												{
													["nome"] = "Unknown",
													["total"] = 12406,
												}, -- [2]
											},
										},
										["n_dmg"] = 73318,
										["n_min"] = 9059,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 73318,
										["c_max"] = 0,
										["id"] = 20271,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[86704] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11739,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Unknown",
													["total"] = 28907,
												}, -- [1]
												{
													["nome"] = "Bigshootings",
													["total"] = 0,
												}, -- [2]
												{
													["nome"] = "Beast <Bigshootings>",
													["total"] = 11739,
												}, -- [3]
											},
										},
										["n_dmg"] = 40646,
										["n_min"] = 5705,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 40646,
										["c_max"] = 0,
										["id"] = 86704,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[96172] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6663,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 3881,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 6663,
												}, -- [2]
											},
										},
										["n_dmg"] = 10544,
										["n_min"] = 3881,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10544,
										["c_max"] = 0,
										["id"] = 96172,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[114916] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 20725,
										["g_amt"] = 0,
										["n_max"] = 22703,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 62111,
												}, -- [1]
											},
										},
										["n_dmg"] = 41386,
										["n_min"] = 2328,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 62111,
										["c_max"] = 9343,
										["id"] = 114916,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 4361,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
							},
							["custom"] = 0,
							["last_dps"] = 12090.64872108108,
							["colocacao"] = 1,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590175,
							["serial"] = "0x0700000000000469",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 8465,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Bigshootings",
										["total"] = 69044,
									}, -- [1]
									{
										["nome"] = "Decapisbad",
										["total"] = 8020,
									}, -- [2]
									{
										["nome"] = "Unknown",
										["total"] = 7088,
									}, -- [3]
								},
							},
							["pets"] = {
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 84152.002664,
							["last_event"] = 1638590202,
							["dps_started"] = false,
							["total"] = 84152.002664,
							["delay"] = 0,
							["ownerName"] = "Dmgur",
							["nome"] = "Guardian of Ancient Kings <Dmgur>",
							["damage_taken"] = 0.002664,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20598,
										["g_amt"] = 0,
										["n_max"] = 10299,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 69044,
												}, -- [1]
												{
													["nome"] = "Decapisbad",
													["total"] = 8020,
												}, -- [2]
												{
													["nome"] = "Unknown",
													["total"] = 7088,
												}, -- [3]
											},
										},
										["n_dmg"] = 63554,
										["n_min"] = 7088,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 84152,
										["c_max"] = 20598,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 20598,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									}, -- [1]
								},
							},
							["end_time"] = 1638590211,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590176,
							["serial"] = "0xF130B5AA000E5938",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 55,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.003612,
							["last_hps"] = 0,
							["healing_from"] = {
								["Dmgur"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 0,
										["total"] = 277464,
										["nome"] = "Dmgur",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.003612,
							["total_without_pet"] = 277464.003612,
							["totalover_without_pet"] = 0.003612,
							["fight_component"] = true,
							["end_time"] = 1638590211,
							["classe"] = "PALADIN",
							["total"] = 277464.003612,
							["nome"] = "Dmgur",
							["delay"] = 0,
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[130551] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 55900,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 186168,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 41074,
										["counter"] = 4,
										["overheal"] = 0,
										["total"] = 186168,
										["c_max"] = 0,
										["id"] = 130551,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 186168,
										["absorbed"] = 0,
									},
									[19750] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 46516,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 91296,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 44780,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 91296,
										["c_max"] = 0,
										["id"] = 19750,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 91296,
										["absorbed"] = 0,
									},
								},
							},
							["heal_enemy"] = {
							},
							["healing_taken"] = 277464.003612,
							["custom"] = 0,
							["last_event"] = 1638590211,
							["on_hold"] = false,
							["start_time"] = 1638590186,
							["serial"] = "0x0700000000000469",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 55,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 55,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 148,
							["nome"] = "Taintedtotem",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638590211,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[51470] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 51470,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 324,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[77747] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 77747,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[116956] = {
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 116956,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "SHAMAN",
							["tipo"] = 4,
							["serial"] = "0x0700000000000721",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[81326] = {
										["activedamt"] = 2,
										["uptime"] = 36,
										["id"] = 81326,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31803] = {
										["activedamt"] = 2,
										["uptime"] = 37,
										["id"] = 31803,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105421] = {
										["activedamt"] = 7,
										["uptime"] = 6,
										["id"] = 105421,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105593] = {
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = 105593,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 2,
										["uptime"] = 37,
										["id"] = 115798,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114916] = {
										["activedamt"] = 0,
										["uptime"] = 10,
										["id"] = 114916,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["cooldowns_defensive"] = 2.00488,
							["buff_uptime"] = 177,
							["last_cooldown"] = {
								1638590193.107, -- [1]
								498, -- [2]
							},
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[131634] = {
										["activedamt"] = 3,
										["uptime"] = 18,
										["id"] = 131634,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[125489] = {
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = 125489,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86700] = {
										["activedamt"] = 1,
										["uptime"] = 28,
										["id"] = 86700,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[84963] = {
										["activedamt"] = 1,
										["uptime"] = 33,
										["id"] = 84963,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1044] = {
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 1044,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31821] = {
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 31821,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[87173] = {
										["activedamt"] = 5,
										["uptime"] = 15,
										["id"] = 87173,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86698] = {
										["activedamt"] = 1,
										["uptime"] = 28,
										["id"] = 86698,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[59578] = {
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 59578,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114250] = {
										["activedamt"] = 4,
										["uptime"] = 17,
										["id"] = 114250,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[498] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "PALADIN",
							["cooldowns_defensive_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Dmgur",
										["total"] = 1,
									}, -- [1]
									{
										["nome"] = "[*] raid wide cooldown",
										["total"] = 1,
									}, -- [2]
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 127,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["cooldowns_defensive_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[498] = {
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dmgur",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
									[31821] = {
										["id"] = 31821,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "[*] raid wide cooldown",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
								},
							},
							["tipo"] = 4,
							["last_event"] = 1638590211,
							["nome"] = "Dmgur",
							["pets"] = {
							},
							["serial"] = "0x0700000000000469",
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [2]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["tipo"] = 2,
					["combatId"] = 55,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Dampfhammer"] = true,
					["Taintedtotem"] = true,
					["Weavil"] = true,
					["Nydan"] = true,
					["Dmgur"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Decapisbad",
				["combat_counter"] = 205,
				["totals"] = {
					461687.965853, -- [1]
					277463.981984, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = -0.007280999999999871,
						["cooldowns_defensive"] = 1.998944,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["Dmgur"] = {
						{
							true, -- [1]
							118253, -- [2]
							4802, -- [3]
							1638590215.06, -- [4]
							215458, -- [5]
							"Bigshootings", -- [6]
							nil, -- [7]
							8, -- [8]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["__call"] = {
				},
				["data_inicio"] = "22:56:15",
				["end_time"] = 1638590211,
				["combat_id"] = 55,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["frags"] = {
					["Bigshootings"] = 1,
				},
				["data_fim"] = "22:56:52",
				["contra"] = "Decapisbad",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					377536, -- [1]
					277464, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 2,
					}, -- [4]
				},
				["start_time"] = 1638590174,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 54,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Decapisbad"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Wild Mature Swine",
										["total"] = 20532,
									}, -- [1]
									{
										["nome"] = "Elder Mottled Boar",
										["total"] = 20532,
									}, -- [2]
									{
										["nome"] = "Bigshootings",
										["total"] = 19393,
									}, -- [3]
									{
										["nome"] = "Decapisbad",
										["total"] = 6774,
									}, -- [4]
								},
							},
							["pets"] = {
								"Guardian of Ancient Kings <Dmgur>", -- [1]
							},
							["end_time"] = 1638590174,
							["last_event"] = 1638590174,
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 60457.005369,
							["delay"] = 1638590139,
							["dps_started"] = false,
							["total"] = 67231.00536899999,
							["classe"] = "PALADIN",
							["damage_taken"] = 3113.005369,
							["nome"] = "Dmgur",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6661,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 6661,
												}, -- [1]
											},
										},
										["n_dmg"] = 6661,
										["n_min"] = 6661,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6661,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									}, -- [1]
									[96172] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2429,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 2429,
												}, -- [1]
											},
										},
										["n_dmg"] = 2429,
										["n_min"] = 2429,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 2429,
										["c_max"] = 0,
										["id"] = 96172,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[42463] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1317,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 2411,
												}, -- [1]
											},
										},
										["n_dmg"] = 2411,
										["n_min"] = 1094,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2411,
										["c_max"] = 0,
										["id"] = 42463,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[35395] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7892,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 7892,
												}, -- [1]
											},
										},
										["n_dmg"] = 7892,
										["n_min"] = 7892,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7892,
										["c_max"] = 0,
										["id"] = 35395,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[20271] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20532,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Wild Mature Swine",
													["total"] = 20532,
												}, -- [1]
												{
													["nome"] = "Elder Mottled Boar",
													["total"] = 20532,
												}, -- [2]
											},
										},
										["n_dmg"] = 41064,
										["n_min"] = 20532,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 41064,
										["c_max"] = 0,
										["id"] = 20271,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
							},
							["custom"] = 0,
							["last_dps"] = 1727.343010542857,
							["colocacao"] = 1,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590166,
							["serial"] = "0x0700000000000469",
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Beast <Bigshootings>"] = true,
								["Bigshootings"] = true,
								["Unknown"] = true,
								["Spirit Beast"] = true,
								["Beast"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["avoidance"] = {
								["Beast <Bigshootings>"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 1,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 1,
									["HITS"] = 1,
									["FULL_HIT_AMT"] = 2761,
								},
								["overall"] = {
									["DODGE"] = 2,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 140,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 9,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 140,
									["HITS"] = 86,
									["FULL_HIT_AMT"] = 521407,
								},
								["Bigshootings"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 55,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 55,
									["HITS"] = 14,
									["FULL_HIT_AMT"] = 275421,
								},
								["Unknown"] = {
									["DODGE"] = 1,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 56,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 1,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 56,
									["HITS"] = 49,
									["FULL_HIT_AMT"] = 150187,
								},
								["Spirit Beast"] = {
									["DODGE"] = 1,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 21,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 8,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 21,
									["HITS"] = 15,
									["FULL_HIT_AMT"] = 75414,
								},
								["Beast"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 7,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 7,
									["HITS"] = 7,
									["FULL_HIT_AMT"] = 17624,
								},
							},
							["pets"] = {
							},
							["delay"] = 0,
							["classe"] = "WARRIOR",
							["tipo"] = 1,
							["total_without_pet"] = 0.006027,
							["start_time"] = 1638589839,
							["dps_started"] = false,
							["end_time"] = 1638589839,
							["damage_taken"] = 521407.006027,
							["friendlyfire_total"] = 0,
							["nome"] = "Dampfhammer",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 0,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["total"] = 0.006027,
						}, -- [2]
						{
							["flag_original"] = 8465,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Decapisbad",
										["total"] = 6774,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 6774.006465,
							["last_event"] = 1638590174,
							["dps_started"] = false,
							["total"] = 6774.006465,
							["delay"] = 0,
							["ownerName"] = "Dmgur",
							["nome"] = "Guardian of Ancient Kings <Dmgur>",
							["damage_taken"] = 0.006465,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6774,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Decapisbad",
													["total"] = 6774,
												}, -- [1]
											},
										},
										["n_dmg"] = 6774,
										["n_min"] = 6774,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6774,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									}, -- [1]
								},
							},
							["end_time"] = 1638590174,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638590174,
							["serial"] = "0xF130B5AA000E5938",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 54,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 54,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 54,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 140,
							["nome"] = "Taintedtotem",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638589839,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[51470] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 51470,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 324,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[77747] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 77747,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[116956] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 116956,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "SHAMAN",
							["tipo"] = 4,
							["serial"] = "0x0700000000000721",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 140,
							["nome"] = "Weavil",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638589839,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[77769] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 77769,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[19506] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 19506,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[8221] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 8221,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[63963] = {
										["activedamt"] = 1,
										["uptime"] = 35,
										["id"] = 63963,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "HUNTER",
							["tipo"] = 4,
							["serial"] = "0x070000000000049B",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [2]
						{
							["flag_original"] = 1298,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["tipo"] = 4,
							["pets"] = {
							},
							["nome"] = "Dampfhammer",
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[145674] = {
										["activedamt"] = 1,
										["uptime"] = 27,
										["id"] = 145674,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[12880] = {
										["activedamt"] = 3,
										["uptime"] = 14,
										["id"] = 12880,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[84619] = {
										["activedamt"] = 2,
										["uptime"] = 20,
										["id"] = 84619,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["last_event"] = 1638589839,
							["buff_uptime"] = 61,
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["classe"] = "WARRIOR",
						}, -- [3]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["tipo"] = 2,
					["combatId"] = 54,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Dampfhammer"] = true,
					["Taintedtotem"] = true,
					["Weavil"] = true,
					["Nydan"] = true,
					["Dmgur"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Unknown",
				["combat_counter"] = 204,
				["totals"] = {
					67230.9543819995, -- [1]
					-0.016471, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = -0.003859000000000279,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["Dmgur"] = {
						{
							true, -- [1]
							1, -- [2]
							3113, -- [3]
							1638590177.862, -- [4]
							388575, -- [5]
							"Decapisbad", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = false,
				["__call"] = {
				},
				["data_inicio"] = "22:50:05",
				["end_time"] = 1638589839,
				["combat_id"] = 54,
				["hasSaved"] = true,
				["frags"] = {
				},
				["data_fim"] = "22:50:40",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					60457, -- [1]
					0, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1638589804,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 53,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["damage_from"] = {
								["Beast <Bigshootings>"] = true,
								["Bigshootings"] = true,
								["Unknown"] = true,
								["Spirit Beast"] = true,
								["Beast"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Bigshootings",
										["total"] = 810687,
									}, -- [1]
									{
										["nome"] = "Spirit Beast",
										["total"] = 69008,
									}, -- [2]
								},
							},
							["pets"] = {
								"Guardian of Ancient Kings <Dmgur>", -- [1]
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["tipo"] = 1,
							["classe"] = "PALADIN",
							["total_without_pet"] = 774534.001378,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1638589770,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 647962.001378,
							["nome"] = "Dmgur",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 17708,
										["g_amt"] = 0,
										["n_max"] = 9480,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 68012,
												}, -- [1]
											},
										},
										["n_dmg"] = 50304,
										["n_min"] = 7224,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 68012,
										["c_max"] = 17708,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 17708,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["MISS"] = 2,
									}, -- [1]
									[24275] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36042,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 105866,
												}, -- [1]
											},
										},
										["n_dmg"] = 105866,
										["n_min"] = 17103,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 105866,
										["c_max"] = 0,
										["id"] = 24275,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["MISS"] = 1,
									},
									[35395] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10750,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 28948,
												}, -- [1]
											},
										},
										["n_dmg"] = 28948,
										["n_min"] = 8639,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 28948,
										["c_max"] = 0,
										["id"] = 35395,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["MISS"] = 1,
									},
									[879] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 89977,
										["g_amt"] = 0,
										["n_max"] = 14572,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 104549,
												}, -- [1]
											},
										},
										["n_dmg"] = 14572,
										["n_min"] = 14572,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 104549,
										["c_max"] = 57101,
										["id"] = 879,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 32876,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[96172] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17729,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 91207,
												}, -- [1]
											},
										},
										["n_dmg"] = 91207,
										["n_min"] = 2942,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 91207,
										["c_max"] = 0,
										["id"] = 96172,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[20271] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 25142,
										["g_amt"] = 0,
										["n_max"] = 25587,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 128101,
												}, -- [1]
											},
										},
										["n_dmg"] = 102959,
										["n_min"] = 12205,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 128101,
										["c_max"] = 25142,
										["id"] = 20271,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 25142,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[31803] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 31188,
										["g_amt"] = 0,
										["n_max"] = 6225,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 104525,
												}, -- [1]
											},
										},
										["n_dmg"] = 73337,
										["n_min"] = 1376,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 104525,
										["c_max"] = 13445,
										["id"] = 31803,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 8332,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[42463] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 12241,
										["g_amt"] = 0,
										["n_max"] = 2354,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 41745,
												}, -- [1]
											},
										},
										["n_dmg"] = 29504,
										["n_min"] = 1350,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 41745,
										["c_max"] = 4752,
										["id"] = 42463,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 3684,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[85256] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 44300,
										["g_amt"] = 0,
										["n_max"] = 29576,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 95309,
												}, -- [1]
											},
										},
										["n_dmg"] = 51009,
										["n_min"] = 21433,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 95309,
										["c_max"] = 44300,
										["id"] = 85256,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 44300,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[86704] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6272,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Spirit Beast",
													["total"] = 6272,
												}, -- [1]
											},
										},
										["n_dmg"] = 6272,
										["n_min"] = 6272,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6272,
										["c_max"] = 0,
										["id"] = 86704,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
							},
							["custom"] = 0,
							["last_dps"] = 16290.64817366667,
							["colocacao"] = 1,
							["last_event"] = 1638589770,
							["on_hold"] = false,
							["start_time"] = 1638589716,
							["serial"] = "0x0700000000000469",
							["total"] = 879695.001378,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["damage_from"] = {
								["Unknown"] = true,
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["classe"] = "WARRIOR",
							["pets"] = {
							},
							["delay"] = 0,
							["friendlyfire_total"] = 0,
							["last_event"] = 0,
							["total_without_pet"] = 0.006311,
							["start_time"] = 1638589804,
							["dps_started"] = false,
							["total"] = 0.006311,
							["damage_taken"] = 1980.006311,
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["nome"] = "Dampfhammer",
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["last_dps"] = 0,
							["end_time"] = 1638589804,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 4,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 4,
									["HITS"] = 4,
									["FULL_HIT_AMT"] = 1980,
								},
								["Unknown"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 4,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 4,
									["HITS"] = 4,
									["FULL_HIT_AMT"] = 1980,
								},
							},
						}, -- [2]
						{
							["flag_original"] = 8465,
							["damage_from"] = {
							},
							["targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Bigshootings",
										["total"] = 42425,
									}, -- [1]
									{
										["nome"] = "Spirit Beast",
										["total"] = 62736,
									}, -- [2]
								},
							},
							["pets"] = {
							},
							["friendlyfire"] = {
								["tipo"] = 5,
								["_ActorTable"] = {
								},
							},
							["friendlyfire_total"] = 0,
							["total_without_pet"] = 105161.005594,
							["last_event"] = 1638589749,
							["dps_started"] = false,
							["total"] = 105161.005594,
							["delay"] = 1638589749,
							["ownerName"] = "Dmgur",
							["nome"] = "Guardian of Ancient Kings <Dmgur>",
							["damage_taken"] = 0.005594,
							["spell_tables"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12156,
										["targets"] = {
											["tipo"] = 6,
											["_ActorTable"] = {
												{
													["nome"] = "Bigshootings",
													["total"] = 42425,
												}, -- [1]
												{
													["nome"] = "Spirit Beast",
													["total"] = 62736,
												}, -- [2]
											},
										},
										["n_dmg"] = 105161,
										["n_min"] = 8933,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 105161,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									}, -- [1]
								},
							},
							["end_time"] = 1638589770,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1638589740,
							["serial"] = "0xF130B5AA000E5462",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 53,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.0039,
							["last_hps"] = 0,
							["healing_from"] = {
								["Dmgur"] = true,
							},
							["targets"] = {
								["tipo"] = 4,
								["_ActorTable"] = {
									{
										["overheal"] = 76315,
										["total"] = 437821,
										["nome"] = "Dmgur",
										["absorbed"] = 0,
									}, -- [1]
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 76315.0039,
							["total_without_pet"] = 437821.0039,
							["totalover_without_pet"] = 0.0039,
							["fight_component"] = true,
							["end_time"] = 1638589770,
							["classe"] = "PALADIN",
							["total"] = 437821.0039,
							["nome"] = "Dmgur",
							["delay"] = 1638589749,
							["grupo"] = true,
							["spell_tables"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[130551] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["n_max"] = 72954,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 76315,
													["total"] = 326628,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 37246,
										["counter"] = 5,
										["overheal"] = 76315,
										["total"] = 326628,
										["c_max"] = 72474,
										["id"] = 130551,
										["c_min"] = 72474,
										["c_curado"] = 72474,
										["n_amt"] = 4,
										["n_curado"] = 254154,
										["absorbed"] = 0,
									},
									[115547] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["n_max"] = 3369,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 33354,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 3321,
										["counter"] = 10,
										["overheal"] = 0,
										["total"] = 33354,
										["c_max"] = 0,
										["id"] = 115547,
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 10,
										["n_curado"] = 33354,
										["absorbed"] = 0,
									},
									[114917] = {
										["c_amt"] = 2,
										["totalabsorb"] = 0,
										["n_max"] = 31147,
										["targets"] = {
											["tipo"] = 4,
											["_ActorTable"] = {
												{
													["overheal"] = 0,
													["total"] = 77839,
													["nome"] = "Dmgur",
													["absorbed"] = 0,
												}, -- [1]
											},
										},
										["n_min"] = 3193,
										["counter"] = 10,
										["overheal"] = 0,
										["total"] = 77839,
										["c_max"] = 7959,
										["id"] = 114917,
										["c_min"] = 6067,
										["c_curado"] = 14026,
										["n_amt"] = 8,
										["n_curado"] = 63813,
										["absorbed"] = 0,
									},
								},
							},
							["heal_enemy"] = {
							},
							["healing_taken"] = 437821.0039,
							["custom"] = 0,
							["last_event"] = 1638589767,
							["on_hold"] = false,
							["start_time"] = 1638589740,
							["serial"] = "0x0700000000000469",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 53,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 53,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 216,
							["nome"] = "Taintedtotem",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638589770,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[51470] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 51470,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[324] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 324,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[77747] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 77747,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[116956] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 116956,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "SHAMAN",
							["tipo"] = 4,
							["serial"] = "0x0700000000000721",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime"] = 216,
							["nome"] = "Weavil",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1638589770,
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[77769] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 77769,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[19506] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 19506,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[8221] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 8221,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[63963] = {
										["activedamt"] = 1,
										["uptime"] = 54,
										["id"] = 63963,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "HUNTER",
							["tipo"] = 4,
							["serial"] = "0x070000000000049B",
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [2]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["tipo"] = 4,
							["pets"] = {
							},
							["nome"] = "Dampfhammer",
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[469] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 469,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["last_event"] = 1638589726,
							["buff_uptime"] = 10,
							["isTank"] = true,
							["serial"] = "0x0700000000000708",
							["classe"] = "WARRIOR",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[81326] = {
										["activedamt"] = 0,
										["uptime"] = 47,
										["id"] = 81326,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31803] = {
										["activedamt"] = 0,
										["uptime"] = 54,
										["id"] = 31803,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105421] = {
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = 105421,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105593] = {
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = 105593,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115798] = {
										["activedamt"] = 0,
										["uptime"] = 46,
										["id"] = 115798,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["cooldowns_defensive"] = 1.006033,
							["buff_uptime"] = 339,
							["last_cooldown"] = {
								1638589744.369, -- [1]
								498, -- [2]
							},
							["buff_uptime_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[131634] = {
										["activedamt"] = 3,
										["uptime"] = 22,
										["id"] = 131634,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86698] = {
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = 86698,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[125489] = {
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = 125489,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[86700] = {
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = 86700,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[1044] = {
										["activedamt"] = 2,
										["uptime"] = 12,
										["id"] = 1044,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114917] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 114917,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[84963] = {
										["activedamt"] = 1,
										["uptime"] = 48,
										["id"] = 84963,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[96229] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 96229,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[114250] = {
										["activedamt"] = 2,
										["uptime"] = 51,
										["id"] = 114250,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[115547] = {
										["activedamt"] = 1,
										["uptime"] = 20,
										["id"] = 115547,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[105809] = {
										["activedamt"] = 1,
										["uptime"] = 18,
										["id"] = 105809,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[87173] = {
										["activedamt"] = 8,
										["uptime"] = 20,
										["id"] = 87173,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[126679] = {
										["activedamt"] = 1,
										["uptime"] = 19,
										["id"] = 126679,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[498] = {
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[59578] = {
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 59578,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
									[31884] = {
										["activedamt"] = 1,
										["uptime"] = 20,
										["id"] = 31884,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
											},
										},
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["classe"] = "PALADIN",
							["cooldowns_defensive_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
									{
										["nome"] = "Dmgur",
										["total"] = 1,
									}, -- [1]
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 159,
							["buff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["cooldowns_defensive_spell_tables"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[498] = {
										["id"] = 498,
										["targets"] = {
											["tipo"] = 10,
											["_ActorTable"] = {
												{
													["nome"] = "Dmgur",
													["total"] = 1,
												}, -- [1]
											},
										},
										["counter"] = 1,
									},
								},
							},
							["tipo"] = 4,
							["last_event"] = 1638589770,
							["nome"] = "Dmgur",
							["pets"] = {
							},
							["serial"] = "0x0700000000000469",
							["debuff_uptime_targets"] = {
								["tipo"] = 6,
								["_ActorTable"] = {
								},
							},
						}, -- [4]
					},
				}, -- [4]
				{
					["_NameIndexTable"] = {
					},
					["tipo"] = 2,
					["combatId"] = 53,
					["_ActorTable"] = {
					},
					["need_refresh"] = true,
				}, -- [5]
				["raid_roster"] = {
					["Dampfhammer"] = true,
					["Taintedtotem"] = true,
					["Weavil"] = true,
					["Nydan"] = true,
					["Dmgur"] = true,
				},
				["last_events_tables"] = {
				},
				["enemy"] = "Spirit Beast",
				["combat_counter"] = 203,
				["totals"] = {
					879694.9492899999, -- [1]
					437820.9736769999, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = -0.001221000000000139,
						["cooldowns_defensive"] = 0.990227,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["Dampfhammer"] = {
						{
							true, -- [1]
							1, -- [2]
							495, -- [3]
							1638589806.024, -- [4]
							517515, -- [5]
							"Unknown", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [1]
						{
							true, -- [1]
							1, -- [2]
							495, -- [3]
							1638589806.024, -- [4]
							517515, -- [5]
							"Unknown", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [2]
						{
							true, -- [1]
							1, -- [2]
							495, -- [3]
							1638589806.024, -- [4]
							517515, -- [5]
							"Unknown", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [3]
						{
							true, -- [1]
							1, -- [2]
							495, -- [3]
							1638589806.024, -- [4]
							517515, -- [5]
							"Unknown", -- [6]
							nil, -- [7]
							1, -- [8]
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						["n"] = 5,
					},
				},
				["frags_need_refresh"] = true,
				["__call"] = {
				},
				["data_inicio"] = "22:48:37",
				["end_time"] = 1638589770,
				["combat_id"] = 53,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["frags"] = {
					["Torque"] = 1,
					["Bigshootings"] = 2,
				},
				["data_fim"] = "22:49:31",
				["contra"] = "Spirit Beast",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					774534, -- [1]
					437821, -- [2]
					{
						["e_rage"] = 0,
						["mana"] = 0,
						["runepower"] = 0,
						["e_energy"] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 1,
					}, -- [4]
				},
				["start_time"] = 1638589716,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [5]
		},
	},
	["tabela_instancias"] = {
	},
	["combat_id"] = 57,
	["savedStyles"] = {
	},
	["savedbuffs"] = {
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["SoloTablesSaved"] = {
		["LastSelected"] = "DETAILS_PLUGIN_TIME_ATTACK",
		["Mode"] = 3,
	},
	["last_version"] = "v1.29.3",
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = true,
			["verticalSnap"] = false,
			["is_open"] = true,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				2, -- [1]
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -414.8136444091797,
					["x"] = 742.1146240234375,
					["w"] = 222.4377288818359,
					["h"] = 130.3727111816406,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = 1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = true,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = true,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[3] = 1,
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -414.8136444091797,
					["x"] = 539.4969482421875,
					["w"] = 182.7975921630859,
					["h"] = 130.3727111816406,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 1,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-005,
					["w"] = 320.0001525878906,
					["h"] = 129.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300.0000610351563,
					["h"] = 299.9999694824219,
				},
			},
		}, -- [3]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-005,
					["w"] = 320.0001525878906,
					["h"] = 129.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [4]
	},
	["last_instance_time"] = 1638586795,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1639765874,
		["last_version"] = 6,
	},
	["last_instance_id"] = 1011,
}
