
_detalhes_databaseVanguard = {
}
