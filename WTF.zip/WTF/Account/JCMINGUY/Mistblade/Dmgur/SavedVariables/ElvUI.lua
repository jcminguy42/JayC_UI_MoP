
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/gladius config", -- [1]
		"/gladius hide", -- [2]
		"/s Any PPCers in the chattuh", -- [3]
		"/elvui", -- [4]
	},
	["ChatHistoryLog"] = {
		{
			"Zephyr ? any chance you set me to current gm of my guild if you're not too busy please ?", -- [1]
			"Reichu-Lotus", -- [2]
			"Orcish", -- [3]
			"", -- [4]
			"Reichu", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			6, -- [11]
			"0x0700000000000102", -- [12]
			0, -- [13]
			false, -- [14]
			false, -- [15]
			[52] = "Reichu",
			[51] = 1638558474,
			[50] = "CHAT_MSG_SAY",
		}, -- [1]
		{
			"Manually adjusting that inside the database will only cause troubles", -- [1]
			"Zephyr", -- [2]
			"", -- [3]
			"", -- [4]
			"Zephyr", -- [5]
			"GM", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			8, -- [11]
			false, -- [12]
			0, -- [13]
			false, -- [14]
			false, -- [15]
			[52] = "Zephyr",
			[51] = 1638558492,
			[50] = "CHAT_MSG_SAY",
		}, -- [2]
	},
}
