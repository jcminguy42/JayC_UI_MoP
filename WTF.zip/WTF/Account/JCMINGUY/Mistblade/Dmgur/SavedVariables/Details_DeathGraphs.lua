
DeathGraphsDBDeaths = {
}
DeathGraphsDBEndurance = {
}
