
BagnonFrameSettings = {
	["version"] = "5.4.15",
	["frames"] = {
		["inventory"] = {
			["frameColor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0.8661612719297409, -- [4]
			},
			["hasBagFrame"] = false,
			["frameBorderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
			},
			["y"] = 150.0000152587891,
			["hasDBOFrame"] = false,
		},
	},
}
