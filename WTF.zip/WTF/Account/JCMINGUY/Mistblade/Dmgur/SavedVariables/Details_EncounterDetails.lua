
EncounterDetailsDB = {
	["emotes"] = {
		{
			["boss"] = "Wing Leader Ner'onok",
		}, -- [1]
		{
			["boss"] = "General Pa'valak",
		}, -- [2]
		{
			["boss"] = "Commander Vo'jak",
		}, -- [3]
	},
}
