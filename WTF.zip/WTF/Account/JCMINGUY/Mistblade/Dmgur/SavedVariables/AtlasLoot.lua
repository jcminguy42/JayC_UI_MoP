
AtlasLootCharDB = {
	["namespaces"] = {
		["WishList"] = {
		},
	},
	["profileKeys"] = {
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
	},
	["AtlasLootVersion"] = "70703",
}
