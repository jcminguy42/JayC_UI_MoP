
MapsterDB = {
	["namespaces"] = {
		["GroupIcons"] = {
		},
		["Coords"] = {
		},
		["FogClear"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 1,
				},
			},
		},
		["BattleMap"] = {
		},
	},
	["profileKeys"] = {
		["Lotusprep - [EN] Evermoon"] = "Default",
		["Dmgur - Lotus"] = "Default",
		["Dmgurx - Lotus"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["scale"] = 0.85,
			["hideMapButton"] = true,
			["modules"] = {
				["Coords"] = false,
			},
		},
	},
}
