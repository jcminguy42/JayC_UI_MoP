
SimulationcraftDB = {
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
