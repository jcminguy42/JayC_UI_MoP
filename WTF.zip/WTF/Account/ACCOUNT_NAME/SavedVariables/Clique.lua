
CliqueDB = nil
CliqueDB3 = {
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["profiles"] = {
		["Wafty - Mistblade"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "SHIFT-BUTTON3",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["spell"] = "Greater Healing Wave",
					["key"] = "ALT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					["type"] = "spell",
				}, -- [2]
				{
					["type"] = "menu",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
				}, -- [3]
				{
					["spell"] = "Healing Surge",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Riptide",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\spell_nature_riptide",
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Purify Spirit",
					["key"] = "F6",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Ability_Shaman_CleanseSpirit",
					["type"] = "spell",
				}, -- [6]
				{
					["spell"] = "Unleash Elements",
					["key"] = "E",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Shaman_ImprovedStormstrike",
					["type"] = "spell",
				}, -- [7]
				{
					["spell"] = "Chain Heal",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					["type"] = "spell",
				}, -- [8]
				{
					["spell"] = "Healing Wave",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Earth Shield",
					["key"] = "Q",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					["type"] = "spell",
				}, -- [10]
			},
		},
	},
}
