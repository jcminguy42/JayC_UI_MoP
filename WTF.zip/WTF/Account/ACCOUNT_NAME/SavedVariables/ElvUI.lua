
ElvDB = {
	["gold"] = {
		["[EN] Evermoon"] = {
			["Lotusprep"] = 0,
		},
		["Lotus"] = {
			["Dmgur"] = 455817297,
		},
		["Mistblade"] = {
			["Wafty"] = 89232760,
		},
	},
	["global"] = {
		["general"] = {
			["WorldMapCoordinates"] = {
				["enable"] = false,
			},
			["UIScale"] = 0.85,
		},
		["ignoreIncompatible"] = true,
		["unitframe"] = {
			["aurafilters"] = {
				["Ret"] = {
					["type"] = "Whitelist",
					["spells"] = {
						[31801] = {
							["enable"] = false,
							["priority"] = 1,
							["stackThreshold"] = 0,
						},
						[31803] = {
							["enable"] = true,
							["priority"] = 1,
							["stackThreshold"] = 0,
						},
					},
				},
				["Blacklist"] = {
					["spells"] = {
						[17364] = {
							["enable"] = true,
							["priority"] = 0,
							["stackThreshold"] = 0,
						},
					},
				},
				["Enhancement"] = {
					["type"] = "Whitelist",
					["spells"] = {
						[8050] = {
							["enable"] = true,
							["priority"] = 0,
							["stackThreshold"] = 0,
						},
					},
				},
				["Arms"] = {
					["type"] = "Whitelist",
					["spells"] = {
						[47465] = {
							["enable"] = true,
							["priority"] = 2,
							["stackThreshold"] = 0,
						},
						[58567] = {
							["enable"] = true,
							["priority"] = 1,
							["stackThreshold"] = 5,
						},
						[""] = {
							["enable"] = true,
							["priority"] = 0,
							["stackThreshold"] = 0,
						},
					},
				},
			},
		},
		["nameplates"] = {
			["filters"] = {
				["ElvUI_NonTarget"] = {
				},
				["ElvUI_Totem"] = {
				},
				["ElvUI_Target"] = {
				},
				["ElvUI_Boss"] = {
				},
			},
		},
	},
	["faction"] = {
		["[EN] Evermoon"] = {
			["Lotusprep"] = "Horde",
		},
		["Lotus"] = {
			["Dmgur"] = "Horde",
		},
		["Mistblade"] = {
			["Wafty"] = "Horde",
		},
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["class"] = {
		["[EN] Evermoon"] = {
			["Lotusprep"] = "PALADIN",
		},
		["Lotus"] = {
			["Dmgur"] = "PALADIN",
		},
		["Mistblade"] = {
			["Wafty"] = "SHAMAN",
		},
	},
	["profileKeys"] = {
		["Lotusprep - [EN] Evermoon"] = "DarkTheme",
		["Wafty - Mistblade"] = "DarkTheme",
		["Dmgur - Lotus"] = "DarkTheme",
	},
	["profiles"] = {
		["Wafty - Mistblade"] = {
		},
		["Lotusprep - [EN] Evermoon"] = {
			["currentTutorial"] = 1,
		},
		["DarkTheme"] = {
			["databars"] = {
				["threat"] = {
					["font"] = "Homespun",
					["reverseFill"] = true,
					["height"] = 5,
					["fontOutline"] = "OUTLINE",
					["width"] = 220,
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["width"] = 340,
					["font"] = "Naowh",
					["fontOutline"] = "OUTLINE",
					["height"] = 8,
					["hideInCombat"] = true,
					["orientation"] = "HORIZONTAL",
				},
				["honor"] = {
					["enable"] = false,
					["font"] = "Naowh",
					["fontOutline"] = "OUTLINE",
				},
				["reputation"] = {
					["font"] = "Naowh",
					["fontOutline"] = "OUTLINE",
				},
				["azerite"] = {
					["textFormat"] = "PERCENT",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Naowh",
					["height"] = 8,
					["width"] = 340,
				},
			},
			["currentTutorial"] = 1,
			["bags"] = {
				["itemLevelFont"] = "Arial Narrow",
				["junkIcon"] = true,
				["itemLevel"] = false,
				["moneyFormat"] = "BLIZZARD",
				["countFontSize"] = 12,
				["upgradeIcon"] = false,
				["itemLevelFontSize"] = 12,
				["sortInverted"] = false,
				["bagWidth"] = 362,
				["countFont"] = "Arial Narrow",
				["vendorGrays"] = {
					["enable"] = true,
				},
				["professionBagColors"] = false,
				["countFontOutline"] = "THICKOUTLINE",
				["bankWidth"] = 474,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["font"] = "GothamNarrowUltra",
					},
				},
				["itemLevelFontOutline"] = "OUTLINE",
			},
			["hideTutorial"] = 1,
			["chat"] = {
				["tabFontOutline"] = "OUTLINE",
				["lfgIcons"] = false,
				["chatHistory"] = false,
				["separateSizes"] = true,
				["panelHeightRight"] = 225,
				["font"] = "Arial Narrow",
				["panelWidth"] = 450,
				["fontSize"] = 12,
				["emotionIcons"] = false,
				["panelColorConverted"] = true,
				["panelHeight"] = 210,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelWidthRight"] = 352,
				["panelBackdrop"] = "HIDEBOTH",
				["hideChatToggles"] = true,
				["inactivityTimer"] = 60,
				["tabFont"] = "Arial Narrow",
			},
			["tooltip"] = {
				["fontOutline"] = "OUTLINE",
				["npcID"] = false,
				["healthBar"] = {
					["statusPosition"] = "TOP",
					["font"] = "Arial Narrow",
					["fontSize"] = 12,
				},
				["guildRanks"] = false,
				["font"] = "Arial Narrow",
				["fontSize"] = 12,
				["visibility"] = {
					["combatOverride"] = "HIDE",
				},
			},
			["general"] = {
				["totems"] = {
					["spacing"] = 1,
					["size"] = 28,
				},
				["valuecolor"] = {
					["b"] = 0.4352941176470588,
					["g"] = 0.4352941176470588,
					["r"] = 0.4352941176470588,
				},
				["loginmessage"] = false,
				["threat"] = {
					["textfont"] = "Arial Narrow",
					["textOutline"] = "OUTLINE",
				},
				["autoRoll"] = true,
				["font"] = "Arial Narrow",
				["altPowerBar"] = {
					["fontSize"] = 14,
					["smoothbars"] = true,
					["font"] = "Naowh",
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFont"] = "Arial Narrow",
				},
				["bottomPanel"] = false,
				["backdropcolor"] = {
					["a"] = 1,
				},
				["objectiveFrameHeight"] = 450,
				["itemLevel"] = {
					["itemLevelFont"] = "Arial Narrow",
				},
			},
			["unitframe"] = {
				["targetOnMouseDown"] = true,
				["fontSize"] = 12,
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["colorOverride"] = "FORCE_ON",
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["height"] = 5,
							["enable"] = false,
						},
						["width"] = 100,
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[namecolor][name:short]",
							["yOffset"] = 14,
						},
						["height"] = 16,
						["raidicon"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["debuffs"] = {
							["sizeOverride"] = 36,
							["enable"] = true,
							["yOffset"] = 10,
							["anchorPoint"] = "LEFT",
							["priority"] = "Blacklist,Personal",
							["perrow"] = 1,
							["xOffset"] = -1,
						},
						["enable"] = false,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["buffIndicator"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["height"] = 5,
							["enable"] = false,
						},
						["width"] = 99,
						["infoPanel"] = {
							["height"] = 14,
						},
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name:short]",
							["yOffset"] = 14,
						},
						["height"] = 16,
						["buffs"] = {
							["sizeOverride"] = 46,
							["priority"] = "CastByNPC",
						},
						["castbar"] = {
							["enable"] = false,
							["iconSize"] = 32,
							["width"] = 340,
							["height"] = 24,
						},
					},
					["focustarget"] = {
						["disableTargetGlow"] = true,
						["castbar"] = {
							["width"] = 64,
						},
						["width"] = 64,
						["name"] = {
							["position"] = "LEFT",
							["text_format"] = "[namecolor][name:short]",
							["yOffset"] = 14,
						},
						["power"] = {
							["height"] = 4,
						},
						["height"] = 16,
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["raid"] = {
						["threatStyle"] = "BORDERS",
						["GPSArrow"] = {
							["enable"] = false,
						},
						["debuffs"] = {
							["countFontSize"] = 11,
							["sizeOverride"] = 16,
							["enable"] = true,
							["anchorPoint"] = "CENTER",
							["clickThrough"] = true,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["perrow"] = 1,
							["xOffset"] = 1,
						},
						["name"] = {
							["text_format"] = "[namecolor][name:veryshort]",
						},
						["height"] = 40,
						["buffs"] = {
							["anchorPoint"] = "TOPRIGHT",
						},
						["raidicon"] = {
							["attachTo"] = "TOPRIGHT",
							["enable"] = false,
							["yOffset"] = 0,
						},
						["horizontalSpacing"] = 0,
						["rdebuffs"] = {
							["xOffset"] = 30,
							["showDispellableDebuff"] = false,
							["font"] = "Arial Narrow",
							["fontOutline"] = "OUTLINE",
							["stack"] = {
								["xOffset"] = 4,
								["yOffset"] = -5,
								["position"] = "RIGHT",
							},
							["size"] = 17,
						},
						["colorOverride"] = "FORCE_ON",
						["growthDirection"] = "DOWN_RIGHT",
						["roleIcon"] = {
							["damager"] = false,
							["size"] = 16,
						},
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["text_format"] = "",
							["yOffset"] = 4,
						},
						["numGroups"] = 8,
						["verticalSpacing"] = 1,
					},
					["target"] = {
						["debuffs"] = {
							["sizeOverride"] = 32,
							["yOffset"] = -98,
							["anchorPoint"] = "TOPLEFT",
							["countFont"] = "Arial Narrow",
							["perrow"] = 4,
							["attachTo"] = "FRAME",
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["threatStyle"] = "HEALTHBORDER",
						["customTexts"] = {
							["Power text"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[power:current]",
								["yOffset"] = -22,
								["font"] = "Naowh",
								["justifyH"] = "RIGHT",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -2,
								["size"] = 8,
							},
						},
						["healPrediction"] = {
							["enable"] = false,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[name:abbrev]",
							["yOffset"] = -10,
						},
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 27,
							["yOffset"] = -1,
							["anchorPoint"] = "TOPLEFT",
							["sortDirection"] = "ASCENDING",
							["priority"] = "Blacklist,Personal,Boss,nonPersonal",
							["numrows"] = 3,
							["countFont"] = "Arial Narrow",
						},
						["raidicon"] = {
							["attachTo"] = "CENTER",
							["enable"] = false,
							["yOffset"] = 2,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = 0,
							["text_format"] = "",
							["yOffset"] = -20,
							["strataAndLevel"] = {
								["useCustomLevel"] = true,
								["frameLevel"] = 8,
							},
							["position"] = "CENTER",
							["detachedWidth"] = 220,
							["height"] = 15,
							["detachFromFrame"] = true,
						},
						["portrait"] = {
							["overlay"] = true,
						},
						["width"] = 220,
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 0,
							["text_format"] = "   [health:current-percent]",
							["yOffset"] = 7,
						},
						["colorOverride"] = "FORCE_ON",
						["castbar"] = {
							["xOffsetText"] = 5,
							["iconSize"] = 20,
							["iconXOffset"] = 18,
							["iconAttachedTo"] = "Castbar",
							["width"] = 220,
							["height"] = 23,
						},
					},
					["player"] = {
						["debuffs"] = {
							["enable"] = false,
							["yOffset"] = 3,
							["perrow"] = 6,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["additionalPowerText"] = false,
							["height"] = 29,
							["autoHide"] = true,
							["detachedWidth"] = 300,
						},
						["threatStyle"] = "NONE",
						["healPrediction"] = {
							["enable"] = false,
						},
						["name"] = {
							["position"] = "TOPLEFT",
							["xOffset"] = 4,
							["yOffset"] = 14,
						},
						["height"] = 36,
						["raidicon"] = {
							["attachTo"] = "CENTER",
							["enable"] = false,
							["yOffset"] = 2,
						},
						["colorOverride"] = "FORCE_ON",
						["aurabar"] = {
							["enable"] = false,
						},
						["RestIcon"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["icon"] = false,
							["width"] = 444,
							["height"] = 20,
							["latency"] = false,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
							["height"] = 20,
							["hideonnpc"] = true,
							["detachFromFrame"] = true,
							["detachedWidth"] = 444,
						},
						["portrait"] = {
							["overlay"] = true,
							["fullOverlay"] = true,
							["overlayAlpha"] = 0.19,
						},
						["width"] = 444,
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "BOTTOMRIGHT",
							["xOffset"] = 0,
							["text_format"] = "",
							["yOffset"] = -18,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
					},
					["raid40"] = {
						["disableTargetGlow"] = true,
						["groupBy"] = "ROLE",
						["threatStyle"] = "BORDERS",
						["GPSArrow"] = {
							["size"] = 40,
						},
						["debuffs"] = {
							["countFontSize"] = 11,
							["sizeOverride"] = 16,
							["anchorPoint"] = "CENTER",
							["clickThrough"] = true,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["perrow"] = 1,
							["xOffset"] = 1,
						},
						["height"] = 40,
						["verticalSpacing"] = 1,
						["raidicon"] = {
							["attachTo"] = "TOPRIGHT",
							["enable"] = false,
							["yOffset"] = 0,
						},
						["horizontalSpacing"] = 0,
						["rdebuffs"] = {
							["xOffset"] = 69,
							["yOffset"] = 2,
							["font"] = "Arial Narrow",
							["fontOutline"] = "OUTLINE",
							["stack"] = {
								["xOffset"] = 4,
								["position"] = "RIGHT",
								["yOffset"] = -5,
							},
							["size"] = 17,
						},
						["colorOverride"] = "FORCE_ON",
						["growthDirection"] = "RIGHT_UP",
						["roleIcon"] = {
							["xOffset"] = 0,
							["yOffset"] = 0,
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "",
							["yOffset"] = 4,
						},
						["buffs"] = {
							["anchorPoint"] = "TOPRIGHT",
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "BOTTOMRIGHT",
						},
						["disableTargetGlow"] = true,
						["CombatIcon"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["iconSize"] = 44,
							["iconXOffset"] = -2,
							["iconAttached"] = false,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "Arial Narrow",
								["fontSize"] = 11,
							},
							["width"] = 140,
							["height"] = 20,
							["iconYOffset"] = -8,
							["latency"] = false,
						},
						["width"] = 140,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["height"] = 4,
							["enable"] = false,
						},
						["height"] = 28,
						["name"] = {
							["position"] = "LEFT",
							["xOffset"] = 4,
							["text_format"] = "[namecolor][name:short]",
						},
						["raidicon"] = {
							["enable"] = false,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["debuffs"] = {
							["sizeOverride"] = 36,
							["yOffset"] = 0,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
							["maxDuration"] = 0,
							["xOffset"] = 1,
						},
						["portrait"] = {
							["width"] = 35,
							["camDistanceScale"] = 1,
						},
						["enable"] = false,
						["growthDirection"] = "UP",
						["spacing"] = 17,
						["castbar"] = {
							["width"] = 180,
							["height"] = 12,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["infoPanel"] = {
							["height"] = 16,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["xOffset"] = -2,
							["text_format"] = "[health:current] || [perhp]%",
						},
						["disableTargetGlow"] = true,
						["height"] = 36,
						["buffs"] = {
							["sizeOverride"] = 20,
							["yOffset"] = -10,
							["anchorPoint"] = "TOPLEFT",
							["maxDuration"] = 0,
							["xOffset"] = 2,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
							["xOffset"] = 2,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[name:veryshort]",
							["yOffset"] = 16,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["sizeOverride"] = 32,
							["yOffset"] = 0,
							["priority"] = "Ret,Blacklist,CastByUnit",
							["numrows"] = 1,
							["countFont"] = "Arial Narrow",
							["perrow"] = 1,
							["xOffset"] = -10,
						},
						["disableTargetGlow"] = true,
						["colorOverride"] = "FORCE_ON",
						["growthDirection"] = "UP",
						["spacing"] = 48,
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
							["xOffset"] = -2,
							["text_format"] = "",
						},
						["power"] = {
							["text_format"] = "",
							["position"] = "LEFT",
							["xOffset"] = 2,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 102,
						["name"] = {
							["position"] = "TOPRIGHT",
							["xOffset"] = 42,
							["text_format"] = "[name:short]",
							["yOffset"] = -10,
						},
						["height"] = 23,
						["buffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 20,
							["yOffset"] = 1,
							["anchorPoint"] = "TOPLEFT",
							["priority"] = "Boss,Blacklist",
							["countFont"] = "Arial Narrow",
						},
						["castbar"] = {
							["iconXOffset"] = 0,
							["width"] = 102,
						},
					},
					["party"] = {
						["disableTargetGlow"] = true,
						["verticalSpacing"] = -1,
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 24,
							["yOffset"] = -24,
							["anchorPoint"] = "TOPLEFT",
							["clickThrough"] = true,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["countFont"] = "Friz Quadrata TT",
							["perrow"] = 3,
							["xOffset"] = 190,
						},
						["threatStyle"] = "NONE",
						["healPrediction"] = {
							["enable"] = true,
						},
						["disableMouseoverGlow"] = true,
						["infoPanel"] = {
							["height"] = 12,
						},
						["name"] = {
							["position"] = "LEFT",
							["xOffset"] = 4,
							["text_format"] = "[namecolor][name:short]",
							["yOffset"] = 14,
						},
						["height"] = 60,
						["buffs"] = {
							["sizeOverride"] = 20,
							["yOffset"] = -20,
							["anchorPoint"] = "TOPLEFT",
							["perrow"] = 2,
						},
						["raidicon"] = {
							["attachTo"] = "RIGHT",
							["xOffset"] = -4,
							["yOffset"] = 0,
						},
						["horizontalSpacing"] = -1,
						["rdebuffs"] = {
							["xOffset"] = 28,
							["yOffset"] = 12,
							["font"] = "Arial Narrow",
							["fontOutline"] = "OUTLINE",
							["stack"] = {
								["xOffset"] = 4,
								["position"] = "RIGHT",
								["yOffset"] = -5,
							},
							["size"] = 18,
						},
						["colorOverride"] = "FORCE_ON",
						["growthDirection"] = "DOWN_RIGHT",
						["buffIndicator"] = {
							["size"] = 10,
						},
						["roleIcon"] = {
							["yOffset"] = -1,
							["xOffset"] = 1,
							["size"] = 18,
						},
						["readycheckIcon"] = {
							["size"] = 14,
							["yOffset"] = 4,
						},
						["power"] = {
							["enable"] = false,
							["text_format"] = "",
							["position"] = "BOTTOMRIGHT",
							["height"] = 8,
							["xOffset"] = 0,
						},
						["width"] = 150,
						["health"] = {
							["position"] = "BOTTOM",
							["xOffset"] = 0,
							["text_format"] = "",
							["yOffset"] = 4,
						},
						["orientation"] = "MIDDLE",
					},
				},
				["font"] = "Arial Narrow",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.94,
						["g"] = 0.8,
						["r"] = 0.41,
					},
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["castReactionColor"] = true,
					["classResources"] = {
						["DEATHKNIGHT"] = {
							["b"] = 0.1254901960784314,
							["g"] = 0.1254901960784314,
							["r"] = 0.1254901960784314,
						},
						["comboPoints"] = {
							{
								["b"] = 0,
								["g"] = 1,
								["r"] = 1,
							}, -- [1]
							{
								["b"] = 0,
								["g"] = 1,
								["r"] = 1,
							}, -- [2]
							{
								["b"] = 0,
								["g"] = 1,
								["r"] = 1,
							}, -- [3]
						},
					},
					["castbar_backdrop"] = {
						["b"] = 0.4352941176470588,
						["g"] = 0.4352941176470588,
						["r"] = 0.4352941176470588,
					},
					["tapped"] = {
						["b"] = 0.7568627450980392,
						["g"] = 0.7254901960784314,
						["r"] = 0.7333333333333333,
					},
					["customcastbarbackdrop"] = true,
					["power_backdrop"] = {
						["b"] = 0.4352941176470588,
						["g"] = 0.4352941176470588,
						["r"] = 0.4352941176470588,
					},
					["customclasspowerbackdrop"] = true,
					["colorhealthbyvalue"] = false,
					["custompowerbackdrop"] = true,
					["health_backdrop"] = {
						["b"] = 0.1254901960784314,
						["g"] = 0.1254901960784314,
						["r"] = 0.1254901960784314,
					},
					["classpower_backdrop"] = {
						["b"] = 0.4352941176470588,
						["g"] = 0.4352941176470588,
						["r"] = 0.4352941176470588,
					},
					["power"] = {
						["MANA"] = {
							["b"] = 0.9372549019607843,
							["g"] = 0.8,
							["r"] = 0,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.8980392156862745,
							["r"] = 0.007843137254901961,
						},
						["INSANITY"] = {
							["r"] = 0.549019607843137,
							["g"] = 0.141176470588235,
							["b"] = 0.690196078431373,
						},
					},
					["castColor"] = {
						["b"] = 0.1294117647058823,
						["g"] = 0.1254901960784314,
						["r"] = 0.1254901960784314,
					},
					["health"] = {
						["b"] = 0.1294117647058823,
						["g"] = 0.1294117647058823,
						["r"] = 0.1176470588235294,
					},
					["auraBarByType"] = false,
				},
				["fontOutline"] = "OUTLINE",
				["cooldown"] = {
					["threshold"] = -1,
					["fonts"] = {
						["enable"] = true,
						["font"] = "Arial Narrow",
						["fontSize"] = 16,
					},
				},
				["thinBorders"] = false,
			},
			["datatexts"] = {
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightChatDataPanel"] = {
						[2] = "Durability",
					},
					["MinimapPanel"] = {
						"Date", -- [1]
						"Time", -- [2]
					},
					["LeftChatDataPanel"] = {
						["enable"] = false,
					},
					["RightMiniPanel"] = "AtlasLoot",
				},
				["fontOutline"] = "OUTLINE",
				["leftChatPanel"] = false,
				["rightChatPanel"] = false,
				["font"] = "Arial Narrow",
			},
			["actionbar"] = {
				["bar3"] = {
					["hotkeyFont"] = "Arial Narrow",
					["countTextPosition"] = "BOTTOM",
					["buttonsPerRow"] = 12,
					["countFontSize"] = 14,
					["point"] = "TOPLEFT",
					["hotkeyFontSize"] = 12,
					["buttonSpacing"] = 1,
					["hotkeyFontOutline"] = "THICKOUTLINE",
					["backdropSpacing"] = 0,
					["countFont"] = "Expressway",
					["buttons"] = 12,
					["backdrop"] = true,
					["buttonSize"] = 36,
					["showGrid"] = false,
					["customHotkeyFont"] = true,
				},
				["fontOutline"] = "OUTLINE",
				["bar1"] = {
					["hotkeyFontOutline"] = "THICKOUTLINE",
					["keepSizeRatio"] = false,
					["backdrop"] = true,
					["hotkeyTextYOffset"] = -4,
					["hotkeyFontSize"] = 12,
					["point"] = "TOPLEFT",
					["customHotkeyFont"] = true,
					["buttonSpacing"] = 1,
					["hotkeyFont"] = "Arial Narrow",
					["backdropSpacing"] = 0,
					["buttonSize"] = 36,
					["paging"] = {
						["SHAMAN"] = "",
					},
					["showGrid"] = false,
				},
				["font"] = "Arial Narrow",
				["hotkeyTextYOffset"] = 0,
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonSpacing"] = 1,
					["hideHotkey"] = true,
					["backdropSpacing"] = 1,
					["backdrop"] = false,
					["buttonSize"] = 26,
					["buttonsPerRow"] = 10,
					["visibility"] = "[petbattle] hide;[pet,novehicleui,nooverridebar,nopossessbar] show;hide[keybinds] hide:[mount] hide;",
				},
				["bar6"] = {
					["enabled"] = true,
					["mouseover"] = true,
					["buttonSpacing"] = 0,
					["buttonSize"] = 30,
				},
				["globalFadeAlpha"] = 1,
				["microbar"] = {
					["enabled"] = true,
					["buttonSize"] = 18,
					["buttonSpacing"] = -3,
					["backdropSpacing"] = -1,
					["mouseover"] = true,
				},
				["bar2"] = {
					["buttonHeight"] = 30,
					["hotkeyTextPosition"] = "TOP",
					["countTextPosition"] = "TOP",
					["keepSizeRatio"] = false,
					["backdrop"] = true,
					["hotkeyTextYOffset"] = 0,
					["hotkeyFontSize"] = 14,
					["countFontSize"] = 19,
					["point"] = "TOPLEFT",
					["buttonSpacing"] = 1,
					["hideHotkey"] = true,
					["backdropSpacing"] = 0,
					["countFont"] = "Expressway",
					["buttonSize"] = 34,
					["customCountFont"] = true,
					["hotkeyFont"] = "Expressway",
					["showGrid"] = false,
					["customHotkeyFont"] = true,
				},
				["hotkeytext"] = false,
				["bar5"] = {
					["enabled"] = false,
					["buttonsPerRow"] = 12,
					["point"] = "TOPLEFT",
					["buttonSize"] = 24,
					["buttonSpacing"] = 0,
					["backdropSpacing"] = 4,
					["buttons"] = 12,
				},
				["fontSize"] = 11,
				["useDrawSwipeOnCharges"] = true,
				["macrotext"] = true,
				["stanceBar"] = {
					["mouseover"] = true,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["font"] = "GothamNarrowUltra",
						["fontOutline"] = "THICKOUTLINE",
					},
					["threshold"] = -1,
				},
				["bar4"] = {
					["mouseover"] = true,
					["buttonsPerRow"] = 12,
					["buttonSize"] = 30,
					["buttonSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["lowHealthThreshold"] = 0,
				["filters"] = {
					["Boss"] = {
						["triggers"] = {
							["enable"] = true,
						},
					},
					["Shaman totems"] = {
						["triggers"] = {
							["enable"] = true,
						},
					},
					["Spawn of G'huun"] = {
						["triggers"] = {
							["enable"] = true,
						},
					},
					["Enemy NPCs"] = {
						["triggers"] = {
							["enable"] = true,
						},
					},
					["Mark of the Crane"] = {
						["triggers"] = {
							["enable"] = true,
						},
					},
				},
				["threat"] = {
					["goodScale"] = 1,
					["indicator"] = true,
				},
				["glowStyle"] = "style1",
				["font"] = "Arial Narrow",
				["targetScale"] = 1.25,
				["plateSize"] = {
					["friendlyWidth"] = 90,
					["enemyHeight"] = 10,
					["enemyWidth"] = 80,
					["friendlyHeight"] = 10,
				},
				["smoothbars"] = true,
				["motionType"] = "OVERLAP",
				["cutaway"] = {
					["health"] = {
						["enabled"] = true,
						["fadeOutTime"] = 0.4,
						["lengthBeforeFade"] = 0.2,
					},
				},
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
							["countFont"] = "Arial Narrow",
							["durationFont"] = "Arial Narrow",
						},
						["castbar"] = {
							["yOffset"] = -3,
							["textPosition"] = "ONBAR",
							["width"] = 80,
							["font"] = "Naowh",
							["height"] = 10,
							["iconOffsetX"] = 5,
						},
						["questIcon"] = {
							["position"] = "CENTER",
							["yOffset"] = 35,
						},
						["raidTargetIndicator"] = {
							["xOffset"] = 0,
							["yOffset"] = 12,
							["size"] = 30,
							["position"] = "TOP",
						},
						["eliteIcon"] = {
							["xOffset"] = -1,
							["enable"] = true,
							["size"] = 12,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 12,
								["font"] = "Arial Narrow",
								["format"] = "[health:current-percent]",
							},
							["width"] = 80,
						},
						["name"] = {
							["abbrev"] = true,
							["fontSize"] = 8,
							["font"] = "Naowh",
							["yOffset"] = -2,
						},
						["level"] = {
							["enable"] = false,
							["font"] = "Naowh",
							["yOffset"] = -21,
						},
						["power"] = {
							["classColor"] = true,
							["text"] = {
								["font"] = "Naowh",
							},
							["hideWhenEmpty"] = true,
							["height"] = 4,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["name"] = {
							["font"] = "Naowh",
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["filters"] = {
								["priority"] = "Blacklist,Personal,CCDebuffs",
							},
						},
						["castbar"] = {
							["font"] = "Naowh",
							["height"] = 4,
						},
						["raidTargetIndicator"] = {
							["size"] = 30,
							["position"] = "TOP",
						},
						["name"] = {
							["abbrev"] = true,
							["fontSize"] = 10,
							["font"] = "Naowh",
							["yOffset"] = -2,
						},
						["buffs"] = {
							["filters"] = {
								["maxDuration"] = 0,
								["priority"] = "Blacklist,blockNoDuration,PlayerBuffs,TurtleBuffs",
							},
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 12,
								["font"] = "Expressway",
								["format"] = "[health:current-percent]",
							},
							["width"] = 100,
						},
						["level"] = {
							["enable"] = false,
							["font"] = "Naowh",
							["yOffset"] = -21,
						},
					},
					["FRIENDLY_NPC"] = {
						["name"] = {
							["font"] = "Naowh",
						},
					},
				},
				["colors"] = {
					["glowColor"] = {
						["a"] = 0.5051845610141754,
						["g"] = 0.9764705882352941,
						["r"] = 0.9686274509803922,
					},
					["selection"] = {
						[0] = {
							["r"] = 0.1254901960784314,
							["g"] = 0.1254901960784314,
							["b"] = 0.1294117647058823,
						},
					},
					["threat"] = {
						["badColor"] = {
							["b"] = 0.4352941176470588,
							["g"] = 0.4352941176470588,
							["r"] = 0.4352941176470588,
						},
						["goodColor"] = {
							["g"] = 0.8666666666666667,
							["r"] = 0.2392156862745098,
						},
					},
				},
				["thinBorders"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,215",
				["ThreatBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,272,326",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-5,-5",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,175",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,62,468",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,0,6",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-221,-5",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,325",
				["TargetPowerBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-338,329",
				["ElvUF_FocusTargetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,611,566",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,0,246",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-241",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,184,129",
				["SocialMenuMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,157,227",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,215,627",
				["ElvUF_BodyGuardMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,478,251",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,0,904",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,141",
				["TotemBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-344,-1",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,233",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-267,-277",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-338,340",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,232",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,1,117",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,356,226",
				["VehicleSeatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,451,73",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,-166,-1",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-21",
				["ElvTooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,319",
				["ElvUIBankMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-214",
				["ElvBar_Pet"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,218",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-484",
				["ElvUF_Raid40Mover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-232,347",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,0,213",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,305",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,904",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,166,0",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,405",
				["VehicleLeaveButton"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,617,349",
				["AltPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,223",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,0,87",
				["ReputationBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,445,29",
				["ArtifactBarMover"] = "TOP,ElvUIParent,TOP,0,-4",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-36",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-457,-373",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-59,-240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,35,4",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["AzeriteBarMover"] = "TOP,ElvUIParent,TOP,0,-4",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,124",
				["ElvUF_TargetCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-338,309",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,153",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-218,-231",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-332,290",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,219",
				["RightChatMover"] = "TOP,ElvUIParent,TOP,0,-233",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-150",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-221,-151",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,69,1014",
			},
			["cooldown"] = {
				["checkSeconds"] = true,
				["fonts"] = {
					["enable"] = true,
					["font"] = "Arial Narrow",
					["fontSize"] = 14,
					["fontOutline"] = "THICKOUTLINE",
				},
				["threshold"] = -1,
			},
			["auras"] = {
				["font"] = "Arial Narrow",
				["fontOutline"] = "OUTLINE",
				["consolidatedBuffs"] = {
					["filter"] = false,
					["font"] = "Arial Narrow",
					["fontOutline"] = "OUTLINE",
				},
				["buffs"] = {
					["countFontSize"] = 12,
					["timeYOffset"] = -3,
					["horizontalSpacing"] = 3,
					["size"] = 26,
					["timeXOffset"] = 1,
					["countFont"] = "Arial Narrow",
					["timeFont"] = "Arial Narrow",
					["countFontOutline"] = "THICKOUTLINE",
					["timeFontOutline"] = "THICKOUTLINE",
					["durationFontSize"] = 12,
				},
				["cooldown"] = {
					["threshold"] = -1,
				},
				["debuffs"] = {
					["countFontSize"] = 12,
					["timeYOffset"] = -3,
					["timeXOffset"] = 1,
					["countFont"] = "Friz Quadrata TT",
					["timeFont"] = "Friz Quadrata TT",
					["countFontOutline"] = "THICKOUTLINE",
					["timeFontOutline"] = "THICKOUTLINE",
					["horizontalSpacing"] = 3,
					["durationFontSize"] = 12,
				},
			},
		},
		["Dmgur - Lotus"] = {
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
		["Wafty - Mistblade"] = "Wafty - Mistblade",
		["Dmgur - Lotus"] = "Dmgur - Lotus",
	},
	["profiles"] = {
		["Lotusprep - [EN] Evermoon"] = {
			["general"] = {
				["pixelPerfect"] = false,
				["replaceBlizzFonts"] = false,
				["chatBubbles"] = "nobackdrop",
				["chatBubbleFontOutline"] = "THICKOUTLINE",
				["chatBubbleFont"] = "Arial Narrow",
				["namefont"] = "Arial Narrow",
				["dmgfont"] = "Arial Narrow",
			},
			["nameplates"] = {
				["enable"] = false,
			},
			["install_complete"] = "6.08",
			["theme"] = "class",
			["chat"] = {
				["enable"] = false,
			},
		},
		["Wafty - Mistblade"] = {
			["general"] = {
				["pixelPerfect"] = false,
			},
			["install_complete"] = 2.76,
		},
		["Dmgur - Lotus"] = {
			["install_complete"] = 2.76,
			["general"] = {
				["pixelPerfect"] = false,
				["chatBubbles"] = "nobackdrop",
				["chatBubbleFontOutline"] = "THICKOUTLINE",
				["chatBubbleFont"] = "Friz Quadrata TT",
				["dmgfont"] = "Arial Narrow",
			},
			["chat"] = {
				["enable"] = false,
			},
		},
	},
}
