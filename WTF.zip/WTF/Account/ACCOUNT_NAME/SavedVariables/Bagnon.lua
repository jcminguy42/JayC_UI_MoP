
BagnonGlobalSettings = {
	["highlightSetItems"] = false,
	["version"] = "5.4.15",
	["slotColors"] = {
		["normal"] = {
			0.396078431372549, -- [1]
			0.396078431372549, -- [2]
			0.396078431372549, -- [3]
		},
	},
	["highlightOpacity"] = 0.4,
}
