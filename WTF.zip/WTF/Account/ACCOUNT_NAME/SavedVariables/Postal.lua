
Postal3DB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Asdfawe|Mistblade|Horde|1|PALADIN", -- [1]
				"Dmgurx|Lotus|Horde|90|SHAMAN", -- [2]
				"Dmgur|Lotus|Horde|90|PALADIN", -- [3]
				"Dmgur|Mistblade|Alliance|90|WARRIOR", -- [4]
				"Dmgur|Mistblade|Horde|90|WARRIOR", -- [5]
				"Lotusprep|[EN] Evermoon|Horde|1|PALADIN", -- [6]
				"Wafty|Mistblade|Horde|90|SHAMAN", -- [7]
			},
		},
	},
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Wafty - Mistblade",
		["Asdfawe - Mistblade"] = "Asdfawe - Mistblade",
		["Dmgur - Mistblade"] = "Dmgur - Mistblade",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
	},
	["profiles"] = {
		["Wafty - Mistblade"] = {
			["BlackBook"] = {
				["recent"] = {
					"Eleny|Mistblade|Horde", -- [1]
					"Minmaxer|Mistblade|Horde", -- [2]
					"Dmgur|Mistblade|Horde", -- [3]
					"Caries|Mistblade|Horde", -- [4]
				},
			},
		},
		["Asdfawe - Mistblade"] = {
		},
		["Dmgur - Mistblade"] = {
		},
		["Lotusprep - [EN] Evermoon"] = {
		},
		["Dmgur - Lotus"] = {
		},
		["Dmgurx - Lotus"] = {
		},
	},
}
