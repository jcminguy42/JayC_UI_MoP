
SimpleUnitFramesDB = {
	["profileKeys"] = {
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
	},
	["global"] = {
		["bartexture"] = {
			["texture"] = "ThreatPlatesBar",
		},
	},
	["profiles"] = {
		["Dmgur - Lotus"] = {
		},
		["Lotusprep - [EN] Evermoon"] = {
			["player"] = {
				["icon"] = false,
				["mhp"] = "HPnone",
			},
		},
	},
}
