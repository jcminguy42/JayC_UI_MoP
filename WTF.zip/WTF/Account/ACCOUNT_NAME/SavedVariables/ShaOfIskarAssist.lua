
ShaOfIskarAssistDB = {
	["namespaces"] = {
		["ChampionOfTheLightAssist"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["xPos"] = 319.1895751953125,
					["lock"] = true,
					["yPos"] = 37.25521087646484,
				},
			},
		},
	},
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["profiles"] = {
		["Wafty - Mistblade"] = {
		},
	},
}
