
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/i How tf did u find that", -- [1]
		"/i kk", -- [2]
		"/i whrere now", -- [3]
		"/i xd", -- [4]
		"/i challenge mode?", -- [5]
		"/i We could go do it rn if u want", -- [6]
		"/i get dps and big boom", -- [7]
		"/i ez W", -- [8]
		"/i 10% rep woohoo", -- [9]
		"/i pce", -- [10]
		"/i but okok np", -- [11]
		"/p who knows", -- [12]
		"/p xd", -- [13]
		"/5 Ladder near tree, go up, click bear, aim bear from top to the net", -- [14]
		"/spit", -- [15]
		"/g ppc", -- [16]
		"/g :ppc:", -- [17]
		"/g alt time?", -- [18]
		"/ert", -- [19]
		"/elvui", -- [20]
	},
	["ChatHistoryLog"] = {
	},
}
