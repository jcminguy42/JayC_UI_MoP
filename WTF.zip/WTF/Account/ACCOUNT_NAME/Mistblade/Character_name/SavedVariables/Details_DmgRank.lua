
_detalhes_databaseDmgRank = {
	["lasttry"] = {
	},
	["annouce"] = true,
	["dpshistory"] = {
	},
	["level"] = 1,
	["dps"] = 0,
}
