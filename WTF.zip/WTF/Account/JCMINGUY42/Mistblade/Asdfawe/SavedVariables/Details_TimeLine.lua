
DetailsTimeLineDB = {
	["max_segments"] = 4,
	["combat_data"] = {
	},
	["hide_on_combat"] = false,
	["IndividualSpells"] = {
	},
	["useicons"] = true,
	["cooldowns_timeline"] = {
	},
	["window_scale"] = 1,
	["deaths_data"] = {
	},
	["debuff_timeline"] = {
	},
	["backdrop_color"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		0.4, -- [4]
	},
	["BossSpellCast"] = {
	},
}
