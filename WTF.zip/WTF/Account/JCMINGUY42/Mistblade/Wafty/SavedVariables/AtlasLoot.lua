
AtlasLootCharDB = {
	["namespaces"] = {
		["WishList"] = {
		},
	},
	["profileKeys"] = {
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["AtlasLootVersion"] = "70703",
}
