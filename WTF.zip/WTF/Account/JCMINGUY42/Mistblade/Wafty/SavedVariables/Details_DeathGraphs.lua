
DeathGraphsDBDeaths = {
	["365974"] = {
		["hash"] = "365974",
		["type"] = "deaths",
		["name"] = "The Lich King",
		["id"] = 36597,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["index"] = 12,
			["zone"] = "Icecrown Citadel",
			["encounter"] = "The Lich King",
			["name"] = "The Lich King",
			["diff"] = 4,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["604104"] = {
		["hash"] = "604104",
		["type"] = "deaths",
		["name"] = "Elegon",
		["id"] = 60410,
		["diff"] = 4,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 896,
			["diff_string"] = "25 Player",
			["name"] = "Elegon",
			["zone"] = "Mogu'shan Vaults",
			["encounter"] = "Elegon",
			["try_number"] = 3,
			["index"] = 5,
			["diff"] = 4,
		},
	},
	["604004"] = {
		["hash"] = "604004",
		["type"] = "deaths",
		["name"] = "Will of the Emperor",
		["id"] = 60400,
		["diff"] = 4,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 896,
			["diff_string"] = "25 Player",
			["index"] = 6,
			["zone"] = "Mogu'shan Vaults",
			["encounter"] = "Will of the Emperor",
			["diff"] = 4,
			["name"] = "Will of the Emperor",
		},
	},
	["605864"] = {
		["hash"] = "605864",
		["type"] = "deaths",
		["diff"] = 4,
		["id"] = 60586,
		["player_db"] = {
			["Jaeh"] = {
				["name"] = "Jaeh",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Limbo"] = {
				["name"] = "Limbo",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Taintedbrew"] = {
				["name"] = "Taintedbrew",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Smashval"] = {
				["name"] = "Smashval",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 1,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["609994"] = {
		["hash"] = "609994",
		["type"] = "deaths",
		["diff"] = 4,
		["id"] = 60999,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 4,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["624424"] = {
		["hash"] = "624424",
		["type"] = "deaths",
		["diff"] = 4,
		["id"] = 62442,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 2,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["368534"] = {
		["hash"] = "368534",
		["type"] = "deaths",
		["name"] = "Sindragosa",
		["id"] = 36853,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["name"] = "Sindragosa",
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Sindragosa",
			["diff"] = 4,
			["index"] = 11,
			["try_number"] = 1,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["366784"] = {
		["hash"] = "366784",
		["type"] = "deaths",
		["name"] = "Professor Putricide",
		["id"] = 36678,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["index"] = 7,
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Professor Putricide",
			["name"] = "Professor Putricide",
			["diff"] = 4,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["366264"] = {
		["hash"] = "366264",
		["type"] = "deaths",
		["name"] = "Festergut",
		["id"] = 36626,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["name"] = "Festergut",
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Festergut",
			["diff"] = 4,
			["index"] = 5,
			["try_number"] = 2,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["600474"] = {
		["hash"] = "600474",
		["type"] = "deaths",
		["name"] = "Elegon",
		["id"] = 60047,
		["diff"] = 4,
		["player_db"] = {
			["Ravenppc"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ravenppc",
				["class"] = "WARLOCK",
			},
			["Smokeppc"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Smokeppc",
				["class"] = "DEATHKNIGHT",
			},
			["Nydan"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Nydan",
				["class"] = "HUNTER",
			},
			["Jaeh"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Jaeh",
				["class"] = "WARRIOR",
			},
			["Prismma"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Prismma",
				["class"] = "SHAMAN",
			},
		},
		["boss_table"] = {
			["diff_string"] = "25 Player",
			["index"] = 1,
			["zone"] = "Mogu'shan Vaults",
			["id"] = 1500,
			["mapid"] = 896,
			["try_number"] = 2,
			["diff"] = 4,
			["name"] = "Elegon",
			["encounter"] = "Elegon",
		},
	},
	["288603"] = {
		["hash"] = "288603",
		["type"] = "deaths",
		["name"] = "Sartharion",
		["id"] = 28860,
		["diff"] = 3,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 532,
			["diff_string"] = "10 Player",
			["index"] = 1,
			["zone"] = "The Obsidian Sanctum",
			["encounter"] = "Sartharion",
			["diff"] = 3,
			["name"] = "Sartharion",
		},
	},
	["629834"] = {
		["hash"] = "629834",
		["type"] = "deaths",
		["diff"] = 4,
		["id"] = 62983,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 3,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
}
DeathGraphsDBEndurance = {
	["365974"] = {
		["hash"] = "365974",
		["type"] = "endurance",
		["name"] = "The Lich King",
		["id"] = 36597,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["index"] = 12,
			["zone"] = "Icecrown Citadel",
			["encounter"] = "The Lich King",
			["name"] = "The Lich King",
			["diff"] = 4,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["604104"] = {
		["hash"] = "604104",
		["type"] = "endurance",
		["name"] = "Elegon",
		["id"] = 60410,
		["diff"] = 4,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 896,
			["diff_string"] = "25 Player",
			["name"] = "Elegon",
			["zone"] = "Mogu'shan Vaults",
			["encounter"] = "Elegon",
			["try_number"] = 3,
			["index"] = 5,
			["diff"] = 4,
		},
	},
	["604004"] = {
		["hash"] = "604004",
		["type"] = "endurance",
		["name"] = "Will of the Emperor",
		["id"] = 60400,
		["diff"] = 4,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 896,
			["diff_string"] = "25 Player",
			["index"] = 6,
			["zone"] = "Mogu'shan Vaults",
			["encounter"] = "Will of the Emperor",
			["diff"] = 4,
			["name"] = "Will of the Emperor",
		},
	},
	["605864"] = {
		["hash"] = "605864",
		["type"] = "endurance",
		["diff"] = 4,
		["id"] = 60586,
		["player_db"] = {
			["Madawng"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Wafty"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Ploto"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Caries"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Jadamssham"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Treasure"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Baber"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Limbo"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						168.1670000000158, -- [2]
						"Breath of Fear |cFFFF3333181,500|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Ravenppc"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Smokeppc"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Letemfly"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Minmaxer"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Taintedbrew"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Clawbear"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Saynt"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Dampfhammer"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Imre"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Dizna"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Tellios"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Jaeh"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						227.2440000000061, -- [2]
						"Melee |cFFFF3333189,059|r", -- [3]
					}, -- [1]
				},
			},
			["Foxy"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Nnydruid"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Topen"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Gqnjamon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Pasta"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Juterna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Deryn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Jackman"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Cryptik"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Smashu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Bdub"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Kimlip"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Onmyown"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Smashval"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						1, -- [1]
						262.5260000000126, -- [2]
						"Melee |cFFFF3333176,232|r", -- [3]
					}, -- [1]
				},
			},
			["Sober"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Eleny"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Prismma"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Nydan"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 1,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["609994"] = {
		["hash"] = "609994",
		["type"] = "endurance",
		["diff"] = 4,
		["id"] = 60999,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 4,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["624424"] = {
		["hash"] = "624424",
		["type"] = "endurance",
		["diff"] = 4,
		["id"] = 62442,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 2,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
	["368534"] = {
		["hash"] = "368534",
		["type"] = "endurance",
		["name"] = "Sindragosa",
		["id"] = 36853,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["name"] = "Sindragosa",
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Sindragosa",
			["diff"] = 4,
			["index"] = 11,
			["try_number"] = 1,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["366784"] = {
		["hash"] = "366784",
		["type"] = "endurance",
		["name"] = "Professor Putricide",
		["id"] = 36678,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["index"] = 7,
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Professor Putricide",
			["name"] = "Professor Putricide",
			["diff"] = 4,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["366264"] = {
		["hash"] = "366264",
		["type"] = "endurance",
		["name"] = "Festergut",
		["id"] = 36626,
		["boss_table"] = {
			["mapid"] = 605,
			["diff_string"] = "25 Player",
			["name"] = "Festergut",
			["zone"] = "Icecrown Citadel",
			["encounter"] = "Festergut",
			["diff"] = 4,
			["index"] = 5,
			["try_number"] = 2,
		},
		["player_db"] = {
		},
		["diff"] = 4,
	},
	["600474"] = {
		["hash"] = "600474",
		["type"] = "endurance",
		["name"] = "Elegon",
		["id"] = 60047,
		["diff"] = 4,
		["player_db"] = {
			["Madawng"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Cryptik"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Dampfhammer"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Caries"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Treasure"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Tellios"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Jaeh"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						339.9330000000191, -- [2]
						"Unstable Energy |cFFFF333318,602|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Baber"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Topen"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Nnydruid"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Ravenppc"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						199.9560000000056, -- [2]
						"Melee |cFFFF333399,271|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Sereph"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Smokeppc"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						147.3150000000023, -- [2]
						"Energy Conduit |cFFFF3333276,241|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Eleny"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Nydan"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						245.0680000000284, -- [2]
						"Discharge |cFFFF333350,698|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Taintedbrew"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Foxy"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Bdub"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Smashval"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Onmyown"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Colinp"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Wafty"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Prismma"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						350.88400000002, -- [2]
						"Melee |cFFFF333363,126|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Minmaxer"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Hotsndots"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
		},
		["boss_table"] = {
			["diff_string"] = "25 Player",
			["index"] = 1,
			["zone"] = "Mogu'shan Vaults",
			["id"] = 1500,
			["mapid"] = 896,
			["try_number"] = 2,
			["diff"] = 4,
			["name"] = "Elegon",
			["encounter"] = "Elegon",
		},
	},
	["288603"] = {
		["hash"] = "288603",
		["type"] = "endurance",
		["name"] = "Sartharion",
		["id"] = 28860,
		["diff"] = 3,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 532,
			["diff_string"] = "10 Player",
			["index"] = 1,
			["zone"] = "The Obsidian Sanctum",
			["encounter"] = "Sartharion",
			["diff"] = 3,
			["name"] = "Sartharion",
		},
	},
	["629834"] = {
		["hash"] = "629834",
		["type"] = "endurance",
		["diff"] = 4,
		["id"] = 62983,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = -1,
			["diff_string"] = "25 Player",
			["index"] = 3,
			["zone"] = "Terrace of Endless Spring",
			["diff"] = 4,
		},
	},
}
DeathGraphsDBCurrent = {
	{
		["deaths"] = {
			{
				["maxhealth"] = 398509,
				["timeofdeath"] = 168.1670000000158,
				["name"] = "Limbo",
				["time"] = 1649008661.269,
				["class"] = "WARRIOR",
				["timestring"] = "2m 48s",
				["events"] = {
					{
						4, -- [1]
						119086, -- [2]
						1, -- [3]
						1649008652.749, -- [4]
						423681, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						true, -- [1]
						119086, -- [2]
						94238, -- [3]
						1649008652.749, -- [4]
						329443, -- [5]
						"Terror Spawn", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [2]
					{
						false, -- [1]
						94472, -- [2]
						68289, -- [3]
						1649008653.143, -- [4]
						397732, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [3]
					{
						false, -- [1]
						34861, -- [2]
						44182, -- [3]
						1649008653.7, -- [4]
						423681, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						false, -- [1]
						77489, -- [2]
						6962, -- [3]
						1649008656.629, -- [4]
						423681, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [5]
					{
						false, -- [1]
						77489, -- [2]
						6962, -- [3]
						1649008659.58, -- [4]
						423681, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [6]
					{
						4, -- [1]
						119414, -- [2]
						1, -- [3]
						1649008659.706, -- [4]
						423681, -- [5]
						"Sha of Fear", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						4, -- [1]
						125786, -- [2]
						1, -- [3]
						1649008659.706, -- [4]
						423681, -- [5]
						"Sha of Fear", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						47753, -- [2]
						87510, -- [3]
						1649008660.262, -- [4]
						329691, -- [5]
						"Tellios", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						true, -- [1]
						119414, -- [2]
						181500, -- [3]
						1649008660.262, -- [4]
						329691, -- [5]
						"Sha of Fear", -- [6]
						87510, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [10]
					{
						true, -- [1]
						119414, -- [2]
						181500, -- [3]
						1649008660.825, -- [4]
						148191, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [11]
					{
						true, -- [1]
						119414, -- [2]
						181500, -- [3]
						1649008661.239, -- [4]
						1, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						33309, -- [10]
					}, -- [12]
					{
						3, -- [1]
						871, -- [2]
						1, -- [3]
						1649008607.489, -- [4]
						0, -- [5]
						"Limbo", -- [6]
					}, -- [13]
				},
			}, -- [1]
			{
				["maxhealth"] = 415421,
				["timeofdeath"] = 227.2440000000061,
				["name"] = "Jaeh",
				["time"] = 1649008720.346,
				["class"] = "WARRIOR",
				["timestring"] = "3m 47s",
				["events"] = {
					{
						false, -- [1]
						73921, -- [2]
						52354, -- [3]
						1649008693.861, -- [4]
						442287, -- [5]
						"Dizna", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						119952, -- [2]
						33627, -- [3]
						1649008695.84, -- [4]
						447522, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						86273, -- [2]
						9599, -- [3]
						1649008696.817, -- [4]
						365477, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [3]
					{
						true, -- [1]
						119086, -- [2]
						91644, -- [3]
						1649008696.817, -- [4]
						365477, -- [5]
						"Terror Spawn", -- [6]
						9599, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [4]
					{
						false, -- [1]
						73921, -- [2]
						26591, -- [3]
						1649008696.97, -- [4]
						392068, -- [5]
						"Dizna", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						4, -- [1]
						119086, -- [2]
						2, -- [3]
						1649008696.97, -- [4]
						392068, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						121129, -- [2]
						10696, -- [3]
						1649008697.66, -- [4]
						405423, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						119952, -- [2]
						16769, -- [3]
						1649008697.792, -- [4]
						422192, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						86273, -- [2]
						7839, -- [3]
						1649008698.07, -- [4]
						325153, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [9]
					{
						true, -- [1]
						119086, -- [2]
						104878, -- [3]
						1649008698.07, -- [4]
						325153, -- [5]
						"Terror Spawn", -- [6]
						7839, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [10]
					{
						4, -- [1]
						119086, -- [2]
						3, -- [3]
						1649008698.211, -- [4]
						325153, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						73921, -- [2]
						56260, -- [3]
						1649008698.517, -- [4]
						381413, -- [5]
						"Dizna", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						119952, -- [2]
						16934, -- [3]
						1649008699.757, -- [4]
						403973, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						86273, -- [2]
						4833, -- [3]
						1649008699.757, -- [4]
						315097, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [14]
					{
						true, -- [1]
						119495, -- [2]
						93709, -- [3]
						1649008699.757, -- [4]
						315097, -- [5]
						"Sha of Fear", -- [6]
						4833, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [15]
					{
						false, -- [1]
						73921, -- [2]
						27793, -- [3]
						1649008700.166, -- [4]
						342890, -- [5]
						"Dizna", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						false, -- [1]
						73921, -- [2]
						26557, -- [3]
						1649008701.726, -- [4]
						372226, -- [5]
						"Dizna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [17]
					{
						false, -- [1]
						119952, -- [2]
						16579, -- [3]
						1649008701.726, -- [4]
						388805, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						119952, -- [2]
						16420, -- [3]
						1649008703.823, -- [4]
						407880, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						119952, -- [2]
						17494, -- [3]
						1649008705.776, -- [4]
						425374, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [20]
					{
						false, -- [1]
						81280, -- [2]
						176774, -- [3]
						1649008711.099, -- [4]
						461241, -- [5]
						"Smokeppc", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						false, -- [1]
						86273, -- [2]
						14412, -- [3]
						1649008712.347, -- [4]
						373384, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [22]
					{
						true, -- [1]
						119495, -- [2]
						102269, -- [3]
						1649008712.347, -- [4]
						373384, -- [5]
						"Sha of Fear", -- [6]
						14412, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [23]
					{
						true, -- [1]
						119086, -- [2]
						116154, -- [3]
						1649008712.758, -- [4]
						257230, -- [5]
						"Terror Spawn", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [24]
					{
						4, -- [1]
						119086, -- [2]
						4, -- [3]
						1649008712.889, -- [4]
						257230, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						119086, -- [2]
						135394, -- [3]
						1649008714.028, -- [4]
						121836, -- [5]
						"Terror Spawn", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [26]
					{
						4, -- [1]
						119086, -- [2]
						5, -- [3]
						1649008714.152, -- [4]
						121836, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						5185, -- [2]
						68862, -- [3]
						1649008715.701, -- [4]
						190698, -- [5]
						"Saynt", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						true, -- [1]
						119495, -- [2]
						118089, -- [3]
						1649008716.568, -- [4]
						72609, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [29]
					{
						false, -- [1]
						82327, -- [2]
						16228, -- [3]
						1649008719.217, -- [4]
						88837, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						86273, -- [2]
						4632, -- [3]
						1649008720.346, -- [4]
						88837, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						189059, -- [3]
						1649008720.346, -- [4]
						88837, -- [5]
						"Sha of Fear", -- [6]
						4632, -- [7]
						1, -- [8]
						false, -- [9]
						95590, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Jaeh", -- [6]
					}, -- [33]
				},
			}, -- [2]
			{
				["maxhealth"] = 530386,
				["timeofdeath"] = 262.5260000000126,
				["name"] = "Smashval",
				["time"] = 1649008755.628,
				["class"] = "PALADIN",
				["timestring"] = "4m 22s",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1649008783.75, -- [4]
						0, -- [5]
						"Dampfhammer", -- [6]
					}, -- [1]
					{
						2, -- [1]
						95750, -- [2]
						1, -- [3]
						1649008769.338, -- [4]
						0, -- [5]
						"Caries", -- [6]
					}, -- [2]
					{
						false, -- [1]
						53652, -- [2]
						4705, -- [3]
						1649008745.686, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						53652, -- [2]
						4705, -- [3]
						1649008745.686, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [4]
					{
						false, -- [1]
						53652, -- [2]
						4705, -- [3]
						1649008745.686, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [5]
					{
						false, -- [1]
						53652, -- [2]
						4705, -- [3]
						1649008745.686, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [6]
					{
						false, -- [1]
						85222, -- [2]
						31365, -- [3]
						1649008745.686, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						20167, -- [2]
						16870, -- [3]
						1649008745.942, -- [4]
						568018, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [8]
					{
						false, -- [1]
						53652, -- [2]
						2381, -- [3]
						1649008746.08, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [9]
					{
						false, -- [1]
						86273, -- [2]
						8953, -- [3]
						1649008746.796, -- [4]
						477524, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						true, -- [1]
						119086, -- [2]
						99447, -- [3]
						1649008746.796, -- [4]
						477524, -- [5]
						"Terror Spawn", -- [6]
						8953, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [11]
					{
						4, -- [1]
						119086, -- [2]
						3, -- [3]
						1649008746.938, -- [4]
						477524, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						53652, -- [2]
						8387, -- [3]
						1649008747.227, -- [4]
						485911, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						53652, -- [2]
						7529, -- [3]
						1649008747.767, -- [4]
						493440, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [14]
					{
						false, -- [1]
						34861, -- [2]
						39728, -- [3]
						1649008747.906, -- [4]
						533168, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [15]
					{
						false, -- [1]
						20167, -- [2]
						17838, -- [3]
						1649008747.906, -- [4]
						551006, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [16]
					{
						false, -- [1]
						53652, -- [2]
						2381, -- [3]
						1649008748.491, -- [4]
						553387, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [17]
					{
						false, -- [1]
						20167, -- [2]
						17838, -- [3]
						1649008748.761, -- [4]
						568018, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [18]
					{
						false, -- [1]
						20167, -- [2]
						17838, -- [3]
						1649008748.898, -- [4]
						568018, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						false, -- [1]
						53652, -- [2]
						8387, -- [3]
						1649008749.583, -- [4]
						568018, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [20]
					{
						false, -- [1]
						20167, -- [2]
						17838, -- [3]
						1649008749.73, -- [4]
						568018, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						true, -- [1]
						1, -- [2]
						94125, -- [3]
						1649008750.294, -- [4]
						568018, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [22]
					{
						false, -- [1]
						77489, -- [2]
						6260, -- [3]
						1649008750.835, -- [4]
						480153, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [23]
					{
						false, -- [1]
						20167, -- [2]
						15821, -- [3]
						1649008751.683, -- [4]
						495974, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [24]
					{
						false, -- [1]
						20167, -- [2]
						15821, -- [3]
						1649008753.096, -- [4]
						511795, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [25]
					{
						false, -- [1]
						119952, -- [2]
						15625, -- [3]
						1649008753.219, -- [4]
						527420, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [26]
					{
						true, -- [1]
						1, -- [2]
						161449, -- [3]
						1649008753.498, -- [4]
						527420, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [27]
					{
						false, -- [1]
						77489, -- [2]
						6260, -- [3]
						1649008753.78, -- [4]
						372231, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [28]
					{
						false, -- [1]
						20167, -- [2]
						16994, -- [3]
						1649008755.057, -- [4]
						389225, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [29]
					{
						false, -- [1]
						20167, -- [2]
						16994, -- [3]
						1649008755.204, -- [4]
						406219, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [30]
					{
						false, -- [1]
						119952, -- [2]
						16358, -- [3]
						1649008755.204, -- [4]
						422577, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						142420, -- [3]
						1649008755.605, -- [4]
						422577, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [32]
					{
						true, -- [1]
						1, -- [2]
						157078, -- [3]
						1649008755.605, -- [4]
						422577, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [33]
					{
						true, -- [1]
						1, -- [2]
						176232, -- [3]
						1649008755.605, -- [4]
						422577, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						53153, -- [10]
					}, -- [34]
					{
						3, -- [1]
						31850, -- [2]
						1, -- [3]
						1649008704.647, -- [4]
						0, -- [5]
						"Smashval", -- [6]
					}, -- [35]
				},
			}, -- [3]
			{
				["maxhealth"] = 366449,
				["timeofdeath"] = 270.2309999999707,
				["name"] = "Taintedbrew",
				["time"] = 1649008763.333,
				["class"] = "MONK",
				["timestring"] = "4m 30s",
				["events"] = {
					{
						true, -- [1]
						119495, -- [2]
						93936, -- [3]
						1649008744.701, -- [4]
						272878, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [1]
					{
						true, -- [1]
						119086, -- [2]
						106533, -- [3]
						1649008749.753, -- [4]
						168299, -- [5]
						"Terror Spawn", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [2]
					{
						4, -- [1]
						119086, -- [2]
						2, -- [3]
						1649008749.863, -- [4]
						168299, -- [5]
						"Terror Spawn", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						132463, -- [2]
						9094, -- [3]
						1649008753.096, -- [4]
						100819, -- [5]
						"Taintedbrew", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						63544, -- [2]
						9919, -- [3]
						1649008753.78, -- [4]
						111065, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [5]
					{
						false, -- [1]
						115072, -- [2]
						58532, -- [3]
						1649008755.204, -- [4]
						169925, -- [5]
						"Taintedbrew", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						119952, -- [2]
						16358, -- [3]
						1649008755.204, -- [4]
						186283, -- [5]
						"Smashval", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						132463, -- [2]
						18188, -- [3]
						1649008756.34, -- [4]
						204795, -- [5]
						"Taintedbrew", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						139, -- [2]
						13226, -- [3]
						1649008756.475, -- [4]
						218021, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [9]
					{
						false, -- [1]
						77489, -- [2]
						1563, -- [3]
						1649008756.865, -- [4]
						219584, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [10]
					{
						false, -- [1]
						32546, -- [2]
						50054, -- [3]
						1649008757.288, -- [4]
						269965, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						114911, -- [2]
						2604, -- [3]
						1649008758.708, -- [4]
						272898, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						32546, -- [2]
						50747, -- [3]
						1649008758.977, -- [4]
						323645, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [13]
					{
						false, -- [1]
						139, -- [2]
						13226, -- [3]
						1649008759.111, -- [4]
						336871, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						true, -- [1]
						1, -- [2]
						361552, -- [3]
						1649008759.394, -- [4]
						337195, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						77489, -- [2]
						11109, -- [3]
						1649008759.82, -- [4]
						348304, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [16]
					{
						false, -- [1]
						128591, -- [2]
						7557, -- [3]
						1649008759.962, -- [4]
						355861, -- [5]
						"Taintedbrew", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [17]
					{
						true, -- [1]
						1, -- [2]
						346879, -- [3]
						1649008760.785, -- [4]
						356189, -- [5]
						"Sha of Fear", -- [6]
						26863, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [18]
					{
						false, -- [1]
						114911, -- [2]
						3439, -- [3]
						1649008760.923, -- [4]
						39612, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						114911, -- [2]
						2479, -- [3]
						1649008761.196, -- [4]
						42091, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [20]
					{
						false, -- [1]
						114911, -- [2]
						5364, -- [3]
						1649008761.196, -- [4]
						47455, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [21]
					{
						false, -- [1]
						114911, -- [2]
						7909, -- [3]
						1649008761.353, -- [4]
						55364, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						139, -- [2]
						13226, -- [3]
						1649008761.766, -- [4]
						68914, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [23]
					{
						false, -- [1]
						114911, -- [2]
						2271, -- [3]
						1649008762.468, -- [4]
						71185, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [24]
					{
						false, -- [1]
						114911, -- [2]
						3446, -- [3]
						1649008762.468, -- [4]
						74631, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [25]
					{
						false, -- [1]
						114911, -- [2]
						17475, -- [3]
						1649008762.61, -- [4]
						92106, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						11109, -- [3]
						1649008762.889, -- [4]
						103541, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [27]
					{
						false, -- [1]
						114911, -- [2]
						35205, -- [3]
						1649008763.312, -- [4]
						138746, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						false, -- [1]
						114911, -- [2]
						8287, -- [3]
						1649008763.312, -- [4]
						147033, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						false, -- [1]
						114911, -- [2]
						8476, -- [3]
						1649008763.312, -- [4]
						155509, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [30]
					{
						false, -- [1]
						114911, -- [2]
						3483, -- [3]
						1649008763.312, -- [4]
						158992, -- [5]
						"Wafty", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						265436, -- [3]
						1649008763.333, -- [4]
						158992, -- [5]
						"Sha of Fear", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						106444, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Taintedbrew", -- [6]
					}, -- [33]
				},
			}, -- [4]
		},
		["bossname"] = "Sha of Fear",
		["bossicon"] = {
			0, -- [1]
			0.25, -- [2]
			0, -- [3]
			0.25, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\TerraceOfEndlessSprings_BossFaces", -- [5]
		},
		["date"] = 348972.359,
		["timeelapsed"] = 310.9709999999614,
	}, -- [1]
	{
		["deaths"] = {
			{
				["maxhealth"] = 407743,
				["timeofdeath"] = 199.9560000000056,
				["name"] = "Ravenppc",
				["time"] = 1645394583.354,
				["class"] = "WARLOCK",
				["timestring"] = "3m 19s",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1645394611.987, -- [4]
						0, -- [5]
						"Sereph", -- [6]
					}, -- [1]
					{
						false, -- [1]
						48438, -- [2]
						4550, -- [3]
						1645394572.958, -- [4]
						543988, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						63106, -- [2]
						2990, -- [3]
						1645394573.951, -- [4]
						543988, -- [5]
						"Ravenppc", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						63106, -- [2]
						2990, -- [3]
						1645394576.614, -- [4]
						543988, -- [5]
						"Ravenppc", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						4, -- [1]
						116525, -- [2]
						1, -- [3]
						1645394577.591, -- [4]
						543988, -- [5]
						"Emperor's Rage", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						1, -- [2]
						120028, -- [3]
						1645394577.738, -- [4]
						543988, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [6]
					{
						false, -- [1]
						145110, -- [2]
						25225, -- [3]
						1645394577.858, -- [4]
						449185, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						81751, -- [2]
						1569, -- [3]
						1645394578.145, -- [4]
						451197, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						114911, -- [2]
						7761, -- [3]
						1645394578.281, -- [4]
						458958, -- [5]
						"Treasure", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						114911, -- [2]
						28891, -- [3]
						1645394578.281, -- [4]
						487849, -- [5]
						"Treasure", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						false, -- [1]
						81751, -- [2]
						47656, -- [3]
						1645394578.281, -- [4]
						535505, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						false, -- [1]
						63544, -- [2]
						8246, -- [3]
						1645394578.734, -- [4]
						543751, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						63106, -- [2]
						2990, -- [3]
						1645394579.298, -- [4]
						543988, -- [5]
						"Ravenppc", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						true, -- [1]
						1, -- [2]
						69738, -- [3]
						1645394579.298, -- [4]
						543988, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [14]
					{
						true, -- [1]
						1, -- [2]
						143923, -- [3]
						1645394579.298, -- [4]
						543988, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [15]
					{
						false, -- [1]
						81751, -- [2]
						1569, -- [3]
						1645394579.982, -- [4]
						331896, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						true, -- [1]
						116782, -- [2]
						20000, -- [3]
						1645394579.982, -- [4]
						311896, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [17]
					{
						false, -- [1]
						108503, -- [2]
						11966, -- [3]
						1645394580.549, -- [4]
						324315, -- [5]
						"Ravenppc", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [18]
					{
						true, -- [1]
						1, -- [2]
						175366, -- [3]
						1645394580.806, -- [4]
						324315, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [19]
					{
						true, -- [1]
						1, -- [2]
						87109, -- [3]
						1645394580.806, -- [4]
						324315, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [20]
					{
						false, -- [1]
						81751, -- [2]
						1962, -- [3]
						1645394580.968, -- [4]
						63802, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						true, -- [1]
						116782, -- [2]
						20000, -- [3]
						1645394581.097, -- [4]
						43802, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [22]
					{
						false, -- [1]
						139, -- [2]
						10996, -- [3]
						1645394581.363, -- [4]
						54798, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [23]
					{
						false, -- [1]
						63106, -- [2]
						2990, -- [3]
						1645394581.663, -- [4]
						58247, -- [5]
						"Ravenppc", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [24]
					{
						false, -- [1]
						77489, -- [2]
						946, -- [3]
						1645394581.782, -- [4]
						59193, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [25]
					{
						false, -- [1]
						2061, -- [2]
						122635, -- [3]
						1645394581.782, -- [4]
						181828, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [26]
					{
						true, -- [1]
						116782, -- [2]
						20000, -- [3]
						1645394582.069, -- [4]
						161828, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [27]
					{
						false, -- [1]
						114911, -- [2]
						26940, -- [3]
						1645394582.923, -- [4]
						189225, -- [5]
						"Treasure", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						false, -- [1]
						774, -- [2]
						19413, -- [3]
						1645394583.064, -- [4]
						208638, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [29]
					{
						true, -- [1]
						116782, -- [2]
						20000, -- [3]
						1645394583.083, -- [4]
						188638, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [30]
					{
						false, -- [1]
						114911, -- [2]
						20131, -- [3]
						1645394583.354, -- [4]
						208769, -- [5]
						"Treasure", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						141965, -- [3]
						1645394583.354, -- [4]
						208769, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [32]
					{
						true, -- [1]
						1, -- [2]
						99271, -- [3]
						1645394583.354, -- [4]
						208769, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						32467, -- [10]
					}, -- [33]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Ravenppc", -- [6]
					}, -- [34]
				},
			}, -- [1]
			{
				["maxhealth"] = 353387,
				["timeofdeath"] = 350.88400000002,
				["name"] = "Prismma",
				["time"] = 1645394734.282,
				["class"] = "SHAMAN",
				["timestring"] = "5m 50s",
				["events"] = {
					{
						false, -- [1]
						8936, -- [2]
						6767, -- [3]
						1645394727.262, -- [4]
						411456, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [1]
					{
						false, -- [1]
						77489, -- [2]
						5859, -- [3]
						1645394727.262, -- [4]
						411456, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						8936, -- [2]
						6767, -- [3]
						1645394728.941, -- [4]
						411456, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						114163, -- [2]
						12012, -- [3]
						1645394729.365, -- [4]
						411456, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						139, -- [2]
						11282, -- [3]
						1645394729.519, -- [4]
						411456, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [5]
					{
						false, -- [1]
						86273, -- [2]
						17408, -- [3]
						1645394729.64, -- [4]
						411456, -- [5]
						"Cryptik", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [6]
					{
						true, -- [1]
						1, -- [2]
						49130, -- [3]
						1645394729.64, -- [4]
						411456, -- [5]
						"Emperor's Rage", -- [6]
						17408, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [7]
					{
						false, -- [1]
						48503, -- [2]
						26817, -- [3]
						1645394729.64, -- [4]
						411456, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [8]
					{
						true, -- [1]
						1, -- [2]
						79225, -- [3]
						1645394729.64, -- [4]
						411456, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [9]
					{
						false, -- [1]
						34861, -- [2]
						19688, -- [3]
						1645394729.917, -- [4]
						347014, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [10]
					{
						false, -- [1]
						77489, -- [2]
						5412, -- [3]
						1645394730.208, -- [4]
						352426, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						116782, -- [2]
						18000, -- [3]
						1645394730.208, -- [4]
						334426, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [12]
					{
						false, -- [1]
						8936, -- [2]
						6767, -- [3]
						1645394730.799, -- [4]
						341541, -- [5]
						"Nnydruid", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [13]
					{
						true, -- [1]
						1, -- [2]
						127095, -- [3]
						1645394731.169, -- [4]
						341541, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [14]
					{
						true, -- [1]
						1, -- [2]
						49128, -- [3]
						1645394731.169, -- [4]
						341541, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [15]
					{
						true, -- [1]
						116782, -- [2]
						18000, -- [3]
						1645394731.169, -- [4]
						323541, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [16]
					{
						false, -- [1]
						81751, -- [2]
						46833, -- [3]
						1645394731.447, -- [4]
						194499, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [17]
					{
						false, -- [1]
						114163, -- [2]
						24744, -- [3]
						1645394731.755, -- [4]
						219243, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [18]
					{
						false, -- [1]
						114942, -- [2]
						14738, -- [3]
						1645394731.755, -- [4]
						233981, -- [5]
						"Prismma", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [19]
					{
						false, -- [1]
						139, -- [2]
						11282, -- [3]
						1645394732.009, -- [4]
						245263, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [20]
					{
						true, -- [1]
						116782, -- [2]
						18000, -- [3]
						1645394732.165, -- [4]
						227263, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [21]
					{
						false, -- [1]
						81751, -- [2]
						46858, -- [3]
						1645394732.45, -- [4]
						274121, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						1, -- [2]
						126623, -- [3]
						1645394732.742, -- [4]
						274465, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [23]
					{
						true, -- [1]
						1, -- [2]
						62778, -- [3]
						1645394732.742, -- [4]
						274465, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [24]
					{
						true, -- [1]
						116782, -- [2]
						18000, -- [3]
						1645394733.137, -- [4]
						67064, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [25]
					{
						false, -- [1]
						121148, -- [2]
						66081, -- [3]
						1645394733.28, -- [4]
						133145, -- [5]
						"Tellios", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						5412, -- [3]
						1645394733.28, -- [4]
						138557, -- [5]
						"Eleny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						114942, -- [2]
						15066, -- [3]
						1645394733.448, -- [4]
						153623, -- [5]
						"Prismma", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						false, -- [1]
						114163, -- [2]
						12012, -- [3]
						1645394734.14, -- [4]
						165990, -- [5]
						"Cryptik", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [29]
					{
						true, -- [1]
						116782, -- [2]
						18000, -- [3]
						1645394734.14, -- [4]
						147990, -- [5]
						"[*] Titan Gas", -- [6]
						nil, -- [7]
						16, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [30]
					{
						true, -- [1]
						1, -- [2]
						103085, -- [3]
						1645394734.282, -- [4]
						147990, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						0, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						63126, -- [3]
						1645394734.282, -- [4]
						147990, -- [5]
						"Emperor's Rage", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						18221, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Prismma", -- [6]
					}, -- [33]
				},
			}, -- [2]
		},
		["bossname"] = "Will of the Emperor",
		["bossicon"] = {
			0, -- [1]
			0.25, -- [2]
			0, -- [3]
			0.25, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\MogushanVaults_BossFaces", -- [5]
		},
		["date"] = 411105.993,
		["timeelapsed"] = 494.2079999999842,
	}, -- [2]
}
DeathGraphsDBGraph = {
}
