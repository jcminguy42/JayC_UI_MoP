
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 592.4052734375,
		["x"] = 1307.843383789063,
	},
}
