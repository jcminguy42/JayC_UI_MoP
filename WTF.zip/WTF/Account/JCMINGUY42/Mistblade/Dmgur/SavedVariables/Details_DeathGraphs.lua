
DeathGraphsDBDeaths = {
	["490791"] = {
		["hash"] = "490791",
		["type"] = "deaths",
		["name"] = "Commander Ulthok",
		["id"] = 49079,
		["diff"] = 1,
		["player_db"] = {
			["Mallowpuff"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Mallowpuff",
				["class"] = "WARLOCK",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Throne of the Tides",
			["id"] = 1044,
			["mapid"] = 767,
			["try_number"] = 1,
			["diff"] = 1,
			["name"] = "Commander Ulthok",
			["encounter"] = "Commander Ulthok",
		},
	},
	["311251"] = {
		["hash"] = "311251",
		["type"] = "deaths",
		["name"] = "Krik'thir the Gatewatcher",
		["id"] = 31125,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Azjol-Nerub",
			["id"] = 216,
			["mapid"] = 533,
			["try_number"] = 1,
			["diff"] = 1,
			["name"] = "Krik'thir the Gatewatcher",
			["encounter"] = "Krik'thir the Gatewatcher",
		},
	},
	["490641"] = {
		["hash"] = "490641",
		["type"] = "deaths",
		["name"] = "Commander Ulthok, the Festering Prince",
		["id"] = 49064,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 767,
			["diff_string"] = "Normal",
			["index"] = 2,
			["zone"] = "Throne of the Tides",
			["encounter"] = "Commander Ulthok, the Festering Prince",
			["diff"] = 1,
			["name"] = "Commander Ulthok, the Festering Prince",
		},
	},
	["445661"] = {
		["hash"] = "445661",
		["type"] = "deaths",
		["name"] = "Ozumat",
		["id"] = 44566,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 767,
			["diff_string"] = "Normal",
			["name"] = "Ozumat",
			["zone"] = "Throne of the Tides",
			["encounter"] = "Ozumat",
			["try_number"] = 2,
			["index"] = 4,
			["diff"] = 1,
		},
	},
}
DeathGraphsDBEndurance = {
	["490791"] = {
		["hash"] = "490791",
		["type"] = "endurance",
		["name"] = "Commander Ulthok",
		["id"] = 49079,
		["diff"] = 1,
		["player_db"] = {
			["Mallowpuff"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						16.16399999987334, -- [2]
						"Dark Fissure |cFFFF333359,215|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Throne of the Tides",
			["id"] = 1044,
			["mapid"] = 767,
			["try_number"] = 1,
			["diff"] = 1,
			["name"] = "Commander Ulthok",
			["encounter"] = "Commander Ulthok",
		},
	},
	["311251"] = {
		["hash"] = "311251",
		["type"] = "endurance",
		["name"] = "Krik'thir the Gatewatcher",
		["id"] = 31125,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Azjol-Nerub",
			["id"] = 216,
			["mapid"] = 533,
			["try_number"] = 1,
			["diff"] = 1,
			["name"] = "Krik'thir the Gatewatcher",
			["encounter"] = "Krik'thir the Gatewatcher",
		},
	},
	["490641"] = {
		["hash"] = "490641",
		["type"] = "endurance",
		["name"] = "Commander Ulthok, the Festering Prince",
		["id"] = 49064,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 767,
			["diff_string"] = "Normal",
			["index"] = 2,
			["zone"] = "Throne of the Tides",
			["encounter"] = "Commander Ulthok, the Festering Prince",
			["diff"] = 1,
			["name"] = "Commander Ulthok, the Festering Prince",
		},
	},
	["445661"] = {
		["hash"] = "445661",
		["type"] = "endurance",
		["name"] = "Ozumat",
		["id"] = 44566,
		["diff"] = 1,
		["player_db"] = {
		},
		["boss_table"] = {
			["mapid"] = 767,
			["diff_string"] = "Normal",
			["name"] = "Ozumat",
			["zone"] = "Throne of the Tides",
			["encounter"] = "Ozumat",
			["try_number"] = 2,
			["index"] = 4,
			["diff"] = 1,
		},
	},
}
DeathGraphsDBCurrent = {
	{
		["deaths"] = {
			{
				["maxhealth"] = 33963,
				["timeofdeath"] = 16.16399999987334,
				["name"] = "Mallowpuff",
				["time"] = 1643710171.556,
				["class"] = "WARLOCK",
				["timestring"] = "0m 16s",
				["events"] = {
					{
						false, -- [1]
						63106, -- [2]
						269, -- [3]
						1643710164.546, -- [4]
						49112, -- [5]
						"Mallowpuff", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						63106, -- [2]
						239, -- [3]
						1643710166.471, -- [4]
						43755, -- [5]
						"Mallowpuff", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						63106, -- [2]
						239, -- [3]
						1643710168.354, -- [4]
						43755, -- [5]
						"Mallowpuff", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						63106, -- [2]
						239, -- [3]
						1643710170.273, -- [4]
						43755, -- [5]
						"Mallowpuff", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						4, -- [1]
						76094, -- [2]
						1, -- [3]
						1643710170.763, -- [4]
						43755, -- [5]
						"Commander Ulthok", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						108366, -- [2]
						6564, -- [3]
						1643710171.556, -- [4]
						1, -- [5]
						"Mallowpuff", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [6]
					{
						true, -- [1]
						76047, -- [2]
						59215, -- [3]
						1643710171.556, -- [4]
						1, -- [5]
						"Commander Ulthok", -- [6]
						6564, -- [7]
						32, -- [8]
						false, -- [9]
						8896, -- [10]
					}, -- [7]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Mallowpuff", -- [6]
					}, -- [8]
				},
			}, -- [1]
		},
		["bossname"] = "Lady Naz'jar",
		["bossicon"] = {
			0, -- [1]
			0.25, -- [2]
			0, -- [3]
			0.25, -- [4]
			"Interface\\AddOns\\Details\\images\\dungeon\\ThroneoftheTides_BossFaces", -- [5]
		},
		["date"] = 1416393.825,
		["timeelapsed"] = 63.60899999993853,
	}, -- [1]
}
DeathGraphsDBGraph = {
}
