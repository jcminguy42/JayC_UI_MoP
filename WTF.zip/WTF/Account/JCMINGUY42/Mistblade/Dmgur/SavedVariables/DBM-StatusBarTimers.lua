
DBT_PersistentOptions = {
	["DBM"] = {
		["HugeTimerPoint"] = "CENTER",
		["TimerPoint"] = "TOPRIGHT",
		["TimerX"] = -223.0000152587891,
		["HugeTimerX"] = 0,
		["TimerY"] = -260,
		["HugeTimerY"] = -120,
	},
}
