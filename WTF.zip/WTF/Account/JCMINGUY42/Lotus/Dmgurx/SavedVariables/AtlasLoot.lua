
AtlasLootCharDB = {
	["namespaces"] = {
		["WishList"] = {
		},
	},
	["profileKeys"] = {
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
	},
	["AtlasLootVersion"] = "70703",
}
