
EncounterDetailsDB = {
	["emotes"] = {
	},
}
