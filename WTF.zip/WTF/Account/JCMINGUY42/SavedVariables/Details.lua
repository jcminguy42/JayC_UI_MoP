
_detalhes_global = {
	["npcid_pool"] = {
		[69134] = "Kazra'jin",
		[40788] = "Mindbender Ghur'sha",
		[69390] = "Zandalari Storm-Caller",
		[69518] = "Zeb'tula Spearanger",
		[61450] = "Kargesh Grunt",
		[59467] = "Candlestick Mage",
		[67855] = "Red Eye",
		[10317] = "Blackhand Elite",
		[59723] = "Great Wall Explosion Caster Stalker",
		[10381] = "Ravaged Cadaver",
		[10413] = "Crypt Beast",
		[10429] = "Warchief Rend Blackhand <Gyth>",
		[62346] = "Galleon",
		[62474] = "Unga Spearscamp",
		[40021] = "Incendiary Spark",
		[69903] = "Shan'ze Soulripper",
		[56589] = "Striker Ga'dok",
		[56717] = "Hoptallus",
		[21298] = "Corrupt Devotion Aura",
		[40597] = "Geyser <Lady Naz'jar>",
		[61131] = "Mogu'shan Secret-Keeper",
		[69136] = "Zandalari Speaker",
		[69264] = "Shan'ze Thundercaller",
		[67473] = "Animated Warrior",
		[67857] = "Cross-Eye",
		[4385] = "Withervine Rager",
		[66194] = "Waste Scavenger",
		[68497] = "Unknown",
		[39446] = "Lycanthoth",
		[3241] = "Savannah Patriarch",
		[23953] = "Prince Keleseth",
		[13020] = "Vaelastrasz the Corrupt",
		[6520] = "Scorching Elemental",
		[64458] = "Kor'thik Warsinger",
		[62475] = "Unga Bird-Haver",
		[3273] = "Kolkar Stormer",
		[67858] = "Appraising Eye",
		[64714] = "Shek'zeer Needler",
		[62731] = "Unknown",
		[56654] = "Wild Stalker",
		[56718] = "Explosive Brew",
		[70545] = "Mysterious Mushroom",
		[60940] = "Shadowy Minion",
		[59021] = "Bataari Flamecaller",
		[11197] = "Mindless Skeleton <Lord Aurius Rivendare>",
		[59213] = "Woven Boneguard",
		[9198] = "Spirestone Mystic",
		[30702] = "Flame Orb",
		[417] = "Felhunter",
		[57422] = "Mutated Silkmoth",
		[9262] = "Firebrand Invoker",
		[63691] = "Huo-Shuang",
		[53520] = "Plump Lava Worm",
		[37208] = "Thunderhead",
		[59789] = "Thalnos the Soulrender",
		[24849] = "Proto-Drake Rider",
		[69395] = "Unknown",
		[40023] = "Defiled Earth Rager",
		[67860] = "Evil Eye",
		[38104] = "Unknown",
		[56591] = "Pearlfin Aqualyte",
		[25265] = "Demonic Vapor <Wafty>",
		[58766] = "Glade Singer",
		[64971] = "Zan'thik Impaler",
		[21299] = "Coilfang Fathom-Witch",
		[4825] = "Aku'mai Snapjaw",
		[69012] = "Lesser Diffused Lightning <Ravenppc>",
		[36633] = "Ice Sphere",
		[69268] = "Frozen Orb <Drakkari Frozen Warlord>",
		[61389] = "Kargesh Highguard",
		[61453] = "Mu'Shiba",
		[15931] = "Grobbulus",
		[59726] = "Peril",
		[15979] = "Tomb Horror",
		[61965] = "Sap Puddle",
		[59982] = "Meat Graft",
		[13996] = "Blackwing Technician",
		[69013] = "Diffused Lightning",
		[23954] = "Ingvar the Plunderer",
		[62285] = "Shan'ze Ancestor",
		[58319] = "Lesser Sha",
		[39960] = "Deep Murloc Drudge",
		[20052] = "Crystalcore Mechanic",
		[18069] = "Mogor",
		[12141] = "Unknown",
		[58831] = "Bound Servant <Scholomance Neophyte>",
		[44566] = "Ozumat",
		[63053] = "Garalon's Leg",
		[69014] = "Greater Diffused Lightning",
		[69398] = "Unknown",
		[24562] = "Nerub'ar Invader",
		[69910] = "Drakkari Frost Warden",
		[63693] = "Sra'thik Swarmlord",
		[10318] = "Blackhand Assassin",
		[10366] = "Rage Talon Dragon Guard",
		[24850] = "Kalecgos",
		[24882] = "Brutallus",
		[60047] = "Amethyst Guardian",
		[18805] = "High Astromancer Solarian",
		[39705] = "Ascendant Lord Obsidius",
		[62350] = "Salyin Skirmisher",
		[12557] = "Grethok the Controller",
		[37978] = "Triumph War Gryphon",
		[29264] = "Spirit Wolf <Plebbi>",
		[64717] = "Dread Kunchong",
		[68248] = "Corpse Spider",
		[64973] = "Zan'thik Manipulator",
		[21268] = "Netherstrand Longbow",
		[65229] = "Kypa'rak",
		[25618] = "Varidus the Flenser",
		[37083] = "Terrortooth Runner",
		[61711] = "Water Totem",
		[19701] = "Bonechewer Evoker",
		[64014] = "Unknown",
		[37531] = "Frostwarden Handler",
		[69017] = "Primordius",
		[60240] = "Spirit Totem <Gara'jal the Spiritbinder>",
		[62351] = "Salyin Warmonger",
		[69657] = "Zeb'tula Beastcaller",
		[65691] = "Sha Globe",
		[56658] = "Corrupt Droplet",
		[58961] = "Bataari Yaungol",
		[59153] = "Rattlegore",
		[63311] = "Scar-Shell",
		[9199] = "Spirestone Enforcer",
		[61392] = "Harthak Flameseeker",
		[69658] = "Zeb'tula Raptor",
		[9263] = "Firebrand Dreadweaver",
		[37084] = "Terrortooth Scytheclaw",
		[61712] = "Fire Totem <Prismma>",
		[37532] = "Frostwing Whelp",
		[39643] = "Hovel Shadowcaster",
		[69147] = "Unknown",
		[60241] = "Lightning Charge",
		[62352] = "Chief Salyis",
		[31216] = "Wintertouch <Wintertouch>",
		[62480] = "Trained Jungle Lory",
		[62608] = "Gai-Cho Pitchthrower",
		[60753] = "Ookin Marauder",
		[25363] = "Sunblade Cabalist",
		[56915] = "Sun",
		[65231] = "Kypari Crawler",
		[69148] = "Bloodrender Devilsaur",
		[63312] = "Jol'Grum",
		[53141] = "Molten Surger",
		[57299] = "Glade Hunter",
		[63568] = "Amber-Ridden Mushan",
		[5913] = "Tremor Totem <Intrade>",
		[15932] = "Gluth",
		[5929] = "Magma Totem <Flubbah>",
		[15980] = "Naxxramas Cultist",
		[16028] = "Patchwerk",
		[37533] = "Rimefang",
		[16060] = "Gothik the Harvester",
		[23956] = "Dragonflayer Strategist",
		[64336] = "Setting Sun Turret",
		[16124] = "Unrelenting Trainee",
		[24084] = "Tunneling Ghoul",
		[16156] = "Dark Touched Warrior",
		[64720] = "Shek'zeer Manipulator",
		[70429] = "Flesh'rok the Diseased",
		[58835] = "Tar",
		[58899] = "Wildscale Poacher",
		[12222] = "Creeping Sludge",
		[59155] = "Book Case",
		[63313] = "Little Liuyang",
		[53206] = "Hell Hound",
		[131072] = "Monkey",
		[63569] = "Amber Searsting",
		[37022] = "Blighted Abomination",
		[55509] = "Konk",
		[61714] = "Air Totem <Prismma>",
		[10383] = "Unknown <Ravaged Cadaver>",
		[10399] = "Thuzadin Acolyte",
		[60051] = "Cobalt Guardian",
		[62162] = "Horrorscale Scorpid",
		[10447] = "Chromatic Dragonspawn",
		[10463] = "Shrieking Banshee",
		[14605] = "Bone Construct",
		[69791] = "Qiqi <Qiqi>",
		[70047] = "Unknown",
		[25268] = "Unyielding Dead",
		[21270] = "Cosmic Infuser",
		[65169] = "Jade Colossus",
		[57109] = "Minion of Doubt",
		[29618] = "Snowblind Follower",
		[4346] = "Noxious Flayer",
		[25588] = "Hand of the Deceiver",
		[131076] = "Limbchomp",
		[61523] = "Sha of Anger <Sha of Anger>",
		[4378] = "Darkmist Recluse",
		[70176] = "Horgak the Enslaver",
		[70432] = "Cinders",
		[41501] = "Fiery Minion",
		[6505] = "Ravasaur",
		[64338] = "Instructor Kli'thak",
		[6521] = "Living Blaze",
		[24085] = "Dragonflayer Overseer",
		[60692] = "Osul Marauder",
		[62995] = "Animated Protector",
		[56918] = "Mantid Munitions",
		[65170] = "Jade Warrior",
		[69154] = "Zandalari Saurcaller",
		[65362] = "Minion of Doubt",
		[9200] = "Spirestone Reaver",
		[38879] = "Putricide's Trap",
		[69666] = "Zur'chaka the Bonecrafter",
		[16441] = "Guardian of Icecrown",
		[67875] = "Mind's Eye",
		[59605] = "Sodden Hozen Brawler",
		[37216] = "Honor's Stand Officer",
		[59797] = "Mogujia Soul-Caller",
		[41502] = "Twilight Field Captain",
		[9376] = "Blazerunner",
		[62164] = "Crush",
		[69155] = "Zandalari Fetish-Binder",
		[64339] = "Instructor Tak'thok",
		[65573] = "Ik'thik Warrior",
		[11583] = "Nefarian",
		[70179] = "Ritual Guard",
		[64979] = "Vess-Guard Vik'az",
		[131083] = "MastaCat",
		[4818] = "Blindlight Murloc",
		[4834] = "Theramore Infiltrator",
		[34594] = "Burning Blade Raider",
		[63316] = "Cloudbender Kobo",
		[69540] = "Zeb'tula Raptor",
		[59414] = "Broketooth Charger",
		[37025] = "Stinky",
		[63764] = "Battleworn Paratrooper",
		[70308] = "Soul-Fed Construct",
		[15981] = "Naxxramas Acolyte",
		[131085] = "Water Elemental",
		[30003] = "Gnarlhide",
		[16061] = "Instructor Razuvious",
		[11983] = "Firemaw",
		[64340] = "Instructor Maltik",
		[26101] = "Fire Fiend <Sunblade Cabalist>",
		[62485] = "Gagoon",
		[58455] = "Stillwater Crocolisk",
		[69925] = "Zandalari Dinomancer",
		[62677] = "Deadtalker Corpsedefiler",
		[64852] = "Jade Sentinel",
		[64916] = "Kor'thik Swarmguard",
		[60886] = "Coalesced Corruption",
		[131087] = "Rotchewer",
		[18297] = "Gankly Rottenfist",
		[59223] = "Brother Korloff",
		[61334] = "Cursed Mogu Sculpture",
		[24566] = "Nerub'ar Skitterer",
		[131088] = "Lazham",
		[59479] = "Yan-Zhu the Uncasked",
		[16506] = "Naxxramas Worshipper",
		[61910] = "Resin Flake",
		[131089] = "Water Elemental",
		[10400] = "Thuzadin Necromancer",
		[12463] = "Death Talon Flamescale",
		[64277] = "Spirit Fragment",
		[10464] = "Wailing Banshee",
		[62358] = "Corrupt Droplet",
		[60375] = "Zandalari Skullcharger",
		[131090] = "Wolf",
		[58456] = "Thundermaw",
		[69927] = "Zandalari Prelate",
		[70439] = "Torrent of Ice",
		[21272] = "Warp Slicer",
		[65173] = "Echo of Attenuation",
		[63318] = "Chagan Firehoof",
		[61399] = "Glintrok Scout",
		[59416] = "Broketooth Tosser",
		[59480] = "Brittle Skeleton",
		[59544] = "The Nodding Tiger",
		[59672] = "Summit Bonestripper",
		[27829] = "Unknown",
		[25814] = "Fizzcrank Mechagnome",
		[27893] = "Rune Weapon <Mintti>",
		[131093] = "Lobo",
		[68905] = "Lu'lin",
		[19833] = "Venomous Snake <Yoshisuke>",
		[69161] = "Oondasta",
		[62295] = "Omnia Mage",
		[131094] = "Khaafun",
		[58457] = "Silkfeather Hawk",
		[22104] = "Unknown",
		[62679] = "Defiled Spirit",
		[62743] = "Sonic Ring",
		[64982] = "Zan'thik Amberhusk",
		[131095] = "Rootcatcher",
		[65174] = "Echo of Force and Verve",
		[63191] = "Garalon",
		[69162] = "Juvenile Skyscreamer",
		[59225] = "Ball of Fire <Fragrant Lotus>",
		[9201] = "Spirestone Ogre Magus",
		[63447] = "Mogu Statue",
		[47135] = "Fetid Ghoul",
		[39075] = "The Ginormus",
		[15438] = "Greater Fire Elemental <Plebbi>",
		[66348] = "Thunder Hold Armsman",
		[131097] = "Korrorax",
		[58071] = "Trained Compy",
		[60491] = "Sha of Anger",
		[62232] = "Klaxxi Warrior",
		[42707] = "Twilight Nightblade",
		[62360] = "Corrupt Droplet",
		[36701] = "Raging Spirit",
		[62488] = "Grooka Grooka",
		[62552] = "Gai-Cho Yaungol",
		[2630] = "Earthbind Totem <Shakur>",
		[30575] = "Frostbrood Destroyer",
		[62744] = "Sonic Ring",
		[63570] = "Sra'thik Pool-Tender",
		[59800] = "Krik'thik Rager",
		[37782] = "Flesh-eating Insect",
		[21273] = "Phaseshift Bulwark",
		[63694] = "Sra'thik Hivelord",
		[62486] = "Oku-Oku",
		[67854] = "Blue Eye",
		[69164] = "Gurubashi Venom Priest",
		[68241] = "Sha-Infested Yaungol",
		[61337] = "Glintrok Ironhide",
		[69548] = "Unknown",
		[131100] = "Spellhaste <Nim>",
		[19514] = "Al'ar",
		[59546] = "The Talking Fish",
		[37093] = "Lashvine",
		[59552] = "The Crybaby Hozen",
		[59738] = "Light's Hammer <Smashval>",
		[68397] = "Lei Shen",
		[27894] = "Antipersonnel Cannon",
		[59930] = "Empowered Zombie <Empowering Spirit>",
		[69269] = "Zandalari Prospect",
		[65584] = "Ik'thik Slayer",
		[68904] = "Suen",
		[23960] = "Dragonflayer Runecaster",
		[69133] = "Unharnessed Power",
		[39844] = "Howling Riftdweller",
		[16126] = "Unknown",
		[131102] = "Nuri",
		[1016200] = "Lord Victor Nefarius",
		[65839] = "Razorquill Porcupine",
		[40164] = "Fire Cyclone",
		[4810] = "Twilight Reaver",
		[69911] = "Zandalari Warlord",
		[70445] = "Stormbringer Draz'kil",
		[30453] = "Onyx Sanctum Guardian",
		[131103] = "Water Elemental",
		[58971] = "Webbed Victim",
		[30549] = "Baron Rivendare",
		[61146] = "Black Ox Statue <Sheega>",
		[63257] = "Ik'thik Genemancer",
		[59227] = "Wander's Colossal Book of Shadow Puppets",
		[65432] = "Kyparite Pulverizer",
		[65496] = "Dread Fearbringer",
		[47137] = "Mindless Horror",
		[59483] = "Ur-Bataar",
		[59547] = "Jiang",
		[56349] = "Puckish Sprite",
		[53732] = "Unbound Smoldering Elemental",
		[63833] = "Mutating Scorpid",
		[21269] = "Devastation",
		[12416] = "Blackwing Legionnaire",
		[47649] = "Wild Mushroom",
		[59804] = "Unknown",
		[10417] = "Venom Belcher",
		[59102] = "Forest Huntress",
		[69167] = "Gurubashi Bloodlord",
		[3977] = "High Inquisitor Whitemane",
		[15930] = "Feugen",
		[131114] = "Unknown",
		[131106] = "Khuufum",
		[62554] = "Cheng Bo",
		[62618] = "Cosmic Spark",
		[56541] = "Master Snowdrift",
		[40229] = "Scalding Rock Elemental",
		[60763] = "Longying Ranger",
		[9045] = "Scarshield Acolyte",
		[61449] = "Harthak Adept",
		[21274] = "Staff of Disintegration",
		[39980] = "Twilight Sadist",
		[69388] = "Zandalari Spear-Shaper",
		[59100] = "Expired Test Subject",
		[69168] = "Amani'shi Flame Caster",
		[29622] = "Savage Hill Mystic",
		[61339] = "Glintrok Oracle",
		[25592] = "Doomfire Destroyer",
		[69680] = "Ginzo <Ginzo>",
		[15439] = "Fire Elemental Totem <Dosnoventa>",
		[4379] = "Darkmist Silkspinner",
		[40814] = "Azralon the Gatekeeper",
		[25752] = "Scavenge-bot 004-A8",
		[63176] = "Ik'thik Egg-Drone",
		[70448] = "Ancient Python",
		[12464] = "Death Talon Seether",
		[53791] = "Blazing Monstrosity",
		[24083] = "Enslaved Proto-Drake",
		[16697] = "Unknown",
		[62492] = "Unga Totemchipper",
		[69169] = "Amani'shi Protector",
		[64346] = "Parasitoid Sha",
		[64917] = "Sra'thik Ambercaller",
		[69553] = "Shadowed Loa Spirit",
		[131110] = "Coleth",
		[69906] = "Zandalari High Priest",
		[66463] = "Longshadow Bull",
		[36272] = "Apothecary Frye",
		[67852] = "Unknown",
		[56395] = "Shado-Pan Novice",
		[46499] = "Guardian of Ancient Kings <Hahahaha>",
		[40935] = "Gilgoblin Hunter",
		[56862] = "Drunken Hozen Brawler",
		[69515] = "Zandalari Barricade",
		[131116] = "Crane",
		[19516] = "Void Reaver",
		[69170] = "Zandalari Commoner",
		[69298] = "Zandalari Spearanger",
		[59293] = "Scarlet Cannoneer",
		[9218] = "Spirestone Battle Lord",
		[38951] = "Twilight Assassin",
		[59299] = "Scarlet Guardian",
		[9266] = "Smolderthorn Witch Doctor",
		[59613] = "Professor Slate",
		[66100] = "Apparition of Terror",
		[63835] = "Sonic Pulse",
		[11121] = "Black Guard Swordsmith",
		[53793] = "Harbinger of Flame",
		[13456] = "Noxxion's Spawn <Noxxion>",
		[56472] = "Fragrant Lotus",
		[3374] = "Bael'dun Excavator",
		[16125] = "Unrelenting Death Knight",
		[69171] = "Zandalari Jaguar Warrior",
		[58898] = "Vigilant Watchman",
		[69427] = "Dark Animus",
		[3394] = "Barak Kodobane",
		[16925] = "Bonechewer Raider",
		[62813] = "Vor'thik Dreadsworn",
		[25840] = "Entropius",
		[58590] = "Scarlet Zealot",
		[60701] = "Zian of the Endless Shadow",
		[70557] = "Zandalari Prophet",
		[62613] = "Unknown",
		[131144] = "Emily",
		[4811] = "Twilight Aquamancer",
		[4819] = "Blindlight Muckdweller",
		[4827] = "Deep Pool Threshfin",
		[63196] = "Blackguard Battlemaster",
		[69172] = "Sul'lithuz Stonegazer",
		[29623] = "Savage Hill Brute",
		[61341] = "Mounted Mogu",
		[69556] = "Marked Soul",
		[11793] = "Celebrian Dryad",
		[59486] = "Bataari Banner Guard",
		[56473] = "Flying Snow",
		[59614] = "Bored Student",
		[37161] = "Honor's Stand Footman",
		[63836] = "Sonic Pulse",
		[33195] = "Ashenvale Bowman",
		[63495] = "Hatescale Ironface",
		[61981] = "Dreadspinner Tender",
		[28921] = "Hadronox",
		[9197] = "Spirestone Battle Mage",
		[16063] = "Sir Zeliek",
		[69173] = "Farraki Skirmisher",
		[62301] = "Adjunct Kree'zot",
		[12017] = "Broodlord Lashlayer",
		[16127] = "Spectral Trainee",
		[62493] = "Monkey Island Totem <Unga Totemchipper>",
		[62557] = "Unga Totem",
		[20060] = "Lord Sanguinar",
		[70069] = "Shan'ze Animator",
		[56792] = "Figment of Doubt",
		[56672] = "Mistweaver Adept",
		[37165] = "Henry Zykes",
		[59607] = "Spectral Guise <Satella>",
		[60958] = "Pinning Arrow",
		[56906] = "Saboteur Kip'tilak",
		[37090] = "Deviate Terrortooth",
		[59103] = "Forest Cub",
		[34603] = "Unknown",
		[21875] = "Shadow of Leotheras",
		[50783] = "Salyin Warscout",
		[59359] = "Flesh Horror",
		[131120] = "狼",
		[59487] = "Bubble Shield",
		[59551] = "Bopper",
		[60885] = "Minion of Fear",
		[24207] = "Army of the Dead",
		[63837] = "Sonic Pulse",
		[62759] = "Kor'thik Scorpid",
		[65803] = "Cobalt Mine",
		[53794] = "Smouldering Hatchling",
		[20435] = "Overseer Athanel",
		[40936] = "Faceless Watcher",
		[60127] = "Ordo Warbringer",
		[69175] = "Farraki Wastewalker",
		[64454] = "Zar'thik Augurer",
		[69431] = "Shan'ze Bloodseeker",
		[56289] = "Riverstride Jinyu",
		[62494] = "Unga Nibstabber",
		[48229] = "Kobold Digger",
		[131154] = "Core Hound",
		[68024] = "Unknown",
		[59553] = "The Songbird Queen",
		[62814] = "Vor'thik Fear-Shaper",
		[21212] = "Lady Vashj",
		[20031] = "Bloodwarder Legionnaire",
		[131123] = "Elemental de agua",
		[56929] = "Krik'thik Protectorate",
		[70586] = "Eternal Guardian",
		[37217] = "Precious",
		[69176] = "Amani'shi Beast Shaman",
		[70596] = "Spirit Gaze",
		[39843] = "Twilight Stormcaller",
		[63942] = "Sha of Fear",
		[131124] = "Brainripper",
		[131086] = "Water Elemental",
		[69944] = "Sand Elemental",
		[25722] = "Coldarra Spellweaver",
		[5419] = "Glasshide Basilisk",
		[131119] = "FAROFA",
		[59808] = "Shado-Pan Stormbringer",
		[11794] = "Sister of Celebras",
		[53795] = "Egg Pile",
		[67977] = "Tortos",
		[37229] = "Frostwarden Sorceress",
		[56034] = "Thieving Plainshawk",
		[69177] = "Amani Warbear",
		[37038] = "Vengeful Fleshreaper",
		[30071] = "Stitched Colossus",
		[60384] = "Zandalari Pterror Wing",
		[131126] = "Spirit Beast",
		[62559] = "Shan'ze Deathspeaker",
		[60576] = "Stone Quilen",
		[12459] = "Blackwing Warlock",
		[62751] = "Dread Lurker",
		[60768] = "Energizing Smash",
		[22236] = "Water Elemental Totem <Greyheart Tidecaller>",
		[46249] = "Riverpaw Slayer",
		[131127] = "Thulnuz",
		[44648] = "Unyielding Behemoth",
		[42475] = "Fungal Behemoth",
		[69050] = "Crimson Fog",
		[61216] = "Glintrok Hexxer",
		[71353] = "Viletongue Decimator",
		[30680] = "Onyx Brood General",
		[9219] = "Spirestone Butcher",
		[36627] = "Rotface",
		[28729] = "Watcher Narjil",
		[9267] = "Smolderthorn Axe Thrower",
		[70219] = "Putrid Waste",
		[70202] = "Manchu",
		[37228] = "Frostwarden Warrior",
		[59811] = "Unstable Energy",
		[59873] = "Corrupt Living Water",
		[16145] = "Death Knight Captain",
		[45672] = "Naz'jar Soldier",
		[37548] = "Grasping Overgrowth",
		[69051] = "Amber Fog",
		[69909] = "Amani'shi Flame Chanter",
		[64351] = "Amber Trap",
		[60871] = "Taran Zhu",
		[63782] = "Battleworn Paratrooper",
		[131130] = "Dirtgrinder",
		[67772] = "Creeping Moor Beast",
		[67900] = "Alliance Sentinel",
		[9217] = "Spirestone Lord Magus",
		[62726] = "Sonic Ring",
		[52581] = "Cinderweb Drone",
		[21213] = "Morogrim Tidewalker",
		[56803] = "Static Field Stalker",
		[25371] = "Sunblade Dawn Priest",
		[64393] = "Night Terror",
		[25166] = "Grand Warlock Alythess",
		[69052] = "Azure Fog",
		[44841] = "Blight Beast",
		[69711] = "Call Da Storm Stalker North",
		[61345] = "Mogu Archer",
		[16363] = "Unknown",
		[59426] = "Bopper",
		[40107] = "Thol'embaar",
		[67901] = "Alliance Footman",
		[39148] = "Zumonga",
		[15952] = "Maexxna",
		[59746] = "Scarlet Centurion",
		[69383] = "Quivering Blob",
		[25851] = "Volatile Fiend",
		[67030] = "Krik'thik Wingguard",
		[9044] = "Scarshield Sentry",
		[39596] = "Teeming Waterguard",
		[16064] = "Thane Korth'azz",
		[64197] = "Unknown",
		[10412] = "Crypt Crawler",
		[56912] = "Krik'thik Engulfer",
		[60386] = "Zandalari Terror Rider",
		[62497] = "Unga Keg-Blocker",
		[69821] = "Thunder Lord",
		[20062] = "Grand Astromancer Capernian",
		[62689] = "Sonic Ring",
		[70205] = "Weisheng",
		[10083] = "Rage Talon Flamescale",
		[62881] = "Gaohun the Soul-Severer",
		[28410] = "Dragonflayer Spiritualist",
		[131135] = "Unknown",
		[131142] = "Monkeh",
		[70534] = "Skeletal Lasher",
		[34543] = "Fez",
		[69182] = "Gara'jal's Soul",
		[12258] = "Razorlash",
		[40876] = "Kelsey Steelspark",
		[53222] = "Flamewaker Centurion",
		[262144] = "Dagradath",
		[28730] = "Watcher Gashra",
		[59555] = "Haunting Sha",
		[39149] = "Sarinexx",
		[70206] = "Untrained Quilen",
		[45418] = "Grundig Darkcloud",
		[66368] = "Carrion Vulture",
		[10371] = "Rage Talon Captain",
		[131137] = "Esporiélago",
		[24892] = "Curse of Boundless Agony",
		[28017] = "Bloodworm",
		[60131] = "Spirit Worg",
		[61455] = "Gurthan Quilen",
		[64353] = "Set'thik Gale-Slicer",
		[10316] = "Blackhand Incarcerator",
		[63685] = "Sra'thik Swarm-Leader",
		[131138] = "Dog <Notethical>",
		[38199] = "Frostblade <Frostwarden Warrior>",
		[69951] = "Crimson Wake <Large Anima Golem>",
		[62858] = "Beast <Yoshisuke>",
		[59399] = "Skull Banner <Likeanerd>",
		[28731] = "Watcher Silthik",
		[46506] = "Guardian of Ancient Kings <Zaxc>",
		[21246] = "Serpentshrine Sporebat",
		[69382] = "Malignant Ooze",
		[69254] = "Spiritbinder Cha'lat",
		[44715] = "Vicious Mindlasher",
		[61155] = "Wily Woodling",
		[69184] = "Risen Drakkari Warrior",
		[54702] = "Gormali Raider",
		[61347] = "Kingsguard",
		[53223] = "Flamewaker Beast Handler",
		[131112] = "Unknown",
		[39022] = "Tidal Strider",
		[45227] = "Darkmist Broodqueen",
		[37232] = "Nerub'ar Broodling",
		[60621] = "Corrupted Waters <Elder Asani>",
		[61003] = "Dread Spawn <[*] Conjure Dread Spawn>",
		[70533] = "Skeletal Lashling",
		[10339] = "Gyth",
		[60447] = "Krik'thik Saboteur",
		[37744] = "Frost Freeze Trap",
		[25948] = "Doomfire Shard <Doomfire Destroyer>",
		[9524] = "Kolkar Invader",
		[23965] = "Unknown",
		[69313] = "Living Poison",
		[20048] = "Crimson Hand Centurion",
		[58726] = "Scarlet Cannon",
		[39982] = "Crazed Mage",
		[62563] = "Shek'zeer Bladesworn",
		[46251] = "Riverpaw Looter",
		[62691] = "Unknown",
		[60708] = "Meng the Demented",
		[56678] = "Jade Staff",
		[22238] = "Serpentshrine Tidecaller <Greyheart Tidecaller>",
		[26125] = "Risen Ally <Eisberg>",
		[62405] = "Sra'thik Amber-Trapper",
		[4812] = "Twilight Loreseeker",
		[63625] = "Krik'thik Battletank",
		[34545] = "Razormane Frenzy",
		[40943] = "Gilgoblin Aquamage",
		[13282] = "Noxxion",
		[42925] = "Ravenous Tunneler",
		[53224] = "Flamewaker Taskmaster",
		[9236] = "Shadow Hunter Vosh'gajin",
		[69826] = "Zandalari Striker",
		[9268] = "Smolderthorn Berserker",
		[47131] = "Frantic Geist",
		[69454] = "Unknown",
		[68291] = "Ice Wall",
		[59240] = "Scarlet Hall Guardian",
		[70594] = "Mist Lurker",
		[70153] = "Fungal Growth",
		[6243] = "Gelihast",
		[10416] = "Bile Spewer",
		[3271] = "Razormane Mystic",
		[25741] = "M'uru",
		[64355] = "Kor'thik Silentwing",
		[15929] = "Stalagg",
		[18944] = "Fel Soldier",
		[69699] = "Massive Anima Golem",
		[131117] = "Snuggles",
		[46252] = "Riverpaw Shaman",
		[68036] = "Durumu the Forgotten",
		[62756] = "Kor'thik Chitinel",
		[19136] = "Flamewaker Imp",
		[21215] = "Leotheras the Blind",
		[64995] = "Adjunct Sek'ot",
		[25373] = "Shadowsword Soulbinder",
		[4820] = "Blindlight Oracle",
		[62795] = "Sik'thik Warden",
		[25469] = "Mindless Aberration",
		[9684] = "Lar'korwi",
		[61445] = "Haiyan the Unstoppable",
		[19424] = "Bleeding Hollow Tormentor",
		[38896] = "Blazebound Elemental",
		[131148] = "Tombleaper",
		[59494] = "Yeasty Brew Alemental",
		[59598] = "Lesser Sha",
		[60583] = "Protector Kaolan",
		[11859] = "Doomguard <Caries>",
		[29404] = "Savage Hill Scavenger",
		[40925] = "Tainted Sentry",
		[63972] = "Krik'thik Hiveling",
		[16017] = "Patchwork Golem",
		[4832] = "Twilight Lord Kelris",
		[62860] = "Beast <Kander>",
		[16065] = "Lady Blaumeux",
		[18402] = "Warmaul Champion",
		[62980] = "Imperial Vizier Zor'lok",
		[58822] = "Unknown",
		[16129] = "Shadow Fissure <Kel'Thuzad>",
		[131150] = "Элементаль воды",
		[20032] = "Bloodwarder Vindicator",
		[20064] = "Thaladred the Darkener",
		[16193] = "Skeletal Smith",
		[60710] = "Subetai the Swift",
		[2523] = "Searing Totem <Bloodlustbot>",
		[58791] = "Unknown",
		[66503] = "Thunder Hold Infantryman",
		[131151] = "Zeple",
		[43499] = "Consecration",
		[59150] = "Flameweaver Koegler",
		[30682] = "Onyx Flight Captain",
		[59175] = "Master Archer",
		[62311] = "Shan'ze Cloudrunner",
		[18401] = "Skra'gath",
		[65508] = "Snagtooth Pesterling",
		[131152] = "Ratkeeper",
		[28732] = "Anub'ar Warrior",
		[25165] = "Lady Sacrolash",
		[61670] = "Sik'thik Demolisher",
		[62758] = "Kor'thik Battlesinger",
		[28860] = "Sartharion",
		[56106] = "Thieving Wolf",
		[10372] = "Rage Talon Fire Tongue",
		[131153] = "Bragkek",
		[10404] = "Pustulating Horror",
		[62602] = "Kri'thik Screecher",
		[39665] = "Rom'ogg Bonecrusher",
		[61387] = "Quilen Guardian",
		[64357] = "Kor'thik Swarmer",
		[59309] = "Obedient Hound",
		[64485] = "Young Kunchong",
		[39985] = "Mad Prisoner",
		[50284] = "Twilight Zealot",
		[46254] = "Hogger",
		[60647] = "Osul Sharphorn",
		[46382] = "Petty Criminal",
		[9237] = "War Master Voone",
		[21216] = "Hydross the Unstable",
		[66505] = "Thunder Hold Armsman",
		[64195] = "Muckscale Shaman",
		[28733] = "Anub'ar Shadowcaster",
		[36897] = "Unknown",
		[61159] = "Greenstone Terror",
		[65317] = "Xiang",
		[40817] = "Shadow of Obsidius",
		[39978] = "Twilight Torturer",
		[59368] = "Krastinovian Carver",
		[25593] = "Apocalypse Guard",
		[58910] = "Plainshawk",
		[67913] = "Dwarven Mortar Team Engineer",
		[41201] = "Noxious Mire",
		[25758] = "Defendo-tank 66D",
		[59752] = "Shado-Pan Ambusher",
		[62633] = "Sik'thik Builder",
		[66506] = "Thunder Hold Cannoneer",
		[64341] = "Instructor Zarik",
		[63592] = "Set'thik Gustwing",
		[70209] = "Untrained Quilen",
		[69065] = "Zandalari Beastcaller",
		[21920] = "Tidewalker Lurker",
		[64358] = "Set'thik Tempest",
		[60459] = "Flame Rider",
		[60392] = "Troll Explosives",
		[36880] = "Decaying Colossus",
		[20033] = "Astromancer",
		[19423] = "Bleeding Hollow Worg",
		[65995] = "Shek'zeer Bladesworn",
		[46383] = "Randolph Moloch",
		[60776] = "Empyreal Focus",
		[56746] = "Carbonation",
		[53128] = "Giant Fire Scorpion",
		[131159] = "Water Elemental",
		[59205] = "Mantid Munitions",
		[15953] = "Grand Widow Faerlina",
		[62508] = "Unga Brewstealer",
		[61224] = "Blind Rage",
		[59241] = "Scarlet Treasurer",
		[40882] = "Twilight Infiltrator",
		[59369] = "Doctor Theolen Krastinov",
		[131160] = "Marrowstalker",
		[69834] = "Lightning Guardian",
		[9269] = "Smolderthorn Seer",
		[62029] = "Greatback Mushan",
		[9264] = "Firebrand Pyromancer",
		[89] = "Infernal",
		[61034] = "Terror Spawn",
		[61928] = "Sik'thik Guardian",
		[61929] = "Sik'thik Amber-Weaver",
		[60009] = "Feng the Accursed",
		[59915] = "Jasper Guardian",
		[59794] = "Krik'thik Disruptor",
		[16803] = "Death Knight Understudy",
		[29117] = "Anub'ar Champion",
		[52498] = "Beth'tilac",
		[60393] = "Troll Explosives",
		[39987] = "Evolved Twilight Zealot",
		[62568] = "Gai-Cho Gatewatcher",
		[62632] = "Sik'thik Engineer",
		[63206] = "Ik'thik Harvester",
		[60713] = "Osul Charger",
		[69702] = "Ritualist Kitling",
		[56747] = "Gu Cloudstrike",
		[131167] = "Earthfeeder",
		[56875] = "Krik'thik Demolisher",
		[16290] = "Fallout Slime",
		[25369] = "Sunblade Vindicator",
		[36597] = "The Lich King",
		[40755] = "Emissary of Flame",
		[59242] = "Woven Boneguard",
		[40883] = "Skywall Denizen",
		[19458] = "Ripp",
		[21966] = "Fathom-Guard Sharkkis",
		[69836] = "Juvenile",
		[41139] = "Naz'jar Spiritmender",
		[30452] = "Power of Tenebron",
		[41500] = "Twilight Scorchlord",
		[39708] = "Twilight Flame Caller",
		[69825] = "Thunder Trap",
		[63976] = "Krik'thik Needler",
		[16018] = "Bile Retcher",
		[16034] = "Plague Beast",
		[59972] = "Ordo Warrior",
		[69069] = "Living Fluid",
		[10319] = "Blackhand Iron Guard",
		[45410] = "Elder Stormhoof",
		[60585] = "Elder Regail",
		[30205] = "Forgotten Depths Acolyte",
		[16146] = "Death Knight",
		[20034] = "Star Scryer",
		[60586] = "Elder Asani",
		[30333] = "Forgotten Depths Slayer",
		[67859] = "Hungry Eye",
		[69700] = "Large Anima Golem",
		[56748] = "Sudsy Brew Alemental <Sudsy Brew Alemental>",
		[24320] = "Fire Nova Totem",
		[56876] = "Krik'thik Sapper",
		[44658] = "Deep Murloc Invader",
		[59051] = "Strife",
		[69070] = "Viscous Horror",
		[46248] = "Riverpaw Basher",
		[9216] = "Spirestone Warlord",
		[40884] = "Deepholm Denizen",
		[69582] = "Ice Wall <Blue Eye>",
		[36943] = "Bristleback Invader",
		[28734] = "Anub'ar Skirmisher",
		[63490] = "Hatescale Spitter",
		[59372] = "Scarlet Scholar",
		[53127] = "Fire Scorpion",
		[10814] = "Chromatic Elite Guard",
		[69713] = "Call Da Storm Stalker East",
		[12420] = "Blackwing Mage",
		[3243] = "Savannah Highmane",
		[10405] = "Plague Ghoul",
		[12468] = "Death Talon Hatcher",
		[10437] = "Nerub'enkan",
		[63973] = "Krik'thik Swarmer",
		[29118] = "Anub'ar Crypt Fiend",
		[69455] = "Zandalari Water-Binder",
		[62442] = "Tsulong",
		[29214] = "Anub'ar Assassin",
		[30110] = "Hungry Penguin <Orinoko Tuskbreaker>",
		[39926] = "Twilight Inciter",
		[70095] = "Juvenile",
		[62762] = "Amber Pool Stalker",
		[62826] = "Keening Spirit",
		[21218] = "Vashj'ir Honor Guard",
		[68480] = "Iron Qon's Spear <Iron Qon>",
		[56877] = "Raigonn",
		[131084] = "Water Elemental",
		[17252] = "Felguard",
		[131081] = "Demosaurio",
		[69200] = "Drakkari God-Hulk",
		[4341] = "Drywallow Crocolisk",
		[53167] = "Unbound Pyrelord",
		[65513] = "Dread Behemoth",
		[69712] = "Ji-Kun",
		[63594] = "Coagulated Amber",
		[55470] = "Hozen Groundpounder",
		[63684] = "Sra'thik Will-Breaker",
		[70224] = "Rotting Scavenger",
		[61989] = "Cursed Mogu Sculpture",
		[25624] = "Infested Prisoner",
		[59884] = "Fallen Crusader <Thalnos the Soulrender>",
		[131082] = "Wolf",
		[30014] = "Yggdras",
		[69185] = "Risen Drakkari Champion",
		[46261] = "Enraged Fire Elemental",
		[6508] = "Venomhide Ravasaur",
		[131113] = "Bigglesworth",
		[62379] = "Omnia Mage",
		[60396] = "Emperor's Rage",
		[39990] = "Twilight Zealot",
		[20035] = "Bloodwarder Marshal",
		[19422] = "Bleeding Hollow Necrolyte",
		[58605] = "Scarlet Judicator",
		[9046] = "Scarshield Quartermaster",
		[44404] = "Naz'jar Tempest Witch",
		[58856] = "Haunting Sha",
		[30451] = "Power of Shadron",
		[60391] = "Troll Explosives",
		[61038] = "Yang Guoshi",
		[18399] = "Murkblood Twin",
		[67027] = "Jungle Brewstealer",
		[63275] = "Corrupted Protector",
		[53006] = "Unknown",
		[65450] = "Ancient Guardian",
		[59373] = "Scarlet Pupil",
		[69714] = "Call Da Storm Stalker South",
		[28735] = "Skittering Swarmer",
		[53648] = "Inferno Hawk",
		[70227] = "Skittering Spiderling",
		[8996] = "Voidwalker Minion",
		[63681] = "Sra'thik Regenerator",
		[70334] = "Stone Sentinel",
		[131077] = "海龟",
		[45620] = "Naz'jar Soldier",
		[66772] = "Beast of Jade",
		[3375] = "Bael'dun Foreman",
		[3379] = "Burning Blade Bruiser",
		[6506] = "Ravasaur Runner",
		[29119] = "Anub'ar Necromancer",
		[69459] = "Bound Water Elemental",
		[60397] = "Emperor's Strength",
		[131178] = "Hyena",
		[69843] = "Zao'cho",
		[46260] = "Searing Destroyer",
		[59302] = "Sergeant Verdone",
		[3415] = "Savannah Huntress",
		[60781] = "Soul Fragment",
		[69374] = "War-God Jalak",
		[4805] = "Blackfathom Sea Witch",
		[4813] = "Twilight Shadowmage",
		[25753] = "Sentry-bot 57-K",
		[4829] = "Aku'mai",
		[59207] = "Mantid Munitions",
		[69438] = "Thrown Spear",
		[40665] = "Southsea Scoundrel <Dmgur>",
		[25591] = "Painbringer",
		[19460] = "Bleeding Hollow Skeleton",
		[61485] = "General Pa'valak",
		[12460] = "Death Talon Wyrmguard",
		[61613] = "Sap Residue",
		[3475] = "Echeyakee",
		[3269] = "Razormane Geomancer",
		[66262] = "Consecration",
		[64620] = "Beast",
		[65575] = "Vor'thik Swarmborn",
		[43101] = "Son of Kor",
		[67966] = "Whirl Turtle",
		[63593] = "Set'thik Zephyrian",
		[14020] = "Chromaggus",
		[23970] = "Vrykul Skeleton",
		[36853] = "Sindragosa",
		[69629] = "Deep Submerge",
		[60398] = "Emperor's Courage",
		[3527] = "Healing Stream Totem",
		[20036] = "Bloodwarder Squire",
		[62637] = "Cursed Brew",
		[62701] = "Mutated Construct",
		[52530] = "Alysrazor",
		[65312] = "Mutant Parasite <Jihong>",
		[131105] = "Water Elemental",
		[10438] = "Maleki the Pallid",
		[63021] = "Pheromone Trail",
		[65132] = "Shao-Tien Conqueror",
		[58928] = "Shao-Tien Antiquator",
		[69078] = "Sul the Sandcrawler",
		[68221] = "Bore Worm",
		[29184] = "Impale Target",
		[65452] = "Vengeful Gurthani Spirit",
		[29619] = "Garm Invader",
		[131184] = "Water Elemental",
		[59503] = "Brittle Skeleton",
		[25867] = "Sunblade Dragonhawk",
		[5429] = "Fire Roc",
		[70230] = "Zandalari Blade Initiate",
		[63853] = "Zar'thik Supplicant",
		[66392] = "Unknown",
		[10374] = "Spire Spider",
		[10390] = "Skeletal Guardian",
		[10406] = "Ghoul Ravener",
		[63872] = "Batu",
		[60143] = "Gara'jal the Spiritbinder",
		[37690] = "Unknown",
		[29120] = "Anub'arak",
		[5935] = "Ironeye the Invincible",
		[60399] = "Qin-xi",
		[29216] = "Anub'ar Guardian",
		[131188] = "Voodka",
		[46262] = "Rumbling Earth",
		[62702] = "Sonic Ring",
		[63680] = "Sra'thik Cacophyte",
		[72279] = "Vestige of Pride",
		[21220] = "Coilfang Priestess",
		[17158] = "Dust Howler",
		[68696] = "Diffusion Chain Conduit",
		[58992] = "Shado-Pan Trainee",
		[40633] = "Naz'jar Honor Guard",
		[53619] = "Druid of the Flame",
		[25506] = "Shadowsword Lifeshaper",
		[40825] = "Erunak Stonespeaker",
		[71511] = "Shan'ze Thundercaller",
		[69628] = "Mature Egg of Ji-Kun",
		[63534] = "Flame Wall",
		[67801] = "High Marshal Twinbraid",
		[131125] = "Wormbasher",
		[63726] = "Mutating Scorpid",
		[70232] = "Muckbat",
		[68313] = "Roaming Fog",
		[66394] = "Thunder Hold Cannon",
		[11030] = "Mindless Undead",
		[68697] = "Overcharge Conduit",
		[20037] = "Tempest Falconer",
		[28001] = "Dreadsaber",
		[67034] = "Ik'thik Warrior",
		[60208] = "Hopling",
		[66395] = "Thunder Hold Cannoneer",
		[69465] = "Jin'rokh the Breaker",
		[69593] = "Focused Lightning",
		[39994] = "Unknown",
		[64622] = "Ik'thik Whisperer",
		[46263] = "Slag Fury",
		[67035] = "Ik'thik Slayer",
		[72280] = "Manifestation of Pride",
		[58737] = "Viletongue Raider",
		[56754] = "Azure Serpent",
		[63279] = "Bloodthirsty Saurok",
		[68698] = "Bouncing Bolt Conduit",
		[50805] = "Omnis Grinlok",
		[40634] = "Naz'jar Tempest Witch",
		[59121] = "Kunzen Hunter",
		[69210] = "Skumblade Fleshripper",
		[69338] = "Skumblade Brute",
		[30206] = "Carrion Fleshstripper",
		[131092] = "Water Elemental",
		[9239] = "Smolderthorn Mystic",
		[68476] = "Horridon",
		[58671] = "Ancient Mogu Spirit",
		[23961] = "Dragonflayer Ironhelm",
		[131101] = "Devilsaur <Mmhunter>",
		[59758] = "Terracotta Warrior",
		[62000] = "Dreadspinner",
		[3875] = "Haunted Servitor",
		[66652] = "Lesser Volatile Energy <Sha of Violence>",
		[29217] = "Anub'ar Venomancer",
		[62128] = "Kor'thik Fleetwing",
		[1964] = "Treant <Zbrojdusz>",
		[67164] = "Unknown",
		[70235] = "Frozen Head",
		[16871] = "Bleeding Hollow Grunt",
		[62448] = "Onyx Stormclaw",
		[64559] = "Shek'zeer Clutch-Keeper",
		[68188] = "Feed Pool",
		[46264] = "Lord Overheat",
		[60849] = "Jade Serpent Statue <Tweeka>",
		[58674] = "Angry Hound",
		[58738] = "Viletongue Skirmisher",
		[21221] = "Coilfang Beast-Tamer",
		[17159] = "Storm Rager",
		[10414] = "Patchwork Horror",
		[56357] = "Lupello",
		[69596] = "Icy Shadows <Suen>",
		[64063] = "Mogu'shan Arcanist",
		[25507] = "Sunblade Protector",
		[69340] = "Moon Lotus",
		[65455] = "Krik'thik Wingguard",
		[59378] = "Paleblade Flesheater",
		[62757] = "Kor'thik Havoc",
		[5925] = "Grounding Totem <Tryhardx>",
		[19622] = "Kael'thas Sunstrider",
		[63728] = "Ik'thik Amberstinger",
		[70236] = "Storm Energy",
		[59826] = "Ruqin Elder",
		[19686] = "Nether Anomaly",
		[11910] = "Grimtotem Ruffian",
		[46250] = "Riverpaw Poacher",
		[30017] = "Stinkbeard",
		[16148] = "Spectral Death Knight",
		[63615] = "Krik'thik Wingleader",
		[30113] = "Whisker <Orinoko Tuskbreaker>",
		[64368] = "Apparition of Fear",
		[16164] = "Shade of Naxxramas",
		[60402] = "Zandalari Fire-Dancer",
		[131198] = "Apex",
		[62577] = "Gai-Cho Cauterizer",
		[67934] = "Kirin Tor Construct",
		[34544] = "Tortusk",
		[15352] = "Greater Earth Elemental",
		[58739] = "Borokhula the Destroyer",
		[58803] = "Residual Hatred",
		[30593] = "Forgotten Depths Slayer",
		[56884] = "Taran Zhu",
		[61042] = "Cheng Kang",
		[14261] = "Blue Drakonid",
		[67039] = "Dread Behemoth",
		[63591] = "Kor'thik Reaver",
		[20038] = "Phoenix-Hawk Hatchling",
		[67423] = "Shieldwall Peasant",
		[61540] = "Et'kil",
		[61056] = "Primal Earth Elemental <Aenaz>",
		[41084] = "Blaithe <Dmgur>",
		[40880] = "Firelands Denizen",
		[25600] = "Unliving Swine",
		[60389] = "Troll Explosives",
		[9819] = "Blackhand Veteran",
		[60648] = "Ancient Mogu Machine",
		[10375] = "Spire Spiderling",
		[62002] = "Stormlash Totem",
		[37502] = "Nerub'ar Webweaver",
		[62553] = "Gai-Cho Earthtalker",
		[10439] = "Ramstein the Gorger",
		[69215] = "Unknown",
		[67296] = "Shieldwall Vindicator",
		[69471] = "Spirit of Warlord Teng",
		[16904] = "Unyielding Footman",
		[32593] = "Skittering Swarmer",
		[25625] = "Warsong Aberration <Infested Prisoner>",
		[21339] = "Coilfang Hate-Screamer",
		[10407] = "Fleshflayer Ghoul",
		[58676] = "Scarlet Defender",
		[10382] = "Mangled Cadaver",
		[67902] = "Alliance Priest",
		[43370] = "Red Mist",
		[60438] = "Wildfire Spark",
		[56171] = "Great White Plainshawk",
		[65393] = "East Temple - Corrupted Waters Stalker - MW",
		[68065] = "Megaera",
		[40765] = "Commander Ulthok",
		[67297] = "Shieldwall Rifleman",
		[70240] = "Shan'ze Celestial Shaper",
		[12902] = "Lorgus Jett",
		[66402] = "Swallowed Brewstealer",
		[59712] = "Stone Bulwark Totem <Valjik>",
		[4382] = "Withervine Creeper",
		[63730] = "Sticky Resin",
		[59700] = "Northwind Hawk",
		[59764] = "Healing Tide Totem <Plebbi>",
		[4414] = "Darkfang Venomspitter",
		[25860] = "Blazing Infernal",
		[19459] = "Feng",
		[58664] = "Instructor Chillheart's Phylactery",
		[69880] = "Fallen Zandalari <Smokeppc>",
		[24069] = "Dragonflayer Bonecrusher",
		[37695] = "Drudge Ghoul",
		[21958] = "Enchanted Elemental",
		[23563] = "Soul Weaver",
		[62451] = "The Sra'thik",
		[59520] = "Fizzy Brew Alemental",
		[20039] = "Phoenix-Hawk",
		[58549] = "Sly Pup",
		[58869] = "Blanche's Lightning Rod",
		[68194] = "Young Egg of Ji-Kun",
		[58741] = "Glade Sprinter",
		[28419] = "Frenzied Geist",
		[9096] = "Rage Talon Dragonspawn",
		[61183] = "Belligerent Blossom",
		[58997] = "Abyssal <Fentul>",
		[63346] = "The Dark of Night",
		[59790] = "Ruqin Infantry",
		[9240] = "Smolderthorn Shadow Priest",
		[69346] = "Sand Trap <Farraki Wastewalker>",
		[69474] = "Kresh the Ripper",
		[65522] = "Bubble Shield",
		[63539] = "Flamecoaxing Spirit",
		[15976] = "Venom Stalker",
		[21251] = "Underbog Colossus",
		[63731] = "Mire Beast",
		[25707] = "Magic-bound Ancient",
		[48983] = "Geyser",
		[0] = "[*] Cloud Burst",
		[59893] = "Empowering Spirit",
		[62452] = "The Zar'thik",
		[62590] = "Unga Scallywag",
		[41854] = "Sentinel Ambusher",
		[39679] = "Corla, Herald of Twilight",
		[18952] = "Bonechewer Scavenger",
		[60277] = "Severer of Souls",
		[16873] = "Bleeding Hollow Dark Shaman",
		[16905] = "Unyielding Sorcerer",
		[4798] = "Fallenroot Shadowstalker",
		[56439] = "Sha of Doubt",
		[131211] = "Spirit Beast",
		[25445] = "Nerub'ar Corpse Harvester",
		[70243] = "Archritualist Kelada",
		[10442] = "Chromatic Whelp",
		[64947] = "Mogu'shan Warden",
		[40447] = "Chains of Woe <Rom'ogg Bonecrusher>",
		[4814] = "Twilight Elementalist",
		[58998] = "Scarlet Defender",
		[4830] = "Old Serra'kis",
		[40767] = "Twilight Retainer",
		[25509] = "Priestess of Torment",
		[69348] = "Skumblade Shortfang",
		[69476] = "Spirit Mask",
		[131098] = "Daggorod",
		[64061] = "Mogu'shan Warden",
		[53369] = "Blazing Talon Initiate",
		[9259] = "Firebrand Grunt",
		[45412] = "Lord Aurius Rivendare",
		[9816] = "Pyroguard Emberseer",
		[14022] = "Corrupted Red Whelp",
		[57783] = "Ghost Iron Dragonling",
		[11911] = "Grimtotem Mercenary",
		[4966] = "Private Hendel",
		[69221] = "Zandalari Dinomancer",
		[39616] = "Naz'jar Invader",
		[69093] = "Dreadspore Bulb",
		[37697] = "Volatile Ooze",
		[56184] = "Snagtooth Virmen",
		[22055] = "Coilfang Elite",
		[59519] = "Stout Brew Alemental",
		[16149] = "Spectral Horse",
		[20040] = "Crystalcore Devastator",
		[22119] = "Fathom Lurker <Fathom-Guard Sharkkis>",
		[16165] = "Necro Knight",
		[60726] = "Ku-Tong",
		[62837] = "Grand Empress Shek'zeer",
		[58807] = "Vestige of Hatred",
		[40844] = "Cindermaul",
		[61174] = "Cursed Jade",
		[61046] = "Jinlun Kun",
		[14262] = "Green Drakonid",
		[57080] = "Corrupted Scroll",
		[59191] = "Commander Lindon",
		[59751] = "Shado-Pan Warden",
		[69475] = "Arcanital Tula'chek",
		[38913] = "Twilight Vanquisher",
		[60709] = "Qiang the Merciless",
		[63605] = "Stonebound Watcher",
		[60725] = "Urang",
		[40584] = "Naz'jar Invader",
		[70246] = "Spirit Flayer",
		[35203] = "Gnomebot Pounder",
		[13533] = "Spewed Larva",
		[10376] = "Crystal Fang",
		[131096] = "Dagatik",
		[10408] = "Rockwing Gargoyle",
		[56185] = "Unknown",
		[67304] = "Shieldwall Footman",
		[69223] = "Zandalari Stoneshield",
		[69351] = "Greater Cave Bat",
		[3939] = "Razormane Wolf",
		[16906] = "Unyielding Knight",
		[58488] = "Unknown",
		[62582] = "Shek'zeer Swarmborn",
		[64693] = "Invisible Man",
		[131078] = "Lazgorod",
		[70247] = "Venomous Head",
		[20044] = "Novice Astromancer",
		[25597] = "Oblivion Mage",
		[67177] = "Zar'thik Supplicant",
		[63030] = "Enslaved Bonesmasher",
		[40577] = "Naz'jar Sentinel",
		[10680] = "Summoned Blackhand Dreadweaver <Blackhand Summoner>",
		[53115] = "Molten Lord",
		[69224] = "Zandalari Arcweaver",
		[69352] = "Vampiric Cave Bat",
		[69480] = "Unknown",
		[59384] = "Bluff Hawk",
		[61623] = "Sap Globule",
		[59512] = "Wall of Suds",
		[41153] = "Wild Tornado <Wormwing Screecher>",
		[64308] = "Storm Cloud <Cloudbender Kobo>",
		[70248] = "Arcane Head",
		[25798] = "Shadowsword Berserker",
		[14024] = "Corrupted Blue Whelp",
		[8921] = "Bloodhound",
		[60030] = "Harala the Firespeaker",
		[66794] = "Amber Shards",
		[8889] = "Anvilrage Overseer",
		[60728] = "Battat",
		[69225] = "Zandalari Spiritbinder",
		[60280] = "Lightning Charge",
		[60984] = "Controller",
		[69609] = "Lightning Fissure",
		[22056] = "Coilfang Strider",
		[20041] = "Crystalcore Sentinel",
		[22120] = "Fathom Sporebat <Fathom-Guard Sharkkis>",
		[62711] = "Amber Monstrosity",
		[68202] = "Ji-Kun Fledgling's Egg <Fledgling>",
		[63031] = "Set'thik Fanatic",
		[56762] = "Yu'lon",
		[9097] = "Scarshield Legionnaire",
		[56890] = "Krik'thik Infiltrator",
		[68341] = "Eye Sentry",
		[45381] = "Grimtotem Geomancer",
		[69226] = "Skumblade Seadragon",
		[59193] = "Boneweaver",
		[62589] = "Gai-Cho Boltshooter",
		[59518] = "Bloated Brew Alemental",
		[53244] = "Flamewaker Trainee",
		[16427] = "Soldier of the Frozen Wastes",
		[59641] = "Monstrous Plainshawk",
		[23562] = "Unstoppable Abomination",
		[15430] = "Earth Elemental Totem <Dizna>",
		[59705] = "Scarlet Flamethrower",
		[69492] = "Unknown",
		[59262] = "Demonic Gateway",
		[61245] = "Lightning Surge Totem <Bloodlustbot>",
		[66668] = "Sha-Infested Prowler",
		[61181] = "Krik'thik Limbpincer",
		[64183] = "Enormous Stone Quilen",
		[69099] = "Nalak",
		[69227] = "Skumblade Scavenger",
		[37086] = "Hecklefang Scavenger",
		[68852] = "Rushing Winds",
		[16907] = "Bleeding Hollow Peon",
		[4815] = "Murkshallow Snapclaw",
		[62584] = "Shan'ze Cloudrunner",
		[70507] = "Nether Wyrm",
		[62908] = "Heart of Fear - Armsmaster Ta'yak Tempest Stalker (LTD)",
		[58810] = "Fragment of Hatred",
		[60793] = "Celestial Protector",
		[56763] = "Regenerating Sha",
		[66285] = "Thunder Hold Infantryman",
		[131227] = "Skoll",
		[40579] = "Deep Murloc Hunter",
		[63032] = "Sra'thik Shield Master",
		[44801] = "Blight of Ozumat",
		[69228] = "Skumblade Filthmonger",
		[30020] = "Orinoko Tuskbreaker",
		[19434] = "Dreadcaller",
		[63544] = "Trailblaze <Chagan Firehoof>",
		[41027] = "Wormwing Screecher",
		[24071] = "Dragonflayer Heartsplitter",
		[55873] = "Snagtooth Troublemaker",
		[61945] = "Gurthan Iron Maw",
		[9817] = "Blackhand Dreadweaver",
		[15974] = "Dread Creeper",
		[15990] = "Kel'Thuzad",
		[35334] = "Gnome Engineer",
		[43586] = "Opal Stonethrower",
		[30021] = "Enormos",
		[66413] = "Yeasty Brew Alemental",
		[14023] = "Corrupted Green Whelp",
		[69229] = "Skumblade Saur-Priest",
		[56636] = "Commander Ri'mok",
		[3380] = "Burning Blade Acolyte",
		[60410] = "Elegon",
		[16150] = "Spectral Rider",
		[20042] = "Tempest-Smith",
		[58555] = "Scarlet Fanatic",
		[24200] = "Skarvald the Constructor",
		[58683] = "Scarlet Myrmidon",
		[66287] = "Thunder Hold Lieutenant",
		[56764] = "Consuming Sha",
		[62969] = "Embodied Terror",
		[58875] = "Darkmaster Gandling",
		[56895] = "Weak Spot",
		[34503] = "Unknown",
		[10217] = "Flame Buffet Totem <Smolderthorn Witch Doctor>",
		[61242] = "Glintrok Ironhide",
		[69358] = "Ihgaluk Basilisk",
		[53121] = "Flamewaker Cauterizer",
		[61434] = "Sik'thik Vanguard",
		[41028] = "Wormwing Swifttalon",
		[10394] = "Black Guard Sentry",
		[61626] = "Whilring Dervish <Ming the Cunning>",
		[68079] = "Ro'shak",
		[63993] = "Muckscale Ripper",
		[66288] = "Thunder Hold Sharp-Shooter",
		[59835] = "Krik'thik Swarmer",
		[61946] = "Harthak Stormcaller",
		[61240] = "Unknown",
		[10409] = "Rockwing Screecher",
		[66928] = "Sha Shooter",
		[58108] = "Krik'thik Infiltrator",
		[62266] = "Bronze Quilen",
		[60731] = "Undying Shadows",
		[56637] = "Ook-Ook",
		[21002] = "Nether Vapor",
		[60475] = "Terrorbane",
		[17132] = "Clefthoof Bull",
		[69746] = "Twisted Fate",
		[68080] = "Quet'zal",
		[58684] = "Scarlet Scourge Hewer",
		[66289] = "Osul Spitfire",
		[58812] = "Hateful Essence",
		[58876] = "Starving Hound",
		[56765] = "Destroying Sha",
		[40709] = "Flame Ascendant",
		[10681] = "Summoned Blackhand Veteran <Blackhand Summoner>",
		[10697] = "Bile Slime",
		[69232] = "Ball Lightning <Lei Shen>",
		[53119] = "Flamewaker Forward Guard",
		[65402] = "Gurthan Swiftblade",
		[41030] = "Twilight Dragonkin Armorer",
		[41029] = "Twilight Dragonkin",
		[63610] = "Shao-Tien Dominator",
		[59580] = "Ordo Overseer",
		[68081] = "Dam'ren",
		[63674] = "Mogu Statue",
		[53631] = "Cinderweb Spiderling",
		[61947] = "Kargesh Ribcrusher",
		[25864] = "Felguard Slayer",
		[61499] = "Ring of Fire",
		[37511] = "Bristleback Bladewarden",
		[8890] = "Anvilrage Warden",
		[54015] = "Majordomo Staghelm",
		[3256] = "Sunscale Scytheclaw",
		[63035] = "Zar'thik Zealot",
		[40134] = "Unknown",
		[36296] = "Apothecary Hummel",
		[3272] = "Kolkar Wrangler",
		[3276] = "Witchwing Harpy",
		[9018] = "High Interrogator Gerstahn",
		[24201] = "Dalronn the Controller",
		[58685] = "Scarlet Evangelist",
		[64890] = "Vess-Guard Na'kal",
		[56766] = "Volatile Energy",
		[9098] = "Scarshield Spellbinder",
		[18220] = "Ravenous Windroc",
		[20043] = "Apprentice Star Scryer",
		[30022] = "Vladof the Butcher",
		[9162] = "Young Diemetradon",
		[53120] = "Flamewaker Pathfinder",
		[40838] = "Dark Iron Laborer",
		[61243] = "Gekkan",
		[61436] = "Sik'thik Bladedancer",
		[16429] = "Unknown",
		[63611] = "Shao-Tien Soul-Caller",
		[56701] = "Pearlfin Poolwatcher",
		[59645] = "Cookie McYaungol",
		[62585] = "Shan'ze Cloudrunner",
		[59773] = "Terracotta Guardian",
		[59771] = "Zombified Corpse",
		[11912] = "Grimtotem Brute",
		[36678] = "Professor Putricide",
		[19862] = "Urtrak",
		[66286] = "Thunder Hold Mender",
		[29063] = "Anub'ar Crypt Fiend",
		[69235] = "Shan'ze Gravekeeper",
		[68078] = "Iron Qon",
		[69491] = "Blessed Loa Spirit",
		[25799] = "Shadowsword Fury Mage",
		[64571] = "Lightwell",
		[69740] = "Twisted Fate",
		[56511] = "Corrupt Living Water",
		[9196] = "Highlord Omokk",
		[30023] = "Korrak the Bloodrager",
		[62844] = "Deadtalker Crusher",
		[4799] = "Fallenroot Hellcaller",
		[4807] = "Blackfathom Myrmidon",
		[63036] = "Kor'thik Extremist",
		[4823] = "Barbed Crustacean",
		[4831] = "Lady Sarevess",
		[38664] = "Blackpool Crewman",
		[69236] = "Shan'ze Soulripper",
		[57215] = "Grainhunter Hawk",
		[53185] = "Flamewaker Overseer",
		[59390] = "Mocking Banner <Grogu>",
		[29735] = "Savage Worg",
		[4887] = "Ghamoo-Ra",
		[25609] = "En'kilah Necrolord",
		[55291] = "Shan'ze Spiritclaw",
		[9818] = "Blackhand Summoner",
		[15975] = "Carrion Spinner",
		[46911] = "Lava Surger",
		[63613] = "Krik'thik Wingguard",
		[60458] = "Tribal Alchemist",
		[37513] = "Sabersnout",
		[59078] = "Failed Student <Darkmaster Gandling>",
		[62205] = "Wing Leader Ner'onok",
		[69237] = "Risen Ancestor",
		[69365] = "Star",
		[62397] = "Wind Lord Mel'jarak",
		[61239] = "Glintrok Oracle",
		[40008] = "Lucky",
		[56448] = "Wise Mari",
		[59303] = "Houndmaster Braun",
		[62717] = "Sonic Ring",
		[56640] = "Ball of Fire",
		[65251] = "Haunt of Fear",
		[61029] = "Primal Fire Elemental <Bloodlustbot>",
		[24082] = "Proto-Drake Handler",
		[58943] = "Hozen Gutripper",
		[22347] = "Colossus Lurker",
		[30273] = "Webbed Crusader",
		[28922] = "Anub'ar Crusher",
		[69238] = "Ancient Stone Conqueror",
		[10218] = "Unknown",
		[61374] = "Krik'thik Deep-Scout",
		[10391] = "Skeletal Berserker",
		[61157] = "Sassy Seedling",
		[41096] = "Naz'jar Spiritmender",
		[63677] = "Sra'thik Drone",
		[70134] = "Nest Guardian",
		[47804] = "Twilight Shaper",
		[15989] = "Sapphiron",
		[14456] = "Blackwing Guardsman",
		[63997] = "Muckscale Flesh-Hunter",
		[18733] = "Fel Reaver",
		[60031] = "Pao-kun the Pyromancer",
		[59190] = "Psyfiend <Satella>",
		[29064] = "Anub'ar Necromancer",
		[29096] = "Anub'ar Champion",
		[29128] = "Anub'ar Prime Guard",
		[63589] = "Fixate",
		[19551] = "Ember of Al'ar",
		[10436] = "Baroness Anastari",
		[16974] = "Rogue Voidwalker",
		[25508] = "Shadowsword Guardian",
		[50739] = "Gar'lok",
		[25315] = "Kil'jaeden",
		[23723] = "Sergeant Lukas",
		[66425] = "Sha Haunt",
		[62727] = "Sonic Ring",
		[131075] = "Deku",
		[131104] = "Daglikad",
		[8912] = "Twilight's Hammer Torturer",
		[40713] = "Twilight Augur",
		[61247] = "Glintrok Greenhorn",
		[40841] = "Searing Guardian",
		[70587] = "Shale Stalker",
		[10762] = "Blackhand Thug",
		[29335] = "Anub'ar Webspinner",
		[61567] = "Vizier Jin'bak",
		[63678] = "Sra'thik Mutilator",
		[25370] = "Sunblade Dusk Priest",
		[45383] = "Grimtotem Stomper",
		[53635] = "Cinderweb Drone",
		[66426] = "Sha Harbinger",
		[63998] = "Oracle Hiss'ir",
		[59968] = "Ordo Marauder",
		[60032] = "Akonu the Embercaller",
		[8891] = "Anvilrage Guardsman",
		[131107] = "Tkp",
		[22009] = "Tainted Elemental",
		[21964] = "Fathom-Guard Caribdis",
		[25367] = "Sunblade Arch Mage",
		[68192] = "Hatchling",
		[60480] = "Titan Spark",
		[20045] = "Nether Scryer",
		[63197] = "Blackguard Stalwart",
		[18398] = "Brokentoe",
		[12422] = "Death Talon Dragonspawn",
		[62847] = "Unknown",
		[4978] = "Aku'mai Servant",
		[131091] = "Волк",
		[46379] = "Vicious Thug",
		[40586] = "Lady Naz'jar",
		[55659] = "Wild Imp <Raimond>",
		[19668] = "Shadowfiend",
		[131073] = "Wolf",
		[18978] = "Heckling Fel Sprite",
		[53188] = "Flamewaker Subjugator",
		[12220] = "Constrictor Vine",
		[21214] = "Fathom-Lord Karathress",
		[59521] = "Bubbling Brew Alemental",
		[59430] = "Hateful Ko Ko",
		[37501] = "Nerub'ar Champion",
		[68219] = "Rockfall",
		[15956] = "Anub'Rekhan",
		[43258] = "Lodestone Elemental",
		[63999] = "Muckscale Slayer",
		[59969] = "Musaan the Blazecaster",
		[60033] = "Frenzied Spirit",
		[60390] = "Troll Explosives",
		[62208] = "Resin Shell",
		[60913] = "Energy Charge",
		[64383] = "Unknown",
		[40123] = "Twilight Overseer",
		[69627] = "Amber Parasite",
		[40011] = "Spot",
		[16975] = "Uncontrolled Voidwalker",
		[56924] = "Inflamed Hozen Brawler",
		[25465] = "Kel'Thuzad",
		[68220] = "Gastropod",
		[60801] = "Jung Duk",
		[21229] = "Greyheart Tidecaller",
		[65504] = "Snagtooth Pesterling",
		[59801] = "Krik'thik Wind Shaper",
		[67163] = "Sonic Ring",
		[65134] = "Shao-Tien Fist",
		[25483] = "Shadowsword Manafiend",
		[62511] = "Amber-Shaper Un'sok",
		[60400] = "Jan-xi",
		[37923] = "Triumph Vanguard",
		[25611] = "Warsong Aberration",
		[69756] = "Anima Orb",
		[59522] = "Sudsy Brew Alemental",
		[15928] = "Thaddius",
		[19261] = "Infernal Warbringer",
		[45385] = "Grimtotem Reaver",
		[59778] = "Krik'thik Striker",
		[59184] = "Jandice Barov",
		[39436] = "Twilight Proveditor",
		[59970] = "Ordo Battleyak",
		[30025] = "Erathius, King of Dirt",
		[65133] = "Shao-Tien Sorcerer",
		[14025] = "Corrupted Bronze Whelp",
		[62440] = "Shan'ze Illusionist",
		[21965] = "Fathom-Guard Tidalvess",
		[39445] = "Lycanthoth Vandal",
		[62465] = "Captain Ook",
		[60482] = "Auburn Rascal",
		[20046] = "Astromancer Lord",
		[6047] = "Aqua Guardian",
		[60579] = "Ire <Sha of Anger>",
		[68222] = "Bow Fly Swarm",
		[64283] = "Amber Globule",
		[10398] = "Thuzadin Shadowcaster",
		[62977] = "Fright Spawn",
		[39642] = "Hovel Brute",
		[69905] = "Gurubashi Berserker",
		[12218] = "Vile Larva",
		[70589] = "Cavern Burrower",
		[61250] = "Sorcerer Mogu",
		[16360] = "Zombie Chow",
		[60646] = "Cleansing Waters <Elder Asani>",
		[61442] = "Kuai the Brute",
		[59459] = "Hopling",
		[59523] = "Bataari Battleyak",
		[61634] = "Commander Vo'jak",
		[45322] = "Frozen Orb <Wintertouch>",
		[40923] = "Unstable Corruption",
		[25599] = "Cataclysm Hound",
		[10363] = "General Drakkisath",
		[39437] = "Twilight Hunter",
		[66688] = "Sha Tendrils",
		[12458] = "Blackwing Taskmaster",
		[58927] = "Shao-Tien Fist",
		[131080] = "Serpent",
		[29098] = "Anub'ar Necromancer",
		[69375] = "Hidden Fog",
		[62402] = "Kor'thik Elite Blademaster",
		[14601] = "Ebonroc",
		[62530] = "Unknown",
		[37534] = "Spinestalker",
		[21271] = "Infinity Blades",
		[3261] = "Bristleback Thornweaver",
		[3265] = "Razormane Hunter",
		[58756] = "Scarlet Evoker",
		[21230] = "Greyheart Nether-Mage",
		[44120] = "Sauranok the Mystic",
		[56239] = "Adolescent Mushan",
		[63106] = "Sik'thik Swarmer",
		[131074] = "Unknown",
		[69591] = "Lurker in the Night",
		[18400] = "Rokdar the Sundered Lord",
		[40845] = "Forgemaster Pyrendius",
		[60847] = "Flanking Mogu",
		[38926] = "Twilight Flamecaller",
		[59460] = "Hopling",
		[4376] = "Darkmist Spider",
		[25708] = "Sinister Reflection",
		[61699] = "Sik'thik Amberwing",
		[45387] = "Isha Gloomaxe",
		[53639] = "Flamewaker Cauterizer",
		[39374] = "Warhound <The Ginormus>",
		[39438] = "Twilight Slavedriver",
		[21806] = "Greyheart Spellbinder",
		[64965] = "Milau",
		[63974] = "Krik'thik Locust-Guard",
		[60164] = "Sha-Infested Yaungol",
		[70174] = "Focused Lightning <Zandalari Storm-Caller>",
		[56198] = "Thicket Stalker",
		[30648] = "Fire Cyclone",
		[60381] = "Zandalari Infiltrator",
		[63508] = "Xuen",
		[20047] = "Crimson Hand Battle Mage",
		[62543] = "Blade Lord Ta'yak",
		[18064] = "Warmaul Shaman",
		[56646] = "Fire Flower <Shado-Pan Novice>",
		[58757] = "Scholomance Acolyte",
		[70529] = "Zandalari Execution Guard",
		[60932] = "Ashfang Hyena",
		[62572] = "Kri'thik Aggressor",
		[59148] = "Bataari Flamecaller",
		[54983] = "Treant <Umadbro>",
		[65282] = "Void Tendril <Ashnualah>",
		[71297] = "Tamed Bladetalon",
		[28619] = "Web Wrap <Demontime>",
		[60395] = "Troll Explosives",
		[61444] = "Ming the Cunning",
		[61508] = "Sra'thik Swiftclaw",
		[9260] = "Firebrand Legionnaire",
		[63683] = "Sra'thik Swiftwing",
		[66195] = "Unga Rocket Surgeon",
		[59717] = "Windwalk Totem",
		[53640] = "Flamewaker Sentinel",
		[56655] = "Wild Huntress",
		[56719] = "Sha of Violence",
		[56538] = "Twitchheel Hoarder",
		[131099] = "Plagueravager",
		[66948] = "Twisted Corpse",
		[20063] = "Master Engineer Telonicus",
		[71298] = "Zandalari Beastlord",
		[69379] = "Zandalari Beastcaller",
		[69507] = "Zeb'tula Beastcaller",
		[62468] = "Ookie",
		[131079] = "Danger",
		[16977] = "Arch Mage Xintor",
		[59501] = "Reanimated Corpse",
		[70147] = "Waterspout",
		[66181] = "Zar'thik Supplicant",
		[58758] = "Soul Fragment",
		[21231] = "Greyheart Shield-Bearer",
		[21263] = "Greyheart Technician",
		[63044] = "Paleblade Slithertongue",
		[69452] = "Pale Fog",
		[54984] = "Treant",
		[70212] = "Flaming Head",
		[9265] = "Smolderthorn Shadow Hunter",
		[61338] = "Glintrok Skulker",
		[19440] = "Eye of Grillok",
		[59398] = "Demoralizing Banner <Watchmyshoes>",
		[61509] = "Sra'thik Kunchong",
		[47244] = "Mirror Image <Torch>",
		[70020] = "Pterrorwing Skyscreamer",
		[61701] = "Sik'thik Warrior",
		[70276] = "No'ku Stormsayer",
		[15977] = "Poisonous Skitterer",
		[25837] = "Shadowsword Commander",
		[63179] = "Mistblade Scale-Lord",
		[64068] = "Mogu'shan Engine Keeper",
		[64132] = "Amber Growth",
		[37585] = "Northwatch Recon",
		[131108] = "Emily",
		[20049] = "Crimson Hand Blood Knight",
		[67856] = "Yellow Eye",
		[41935] = "Northwatch Encroacher",
		[24078] = "Dragonflayer Metalworker",
		[53134] = "Ancient Core Hound",
		[40080] = "Unbound Flame Spirit",
		[131109] = "Water Elemental",
		[69701] = "Anima Golem",
		[33193] = "Ashenvale Skirmisher",
		[29684] = "Ticking Bomb <Dragonflayer Strategist>",
		[58823] = "Scholomance Neophyte",
		[11981] = "Flamegor",
		[131111] = "Гидра <Ibnarabi>",
		[60431] = "Yongqi Brute",
		[12219] = "Barbed Lasher",
		[36626] = "Festergut",
		[65348] = "Whirling Blade",
		[59271] = "Demonic Gateway",
		[131118] = "Morrik",
		[28684] = "Krik'thir the Gatewatcher",
		[37023] = "Plague Scientist",
		[69894] = "Grave Guardian",
		[65928] = "Ordo Raider",
		[59655] = "Wascally Wirmen",
		[66184] = "Dread Stalker",
		[53642] = "Cinderweb Spinner",
		[5184] = "Theramore Sentry",
		[67221] = "Terracotta Boss",
		[69314] = "Venomous Effusion",
		[53898] = "Voracious Hatchling",
		[22895] = "Summoned Searing Totem <Ordo Warbringer>",
		[60906] = "Fissure",
		[69255] = "Spiritbinder Tec'uat",
		[25038] = "Felmyst",
		[64453] = "Set'thik Windblade",
		[69639] = "Humming Crystal",
		[40017] = "Twilight Element Warden",
		[16978] = "Lieutenant Commander Thalvos",
		[60561] = "Earthgrab Totem <Bloodlustbot>",
		[58632] = "Armsmaster Harlan",
		[131121] = "Lilly",
		[25294] = "Nerub'ar Web Lord",
		[17138] = "Warmaul Reaver",
		[62982] = "Mindbender <Tellios>",
		[60999] = "Sha of Fear",
		[25214] = "Shadow Image",
		[59080] = "Darkmaster Gandling",
		[25486] = "Shadowsword Vanquisher",
		[58900] = "Wildscale Hunter",
		[70341] = "Tormented Spirit",
		[30681] = "Onyx Blaze Mistress",
		[61447] = "Gurthan Scrapper",
		[59464] = "Hopper",
		[60627] = "Siphoning Shield",
		[63686] = "Sra'thik Vessguard",
		[61970] = "Mistblade Ripper",
		[56462] = "Snagtooth Hooligan",
		[25806] = "Loot Crazed Poacher",
		[10876] = "Unknown <Nerub'enkan>",
		[4977] = "Murkshallow Softshell",
		[62023] = "Coldbite Crocolisk",
		[60040] = "Commander Durand",
		[9043] = "Scarshield Grunt",
		[39698] = "Karsh Steelbender",
		[46381] = "Shifty Thief",
		[19921] = "Viper <Yoshisuke>",
		[41937] = "Marshal Paltrow",
		[24079] = "Dragonflayer Forge Master",
		[69916] = "Gurubashi Berserker",
		[58505] = "Golden Lotus Defender",
		[58569] = "Scarlet Purifier",
		[58633] = "Instructor Chillheart",
		[20145] = "Unstable Voidwalker",
		[64902] = "Kor'thik Fleshrender",
		[62919] = "Unstable Sha",
		[62983] = "Lei Shi",
		[66699] = "Generic Invisible Stalker Controller NonImmune - IH",
		[22352] = "Colossus Rager",
		[44752] = "Faceless Sapper",
		[131149] = "BabySpiders",
		[58198] = "Shado-Pan Disciple",
		[65414] = "Ethereal Sha",
		[69703] = "Rushing Winds",
		[61448] = "Sik'thik Soldier",
		[9683] = "Lar'korwi Mate",
		[9261] = "Firebrand Darkweaver",
		[28781] = "Battleground Demolisher",
		[52447] = "Cinderweb Spiderling",
		[66188] = "Amberscale Basilisk",
		[60951] = "Shado-Pan Ranger",
		[12435] = "Razorgore the Untamed",
		[33302] = "Captain Elendilad",
		[63445] = "Heart of Fear",
		[59545] = "The Golden Beetle",
		[64724] = "Karanosh",
		[69131] = "Frost King Malakk",
		[69715] = "Call Da Storm Stalker West",
		[56732] = "Liu Flameheart",
		[62408] = "Zar'thik Battle-Mender",
		[21301] = "Coilfang Shatterer",
		[40019] = "Twilight Obsidian Borer",
		[69899] = "Farraki Sand Conjurer",
		[40147] = "Baron Geddon",
		[69285] = "Zandalari Spiritweaver",
		[6507] = "Ravasaur Hunter",
		[25295] = "Nerub'ar Swarmer",
		[10435] = "Magistrate Barthilas",
		[10467] = "Mana Tide Totem <Unshakable>",
		[63048] = "Kor'thik Slicer",
		[62293] = "Shan'ze Serpentbinder",
		[36565] = "Apothecary Baxter",
		[69132] = "High Priestess Mar'li",
		[61340] = "Glintrok Hexxer",
		[65415] = "Unknown",
		[19442] = "Worg Master Kruush",
		[23568] = "Captain Darill",
		[47184] = "Stone Trogg Fungalmancer",
		[42924] = "Twilight Laborer",
		[63688] = "Sra'thik Deathmixer",
		[58722] = "Lilian Voss",
		[59722] = "Pile of Corpses",
		[60043] = "Jade Guardian",
		[39595] = "Furious Earthguard",
		[64008] = "Muckscale Shaman",
		[46375] = "Rowdy Troublemaker",
		[66830] = "Sra'thik Worker",
		[48230] = "Ogre Henchman",
		[39700] = "Beauty",
		[61213] = "Krik'thik Conscript",
		[58592] = "Spirit of Redemption",
		[69517] = "Zeb'tula Stoneshield",
		[24080] = "Dragonflayer Weaponsmith",
		[69153] = "Living Sand",
		[20050] = "Crimson Hand Inquisitor",
		[70029] = "Eruption",
		[69792] = "Merik",
		[61398] = "Xin the Weaponmaster",
		[25368] = "Sunblade Slayer",
		[67093] = "Sik'thik Battle-Mender",
		[62495] = "Unga Villager",
		[63049] = "Set'thik Swiftblade",
		[30449] = "Power of Vesperon",
		[59083] = "Bataari Fire-Warrior",
		[69178] = "Drakkari Frozen Warlord",
	},
	["death_recap"] = {
		["enabled"] = true,
		["show_segments"] = false,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		7, -- [1]
		3, -- [2]
		"Environment (Falling)", -- [3]
		[122752] = "Tsulong",
		[115073] = "Qiqi <Qiqi>",
		[37319] = "Phoenix-Hawk Hatchling",
		[125312] = "Blade Lord Ta'yak",
		[117633] = "Zian of the Endless Shadow",
		[38599] = "Coilfang Serpentguard",
		[127360] = 7,
		[119681] = "Unga Villager",
		[8122] = 5,
		[114050] = 7,
		[16870] = 10,
		[145151] = 10,
		[80263] = 11,
		[145152] = 10,
		[122242] = 11,
		[122754] = "Garalon",
		[123266] = 5,
		[124802] = 2,
		[46279] = "Oblivion Mage",
		[145153] = 10,
		[127362] = "Elegon",
		[119683] = "Unga Villager",
		[120195] = "Haiyan the Unstoppable",
		[48583] = "Skarvald the Constructor",
		[114052] = 7,
		[123267] = 5,
		[49863] = "Zandalari Terror Rider",
		[134916] = "Lei Shen",
		[85384] = 1,
		[51399] = 6,
		[119684] = "Xin the Weaponmaster",
		[120196] = "Haiyan the Unstoppable",
		[129923] = 1,
		[122244] = "Sik'thik Engineer",
		[54983] = "Proto-Drake Handler",
		[102791] = 10,
		[121733] = 4,
		[115078] = 11,
		[149254] = 3,
		[124293] = 3,
		[134920] = "Tortos",
		[76171] = "Erunak Stonespeaker",
		[102280] = 10,
		[127365] = 7,
		[60103] = 7,
		[52424] = 6,
		[36554] = 4,
		[124294] = 7,
		[54216] = 3,
		[137994] = "Ritualist Malus",
		[13812] = 3,
		[102793] = 10,
		[120199] = "Sik'thik Amberwing",
		[28134] = "Feugen",
		[80780] = "Shrieking Banshee",
		[137995] = "Ritualist Xeron",
		[115080] = 11,
		[14516] = "Riverpaw Slayer",
		[116616] = 7,
		[117640] = 11,
		[120200] = "Sik'thik Amberwing",
		[121224] = "Cursed Mogu Sculpture",
		[80781] = "Rockwing Screecher",
		[15284] = "Lord Aurius Rivendare",
		[122760] = "Imperial Vizier Zor'lok",
		[45770] = "Hand of the Deceiver",
		[83853] = 8,
		[93068] = 4,
		[137998] = "Ritual Guard",
		[102795] = 10,
		[120201] = "Haiyan the Unstoppable",
		[16244] = "Dragonflayer Overseer",
		[89485] = 5,
		[122761] = "Imperial Vizier Zor'lok",
		[123273] = 11,
		[91021] = 4,
		[124809] = "Zar'thik Supplicant",
		[117642] = 11,
		[1079] = 10,
		[42955] = 8,
		[17512] = 11,
		[127881] = 3,
		[114571] = "Strife",
		[140049] = "Zandalari Blade Initiate",
		[46283] = "Apocalypse Guard",
		[76688] = "Twilight Obsidian Borer",
		[54986] = 2,
		[127882] = 3,
		[120715] = 7,
		[5019] = 8,
		[5211] = 10,
		[41932] = "Tidewalker Lurker",
		[117644] = 11,
		[140052] = "Flesh'rok the Diseased",
		[119692] = "Sha of Fear",
		[22120] = "Serpentshrine Sporebat",
		[114061] = "Jandice Barov",
		[45004] = "Kalecgos",
		[30823] = 7,
		[123788] = "Grand Empress Shek'zeer",
		[45772] = "Hand of the Deceiver",
		[117645] = 1,
		[138006] = "[*] Electrified Waters",
		[127372] = 7,
		[119693] = "Sha of Fear",
		[120717] = 7,
		[114062] = "Jandice Barov",
		[1535] = 7,
		[1543] = 3,
		[124301] = 7,
		[92049] = 1,
		[117646] = 6,
		[35022] = 9,
		[122254] = "Unga Spearscamp",
		[123790] = "Imperial Vizier Zor'lok",
		[117647] = 11,
		[1719] = 1,
		[13813] = 3,
		[55500] = 7,
		[120207] = "Controller",
		[48333] = 11,
		[129934] = 1,
		[139035] = "Zeb'tula Stoneshield",
		[123791] = "Imperial Vizier Zor'lok",
		[124815] = "Sra'thik Shield Master",
		[42702] = "Vrykul Skeleton",
		[34767] = 2,
		[104338] = 1,
		[136989] = "[*] Throw Spear",
		[122768] = "Tsulong",
		[106898] = 10,
		[123792] = "[*] Cry of Terror",
		[1943] = 4,
		[117649] = 11,
		[55501] = 10,
		[136991] = "[*] Biting Cold",
		[48846] = 9,
		[8187] = "Magma Totem <Wafty>",
		[82326] = 2,
		[8374] = "Twilight Reaver",
		[124817] = "Sra'thik Shield Master",
		[117650] = 1,
		[118162] = "Subetai the Swift",
		[118674] = 11,
		[52174] = 1,
		[113043] = 10,
		[53454] = "Impale Target",
		[67481] = "Волк",
		[46287] = "Apocalypse Guard",
		[117651] = 6,
		[118163] = "Subetai the Swift",
		[19434] = 3,
		[55502] = 2,
		[136995] = "Viscous Horror",
		[122259] = "Sik'thik Engineer",
		[10] = 8,
		[92055] = 1,
		[76185] = "Ascendant Lord Obsidius",
		[125843] = "Tsulong",
		[127379] = 7,
		[2782] = 10,
		[124308] = 7,
		[100247] = "Branch of Nordrassil",
		[2894] = 7,
		[46544] = "Sunblade Cabalist",
		[55503] = 10,
		[47568] = 6,
		[11958] = 8,
		[32233] = "Mindbender <Tellios>",
		[136999] = 11,
		[16491] = 1,
		[41425] = 8,
		[99736] = "Ancient Core Hound",
		[124821] = "Kor'thik Reaver",
		[137000] = "Viscous Horror",
		[42705] = "Ingvar the Plunderer",
		[26090] = "Ruda <Kamyk>",
		[122774] = "Garalon",
		[116631] = "[*] Colossus",
		[76188] = "Ascendant Lord Obsidius",
		[13750] = 4,
		[127382] = 7,
		[119703] = "Siege Explosives",
		[49361] = 8,
		[75677] = "Twilight Zealot",
		[76189] = "Shadow of Obsidius",
		[140076] = 9,
		[36563] = 4,
		[124824] = 2,
		[109466] = 9,
		[31850] = 2,
		[16246] = 7,
		[114074] = 7,
		[122777] = "Tsulong",
		[115098] = 11,
		[115610] = 8,
		[138032] = "Lei Shen",
		[126873] = 7,
		[43987] = 8,
		[122266] = 10,
		[18540] = 9,
		[115611] = 8,
		[45779] = "Volatile Fiend",
		[27243] = 9,
		[133939] = "Tortos",
		[113564] = "Master Archer",
		[122267] = 8,
		[5116] = 3,
		[49363] = 3,
		[124827] = "Kor'thik Reaver",
		[5308] = 1,
		[126875] = 7,
		[111005] = 2,
		[122268] = 10,
		[122780] = "Tsulong",
		[131894] = 3,
		[45524] = 6,
		[108446] = 9,
		[46292] = "Cataclysm Hound",
		[145205] = 10,
		[31723] = "Doomfire Destroyer",
		[32235] = 3,
		[135991] = "Lei Shen",
		[122269] = 1,
		[32747] = 2,
		[124317] = "General Pa'valak",
		[75683] = "Lady Naz'jar",
		[135992] = 3,
		[103840] = 1,
		[122270] = 1,
		[99233] = 1,
		[133946] = "Tortos",
		[117663] = 7,
		[6940] = "Elegon",
		[71077] = "Sindragosa",
		[121247] = "Cursed Mogu Sculpture",
		[122783] = 11,
		[131900] = 3,
		[139068] = 7,
		[140092] = "Ji-Kun",
		[60116] = 1,
		[52437] = 1,
		[122784] = "Amber-Shaper Un'sok",
		[45270] = "Shadow Image",
		[54485] = 7,
		[117665] = "Sha of Doubt",
		[111010] = "Scarlet Zealot",
		[63956] = 10,
		[8092] = 5,
		[57557] = "Sartharion",
		[91045] = "Ogre Henchman",
		[116130] = 8,
		[124833] = 2,
		[117666] = 11,
		[121762] = "Sik'thik Builder",
		[114083] = 7,
		[122786] = "[*] Broken Leg",
		[45271] = "Shadow Image",
		[107428] = 11,
		[46551] = "Fire Fiend <Sunblade Cabalist>",
		[123811] = "Imperial Vizier Zor'lok",
		[138052] = "Ji-Kun",
		[128419] = "Dread Spawn <[*] Conjure Dread Spawn>",
		[123812] = "Imperial Vizier Zor'lok",
		[55255] = "Death Knight Captain",
		[94632] = 8,
		[121253] = 11,
		[122789] = "Sunbeam",
		[140103] = "[*] Dust Cloud",
		[12472] = 8,
		[126373] = "Quilen",
		[118694] = 3,
		[35290] = "Dog <Notethical>",
		[60119] = 10,
		[122278] = 11,
		[114599] = "Lesser Sha",
		[45529] = 6,
		[91562] = "Fetid Ghoul",
		[53] = 4,
		[144201] = 11,
		[76716] = "Defiled Earth Rager",
		[27758] = "Patchwork Golem",
		[116136] = 8,
		[29166] = 10,
		[76717] = "Defiled Earth Rager",
		[35035] = "Crystalcore Devastator",
		[51673] = "Antipersonnel Cannon",
		[103850] = 3,
		[96171] = 6,
		[114089] = 7,
		[53209] = 3,
		[106922] = 10,
		[115625] = "Ziggorod",
		[23023] = "Razorgore the Untamed",
		[76718] = "Incendiary Spark",
		[55001] = 3,
		[70063] = "The Lich King",
		[112042] = "Metatrax",
		[96172] = 2,
		[122281] = 11,
		[106923] = "Azure Serpent",
		[41435] = 6,
		[33500] = "Bloodwarder Legionnaire",
		[66] = 8,
		[76207] = "Mindbender Ghur'sha",
		[125865] = "Zar'thik Augurer",
		[140112] = "Zeb'tula Beastcaller",
		[119722] = "Elegon",
		[71088] = "Pustulating Horror",
		[71] = 1,
		[37852] = 7,
		[117163] = "Elder Asani",
		[46555] = "Sunblade Arch Mage",
		[69041] = 3,
		[126890] = 11,
		[133971] = "Whirl Turtle",
		[78] = 1,
		[136019] = "Diffused Lightning",
		[106413] = "[*] Ball of Fire",
		[106925] = "Consuming Sha",
		[116140] = "Houndmaster Braun",
		[75697] = "Twilight Zealot",
		[125355] = 11,
		[76721] = "Naz'jar Sentinel",
		[42972] = "Dragonflayer Strategist",
		[5405] = 8,
		[128939] = 11,
		[136021] = "Greater Diffused Lightning",
		[11129] = 8,
		[114093] = 7,
		[106414] = "[*] Fire Flower",
		[53467] = "Anub'arak",
		[132950] = 3,
		[133974] = "Whirl Turtle",
		[124844] = "Grand Empress Shek'zeer",
		[38621] = "Proto-Drake Handler",
		[126892] = 11,
		[132951] = 3,
		[23920] = 1,
		[71603] = "Professor Putricide",
		[122285] = 10,
		[73651] = 4,
		[115630] = "Shado-Pan Warden",
		[124845] = "Grand Empress Shek'zeer",
		[100784] = 11,
		[99] = 10,
		[138072] = 11,
		[77747] = 7,
		[6653] = 11,
		[37854] = "Morogrim Tidewalker",
		[46557] = "Sunblade Slayer",
		[118191] = "Minion of Fear",
		[111024] = "Spirit of Redemption",
		[63963] = 1,
		[112048] = 1,
		[120751] = 7,
		[113072] = 6,
		[122287] = 2,
		[106929] = "Consuming Sha",
		[57820] = 6,
		[124335] = 11,
		[125359] = 11,
		[50653] = "Enslaved Proto-Drake",
		[69046] = 4,
		[126895] = 11,
		[128943] = 1,
		[113073] = 3,
		[120] = 8,
		[131934] = 10,
		[83381] = "Cat <Brag>",
		[122] = 8,
		[23153] = "Chromaggus",
		[15801] = "Smolderthorn Seer",
		[23537] = "Chromaggus",
		[128432] = 3,
		[32240] = 2,
		[32752] = "Lazgup <Ravenppc>",
		[57821] = 5,
		[124849] = "Grand Empress Shek'zeer",
		[133] = 8,
		[42463] = 2,
		[136] = 3,
		[128433] = 3,
		[120754] = 7,
		[113075] = 2,
		[60893] = 7,
		[140129] = "Juvenile",
		[46559] = "Sunblade Vindicator",
		[38624] = "Greyheart Tidecaller",
		[2479] = 3,
		[122291] = 10,
		[139107] = "Appraising Eye",
		[57822] = 5,
		[116660] = "[*] River's Song",
		[42208] = 8,
		[125875] = "Zar'thik Augurer",
		[78777] = 10,
		[172] = 9,
		[136037] = "Primordius",
		[30449] = 8,
		[106422] = "Master Snowdrift",
		[116661] = "[*] Energy Conduit",
		[125876] = "Zar'thik Augurer",
		[118197] = 10,
		[127412] = "Unga Scallywag",
		[23922] = 1,
		[129460] = "Cobalt Guardian",
		[106423] = "Master Snowdrift",
		[49376] = 10,
		[125877] = "Set'thik Windblade",
		[126389] = 2,
		[126901] = "Kor'thik Fleshrender",
		[127413] = "Unga Scallywag",
		[120758] = "Commander Vo'jak",
		[60639] = "Vesperon",
		[53472] = "Anub'arak",
		[37858] = "Morogrim Tidewalker",
		[46561] = "Sunblade Dusk Priest",
		[55264] = "Death Knight Captain",
		[140138] = "Arcane Head",
		[111544] = "Blanche's Lightning Rod",
		[120759] = "Commander Vo'jak",
		[121783] = 2,
		[81340] = 6,
		[122807] = 3,
		[3599] = 7,
		[33763] = 10,
		[50401] = 6,
		[85948] = 6,
		[120760] = "Commander Vo'jak",
		[15290] = 5,
		[45026] = "Kalecgos",
		[82365] = 10,
		[46306] = "Doomfire Destroyer",
		[46562] = "Sunblade Dusk Priest",
		[15802] = "Smolderthorn Seer",
		[77758] = 10,
		[131951] = "Cursed Mogu Sculpture",
		[71103] = "Plague Scientist",
		[32242] = 1,
		[106427] = "Shado-Pan Novice",
		[131952] = "Cursed Mogu Sculpture",
		[123833] = "Imperial Vizier Zor'lok",
		[137072] = "Zandalari Spear-Shaper",
		[139120] = 3,
		[45027] = "Kalecgos",
		[116155] = "Yeasty Brew Alemental",
		[37860] = "Morogrim Tidewalker",
		[136050] = "Primordius",
		[46563] = "Sunblade Dawn Priest",
		[118203] = 5,
		[55266] = "Dark Touched Warrior",
		[71617] = "Professor Putricide",
		[136051] = 11,
		[138099] = "Ritualist Malus",
		[122811] = 3,
		[324] = 7,
		[5246] = 1,
		[125883] = "Twiig",
		[42724] = "Dragonflayer Weaponsmith",
		[5374] = 4,
		[134005] = "Wandering Eye",
		[137077] = "Zandalari Spear-Shaper",
		[45284] = 7,
		[37861] = "Morogrim Tidewalker",
		[46564] = "Sunblade Dawn Priest",
		[77762] = 7,
		[370] = 7,
		[134007] = "Wandering Eye",
		[32243] = 7,
		[137079] = "Zandalari Spear-Shaper",
		[116670] = 11,
		[70084] = "Sindragosa",
		[120254] = 11,
		[408] = 4,
		[53220] = 3,
		[106944] = "Destroying Sha",
		[134010] = "Wandering Eye",
		[124862] = "Grand Empress Shek'zeer",
		[125886] = "Set'thik Windblade",
		[77764] = 10,
		[134011] = "[*] Spinning Shell",
		[71621] = "Professor Putricide",
		[121279] = 10,
		[114624] = 3,
		[124863] = 11,
		[458] = 1,
		[21749] = "Barbed Lasher",
		[470] = 10,
		[472] = 1,
		[80325] = 3,
		[139133] = 9,
		[116161] = 7,
		[108482] = 9,
		[76230] = "[*] Mind Fog",
		[117697] = "Zian of the Endless Shadow",
		[15867] = "Smolderthorn Witch Doctor",
		[498] = 2,
		[120257] = 2,
		[32244] = 1,
		[137087] = "Unknown",
		[8190] = 7,
		[57573] = 1,
		[115650] = "Fizzy Brew Alemental",
		[116162] = "Fizzy Brew Alemental",
		[16886] = 10,
		[77767] = 3,
		[556] = 7,
		[121282] = "Wing Leader Ner'onok",
		[45031] = "Sathrovarr the Corruptor",
		[115139] = "Thalnos the Soulrender",
		[588] = 5,
		[596] = 5,
		[54758] = 11,
		[77768] = "Unknown",
		[19574] = 3,
		[121283] = 11,
		[115140] = "Thalnos the Soulrender",
		[115652] = "Bloated Brew Alemental",
		[77769] = 3,
		[676] = 1,
		[71114] = "Decaying Colossus",
		[688] = 9,
		[121284] = "Wing Leader Ner'onok",
		[129987] = "Whirlwind of Blades <Derenter>",
		[11196] = 7,
		[45032] = "Sathrovarr the Corruptor",
		[124868] = 9,
		[76234] = "Mindbender Ghur'sha",
		[117701] = "Zian of the Endless Shadow",
		[740] = 10,
		[744] = "Vile Larva",
		[32245] = 8,
		[129476] = 9,
		[137095] = "Pale Fog",
		[122309] = 5,
		[106439] = "Shado-Pan Novice",
		[106951] = 10,
		[123845] = "Heart of Fear",
		[83914] = "Vicious Mindlasher",
		[34026] = 3,
		[137096] = "Zandalari Spear-Shaper",
		[42729] = "Ingvar the Plunderer",
		[112071] = 10,
		[96201] = "Shale Spider",
		[121286] = 11,
		[44521] = 1,
		[122310] = 9,
		[61671] = 1,
		[76748] = 1,
		[55016] = 7,
		[131979] = "Unknown",
		[137099] = "Zandalari Water-Binder",
		[116680] = 11,
		[69070] = 3,
		[51945] = 7,
		[15228] = "Zandalari Fire-Dancer",
		[122312] = 1,
		[134030] = "Tortos",
		[980] = 9,
		[93644] = 1,
		[134031] = "Whirl Turtle",
		[32246] = 9,
		[16188] = 7,
		[137103] = "Hidden Fog",
		[122313] = 1,
		[116170] = "Fizzy Brew Alemental",
		[117194] = "Jan-xi",
		[137104] = "Hidden Fog",
		[51690] = 4,
		[112075] = "Starving Hound",
		[120778] = "Sik'thik Swarmer",
		[122314] = 10,
		[114635] = 9,
		[115147] = "Thalnos the Soulrender",
		[136082] = 5,
		[94158] = 11,
		[140178] = "Nether Wyrm",
		[120267] = "Xuen <Shamkim>",
		[96206] = 10,
		[136083] = 5,
		[153489] = 5,
		[122315] = 8,
		[73681] = 7,
		[140179] = "Nether Wyrm",
		[5215] = 10,
		[136084] = 6,
		[117708] = "Meng the Demented",
		[140180] = "Zao'cho",
		[120268] = 7,
		[52459] = 1,
		[113613] = 4,
		[138133] = "Lightning Fissure",
		[73682] = 7,
		[74194] = 7,
		[136086] = 3,
		[125900] = "Kor'thik Warsinger",
		[1464] = 1,
		[102351] = 10,
		[120269] = "[*] Caustic Tar",
		[48108] = 8,
		[32375] = 5,
		[122317] = 1,
		[73683] = 7,
		[116174] = "Gara'jal the Spiritbinder",
		[58859] = "Spirit Wolf <Wafty>",
		[102352] = 10,
		[43757] = "Dragonflayer Forge Master",
		[122318] = 1,
		[73684] = 7,
		[131994] = "Sha of Fear",
		[1680] = 1,
		[136090] = 11,
		[125902] = "Kor'thik Warsinger",
		[126926] = "Kor'thik Swarmguard",
		[19577] = 3,
		[141210] = "Exanimexs",
		[1752] = 4,
		[113616] = "Book Case",
		[1784] = 4,
		[20473] = 2,
		[131996] = "Sha of Fear",
		[136092] = 2,
		[1856] = 4,
		[59628] = 4,
		[111569] = "Scarlet Cannon",
		[120272] = 11,
		[23033] = 2,
		[23161] = 9,
		[137118] = "Lu'lin",
		[55021] = 8,
		[126928] = "Kor'thik Swarmguard",
		[55533] = 7,
		[111570] = "Lilian Voss",
		[2008] = 7,
		[120785] = "Mogu'shan Warden",
		[132000] = "Sha of Fear",
		[116178] = "Sudsy Brew Alemental",
		[125393] = 9,
		[120274] = 11,
		[104404] = 11,
		[37104] = "Crystalcore Sentinel",
		[137122] = "Kazra'jin",
		[138146] = 7,
		[139170] = 1,
		[112084] = "Zao Sunseeker",
		[88023] = "The Golden Beetle",
		[56814] = 4,
		[122835] = "[*] Pheromones",
		[115668] = 2,
		[117204] = "Elegon",
		[125907] = "Kor'thik Warsinger",
		[70106] = "Sindragosa",
		[147364] = 11,
		[115157] = "Empowering Spirit",
		[37361] = "Skeletal Guardian",
		[23034] = 2,
		[2912] = 10,
		[38641] = "Greyheart Nether-Mage",
		[102359] = 10,
		[132007] = "Sha of Fear",
		[120789] = "Commander Vo'jak",
		[56815] = 6,
		[114646] = "Haunting Sha",
		[116182] = "Sudsy Brew Alemental <Sudsy Brew Alemental>",
		[33778] = 10,
		[147367] = 1,
		[120278] = "Jokui <Jokui>",
		[137129] = "Star",
		[45297] = 7,
		[3408] = 4,
		[70109] = "Sindragosa",
		[104409] = 3,
		[3600] = 7,
		[57840] = 4,
		[29306] = "Gluth",
		[137133] = "Kazra'jin",
		[15870] = "Superior Healing Ward <Smolderthorn Witch Doctor>",
		[128984] = 3,
		[16190] = 7,
		[113626] = "Flameweaver Koegler",
		[57841] = 4,
		[42739] = "[*] Woe Strike",
		[126937] = "Sra'thik Ambercaller",
		[59889] = 5,
		[128985] = 9,
		[104924] = 7,
		[121818] = 3,
		[61425] = 11,
		[53490] = 3,
		[108508] = 9,
		[117723] = "Player Mirror Image",
		[138162] = 2,
		[94686] = 2,
		[112092] = 9,
		[128986] = 1,
		[129498] = 11,
		[131034] = "Vengeful Gurthani Spirit",
		[57842] = 4,
		[29307] = "Zombie Chow",
		[42740] = "Dragonflayer Runecaster",
		[126939] = "Sra'thik Ambercaller",
		[112093] = "Starving Hound",
		[128987] = 5,
		[80353] = 8,
		[113629] = "Boneweaver",
		[114141] = "Krastinovian Carver",
		[139189] = 7,
		[37109] = "Astromancer",
		[116189] = 11,
		[5760] = 4,
		[135095] = "Lei Shen",
		[32379] = 5,
		[137143] = "Aquila",
		[114654] = 9,
		[16509] = "Doctor Theolen Krastinov",
		[135096] = "Lei Shen",
		[58867] = "Spirit Wolf <Wafty>",
		[118750] = 11,
		[71140] = "Blighted Abomination",
		[52212] = 6,
		[130013] = "The Dark of Night",
		[37110] = "Astromancer",
		[136122] = "Crimson Fog",
		[84963] = 2,
		[146361] = 1,
		[118751] = 9,
		[70117] = "Sindragosa",
		[39414] = "High Astromancer Solarian",
		[113120] = 4,
		[139195] = 7,
		[50421] = 6,
		[29436] = "Fathom-Guard Sharkkis",
		[118752] = 7,
		[111585] = "Lilian Voss",
		[15039] = "Twilight Elementalist",
		[120800] = "Commander Vo'jak",
		[52469] = "Watcher Silthik",
		[137149] = "Kazra'jin",
		[122336] = "Sonic Ring",
		[61684] = "Apex <Minmaxer>",
		[15487] = 5,
		[99811] = "Giant Fire Scorpion",
		[135102] = "Vampiric Cave Bat",
		[54517] = "Stalagg",
		[38391] = "Searing Destroyer",
		[120289] = 7,
		[96228] = 3,
		[16191] = 7,
		[137151] = "Kazra'jin",
		[106979] = "Shado-Pan Fire Archer",
		[116706] = 11,
		[117218] = "Gara'jal the Spiritbinder",
		[137152] = "Hidden Fog",
		[110051] = 5,
		[118754] = 1,
		[17534] = 3,
		[96229] = 6,
		[52470] = "Watcher Silthik",
		[44535] = 7,
		[61685] = "Cryptik <Minmaxer>",
		[117219] = "Gara'jal the Spiritbinder",
		[76776] = "Noxious Mire",
		[138178] = "Thunder Trap",
		[38904] = "Coilfang Beast-Tamer",
		[28157] = "Grobbulus",
		[121827] = 11,
		[49143] = 6,
		[57846] = "Dragonflayer Ironhelm",
		[139204] = "[*] Infrared Tracking",
		[59638] = "Prettycold <Prettycold>",
		[96231] = 2,
		[104934] = 10,
		[121828] = 11,
		[122852] = "Imperial Vizier Zor'lok",
		[82921] = 3,
		[116709] = 11,
		[126436] = 10,
		[139206] = "Zandalari Storm-Caller",
		[70123] = "Sindragosa",
		[104423] = 7,
		[104935] = 8,
		[122853] = "[*] Tempest Slash",
		[57591] = "Fire Cyclone",
		[116198] = 9,
		[33786] = 10,
		[117222] = "Gara'jal the Spiritbinder",
		[42745] = "Savage Worg",
		[128997] = "Spirit Beast <Foxy>",
		[114663] = "Brewmaster Blanche",
		[115175] = 11,
		[115687] = 11,
		[116199] = 3,
		[116711] = "Feng the Accursed",
		[76780] = 7,
		[63735] = 5,
		[134091] = "Whirl Turtle",
		[28542] = "Sapphiron",
		[147402] = 8,
		[115176] = 11,
		[134092] = "Whirl Turtle",
		[34299] = 10,
		[147403] = 3,
		[71150] = "Blighted Abomination",
		[113641] = "Flameweaver Koegler",
		[138189] = "Faded Image of Chi-Ji",
		[139213] = "Zandalari Prelate",
		[82925] = 3,
		[117225] = "Felguard <Amalanar>",
		[117737] = "Meng the Demented",
		[110570] = 10,
		[70127] = "Sindragosa",
		[111594] = "Scholomance Acolyte",
		[79854] = "Fei Li",
		[137167] = 11,
		[147406] = 1,
		[115178] = 11,
		[82926] = 3,
		[116202] = 9,
		[147407] = 7,
		[122346] = "Li Chu",
		[122858] = "Tsulong",
		[99821] = "Giant Fire Scorpion",
		[117227] = "Elder Asani",
		[147409] = 3,
		[87023] = 8,
		[79856] = 7,
		[136147] = "Iron Qon",
		[113644] = "Commander Lindon",
		[147410] = 3,
		[20608] = 7,
		[20736] = 3,
		[5217] = 10,
		[138196] = "Lightning Guardian",
		[147411] = 3,
		[87024] = 8,
		[51963] = "Ebon Gargoyle <Manatees>",
		[121836] = 6,
		[122348] = "Living Amber",
		[147412] = 3,
		[115181] = 11,
		[115693] = 11,
		[5761] = 4,
		[5857] = 9,
		[102383] = 10,
		[114158] = 2,
		[139223] = "Zandalari Prelate",
		[117230] = "Corrupted Waters <Elder Asani>",
		[137176] = "[*] Overloaded Circuits",
		[110575] = 10,
		[111599] = "Scholomance Acolyte",
		[121838] = 2,
		[138201] = "Thunder Lord",
		[37118] = "Tempest-Smith",
		[115695] = 11,
		[6785] = 10,
		[136154] = "Crimson Fog",
		[46589] = "Kil'jaeden",
		[126958] = "Mogu'shan Warden",
		[140250] = 9,
		[71157] = "Plagued Zombie",
		[113136] = "Darkmaster Gandling",
		[137180] = "Jin'rokh the Breaker",
		[139228] = "Zandalari High Priest",
		[111601] = "Scarlet Evoker",
		[71158] = "Unknown",
		[104434] = 11,
		[22273] = "Grethok the Controller",
		[147420] = 10,
		[76790] = "Naz'jar Invader",
		[31616] = 7,
		[139231] = "Zandalari Storm-Caller",
		[115698] = 11,
		[83958] = 11,
		[58877] = "Spirit Wolf <Wafty>",
		[71160] = "Stinky",
		[114163] = 2,
		[37120] = "Tempest-Smith",
		[117235] = "Corrupted Waters <Elder Asani>",
		[138210] = "Thunder Lord",
		[40192] = 5,
		[122355] = 9,
		[124915] = 9,
		[2641] = 3,
		[76793] = "Naz'jar Invader",
		[95223] = 11,
		[113141] = "Darkmaster Gandling",
		[113653] = "Flameweaver Koegler",
		[114165] = 2,
		[106998] = 10,
		[124916] = 9,
		[38145] = "Lady Vashj",
		[56063] = "Naxxramas Acolyte",
		[24450] = "Cat <Brag>",
		[135144] = "Dam'ren",
		[125429] = "Sra'thik Pool-Tender",
		[58879] = 7,
		[126453] = 10,
		[43265] = 6,
		[120822] = 11,
		[113143] = "Darkmaster Gandling",
		[115191] = 4,
		[82939] = 3,
		[134122] = "Blue Eye",
		[135146] = "Dam'ren",
		[3409] = 4,
		[85499] = 2,
		[126966] = "Mogu'shan Warden",
		[134123] = "Red Eye",
		[113144] = "Darkmaster Gandling",
		[113656] = 11,
		[114168] = 9,
		[115192] = 4,
		[134124] = "Yellow Eye",
		[33795] = 1,
		[117752] = "Gara'jal the Spiritbinder",
		[14914] = 5,
		[51713] = 4,
		[22275] = "Death Talon Hatcher",
		[130551] = 2,
		[37123] = "Crystalcore Mechanic",
		[82941] = 3,
		[91644] = "Bird of Prey <Huntsimba>",
		[135150] = "Lei Shen",
		[125432] = "Sra'thik Pool-Tender",
		[68607] = "Apothecary Hummel",
		[126456] = 10,
		[39171] = "Sunblade Vindicator",
		[111610] = "Instructor Chillheart",
		[136175] = "Amber Fog",
		[140271] = 11,
		[126457] = 3,
		[25603] = "Twilight Loreseeker",
		[148463] = 9,
		[51714] = 6,
		[135153] = "[*] Crashing Thunder",
		[136177] = "Azure Fog",
		[37124] = "Star Scryer",
		[126970] = "Mogu'shan Arcanist",
		[4962] = "Crypt Beast",
		[104445] = 7,
		[137203] = "High Priestess Mar'li",
		[139251] = "Zandalari Storm-Caller",
		[115196] = 4,
		[83968] = 10,
		[136180] = 11,
		[117756] = "Meng the Demented",
		[126459] = 6,
		[148467] = 3,
		[136181] = 8,
		[115197] = 4,
		[136182] = 3,
		[11971] = "Blindlight Murloc",
		[136183] = 8,
		[136184] = 3,
		[12739] = "Thuzadin Shadowcaster",
		[126973] = "Mogu'shan Arcanist",
		[51460] = 6,
		[17669] = 1,
		[136185] = 2,
		[114175] = 9,
		[37126] = "Star Scryer",
		[116223] = "Jade Guardian",
		[136186] = 7,
		[125950] = "Jade Serpent Statue <Madani>",
		[118271] = 8,
		[102401] = 10,
		[111616] = 9,
		[136187] = 10,
		[138235] = "Zao'cho",
		[82948] = 3,
		[116224] = "Obedient Hound",
		[35079] = 3,
		[129023] = 10,
		[136189] = "Sul the Sandcrawler",
		[121856] = 3,
		[44806] = "Kalecgos",
		[53509] = "Anub'arak",
		[123904] = 11,
		[136190] = "Sul the Sandcrawler",
		[8034] = 7,
		[138239] = "[*] Electro Pulse",
		[122881] = "Unstable Sha",
		[123393] = 11,
		[91141] = 7,
		[99844] = "Alysrazor",
		[136192] = "Iron Qon",
		[76807] = "Naz'jar Invader",
		[111107] = "Scarlet Judicator",
		[136193] = "[*] Arcing Lightning",
		[122370] = "Amber-Shaper Un'sok",
		[115203] = 11,
		[37640] = "Leotheras the Blind",
		[138242] = 2,
		[95750] = 9,
		[48391] = 10,
		[116740] = 11,
		[126467] = 5,
		[30213] = "Orikkilig <Demontime>",
		[137221] = "Ro'shak",
		[131078] = 8,
		[37129] = "Apprentice Star Scryer",
		[30981] = 3,
		[37641] = "Leotheras the Blind",
		[31365] = "Life Spirit",
		[54791] = "Maleki the Pallid",
		[11972] = "Anvilrage Warden",
		[121861] = 11,
		[32645] = 4,
		[12292] = 1,
		[90633] = 2,
		[12548] = "Twilight Elementalist",
		[140296] = "Thunder Lord",
		[114183] = "Scarlet Scholar",
		[114695] = 2,
		[137226] = "Dam'ren",
		[19975] = 10,
		[137227] = "Dam'ren",
		[114184] = "Scarlet Pupil",
		[137228] = "Dam'ren",
		[118280] = 8,
		[140300] = 11,
		[128519] = 8,
		[96267] = 5,
		[137229] = "Dam'ren",
		[114185] = "Scarlet Scholar",
		[53257] = 3,
		[140301] = "Thunder Lord",
		[83981] = "Unyielding Behemoth",
		[137230] = "Dam'ren",
		[138254] = "Faded Image of Niuzao",
		[96268] = 6,
		[121865] = "Captain Ook",
		[16324] = "Ravaged Cadaver",
		[143375] = 6,
		[76815] = "Naz'jar Spiritmender",
		[51722] = 4,
		[128521] = 1,
		[136209] = "Primordius",
		[1137] = 3,
		[123402] = 11,
		[116235] = "Amethyst Guardian",
		[136210] = "Primordius",
		[125962] = "Jade Serpent Statue <Madani>",
		[118283] = "Emperor's Rage",
		[38924] = "Serpentshrine Sporebat",
		[28167] = "Thaddius",
		[136211] = "Primordius",
		[108557] = 11,
		[125451] = "Sha of Fear",
		[1329] = 4,
		[59658] = 11,
		[51723] = 4,
		[137237] = "Zandalari Dinomancer",
		[114189] = 9,
		[115213] = "Mogu'shan Secret-Keeper",
		[1449] = 8,
		[126476] = 7,
		[1513] = 3,
		[132120] = 11,
		[136216] = "Primordius",
		[17289] = "Blackwing Taskmaster",
		[111631] = "Instructor Chillheart",
		[88082] = "Mirror Image <Pvp>",
		[61451] = 5,
		[13445] = "Bloodhound",
		[124430] = 5,
		[136218] = "Primordius",
		[76820] = "Naz'jar Spiritmender",
		[126478] = 7,
		[102417] = 10,
		[121871] = "Ookie",
		[138267] = "Faded Image of Yu'lon",
		[140315] = "Spirit Mask",
		[1833] = 4,
		[88084] = "Mirror Image <Rivsoft>",
		[52493] = "Watcher Silthik",
		[121872] = "Ookie",
		[22665] = "Lord Victor Nefarius",
		[1953] = 8,
		[15749] = "Summoned Blackhand Veteran <Blackhand Summoner>",
		[138270] = "[*] Electro Wave",
		[55821] = "Stitched Colossus",
		[135199] = "Dam'ren",
		[129552] = 3,
		[113682] = "Flameweaver Koegler",
		[2050] = 5,
		[115730] = 6,
		[2098] = 4,
		[17290] = "Blackwing Mage",
		[139296] = "Hatchling",
		[51470] = 7,
		[129041] = 7,
		[129553] = 10,
		[138273] = "Zao'cho",
		[109076] = 3,
		[118291] = 7,
		[147489] = 11,
		[127506] = 7,
		[28169] = "Grobbulus",
		[129554] = 10,
		[124947] = "Elegon",
		[136228] = "Primordius",
		[126483] = 3,
		[86040] = 9,
		[140324] = "Arcanital Tula'chek",
		[128531] = 11,
		[121876] = "Sra'thik Amber-Trapper",
		[2818] = 4,
		[107030] = "[*] Splash",
		[126484] = 7,
		[47632] = 6,
		[3026] = 10,
		[114198] = 1,
		[12294] = 1,
		[140327] = "Arcanital Tula'chek",
		[12486] = 8,
		[35858] = "Nether Vapor",
		[121878] = 8,
		[53520] = "Anub'arak",
		[13446] = "Ravaged Cadaver",
		[84507] = "Naz'jar Invader",
		[127510] = "Unga Bird-Haver",
		[3490] = "Aku'mai",
		[128534] = 6,
		[72221] = 10,
		[113688] = "Commander Lindon",
		[131116] = 1,
		[3714] = 6,
		[111129] = "Gu Cloudstrike",
		[137261] = "Jin'rokh the Breaker",
		[139309] = "Muckbat",
		[123928] = "Scar-Shell",
		[125464] = "Grand Empress Shek'zeer",
		[118297] = "Primal Fire Elemental <Zadziorny>",
		[139310] = "Skittering Spiderling",
		[111642] = "Lilian's Soul",
		[121881] = 2,
		[139311] = "Flesh'rok the Diseased",
		[123417] = "Sra'thik Shield Master",
		[123929] = "Scar-Shell",
		[8391] = "Aku'mai Snapjaw",
		[8647] = 4,
		[127513] = "Unga Bird-Haver",
		[51730] = 7,
		[103964] = 9,
		[113691] = "Flameweaver Koegler",
		[114203] = 1,
		[139313] = "Flesh'rok the Diseased",
		[115739] = "Commander Durand",
		[54290] = "Anub'ar Webspinner",
		[68641] = "Apothecary Hummel",
		[118299] = "Energy Charge",
		[139314] = "Flesh'rok the Diseased",
		[28299] = "Stalagg",
		[122395] = 2,
		[139315] = "Flesh'rok the Diseased",
		[123931] = "Jol'Grum",
		[109085] = 3,
		[118300] = 10,
		[110621] = 10,
		[111645] = 11,
		[60178] = 3,
		[136245] = "Primordius",
		[114205] = 1,
		[139317] = "Putrid Waste",
		[123420] = "Sra'thik Shield Master",
		[46356] = 10,
		[126492] = 5,
		[103967] = 9,
		[135223] = "Dam'ren",
		[136247] = "Primordius",
		[121885] = 2,
		[122397] = "Brew Defender <Wafty>",
		[139319] = "Zandalari Storm-Caller",
		[123421] = "Kor'thik Slicer",
		[24844] = "Крылатый змей <Beastmaster>",
		[50452] = 6,
		[118302] = 6,
		[139320] = "Zandalari Storm-Caller",
		[129053] = 11,
		[122398] = 2,
		[139321] = 7,
		[123422] = "Kor'thik Slicer",
		[123934] = "Jol'Grum",
		[6788] = 5,
		[126494] = 1,
		[139322] = "Zandalari Storm-Caller",
		[119839] = 9,
		[104993] = "[*] Jade Spirit",
		[130078] = "Unstable Sha",
		[7268] = 8,
		[75813] = "Naz'jar Tempest Witch",
		[76325] = "Twilight Flame Caller",
		[138300] = "[*] Fortitude of the Ox",
		[111649] = "Unknown",
		[97827] = 9,
		[132158] = 10,
		[123936] = "Jol'Grum",
		[116257] = 8,
		[138302] = 5,
		[31884] = 2,
		[8004] = 7,
		[39703] = 7,
		[122913] = "[*] Tasty",
		[115234] = "Klathdoc <Physx>",
		[115746] = "Pip'tok <Khymura>",
		[17038] = 11,
		[121890] = "Unga Totem",
		[122402] = "Amber Monstrosity",
		[109092] = 3,
		[138306] = "[*] Serpent's Vitality",
		[118819] = "Belligerent Blossom",
		[103461] = 11,
		[96294] = 6,
		[113188] = "Failed Student <Darkmaster Gandling>",
		[115236] = "Metatrax",
		[115748] = "Delersia <Khymura>",
		[125475] = 7,
		[110117] = "Ethereal Sha",
		[69674] = "Rotface",
		[53271] = 3,
		[107046] = "Sodden Hozen Brawler",
		[125476] = 7,
		[138310] = 11,
		[87081] = "Blackfathom Myrmidon",
		[121893] = "Captain Ook",
		[138311] = 11,
		[132168] = 1,
		[115750] = 2,
		[125477] = 7,
		[137288] = 2,
		[118310] = "Elegon",
		[132169] = 1,
		[149575] = 3,
		[122406] = "Wind Lord Mel'jarak",
		[82987] = 7,
		[126502] = 5,
		[48153] = 5,
		[122407] = "Wind Lord Mel'jarak",
		[115240] = "Metatrax",
		[115752] = 2,
		[124967] = "Elegon",
		[126503] = 7,
		[147531] = 1,
		[120360] = 3,
		[121896] = "Wind Lord Mel'jarak",
		[122408] = "Amber Monstrosity",
		[15496] = "Skeletal Berserker",
		[23055] = 6,
		[125480] = "Amber Searsting",
		[138318] = "[*] Crane Rush",
		[120361] = 3,
		[138319] = "[*] Feed Pool",
		[75823] = "Corla, Herald of Twilight",
		[121898] = "Wind Lord Mel'jarak",
		[114219] = "Scarlet Scholar",
		[124458] = 11,
		[135250] = 6,
		[135251] = "Tortos",
		[28431] = "Venom Stalker",
		[5221] = 10,
		[125483] = 6,
		[110125] = "Minion of Doubt",
		[127531] = "Galleon",
		[128555] = "Garalon",
		[120876] = 7,
		[44572] = 8,
		[115757] = 8,
		[142421] = 10,
		[116781] = 11,
		[101423] = 2,
		[88625] = 5,
		[130092] = 4,
		[6117] = 8,
		[123437] = "Set'thik Swiftblade",
		[142423] = "Wild Mushroom",
		[116782] = "[*] Titan Gas",
		[76339] = "Mindbender Ghur'sha",
		[142424] = 10,
		[113199] = 9,
		[121902] = "Ookie",
		[124974] = 10,
		[87091] = 11,
		[103985] = 11,
		[122415] = "Amber Monstrosity",
		[115760] = 8,
		[116272] = "Gara'jal the Spiritbinder",
		[116784] = "Feng the Accursed",
		[125487] = 9,
		[139356] = "Archritualist Kelada",
		[127535] = "Lei Shi",
		[89140] = 9,
		[89652] = "Ogre Henchman",
		[106546] = "Bloated Brew Alemental",
		[45342] = "Grand Warlock Alythess",
		[107570] = 1,
		[124464] = 5,
		[125488] = 5,
		[38431] = "Fathom-Guard Sharkkis",
		[7941] = "Greater Earth Elemental <Illidian>",
		[111666] = 7,
		[89653] = 9,
		[114738] = 7,
		[115250] = "Empowering Spirit",
		[124465] = 5,
		[16914] = 10,
		[125489] = 11,
		[42783] = "High Astromancer Solarian",
		[111667] = "Scarlet Evoker",
		[137313] = "Jin'rokh the Breaker",
		[130609] = 10,
		[140385] = "Zandalari Prophet",
		[45855] = "Felmyst",
		[125490] = "Amber Searsting",
		[118323] = 7,
		[127538] = 10,
		[111668] = "Raigonn",
		[28305] = "Shadowfiend <Maible>",
		[57374] = "Lady Blaumeux",
		[124467] = 5,
		[2643] = 3,
		[139364] = "Spirit Flayer",
		[128051] = "The Golden Beetle",
		[103990] = 9,
		[30225] = "Thaladred the Darkener",
		[107574] = 1,
		[124468] = 5,
		[136294] = "Tortos",
		[76858] = 1,
		[138342] = 6,
		[111670] = "Scarlet Zealot",
		[96312] = 10,
		[136295] = "Lei Shen",
		[49184] = 6,
		[124469] = 5,
		[50464] = 10,
		[139368] = "Archritualist Kelada",
		[111671] = "Raigonn",
		[129077] = "Terror Spawn",
		[123958] = "Little Liuyang",
		[3411] = 1,
		[27794] = "Patchwork Golem",
		[121911] = "Unga Bird-Haver",
		[114232] = 2,
		[123959] = "Little Liuyang",
		[50977] = 6,
		[29842] = 1,
		[111673] = 6,
		[60192] = 3,
		[15242] = "Firebrand Invoker",
		[138349] = "Jin'rokh the Breaker",
		[123960] = "Little Liuyang",
		[116281] = "Cobalt Mine",
		[116793] = "[*] Wildfire",
		[137326] = 7,
		[38947] = "Vashj'ir Honor Guard",
		[145518] = 10,
		[57377] = "Sir Zeliek",
		[115770] = "Delersia <Khymura>",
		[134256] = "[*] Slimed",
		[42787] = 7,
		[140400] = "Zandalari Prophet",
		[36132] = "Bloodwarder Marshal",
		[97341] = 7,
		[90174] = 2,
		[132210] = 8,
		[123962] = "Kor'thik Elite Blademaster",
		[45859] = "Anchorite Elbadon",
		[104509] = 7,
		[113724] = 8,
		[89663] = "Kobold Digger",
		[34341] = "Al'ar",
		[79937] = "Darkmaster Gandling",
		[37157] = "Phoenix-Hawk",
		[135286] = 10,
		[117309] = "Elder Asani",
		[46628] = 11,
		[79938] = "Darkmaster Gandling",
		[72259] = "The Lich King",
		[114238] = 10,
		[123965] = "Flame Wall",
		[16789] = "General Drakkisath",
		[34342] = "Al'ar",
		[119358] = "Elegon",
		[17941] = 9,
		[129597] = 11,
		[106560] = "[*] Gushing Brew",
		[123966] = "Little Liuyang",
		[125502] = "Amber Globule",
		[64803] = 3,
		[80964] = 10,
		[123967] = "Little Liuyang",
		[7302] = 8,
		[14795] = 11,
		[119360] = "Elegon",
		[72262] = "The Lich King",
		[80965] = 10,
		[132222] = "Celestial Protector",
		[15499] = 1,
		[84037] = "Neptulon",
		[117313] = 1,
		[138366] = 3,
		[7942] = "Greater Fire Elemental <Wafty>",
		[140414] = "Zandalari Warlord",
		[114242] = "Houndmaster Braun",
		[106563] = "Yan-Zhu the Uncasked",
		[115778] = "Xelgolon <Bukay>",
		[137344] = "High Priestess Mar'li",
		[34600] = 3,
		[127553] = "Gagoon",
		[53030] = "Hadronox",
		[132226] = 3,
		[585] = 5,
		[589] = 5,
		[9484] = 5,
		[125506] = "Commander Lindon",
		[605] = 5,
		[47399] = "Cataclysm Hound",
		[119875] = "General Pa'valak",
		[135299] = 3,
		[121411] = 4,
		[137347] = "High Priestess Mar'li",
		[115268] = "Ekkrezza <Vanhellsing>",
		[10444] = 7,
		[92231] = 5,
		[125507] = "Commander Lindon",
		[117828] = 9,
		[42792] = 1,
		[118852] = 11,
		[120388] = "Dread Spawn <[*] Conjure Dread Spawn>",
		[689] = 9,
		[130115] = "Apparition of Terror",
		[138373] = "Anima Golem",
		[115781] = "Illygok <Lastjedi>",
		[116805] = "Titan Spark",
		[136326] = "Lei Shen",
		[137350] = "High Priestess Mar'li",
		[138374] = 3,
		[118853] = "Empyreal Focus",
		[140422] = "Zandalari Warlord",
		[107079] = 7,
		[115782] = "Illygok <Dotandfear>",
		[16791] = "Magistrate Barthilas",
		[75851] = "Karsh Steelbender",
		[76363] = "Unstable Corruption",
		[126533] = 2,
		[119366] = "Sorcerer Mogu",
		[121414] = 3,
		[18327] = "Baroness Anastari",
		[123974] = "Chagan Firehoof",
		[116295] = "Feng the Accursed",
		[124998] = "Great Wall Explosion Caster Stalker",
		[853] = 2,
		[138378] = "Anima Golem",
		[139402] = "No'ku Stormsayer",
		[86603] = "Shado-Pan Prisoner",
		[124999] = "Great Wall Explosion Caster Stalker",
		[92747] = "Ogre Henchman",
		[51753] = 3,
		[22423] = "Death Talon Flamescale",
		[123976] = "Trailblaze <Chagan Firehoof>",
		[124488] = 11,
		[116809] = 2,
		[117833] = "Meng the Demented",
		[118345] = "Primal Earth Elemental <Madawng>",
		[127560] = "Oku-Oku",
		[111690] = 11,
		[130120] = "Apparition of Terror",
		[114250] = 2,
		[16408] = 1,
		[8269] = "Doctor Theolen Krastinov",
		[4167] = "Araña <Likarius>",
		[99916] = "Unbound Pyrelord",
		[1066] = 10,
		[137360] = "[*] Corrupted Healing",
		[69200] = "The Lich King",
		[127561] = "Oku-Oku",
		[120394] = "Dread Spawn <[*] Conjure Dread Spawn>",
		[1122] = 9,
		[1130] = 3,
		[18328] = "Alliance Peacekeeper",
		[61993] = 9,
		[99917] = "Unbound Smoldering Elemental",
		[54314] = "Anub'ar Prime Guard",
		[109132] = 11,
		[9613] = "Twilight Shadowmage",
		[138386] = "Massive Anima Golem",
		[131219] = 7,
		[120395] = 11,
		[121931] = "Grooka Grooka",
		[138387] = "Dark Animus",
		[122955] = "Commander Vo'jak",
		[115276] = "Fizsillin <Thebigkiller>",
		[99918] = "Unbound Smoldering Elemental",
		[1330] = 4,
		[139412] = "Suen",
		[51755] = "Ariya",
		[138389] = 11,
		[61994] = 7,
		[116301] = 3,
		[54315] = "Anub'ar Prime Guard",
		[117837] = "Meng the Demented",
		[70739] = 7,
		[121421] = "Sik'thik Guardian",
		[113742] = 4,
		[130636] = 7,
		[107087] = 2,
		[41517] = 1,
		[16793] = "Magistrate Barthilas",
		[6343] = 1,
		[118350] = 7,
		[119374] = "[*] Whirlwind",
		[13005] = "Bloodwarder Squire",
		[121422] = "Sik'thik Guardian",
		[114255] = 5,
		[1706] = 5,
		[137370] = "[*] Thundering Throw",
		[146585] = 2,
		[119887] = "Yang Guoshi",
		[121935] = "Grooka Grooka",
		[146586] = 2,
		[122959] = "Xin the Weaponmaster",
		[123471] = "Blade Lord Ta'yak",
		[116304] = 4,
		[116816] = "[*] Wildfire Infusion",
		[1850] = 10,
		[118864] = 11,
		[128079] = "Dreadspinner Tender",
		[128591] = 11,
		[121936] = "Unga Totemchipper",
		[22425] = "Razorgore the Untamed <Wafty>",
		[122960] = "Amber-Shaper Un'sok",
		[90708] = 6,
		[133278] = 1,
		[137374] = "Zandalari Storm-Caller",
		[126544] = 11,
		[118865] = "Cursed Jade",
		[64044] = 5,
		[71255] = "Professor Putricide",
		[113746] = 10,
		[49966] = "Spellhaste <Nim>",
		[126545] = 7,
		[120402] = "Mantid Tar Keg",
		[80983] = "Scarlet Defender",
		[114259] = "Houndmaster Braun",
		[122962] = "Quilen Guardian",
		[123474] = "Instructor Tak'thok",
		[123986] = 11,
		[116819] = "Qin-xi",
		[55342] = 8,
		[70233] = 11,
		[128594] = 3,
		[71769] = "The Lich King",
		[114260] = 6,
		[115284] = "Xelgolon <Bukay>",
		[70234] = 2,
		[128595] = 11,
		[114773] = 6,
		[22682] = "Nefarian",
		[116821] = "Wildfire Spark",
		[137382] = "Lurker in the Night",
		[2948] = 8,
		[119381] = 11,
		[32409] = "[*] Shadow Word: Death",
		[3044] = 3,
		[114262] = "Darkmaster Gandling",
		[24858] = 10,
		[146599] = "Enormous Stone Quilen",
		[131241] = "Shado-Pan Fire Archer",
		[136361] = "Lei Shen",
		[61999] = 6,
		[118871] = 5,
		[104025] = 9,
		[115288] = 11,
		[124503] = 11,
		[3716] = "Metatrax",
		[51505] = 7,
		[72286] = 4,
		[22427] = "Dragonflayer Weaponsmith",
		[73822] = 2,
		[115289] = "Thalnos the Soulrender",
		[123992] = 2,
		[125528] = 3,
		[137390] = "Shadowed Loa Spirit",
		[23451] = 10,
		[127576] = 2,
		[47666] = 5,
		[104027] = 9,
		[122457] = 6,
		[33076] = 5,
		[8399] = "Twilight Lord Kelris",
		[127577] = 1,
		[134321] = "Hatchling",
		[130649] = 6,
		[122970] = "Imperial Vizier Zor'lok",
		[115291] = "[*] Spirit Gale",
		[134322] = "Hatchling",
		[145585] = 1,
		[55090] = 6,
		[118875] = 6,
		[119387] = "Elegon",
		[119899] = "Pip'tok <Khymura>",
		[56626] = "Wasp <Deadaim>",
		[130650] = 10,
		[115804] = 1,
		[124507] = 11,
		[50227] = 1,
		[136372] = "Unknown",
		[5384] = 3,
		[119388] = 1,
		[129115] = 4,
		[72290] = 6,
		[114781] = 3,
		[5672] = "Healing Stream Totem <Wafty>",
		[22812] = 10,
		[129116] = 4,
		[137399] = "Jin'rokh the Breaker",
		[138423] = 3,
		[24604] = 3,
		[115294] = 11,
		[109151] = 9,
		[162997] = 6,
		[139448] = 7,
		[70244] = 9,
		[80483] = 3,
		[130653] = 7,
		[115295] = 11,
		[109152] = 9,
		[138426] = 9,
		[19869] = 7,
		[48181] = 9,
		[137403] = "Suen",
		[130654] = 11,
		[137404] = "Suen",
		[93795] = 11,
		[119392] = 11,
		[35383] = "[*] Flame Patch",
		[30108] = 9,
		[137405] = "[*] Tears of the Sun",
		[53301] = 3,
		[45366] = "Grand Warlock Alythess",
		[99427] = "[*] Incendiary Cloud",
		[119905] = 9,
		[16143] = "Mangled Cadaver",
		[48438] = 10,
		[122465] = 11,
		[49206] = 6,
		[116322] = 3,
		[137408] = "Suen",
		[139456] = "No'ku Stormsayer",
		[51510] = 3,
		[111715] = "Scholomance Neophyte",
		[26013] = 2,
		[135361] = "Dam'ren",
		[121442] = "Wing Leader Ner'onok",
		[9232] = "High Inquisitor Whitemane",
		[123490] = "Enslaved Bonesmasher",
		[115811] = 2,
		[83559] = 3,
		[116835] = "[*] Devastating Arc",
		[137410] = "Suen",
		[119395] = 7,
		[119907] = 9,
		[134339] = 7,
		[121443] = "Wing Leader Ner'onok",
		[40504] = "Razorlash",
		[132292] = 6,
		[92263] = 11,
		[29341] = 9,
		[132293] = 10,
		[52535] = "Anub'ar Shadowcaster",
		[113765] = "Rattlegore",
		[139461] = "Spirit Flayer",
		[132294] = 10,
		[46392] = "Villainous",
		[137414] = "Suen",
		[55095] = 6,
		[86121] = "Vilkacens",
		[113766] = "Brother Korloff",
		[114790] = 9,
		[132296] = 6,
		[17439] = "Black Guard Sentry",
		[132297] = 10,
		[137417] = "[*] Flames of Passion",
		[122470] = 11,
		[36922] = "Spinestalker",
		[132298] = 10,
		[110696] = 10,
		[55608] = "Unrelenting Rider",
		[119911] = 9,
		[28062] = 7,
		[121447] = "Wing Leader Ner'onok",
		[137419] = "Suen",
		[73325] = "Lightwell",
		[139467] = "[*] Lightning Fissure",
		[123495] = "Garalon",
		[124007] = "Xuen <Trekeenbak>",
		[124519] = 7,
		[58936] = "Onyx Blaze Mistress",
		[139468] = "No'ku Stormsayer",
		[71278] = "[*] Choking Gas",
		[88684] = "Lightwell",
		[15248] = "Riverpaw Looter",
		[22559] = "Blue Drakonid",
		[22687] = "Nefarian",
		[115817] = 2,
		[116841] = 11,
		[46394] = "[*] Burn",
		[23455] = 5,
		[139470] = "[*] Choking Gas",
		[55609] = "Unrelenting Rider",
		[119913] = 9,
		[71279] = "[*] Choking Gas Explosion",
		[16144] = "Rage Talon Fire Tongue",
		[121449] = 9,
		[137423] = "[*] Focused Lightning",
		[114282] = 10,
		[140495] = "[*] Lingering Gaze",
		[124009] = "Xuen <Trekeenbak>",
		[116330] = 11,
		[125033] = 11,
		[93805] = 9,
		[51514] = 7,
		[111723] = "Raigonn",
		[120938] = "Resin Flake",
		[88686] = "Lightwell",
		[122474] = "Imperial Vizier Zor'lok",
		[115307] = 11,
		[93806] = 3,
		[110700] = 10,
		[55610] = 6,
		[119915] = 9,
		[65081] = 5,
		[122475] = 1,
		[123499] = "Set'thik Fanatic",
		[5225] = 10,
		[116844] = 11,
		[163025] = 9,
		[110701] = 10,
		[30111] = "Plague Beast",
		[138453] = "Anima Golem",
		[53563] = 2,
		[140502] = "[*] Eye Sore",
		[64058] = 5,
		[128620] = 7,
		[12177] = 3,
		[115310] = 11,
		[17057] = 10,
		[117870] = "Celestial Protector",
		[25504] = 7,
		[111215] = "Armsmaster Harlan",
		[52540] = "Anub'ar Skirmisher",
		[137433] = 11,
		[107120] = "Commander Ri'mok",
		[45885] = "[*] Shadow Spike",
		[116847] = 11,
		[100977] = 10,
		[38462] = "Unknown",
		[38718] = "Underbog Colossus",
		[118895] = 1,
		[111216] = "Armsmaster Harlan",
		[19873] = "Razorgore the Untamed <Wafty>",
		[122479] = "Imperial Vizier Zor'lok",
		[114800] = 9,
		[107121] = "Commander Ri'mok",
		[125551] = 5,
		[58940] = "Onyx Blaze Mistress",
		[93811] = 6,
		[102514] = 5,
		[111217] = "Armsmaster Harlan",
		[70774] = 9,
		[79477] = 1,
		[136413] = "Mind's Eye",
		[22433] = "Death Talon Seether",
		[22561] = "Green Drakonid",
		[123504] = "Dissonance Field",
		[7753] = 2,
		[134366] = "Ji-Kun",
		[116849] = 11,
		[145629] = 6,
		[111218] = "Armsmaster Harlan",
		[134367] = "Hatchling",
		[115314] = 2,
		[124529] = 5,
		[126577] = 10,
		[110707] = 10,
		[119922] = "Kuai the Brute",
		[120946] = "Sik'thik Amber-Weaver",
		[44863] = "Lord Sanguinar",
		[122994] = "Instructor Maltik",
		[115315] = 11,
		[124018] = "Imperial Vizier Zor'lok",
		[134370] = "Ji-Kun",
		[125554] = 5,
		[137442] = 11,
		[110708] = 10,
		[111220] = "Armsmaster Harlan",
		[70777] = 3,
		[142562] = "Viletongue Decimator",
		[71801] = "Nerub'ar Champion",
		[113780] = 4,
		[138467] = "Durumu the Forgotten",
		[2565] = 1,
		[28833] = "Lady Blaumeux",
		[115828] = "Jasper Guardian",
		[2645] = 7,
		[58942] = "Onyx Brood General",
		[69242] = "Raging Spirit",
		[111221] = "Armsmaster Harlan",
		[87160] = 5,
		[60478] = 9,
		[113269] = 2,
		[114805] = "Xiang",
		[115317] = 1,
		[115829] = "Amethyst Guardian",
		[124532] = 1,
		[93816] = 8,
		[70779] = 3,
		[134375] = "Ji-Kun",
		[32289] = 7,
		[3045] = 3,
		[12626] = "Patchwork Horror",
		[119414] = "Sha of Fear",
		[111735] = "Tar",
		[120438] = "Dread Spawn <[*] Conjure Dread Spawn>",
		[145640] = 11,
		[122998] = 8,
		[115831] = "Dagatik",
		[126582] = 2,
		[139498] = "Corpse Spider",
		[119415] = 8,
		[71805] = "Stinky",
		[105593] = 2,
		[122999] = 8,
		[115832] = "Dagatik",
		[134380] = "Ji-Kun",
		[117368] = 11,
		[137452] = 10,
		[43330] = "Anub'ar Necromancer",
		[35395] = 2,
		[134381] = "Ji-Kun",
		[45122] = "Kalecgos",
		[23331] = "Broodlord Lashlayer",
		[118905] = "Lightning Surge Totem <Bappen>",
		[119929] = "Kuai the Brute",
		[134383] = 7,
		[56641] = 3,
		[32546] = 5,
		[139503] = "Archritualist Kelada",
		[115834] = 4,
		[116858] = 9,
		[50498] = "Raptor <Ninjqke>",
		[138480] = "Large Anima Golem",
		[110715] = 10,
		[119930] = "Kuai the Brute",
		[120954] = 11,
		[44867] = 7,
		[114811] = "The Talking Fish",
		[125050] = 3,
		[137458] = "Horridon",
		[119931] = "Kuai the Brute",
		[120955] = "Resin Shell",
		[121467] = 2,
		[48707] = 6,
		[28835] = "Sir Zeliek",
		[137460] = 11,
		[139508] = "No'ku Stormsayer",
		[119932] = "Kuai the Brute",
		[129147] = 7,
		[137461] = 11,
		[138485] = "Crimson Wake <Large Anima Golem>",
		[45124] = 1,
		[91776] = "Risen Ally <Smokeppc>",
		[126588] = 11,
		[110718] = 10,
		[119933] = "Kuai the Brute",
		[56131] = 5,
		[12051] = 8,
		[121981] = "Sik'thik Demolisher",
		[75907] = "Naz'jar Honor Guard",
		[125565] = 1,
		[58947] = "Onyx Sanctum Guardian",
		[93825] = 9,
		[121982] = "Sik'thik Demolisher",
		[106112] = "Figment of Doubt",
		[91778] = "Corpsestalker <Manatees>",
		[135418] = 8,
		[86659] = 2,
		[14099] = "Magistrate Barthilas",
		[121471] = 4,
		[113792] = "Psyfiend <Lexyrus>",
		[106113] = "Sha of Doubt",
		[115840] = "Cobalt Guardian",
		[58180] = 10,
		[93827] = 3,
		[69766] = 2,
		[134397] = "Gastropod",
		[44614] = 8,
		[122496] = "Imperial Vizier Zor'lok",
		[53317] = "Anub'ar Champion",
		[83077] = 3,
		[134398] = "[*] Slime Trail",
		[23333] = 1,
		[93828] = 6,
		[87173] = 2,
		[8042] = 7,
		[32292] = 9,
		[121473] = 4,
		[122497] = "Imperial Vizier Zor'lok",
		[49222] = 6,
		[115842] = "Jade Guardian",
		[60229] = 6,
		[121474] = 4,
		[53318] = "Anub'ar Crusher",
		[107140] = "Azure Serpent",
		[115843] = "Jasper Guardian",
		[38728] = "Novice Astromancer",
		[86663] = 1,
		[19750] = 2,
		[120451] = 9,
		[56646] = "Enraged Fire Elemental",
		[123011] = "Embodied Terror",
		[115844] = "Amethyst Guardian",
		[99974] = "Cinderweb Drone",
		[34121] = "Al'ar",
		[34889] = "cHoNGuS <Chimi>",
		[123012] = "Embodied Terror",
		[99463] = "Cinderweb Drone",
		[84617] = 4,
		[23462] = "Vaelastrasz the Corrupt",
		[118917] = "Glintrok Hexxer",
		[119941] = "Sap Puddle",
		[120453] = "[*] Conjure Dread Spawn",
		[113286] = 7,
		[98440] = "Ronttix",
		[66188] = 6,
		[99464] = "Alysrazor",
		[126597] = 2,
		[45129] = 5,
		[84619] = 1,
		[117895] = 11,
		[111240] = 4,
		[111752] = "Scholomance Neophyte",
		[120455] = "Sha of Fear",
		[113288] = 7,
		[145674] = 1,
		[126599] = 6,
		[132365] = 2,
		[136461] = 7,
		[122504] = "[*] Burning Amber",
		[107146] = "Raigonn",
		[124040] = 11,
		[15572] = "Dragonflayer Metalworker",
		[38219] = "Hydross the Unstable",
		[145677] = 6,
		[110730] = 10,
		[86669] = 2,
		[134415] = "Gastropod",
		[136463] = "Amani Warbear",
		[114826] = "The Songbird Queen",
		[124041] = 11,
		[108683] = 9,
		[58953] = "Onyx Flight Captain",
		[118922] = 3,
		[119946] = "Mu'Shiba",
		[52042] = 7,
		[35916] = "Astromancer",
		[88718] = 7,
		[121994] = "Amber-Shaper Un'sok",
		[53322] = "Anub'ar Crypt Fiend",
		[116363] = "Feng the Accursed",
		[38220] = "Hydross the Unstable",
		[38732] = "Astromancer Lord",
		[127626] = 5,
		[121995] = "Amber-Shaper Un'sok",
		[116364] = "Feng the Accursed",
		[108685] = 9,
		[137492] = "Suen",
		[119948] = "Mu'Shiba",
		[60234] = 10,
		[121484] = "Grooka Grooka",
		[61258] = 6,
		[147732] = 7,
		[116365] = "Feng the Accursed",
		[108686] = 9,
		[46668] = 1,
		[38733] = "Astromancer Lord",
		[102543] = 10,
		[127628] = 5,
		[119949] = "Mu'Shiba",
		[1499] = 3,
		[32295] = 1,
		[1539] = 3,
		[16553] = "Ghoul Ravener",
		[125069] = "Amber-Ridden Mushan",
		[126605] = 9,
		[127629] = "Greater Fire Elemental <Lightofdawn>",
		[113295] = 9,
		[130701] = "Sha of Violence",
		[13589] = "Anvilrage Overseer",
		[125582] = "Cloudbender Kobo",
		[1715] = 1,
		[126606] = 5,
		[102545] = 10,
		[127630] = "Mogu'shan Arcanist",
		[64843] = 5,
		[105617] = 8,
		[66198] = 6,
		[115856] = 2,
		[125071] = 11,
		[139548] = "Megaera",
		[51533] = 7,
		[119952] = 2,
		[71318] = "Frostwarden Sorceress",
		[113809] = "Wander's Colossal Book of Shadow Puppets",
		[139549] = "Megaera",
		[45902] = 6,
		[125072] = "Amber-Ridden Mushan",
		[136478] = "Lei Shen",
		[117905] = "Minion of Fear",
		[102547] = 10,
		[127632] = 5,
		[111762] = "Scholomance Neophyte",
		[32296] = 7,
		[64844] = 5,
		[56909] = "Sartharion",
		[139551] = "Megaera",
		[57933] = 4,
		[91797] = "Corpsestalker <Manatees>",
		[136480] = "Amani'shi Beast Shaman",
		[131361] = 7,
		[86678] = 2,
		[71320] = "Frostwarden Sorceress",
		[17962] = 9,
		[137507] = "[*] Implosion",
		[89751] = "Orikkilig <Demontime>",
		[131364] = 7,
		[57934] = 4,
		[10966] = "Noxxion",
		[122516] = 2,
		[106646] = "Flying Snow",
		[115861] = "Cobalt Guardian",
		[91800] = "Corpsestalker <Manatees>",
		[46160] = "Shadowsword Berserker",
		[23338] = 8,
		[118421] = "Shadowy Minion",
		[71323] = "Frostblade <Frostwarden Warrior>",
		[32297] = 7,
		[136487] = "Amani'shi Beast Shaman",
		[122005] = "[*] Molten Amber",
		[89753] = "Orikkilig <Demontime>",
		[16427] = "Crypt Beast",
		[115350] = "Lilian's Soul",
		[3110] = "Lazgup <Ravenppc>",
		[116374] = "Lightning Charge",
		[50256] = "熊 <Cunabe>",
		[34130] = 9,
		[117910] = "Qiang the Merciless",
		[119446] = "Sha of Anger",
		[87194] = 5,
		[136489] = "Lightning Nova Totem <Amani'shi Beast Shaman>",
		[138537] = "Fallen Zandalari <Deryn>",
		[106648] = "Rolling Barrel",
		[91802] = "Corpsestalker <Manatees>",
		[136490] = "Lightning Nova Totem <Amani'shi Beast Shaman>",
		[117911] = "Celestial Protector",
		[110744] = 5,
		[71325] = "Frostwarden Warrior",
		[48721] = 6,
		[114328] = 9,
		[3606] = "Searing Totem <Wafty>",
		[33619] = 5,
		[116888] = 6,
		[117912] = "Celestial Protector",
		[69278] = "Festergut",
		[110745] = 5,
		[71326] = "Nerub'ar Webweaver",
		[114329] = 9,
		[123032] = 3,
		[23339] = "Firemaw",
		[38995] = "Greyheart Technician",
		[71327] = "Nerub'ar Webweaver",
		[129176] = 5,
		[113306] = 11,
		[122009] = "Unga Keg-Blocker",
		[106651] = "Ook-Ook",
		[33876] = 10,
		[8599] = "Plague Ghoul",
		[119450] = 3,
		[111771] = 9,
		[122010] = "Unga Keg-Blocker",
		[53330] = "Anub'ar Crypt Fiend",
		[132402] = 10,
		[115867] = 11,
		[136498] = "Iron Qon's Spear <Iron Qon>",
		[77472] = 7,
		[132403] = 2,
		[111772] = "Scholomance Acolyte",
		[129178] = "Yang Guoshi",
		[28459] = "Soul Weaver",
		[106653] = "Corrupt Living Water",
		[132404] = 1,
		[91807] = "Corpsestalker <Manatees>",
		[50259] = 10,
		[34133] = "Ember of Al'ar",
		[146739] = 9,
		[118940] = "Glintrok Oracle",
		[71330] = "Frostwarden Sorceress",
		[123036] = "Fright Spawn",
		[115357] = 7,
		[5740] = 9,
		[63058] = 10,
		[126620] = "Onyx Stormclaw",
		[140598] = "Mysterious Mushroom",
		[16429] = "Thuzadin Shadowcaster",
		[33110] = 5,
		[91809] = "Corpsestalker <Manatees>",
		[33878] = 10,
		[101024] = 10,
		[117918] = "Flanking Mogu",
		[102560] = 10,
		[140600] = "Cavern Burrower",
		[111775] = "Lilian Voss",
		[6572] = 1,
		[130205] = "Unga Rocket Surgeon",
		[106656] = "Fire Flower <Shado-Pan Novice>",
		[75428] = "Rom'ogg Bonecrusher",
		[54356] = "Stitched Colossus",
		[137530] = 9,
		[132411] = 9,
		[136507] = "Frost King Malakk",
		[28460] = "Soul Weaver",
		[122527] = "Lesser Sha",
		[114848] = "High Inquisitor Whitemane",
		[115360] = 7,
		[117920] = "Qiang the Merciless",
		[132413] = 9,
		[87204] = 7,
		[122016] = 1,
		[123040] = 5,
		[108194] = 6,
		[23341] = "Firemaw",
		[77478] = 7,
		[56405] = "Gothik the Harvester",
		[48982] = 6,
		[16430] = "Thuzadin Necromancer",
		[66216] = 6,
		[50518] = "CeCe <Bangter>",
		[88742] = 1,
		[89766] = "Vinikilig <Amalanar>",
		[114851] = 6,
		[108196] = 6,
		[38232] = "Dragonflayer Overseer",
		[71337] = "Frostwarden Handler",
		[113828] = 10,
		[114852] = 2,
		[125091] = 7,
		[126115] = "Shado-Pan Ice Archer",
		[122532] = "Living Amber",
		[107174] = 2,
		[115877] = "Apex <Minmaxer>",
		[134470] = "Bow Fly Swarm",
		[125092] = "Enormous Stone Quilen",
		[23214] = 2,
		[46680] = "Kil'jaeden",
		[85673] = 2,
		[127140] = 8,
		[128164] = 7,
		[47960] = 9,
		[56407] = "Spectral Trainee",
		[89769] = "Mining Powder",
		[73899] = 7,
		[134472] = "Bow Fly Swarm",
		[125093] = "[*] Amber Spray",
		[136520] = "Iron Qon's Spear <Iron Qon>",
		[34650] = "Shadowfiend <Maible>",
		[25646] = "Gluth",
		[86698] = 2,
		[129189] = "[*] Sha Globe",
		[136521] = "Sul the Sandcrawler",
		[18223] = 9,
		[138569] = "Massive Anima Golem",
		[107176] = "Inflamed Hozen Brawler",
		[108200] = 6,
		[101033] = 7,
		[101545] = 11,
		[19503] = 3,
		[140618] = "Cavern Burrower",
		[119975] = 6,
		[56408] = "Spectral Death Knight",
		[88747] = 10,
		[20271] = 2,
		[139595] = 11,
		[140619] = "Cavern Burrower",
		[134476] = "Rockfall",
		[126119] = 11,
		[86700] = 2,
		[21807] = "Wily Woodling",
		[134477] = "Orikkilig <Demontime>",
		[15128] = "Firebrand Pyromancer",
		[131406] = 1,
		[22703] = 9,
		[124072] = "Set'thik Gustwing",
		[125096] = "Enormous Stone Quilen",
		[38491] = "Coilfang Hate-Screamer",
		[81070] = 10,
		[117418] = 11,
		[102060] = 1,
		[102572] = "Azure Serpent",
		[8921] = 10,
		[123050] = "Mindbender <Tellios>",
		[53850] = "Naxxramas Cultist",
		[84655] = 1,
		[126122] = "Dissonance Field",
		[102573] = "Azure Serpent",
		[140626] = "Fungal Growth",
		[88751] = 10,
		[89775] = 4,
		[123051] = "Mindbender <Tellios>",
		[75441] = "Unknown",
		[100526] = "Flamewaker Subjugator",
		[77489] = "Lightwell",
		[86704] = 2,
		[119980] = 6,
		[122540] = "Amber Monstrosity",
		[140629] = "Eternal Guardian",
		[23600] = "Bored Student",
		[140630] = "Eternal Guardian",
		[119981] = "Ming the Cunning",
		[124077] = "Set'thik Windblade",
		[118958] = "Glintrok Ironhide",
		[129197] = 5,
		[114863] = "[*] Exploding Shot",
		[84147] = "Scarlet Myrmidon",
		[137562] = 11,
		[19505] = "Droodrom <Caries>",
		[119983] = "Yang Guoshi",
		[80564] = "Lady Naz'jar",
		[114864] = "Bored Student",
		[21169] = 7,
		[34655] = 3,
		[118960] = "Glintrok Ironhide",
		[140636] = "Farraki Sand Conjurer",
		[59996] = 11,
		[129711] = "Celestial Protector",
		[122032] = 2,
		[130735] = 6,
		[45150] = "Brutallus",
		[124080] = "Set'thik Windblade",
		[126640] = 10,
		[118961] = "Master Snowdrift",
		[55645] = "Unrelenting Trainee",
		[119985] = 7,
		[136543] = "Lei Shen",
		[65116] = 3,
		[130736] = 6,
		[114866] = 6,
		[107187] = "Saboteur Kip'tilak",
		[124081] = 11,
		[108211] = 4,
		[140640] = "Nest Guardian",
		[72376] = "The Lich King",
		[122034] = "Shek'zeer Clutch-Keeper",
		[114867] = 6,
		[108212] = 4,
		[38496] = "Coilfang Hate-Screamer",
		[118963] = "Unknown",
		[27825] = "Unrelenting Death Knight",
		[97462] = 1,
		[122547] = "Amber-Shaper Un'sok",
		[123059] = 2,
		[76473] = "Twilight Flame Caller",
		[119476] = "General Pa'valak",
		[137573] = 4,
		[123060] = 2,
		[66235] = 2,
		[93368] = 3,
		[31665] = 4,
		[127156] = 7,
		[2983] = 4,
		[124085] = "Set'thik Zephyrian",
		[108215] = 4,
		[34914] = 5,
		[25778] = "Void Reaver",
		[114871] = 2,
		[53600] = 2,
		[37730] = "Morogrim Tidewalker",
		[46177] = "M'uru",
		[68285] = 10,
		[126646] = 2,
		[127158] = 7,
		[128182] = "Totem of Harmony",
		[56160] = 5,
		[114872] = "Bored Student",
		[33891] = 10,
		[126135] = 5,
		[85692] = "Doomguard <Caries>",
		[111801] = "Unknown",
		[3815] = "Aku'mai",
		[114873] = "Professor Slate",
		[45666] = "Kalecgos",
		[134510] = "Corpse Spider",
		[116921] = 4,
		[23219] = 1,
		[68799] = "Apothecary Frye",
		[132463] = 11,
		[88765] = 7,
		[138607] = "Amani'shi Flame Chanter",
		[123065] = 7,
		[132464] = 7,
		[124089] = "[*] Zephyr",
		[91837] = "Blightcatcher <Deryn>",
		[50274] = "Spellhaste <Nim>",
		[137584] = 4,
		[126649] = 4,
		[137585] = 4,
		[138609] = "Massive Anima Golem",
		[73920] = 7,
		[132466] = "Thalnos the Soulrender",
		[54114] = 3,
		[125626] = "Storm Cloud <Cloudbender Kobo>",
		[137586] = 4,
		[46947] = 1,
		[27827] = 5,
		[88767] = 7,
		[28467] = "Unstoppable Abomination",
		[73921] = 7,
		[136564] = "Drakkari Frozen Warlord",
		[117948] = "Qiang the Merciless",
		[69826] = 2,
		[339] = 10,
		[119996] = 11,
		[35941] = "Kael'thas Sunstrider",
		[122556] = "Amber-Shaper Un'sok",
		[36965] = "Thaladred the Darkener",
		[74434] = 9,
		[137590] = 8,
		[103103] = 9,
		[379] = 7,
		[101568] = 6,
		[25780] = 2,
		[137593] = 2,
		[36966] = "Thaladred the Darkener",
		[107200] = 2,
		[421] = 7,
		[109248] = 3,
		[13787] = "Skeletal Guardian",
		[147833] = 1,
		[119487] = "Sha of Anger",
		[70853] = "Professor Putricide",
		[441] = 10,
		[113344] = 1,
		[73413] = 5,
		[75973] = 2,
		[117952] = 11,
		[34919] = 5,
		[148859] = 5,
		[128191] = 3,
		[112833] = 5,
		[121536] = 5,
		[137597] = 11,
		[107202] = "[*] Invoke Lightning",
		[116417] = "Feng the Accursed",
		[23221] = 1,
		[118977] = 3,
		[119489] = "Sha of Anger",
		[113858] = 9,
		[90309] = 3,
		[107203] = 10,
		[124097] = 3,
		[76487] = "Twilight Torturer",
		[117954] = "Elegon",
		[126657] = 1,
		[546] = 7,
		[86726] = "Randolph Moloch",
		[136577] = "[*] Wind Storm",
		[113859] = "[*] Arcane Bomb",
		[123586] = 11,
		[124098] = 11,
		[117955] = "[*] Expelled Corruption",
		[110788] = 10,
		[86727] = "Randolph Moloch",
		[71369] = "Spinestalker",
		[88263] = 2,
		[113860] = "Zimlock",
		[123075] = 7,
		[140675] = "Spirit Gaze",
		[142723] = 5,
		[126659] = 9,
		[70346] = "Growing Ooze Puddle <Professor Putricide>",
		[111813] = "Unknown",
		[686] = 9,
		[113861] = 9,
		[53351] = 3,
		[710] = 9,
		[118469] = "Gara'jal the Spiritbinder",
		[70859] = 9,
		[128708] = "Bubbling Brew Alemental",
		[113862] = 8,
		[130756] = "Dissonance Field",
		[114886] = "[*] Frigid Grasp",
		[774] = 10,
		[124101] = 11,
		[118470] = 7,
		[131465] = 2,
		[104136] = 9,
		[818] = 2,
		[18103] = "Doctor Theolen Krastinov",
		[115399] = 11,
		[115911] = 10,
		[125638] = "Heart of Fear",
		[127174] = 1,
		[140682] = "Mist Lurker",
		[120519] = "Sha of Fear",
		[136587] = "Gurubashi Venom Priest",
		[122055] = 3,
		[99530] = "Molten Lord",
		[116936] = 11,
		[58984] = 10,
		[118472] = 7,
		[59752] = 1,
		[35947] = "Bloodwarder Legionnaire",
		[53353] = 3,
		[140685] = "Mist Lurker",
		[134542] = 7,
		[116937] = 11,
		[46442] = "Shadowsword Soulbinder",
		[117961] = "Qiang the Merciless",
		[118473] = 7,
		[127176] = 7,
		[140686] = "Mist Lurker",
		[32182] = 7,
		[24375] = "Death Talon Wyrmguard",
		[1022] = 2,
		[123081] = "[*] Pungency",
		[8349] = 7,
		[109259] = 3,
		[117962] = 11,
		[126665] = 1,
		[17464] = 8,
		[71376] = "Rimefang",
		[35948] = "Bloodwarder Marshal",
		[52586] = "Krik'thir the Gatewatcher",
		[138641] = 11,
		[91342] = 6,
		[109260] = 3,
		[126154] = "Lightwell",
		[138642] = 11,
		[71377] = "Rimefang",
		[112844] = "Corpse Spider",
		[137619] = 4,
		[138643] = 10,
		[109773] = 9,
		[138644] = "Dark Animus",
		[118988] = "Gekkan",
		[119500] = "Jokui <Jokui>",
		[5487] = 10,
		[35949] = "Bloodwarder Marshal",
		[114893] = 7,
		[108238] = 10,
		[100559] = "Majordomo Staghelm",
		[38253] = "Tainted Elemental",
		[38509] = "Lady Vashj",
		[47468] = "Hammerbasher <Antipaladin>",
		[107215] = "Mantid Munitions",
		[116942] = "Feng the Accursed",
		[51052] = 6,
		[17465] = 3,
		[86738] = "Vicious Thug",
		[25912] = 2,
		[13341] = "Enraged Fire Elemental",
		[74964] = 7,
		[116943] = "Earthgrab Totem <Wafty>",
		[125646] = 1,
		[6991] = 3,
		[71893] = "Professor Putricide",
		[20153] = "Infernal <Caries>",
		[105681] = 2,
		[138651] = "Amani'shi Flame Chanter",
		[114896] = 7,
		[99538] = "Molten Lord",
		[50285] = "Tallstrider <Shiro>",
		[138652] = "Amani'shi Flame Chanter",
		[86740] = "Rowdy Troublemaker",
		[105682] = 4,
		[115921] = 11,
		[110802] = 10,
		[135583] = "[*] Rushing Winds",
		[8143] = 7,
		[114386] = "Yan-Zhu the Uncasked",
		[8222] = 9,
		[116434] = 5,
		[2120] = 8,
		[2136] = 8,
		[110803] = 10,
		[26297] = 7,
		[137633] = "Humming Crystal",
		[65753] = 1,
		[91350] = "Geyser",
		[116947] = "Earthgrab Totem <Wafty>",
		[19386] = 3,
		[110804] = 10,
		[28089] = "Thaddius",
		[20154] = 2,
		[138659] = "Dark Animus",
		[2584] = 1,
		[75993] = "[*] Lightning Surge",
		[131493] = 9,
		[71386] = "Rimefang",
		[105174] = 9,
		[137637] = 1,
		[22458] = "Blackwing Taskmaster",
		[123092] = "[*] Pheromones",
		[22842] = 10,
		[31289] = "The Nodding Tiger",
		[125652] = "Parasitoid Sha",
		[93400] = 10,
		[110806] = 10,
		[71387] = "Rimefang",
		[121557] = 5,
		[137639] = 11,
		[98008] = 7,
		[107223] = "Sun",
		[16827] = "Cat <Brag>",
		[50288] = 10,
		[34162] = "Void Reaver",
		[110807] = 10,
		[25914] = 2,
		[137641] = "[*] Soul Fragment",
		[61295] = 7,
		[115927] = 3,
		[100057] = "Hell Hound",
		[76508] = "Crazed Mage",
		[93402] = 10,
		[19643] = "Alliance Peacekeeper",
		[105689] = 3,
		[130774] = "Amethyst Guardian",
		[28730] = 5,
		[33395] = "水元素 <Dreckit>",
		[136620] = "Ball Lightning <Lei Shen>",
		[126679] = 1,
		[137645] = "Gara'jal's Soul",
		[36979] = "Netherstrand Longbow",
		[53617] = "Anub'ar Venomancer",
		[75998] = "Naz'jar Honor Guard",
		[38259] = "Coilfang Strider",
		[39027] = "Greyheart Tidecaller",
		[119513] = "Mounted Mogu",
		[105691] = 10,
		[82654] = 3,
		[124121] = 5,
		[100060] = "Flamewaker Cauterizer",
		[34164] = "Void Reaver",
		[77535] = 6,
		[119514] = "Mounted Mogu",
		[135601] = 10,
		[36980] = "Netherstrand Longbow",
		[140721] = 9,
		[38260] = "Coilfang Elite",
		[38516] = "Unknown",
		[110300] = 2,
		[111324] = "Scarlet Defender",
		[141746] = "Viletongue Raider",
		[105693] = 5,
		[114908] = 5,
		[116956] = 7,
		[126683] = 8,
		[52339] = "Battleground Demolisher <Yon>",
		[36213] = "Greater Earth Elemental <Illidian>",
		[105694] = 10,
		[36981] = "Devastation",
		[22972] = "Nefarian",
		[76002] = "Karsh Steelbender",
		[54643] = 10,
		[137654] = "[*] Rushing Winds",
		[138678] = "Unknown",
		[31803] = 2,
		[47476] = 6,
		[90337] = "Monkey",
		[115422] = 9,
		[99552] = "Molten Lord",
		[105696] = 6,
		[114911] = 7,
		[136634] = 3,
		[119519] = "Sha of Fear",
		[134587] = "Blue Eye",
		[71909] = 9,
		[105697] = 7,
		[20925] = 2,
		[120032] = 7,
		[105698] = 11,
		[53365] = 6,
		[99555] = "Molten Lord",
		[112866] = 9,
		[137663] = "[*] Acidic Splash",
		[138687] = "Glacial Freeze Totem <Drakkari Frost Warden>",
		[117986] = "Protector Kaolan",
		[138688] = "[*] Tidal Force",
		[131521] = "Taran Zhu",
		[52086] = "Watcher Silthik",
		[112867] = "Zimlock",
		[98021] = 7,
		[131522] = "Taran Zhu",
		[76008] = "Lady Naz'jar",
		[76520] = "Gilgoblin Hunter",
		[68841] = "Apothecary Frye",
		[138690] = "Drakkari Frost Warden",
		[131523] = 11,
		[119523] = 7,
		[111844] = 11,
		[112868] = 9,
		[48503] = 10,
		[105701] = 5,
		[114404] = "Void Tendril <Maible>",
		[114916] = 2,
		[100070] = "Blazing Monstrosity",
		[135620] = "Zeb'tula Stoneshield",
		[125667] = 1,
		[117988] = "[*] Defiled Ground",
		[110309] = 10,
		[34937] = "Crystalcore Devastator",
		[119524] = "Mogu Archer",
		[70890] = 6,
		[52087] = 9,
		[112869] = 9,
		[105702] = 9,
		[138693] = "Gurubashi Berserker",
		[131526] = 1,
		[22718] = 1,
		[100071] = "Blazing Monstrosity",
		[76522] = "Evolved Twilight Zealot",
		[110310] = 1,
		[119525] = "Mogu Archer",
		[112870] = 9,
		[48504] = 10,
		[49016] = 6,
		[114918] = "Light's Hammer <Smashval>",
		[141767] = "Viletongue Raider",
		[16959] = 10,
		[84714] = 8,
		[120038] = 9,
		[129253] = 5,
		[105704] = 3,
		[114919] = 2,
		[141769] = "Viletongue Raider",
		[46457] = "Shadowsword Manafiend",
		[19263] = 3,
		[85739] = 1,
		[47481] = "Corpseleaper <Pogmog>",
		[105193] = 3,
		[28478] = "Kel'Thuzad",
		[138699] = 3,
		[141771] = "Viletongue Decimator",
		[100074] = "Blazing Monstrosity",
		[127207] = 1,
		[128231] = "Scarlet Myrmidon",
		[136653] = "Gurubashi Bloodlord",
		[105706] = 6,
		[22719] = 6,
		[22975] = "Nefarian",
		[116969] = "Qin-xi",
		[136654] = "Gurubashi Bloodlord",
		[117993] = 11,
		[138702] = 1,
		[39035] = "Serpentshrine Tidecaller <Greyheart Tidecaller>",
		[86765] = "Slag Fury",
		[111850] = "Elder Regail",
		[105707] = 10,
		[114410] = "Brother Korloff",
		[57465] = "Sir Zeliek",
		[33660] = 10,
		[116970] = "Stone Quilen",
		[34172] = "Void Reaver",
		[34428] = 1,
		[126697] = 6,
		[128233] = "Scarlet Evangelist",
		[113899] = "Demonic Gateway <Ravenppc>",
		[130793] = "Xuen <Shamkim>",
		[114923] = 8,
		[127722] = 11,
		[120043] = 6,
		[113900] = "Demonic Gateway <Ravenppc>",
		[138707] = 10,
		[114924] = 8,
		[115436] = "Krik'thik Rager",
		[108269] = 7,
		[67826] = 9,
		[94447] = 10,
		[111341] = "Scarlet Scourge Hewer",
		[130283] = 11,
		[114925] = 9,
		[132566] = 9,
		[108270] = 7,
		[117485] = "Emperor's Courage",
		[31551] = "Dragonflayer Heartsplitter",
		[126700] = 1,
		[31935] = 2,
		[111854] = "Instructor Chillheart",
		[49020] = 6,
		[57723] = 7,
		[108271] = 7,
		[116974] = "Stone Quilen",
		[6353] = 9,
		[112879] = 1,
		[13281] = "Twilight Elementalist",
		[114927] = "Gu Cloudstrike",
		[55164] = 7,
		[131547] = 6,
		[86771] = "Rumbling Earth",
		[128238] = "Gurthan Swiftblade",
		[129262] = "Gekkan",
		[88819] = 2,
		[81140] = 7,
		[57724] = 7,
		[108273] = 7,
		[125167] = 3,
		[118000] = 1,
		[128239] = "Gurthan Swiftblade",
		[120560] = "Gurthan Iron Maw",
		[130287] = "Apex <Minmaxer>",
		[123120] = "[*] Pheromone Trail",
		[22721] = 3,
		[133598] = 2,
		[22977] = "Nefarian",
		[116977] = "Stone Quilen",
		[136670] = "Drakkari Frozen Warlord",
		[8017] = 7,
		[113394] = "Strife",
		[65148] = 2,
		[8177] = 7,
		[123121] = "Lei Shi",
		[76535] = "Gilgoblin Aquamage",
		[126705] = 9,
		[120562] = "Harthak Stormcaller",
		[106228] = "[*] Nothingness",
		[18498] = 1,
		[134626] = "Durumu the Forgotten",
		[108788] = 11,
		[69369] = 10,
		[111348] = "Scarlet Scourge Hewer",
		[28865] = "Unknown",
		[134628] = "Ro'shak",
		[116980] = "Stone Quilen",
		[2649] = "Apex <Minmaxer>",
		[34433] = 5,
		[138724] = 5,
		[120052] = "Batu",
		[131558] = 7,
		[62078] = 10,
		[22978] = "Nefarian",
		[64382] = 1,
		[90361] = 3,
		[116982] = "Stone Quilen",
		[126709] = "Shan'ze Serpentbinder",
		[17475] = "Lord Aurius Rivendare",
		[111351] = "Scarlet Scourge Hewer",
		[43649] = "Dalronn the Controller",
		[45185] = "Brutallus",
		[108280] = 7,
		[109304] = 3,
		[137706] = 9,
		[119031] = 11,
		[23238] = 5,
		[127177] = 1,
		[115194] = 4,
		[122103] = "Brew Defender",
		[138691] = "Dark Animus",
		[73981] = 4,
		[139537] = "Dark Animus",
		[57984] = "Greater Fire Elemental <Bappen>",
		[108281] = 7,
		[50305] = 9,
		[138728] = 11,
		[93435] = 3,
		[138732] = "Jin'rokh the Breaker",
		[119032] = 5,
		[139121] = 4,
		[43650] = "Dalronn the Controller",
		[30146] = 9,
		[136164] = 6,
		[49998] = 6,
		[137709] = "[*] Shatter",
		[81661] = 5,
		[22595] = "Creeping Sludge",
		[45442] = "Kil'jaeden",
		[60118] = 10,
		[22979] = "Nefarian",
		[113901] = 9,
		[46466] = "Shadowsword Lifeshaper",
		[118009] = 6,
		[58875] = 7,
		[131567] = 5,
		[115942] = 1,
		[128248] = "Shado-Pan Ambusher",
		[114661] = 1,
		[137166] = "Kazra'jin",
		[24259] = 9,
		[137614] = "Living Sand",
		[22336] = "Blackwing Warlock",
		[131568] = 2,
		[115450] = 11,
		[8355] = "Bone Construct",
		[136215] = "Primordius",
		[76031] = "Beauty",
		[82174] = 4,
		[126201] = 8,
		[118522] = 7,
		[17476] = "Lord Aurius Rivendare",
		[51586] = "Dragonflayer Spiritualist",
		[128249] = "Scarlet Evoker",
		[136246] = "Primordius",
		[81141] = 6,
		[52610] = 10,
		[84721] = 8,
		[138737] = 4,
		[44799] = "Kalecgos",
		[102355] = 10,
		[11426] = 8,
		[37764] = "Morogrim Tidewalker",
		[76032] = "Beauty",
		[46467] = "Shadowsword Lifeshaper",
		[12544] = "Blackfathom Sea Witch",
		[105421] = 2,
		[127226] = 7,
		[136954] = "Dark Animus",
		[13619] = "Twilight's Hammer Torturer",
		[46021] = 7,
		[142073] = 7,
		[20164] = 2,
		[60782] = 1,
		[138739] = "Farraki Sand Conjurer",
		[54123] = "Maexxna",
		[74497] = 7,
		[37102] = "Crystalcore Devastator",
		[108285] = 7,
		[113855] = "Master Archer",
		[2825] = 7,
		[137716] = "[*] Tidal Force",
		[138740] = "Farraki Sand Conjurer",
		[5394] = 7,
		[51587] = "Dragonflayer Spiritualist",
		[22976] = "Nefarian",
		[44153] = 4,
		[125390] = "Set'thik Windblade",
		[70342] = "Professor Putricide",
		[11327] = 4,
		[5568] = "Ghamoo-Ra",
		[12723] = 1,
		[56674] = "Venom Stalker",
		[120255] = 9,
		[22980] = "Nefarian",
		[116989] = "Empyreal Focus",
		[46468] = "Shadowsword Vanquisher",
		[63106] = 9,
		[138742] = "Farraki Sand Conjurer",
		[86273] = 2,
		[5938] = 4,
		[116606] = "Zandalari Skullcharger",
		[134647] = "Ro'shak",
		[138233] = 11,
		[72451] = "Professor Putricide",
		[70341] = "Professor Putricide",
		[49028] = 6,
		[114942] = 7,
		[132409] = 9,
		[89792] = "Keprik <Amazarak>",
		[108287] = 7,
		[116990] = "Stone Quilen",
		[114874] = "Professor Slate",
		[21562] = 5,
		[111264] = 8,
		[17477] = "Lord Aurius Rivendare",
		[70404] = "Precious",
		[71342] = 9,
		[9791] = "Dragonflayer Bonecrusher",
		[99758] = "Ancient Core Hound",
		[93339] = 4,
		[1120] = 9,
		[45151] = "Greater Earth Elemental <Wafty>",
		[8219] = 1,
		[82691] = 8,
		[126619] = "Onyx Stormclaw",
		[6770] = 4,
		[54096] = "Naxxramas Worshipper",
		[46469] = "Shadowsword Vanquisher",
		[20589] = 1,
		[768] = 10,
		[63619] = "Mindbender <Tellios>",
		[131830] = "[*] Wind Bomb",
		[81297] = 2,
		[128766] = "Shado-Pan Ambusher",
		[121087] = "Cursed Mogu Sculpture",
		[48517] = 10,
		[16496] = "Master Engineer Telonicus",
		[33750] = 7,
		[20549] = 1,
		[82692] = 3,
		[88448] = 9,
		[35781] = "Crystalcore Devastator",
		[35410] = "Al'ar",
		[16278] = 7,
		[63560] = 6,
		[54227] = 3,
		[139772] = "Shan'ze Celestial Shaper",
		[65220] = 11,
		[7068] = "Blackhand Dreadweaver",
		[12470] = "Greater Fire Elemental <Bappen>",
		[112897] = 7,
		[72454] = 6,
		[54861] = 3,
		[61316] = 8,
		[106874] = "[*] Fire Bomb",
		[24379] = 4,
		[133630] = 1,
		[54149] = 2,
		[38023] = "Morogrim Tidewalker",
		[121820] = 9,
		[127663] = 10,
		[7922] = 1,
		[122235] = 11,
		[145138] = 10,
		[47750] = 5,
		[8050] = 7,
		[56453] = 3,
		[48518] = 10,
		[137727] = "Hungry Eye",
		[8178] = 7,
		[123137] = "Unga Brewstealer",
		[123649] = "Kargesh Ribcrusher",
		[119495] = "Sha of Fear",
		[108291] = 10,
		[58501] = 7,
		[117506] = "Zian of the Endless Shadow",
		[28131] = "Patchwerk",
		[77575] = 6,
		[17478] = "Lord Aurius Rivendare",
		[31589] = 8,
		[13877] = 4,
		[246] = "Lady Sarevess",
		[135681] = "Lei Shen",
		[121602] = "Sapfly",
		[72968] = 1,
		[12021] = "Rage Talon Dragonspawn",
		[73680] = 7,
		[107268] = "Saboteur Kip'tilak",
		[76680] = "Twilight Element Warden",
		[108292] = 10,
		[135682] = "Lei Shen",
		[38280] = "Lady Vashj",
		[137730] = "Flaming Head",
		[45002] = "Kalecgos",
		[110852] = "Gu Cloudstrike",
		[17767] = "Korrothion",
		[150017] = "Unknown <Galendrulle>",
		[36936] = 7,
		[48263] = 6,
		[64901] = 5,
		[137731] = "Flaming Head",
		[42223] = 9,
		[28741] = "Maexxna",
		[115460] = 11,
		[115972] = 10,
		[29125] = "Instructor Razuvious",
		[88685] = "Lightwell",
		[136708] = "Sul'lithuz Stonegazer",
		[85256] = 2,
		[138756] = 4,
		[2094] = 4,
		[29893] = 9,
		[95495] = "Defias Cannon",
		[17253] = "Apex <Minmaxer>",
		[23223] = 1,
		[28457] = "Soldier of the Frozen Wastes",
		[104316] = 9,
		[26662] = "Lei Shi",
		[106657] = "Fire Flower <Shado-Pan Novice>",
		[37257] = "Crimson Hand Blood Knight",
		[136010] = "Tortos",
		[22982] = "Nefarian",
		[38025] = "Morogrim Tidewalker",
		[38281] = 7,
		[4987] = 2,
		[12471] = "Fallenroot Hellcaller",
		[94472] = 5,
		[114860] = "Professor Slate",
		[53595] = 2,
		[8435] = "Lady Sarevess",
		[120786] = "Greater Fire Elemental <Wafty>",
		[61294] = 1,
		[81162] = 6,
		[138759] = 6,
		[120458] = "Sha of Fear",
		[2062] = 7,
		[71089] = "Pustulating Horror",
		[134664] = "Ro'shak",
		[104135] = 9,
		[84746] = 4,
		[118022] = 11,
		[138760] = 6,
		[17479] = "Lord Aurius Rivendare",
		[87471] = "Brineshell Snapper",
		[17735] = "Metatrax",
		[53333] = "Anub'ar Necromancer",
		[126667] = "Brewmaster Bo",
		[44425] = 8,
		[122118] = "Shadowy Minion",
		[113764] = "Brother Korloff",
		[131594] = "Viletongue Decimator",
		[123654] = "Ming the Cunning",
		[31842] = 2,
		[138990] = "Jin'rokh the Breaker",
		[52538] = "Anub'ar Skirmisher",
		[84747] = 4,
		[115313] = 11,
		[11392] = 1,
		[63623] = "Spirit Wolf <Wafty>",
		[116694] = 11,
		[47753] = 5,
		[116] = 8,
		[48265] = 6,
		[20167] = 2,
		[85209] = "Elemental Guard",
		[61632] = "Sartharion",
		[120761] = 3,
		[115464] = 11,
		[85710] = "Viletongue Skirmisher",
		[134668] = "Roaming Fog",
		[12880] = 1,
		[113760] = "Fragrant Lotus",
		[15090] = "Firebrand Darkweaver",
		[118] = 8,
		[74906] = "Fire Cyclone",
		[140616] = "Shale Stalker",
		[147405] = 3,
		[38725] = "Apprentice Star Scryer",
		[134990] = "Lei Shen",
		[105226] = 3,
		[97547] = 10,
		[108201] = 6,
		[53385] = 2,
		[698] = 9,
		[38474] = "Coilfang Beast-Tamer",
		[22983] = "Nefarian",
		[46218] = "Volatile Fiend",
		[63685] = 7,
		[101643] = 11,
		[22568] = 10,
		[98444] = 11,
		[140814] = "Waterspout",
		[52537] = 7,
		[69750] = "Unknown",
		[48266] = 6,
		[64904] = 5,
		[48778] = 6,
		[118459] = "Cat <Brag>",
		[114954] = 8,
		[140815] = 5,
		[35546] = 4,
		[138703] = 8,
		[76047] = "Commander Ulthok",
		[117514] = "Undying Shadows",
		[28479] = "Kel'Thuzad",
		[23461] = "Vaelastrasz the Corrupt",
		[17480] = "Lord Aurius Rivendare",
		[132625] = 2,
		[56910] = "Sartharion",
		[974] = 7,
		[117975] = "Protector Kaolan",
		[136018] = "Lesser Diffused Lightning <Ravenppc>",
		[19645] = "Wailing Banshee",
		[1459] = 8,
		[31290] = "Riverpaw Poacher",
		[37260] = "Crimson Hand Blood Knight",
		[123254] = 5,
		[124682] = 11,
		[38028] = "Morogrim Tidewalker",
		[84751] = 3,
		[126218] = "Shan'ze Serpentbinder",
		[124506] = 11,
		[94463] = 7,
		[132627] = 8,
		[47755] = 5,
		[120587] = 5,
		[54833] = 10,
		[136723] = "[*] Sand Trap",
		[137747] = "Durumu the Forgotten",
		[118253] = 3,
		[114956] = "Stone Quilen",
		[5171] = 4,
		[57994] = 7,
		[102051] = 8,
		[135700] = 10,
		[117516] = "Summit Bonestripper",
		[136366] = "Lei Shen",
		[118540] = "[*] Jade Serpent Wave",
		[10789] = 5,
		[11922] = "Constrictor Vine",
		[106658] = "Fire Flower <Shado-Pan Novice>",
		[30151] = "Orikkilig <Demontime>",
		[28458] = "Soldier of the Frozen Wastes",
		[136725] = "Farraki Wastewalker",
		[147362] = 3,
		[48191] = "Scout Captain Elsia",
		[139797] = "Manchu",
		[130965] = 7,
		[124172] = "Sik'thik Vanguard",
		[22984] = "Nefarian",
		[16867] = "Baroness Anastari",
		[106447] = "Shado-Pan Novice",
		[127575] = 3,
		[31687] = 8,
		[106871] = "Sha of Violence",
		[122741] = "Elegon",
		[120077] = "Batu",
		[59604] = "Dragonflayer Heartsplitter",
		[135703] = "[*] Static Shock",
		[136935] = "Kazra'jin",
		[122125] = "[*] Corrosive Resin Pool",
		[1160] = 1,
		[70351] = "Professor Putricide",
		[107279] = "[*] Engulfing Winds",
		[115982] = "Shadowy Minion",
		[75539] = "Rom'ogg Bonecrusher",
		[1463] = 8,
		[34190] = "[*] Arcane Orb",
		[52534] = "Anub'ar Shadowcaster",
		[36982] = "Devastation",
		[105708] = 11,
		[125871] = "Zar'thik Augurer",
		[40120] = 10,
		[80354] = 8,
		[52364] = 1,
		[46560] = "Sunblade Dusk Priest",
		[136710] = "Risen Drakkari Champion",
		[125426] = "Sra'thik Pool-Tender",
		[45248] = "Lady Sacrolash",
		[37262] = "Crimson Hand Battle Mage",
		[23335] = 1,
		[117667] = 11,
		[114108] = 10,
		[117519] = "Protector Kaolan",
		[13585] = "Smolderthorn Seer",
		[126734] = 9,
		[54844] = 2,
		[111376] = "Scarlet Evangelist",
		[126933] = "Kor'thik Swarmguard",
		[135142] = "[*] Frozen Resilience",
		[86392] = 4,
		[121833] = 6,
		[138658] = "[*] Eruption",
		[136932] = "Mind's Eye",
		[139803] = "Manchu",
		[72429] = "Terenas Menethil",
		[21687] = "Noxxion",
		[113364] = "Flameweaver Koegler",
		[70242] = 1,
		[5185] = 10,
		[138979] = 11,
		[108503] = 9,
		[75] = 3,
		[101976] = "Felguard <Amalanar>",
		[107270] = 11,
		[131978] = "Unknown",
		[52365] = "Skorpionzik",
		[75148] = 2,
		[122128] = 5,
		[98007] = "Unknown <Snowwfall>",
		[115798] = 7,
		[37263] = "Crimson Hand Battle Mage",
		[125870] = "Zar'thik Augurer",
		[124688] = 7,
		[1131] = 3,
		[23241] = 10,
		[76687] = 1,
		[139552] = "Megaera",
		[13376] = "Greater Fire Elemental <Bappen>",
		[6673] = 1,
		[23881] = 1,
		[120593] = "Sap Puddle",
		[19615] = 3,
		[105225] = 3,
		[130320] = 11,
		[18562] = 10,
		[23340] = "Ebonroc",
		[114846] = "Commander Lindon",
		[49806] = "Anub'ar Warrior",
		[75543] = "Rom'ogg Bonecrusher",
		[34946] = "Tempest-Smith",
		[114803] = "Jiang",
		[45029] = "Sathrovarr the Corruptor",
		[137303] = "Blessed Loa Spirit",
		[11366] = 8,
		[3604] = "Deep Pool Threshfin",
		[76663] = 3,
		[79639] = 11,
		[137443] = 11,
		[5277] = 4,
		[122246] = "Sik'thik Engineer",
		[114451] = "Yeasty Brew Alemental",
		[53390] = 7,
		[119888] = "Yang Guoshi",
		[2061] = 5,
		[116499] = 10,
		[45525] = 1,
		[19236] = 5,
		[19658] = "Bragkek",
		[138786] = 9,
		[120699] = "Cat <Brag>",
		[2458] = 1,
		[137491] = "Suen",
		[79640] = 10,
		[12323] = 1,
		[20170] = 2,
		[108978] = 8,
		[49039] = 6,
		[115189] = 4,
		[94462] = 6,
		[99606] = "Alysrazor",
		[68983] = "The Lich King",
		[114821] = 6,
		[136740] = "Horridon",
		[148972] = 9,
		[138788] = 9,
		[140210] = "[*] Overloaded Circuits",
		[105687] = 1,
		[128275] = 9,
		[30153] = "Orikkilig <Demontime>",
		[23337] = "Alliance Peacekeeper",
		[136741] = "Horridon",
		[126542] = 11,
		[104420] = 2,
		[123156] = 2,
		[37265] = "Crimson Hand Battle Mage",
		[115989] = 6,
		[22986] = "Nefarian",
		[62606] = 10,
		[23242] = 1,
		[46736] = 11,
		[122224] = 3,
		[131623] = 9,
		[119573] = "[*] Ring of Fire",
		[111894] = 7,
		[5118] = 3,
		[112918] = "Hateful Essence",
		[129812] = 1,
		[113942] = 10,
		[54501] = 9,
		[139815] = "Weisheng",
		[69240] = "Plagued Zombie",
		[85416] = 2,
		[27810] = "Kel'Thuzad",
		[117014] = 7,
		[117526] = "Zandalari Fire-Dancer",
		[118038] = 1,
		[38627] = "Coilfang Fathom-Witch",
		[139816] = "Frozen Head",
		[59791] = 2,
		[120086] = 11,
		[15587] = "Twilight Lord Kelris",
		[88346] = 8,
		[42292] = 1,
		[125927] = 5,
		[137444] = 4,
		[139817] = "Frozen Head",
		[116592] = "Zandalari Fire-Dancer",
		[120588] = 7,
		[136124] = "Azure Fog",
		[125206] = "Jade Guardian",
		[76572] = "Twilight Sadist",
		[49868] = 5,
		[63375] = 7,
		[139818] = "Venomous Head",
		[130633] = "Unknown",
		[133675] = 7,
		[71123] = "Stinky",
		[122064] = "Sra'thik Amber-Trapper",
		[38628] = "Coilfang Fathom-Witch",
		[116997] = "Elegon",
		[70358] = "The Lich King",
		[139819] = "Venomous Head",
		[115827] = "Jade Guardian",
		[99610] = "Flamewaker Forward Guard",
		[139994] = 2,
		[1978] = 3,
		[3674] = 3,
		[68981] = "The Lich King",
		[118552] = "Mogu'shan Secret-Keeper",
		[139820] = "Arcane Head",
		[127767] = 4,
		[138384] = "Anima Golem",
		[82137] = "Rom'ogg Bonecrusher",
		[112921] = 9,
		[106996] = 10,
		[120256] = 3,
		[57463] = "Lady Blaumeux",
		[139821] = "Arcane Head",
		[3929] = "Taiwu",
		[17463] = 1,
		[22987] = 9,
		[70305] = "Frostblade <Frostwarden Warrior>",
		[23243] = 1,
		[140074] = 9,
		[24378] = 1,
		[139822] = "Flaming Head",
		[55697] = "Sapphiron",
		[111898] = 9,
		[48018] = 9,
		[4042] = 1,
		[136751] = "Greater Cave Bat",
		[137323] = 5,
		[49872] = "Antipersonnel Cannon <Chetoo>",
		[118347] = 7,
		[110959] = 8,
		[24907] = 10,
		[120273] = 11,
		[57330] = 6,
		[136752] = "Lu'lin",
		[140628] = "Eternal Guardian",
		[8679] = 4,
		[71169] = 6,
		[86814] = "Riverpaw Basher",
		[43667] = "Prince Keleseth",
		[93622] = 10,
		[121114] = "Sik'thik Amber-Weaver",
		[136753] = "Greater Cave Bat",
		[130632] = "Zip Line",
		[114459] = 7,
		[131634] = 2,
		[37268] = "Crimson Hand Centurion",
		[5229] = 10,
		[127230] = 7,
		[138967] = 7,
		[106827] = "Sha of Violence",
		[45181] = 4,
		[29722] = 9,
		[47251] = "Sunblade Dragonhawk",
		[13692] = "Bloodhound",
		[79136] = 4,
		[135584] = "Scout Captain Elsia",
		[107122] = "[*] Viscous Fluid",
		[37111] = "Novice Astromancer",
		[126532] = 7,
		[82928] = 3,
		[28747] = "Krik'thir the Gatewatcher",
		[125508] = "Amber Globule",
		[137045] = "Lei Shen",
		[94794] = 7,
		[122692] = 9,
		[76577] = 4,
		[131972] = "Sik'thik Battle-Mender",
		[116467] = 2,
		[15872] = "Unknown",
		[136322] = "Lei Shen",
		[35477] = 10,
		[87840] = "Yoshisuke",
		[121116] = 1,
		[124173] = "Sik'thik Vanguard",
		[117829] = "[*] Cowardice",
		[113620] = "Book Case",
		[123164] = 7,
		[128386] = 1,
		[118340] = 1,
		[7328] = 2,
		[348] = 9,
		[51271] = 6,
		[126236] = 6,
		[27808] = "Kel'Thuzad",
		[31602] = "Nerub'enkan",
		[106660] = "Fire Flower <Shado-Pan Novice>",
		[19483] = "Unknown <Amazarak>",
		[48020] = 9,
		[982] = 3,
		[106620] = "Fragrant Lotus",
		[37156] = "Phoenix-Hawk",
		[115009] = "Shado-Pan Stormbringer",
		[148022] = 8,
		[16589] = 10,
		[137231] = "Dam'ren",
		[116510] = "Troll Explosives",
		[80240] = 9,
		[42231] = 10,
		[123014] = "[*] Volatile Amber",
		[93985] = 10,
		[127261] = 3,
		[119582] = 11,
		[114056] = "[*] Bloody Mess",
		[475] = 8,
		[112927] = 9,
		[13159] = 3,
		[122142] = "Borokhula the Destroyer",
		[44949] = 1,
		[106784] = "Rolling Barrel <Nnydruid>",
		[53652] = 2,
		[28440] = "Dread Creeper",
		[116297] = "[*] Strafing Run",
		[106433] = "Master Snowdrift",
		[14030] = "Anvilrage Warden",
		[118047] = "Subetai the Swift",
		[34861] = "Lightwell",
		[62137] = "Risen Ally <Smokeppc>",
		[61309] = 1,
		[79140] = 4,
		[104225] = 9,
		[76516] = "Gilgoblin Hunter",
		[14183] = 4,
		[113952] = 4,
		[81700] = 5,
		[124988] = 10,
		[45866] = "Felmyst",
		[116000] = 6,
		[100130] = 1,
		[33943] = 10,
		[60503] = 1,
		[118048] = "Subetai the Swift",
		[79633] = 10,
		[14887] = "Firebrand Darkweaver",
		[86820] = "Riverpaw Looter",
		[54732] = 1,
		[130186] = 1,
		[112929] = "Hateful Essence",
		[16071] = "Firebrand Dreadweaver",
		[113953] = 4,
		[114465] = "[*] Scorched Earth",
		[45438] = 8,
		[45462] = 6,
		[28695] = 7,
		[147349] = 10,
		[76070] = "Beauty",
		[125728] = "Kor'thik Swarmer",
		[118049] = "Subetai the Swift",
		[77606] = 6,
		[139838] = "Venomous Head",
		[75846] = "Karsh Steelbender",
		[115418] = "Krik'thik Wind Shaper",
		[16103] = "Spire Spider",
		[8433] = "Old Serra'kis",
		[136767] = "Horridon",
		[44457] = 8,
		[114466] = "Wall of Suds",
		[139839] = "Venomous Head",
		[82726] = 3,
		[130008] = "Tsulong",
		[116027] = "Hopper",
		[54311] = "Tomb Horror",
		[76583] = "Twilight Zealot",
		[47528] = 6,
		[8680] = 4,
		[139840] = "Venomous Head",
		[119586] = "Sha of Anger",
		[119354] = "Sik'thik Bladedancer",
		[8936] = 10,
		[115003] = "Yan-Zhu the Uncasked",
		[136769] = "Horridon",
		[115771] = "Cobalt Guardian",
		[26573] = 2,
		[139841] = "Frozen Head",
		[55078] = 6,
		[45018] = "Kalecgos",
		[117507] = "Summit Bonestripper",
		[76612] = "Twilight Zealot",
		[136770] = "Horridon",
		[117543] = 7,
		[136910] = 2,
		[139842] = "Frozen Head",
		[55077] = "Savage Worg",
		[139202] = "[*] Blue Ray Tracking",
		[57381] = "Lady Blaumeux",
		[112932] = "Residual Hatred",
		[82327] = 2,
		[81192] = 10,
		[45242] = 5,
		[123171] = 9,
		[97340] = 9,
		[122482] = "Ice Wall",
		[122929] = "Obedient Hound",
		[119914] = 9,
		[136772] = 7,
		[85288] = 1,
		[126755] = 6,
		[139844] = 2,
		[111397] = 9,
		[120100] = "Ming the Cunning",
		[43928] = "Dragonflayer Metalworker",
		[112933] = "Residual Hatred",
		[115767] = 1,
		[53284] = 11,
		[139836] = "Cinders",
		[115308] = 11,
		[102693] = 10,
		[128232] = "Scarlet Evangelist",
		[137528] = "Ji-Kun",
		[54049] = "Haammon",
		[23246] = 5,
		[126050] = 11,
		[133597] = "Evil Eye",
		[102695] = 4,
		[111398] = "Scarlet Evangelist",
		[120101] = "Ming the Cunning",
		[106454] = "Master Snowdrift",
		[121125] = 11,
		[136775] = 7,
		[122149] = "Zar'thik Battle-Mender",
		[131788] = "Feng the Accursed",
		[12328] = 1,
		[49560] = 6,
		[83242] = 3,
		[99532] = "Molten Lord",
		[108839] = 8,
		[54640] = 10,
		[15708] = "Lord Aurius Rivendare",
		[118566] = "Shan-xi Watershaper",
		[148039] = 2,
		[119590] = "Ring of Fire",
		[12968] = 1,
		[104232] = 9,
		[113000] = 10,
		[136777] = 7,
		[113959] = "Scarlet Defender",
		[120258] = 6,
		[53400] = "Hadronox",
		[37274] = "Crimson Hand Inquisitor",
		[99625] = "Flamewaker Cauterizer",
		[54729] = 6,
		[140380] = 7,
		[76588] = "Twilight Zealot",
		[126246] = "Crane",
		[47001] = "Sunblade Slayer",
		[17] = 5,
		[111400] = 9,
		[126513] = 6,
		[104233] = 9,
		[93341] = 2,
		[8398] = "Aku'mai Servant",
		[130342] = 11,
		[81708] = 8,
		[123175] = "Instructor Kli'thak",
		[115356] = 7,
		[124199] = 8,
		[33831] = 10,
		[117032] = 11,
		[119072] = 2,
		[42650] = 6,
		[77613] = 5,
		[53822] = 6,
		[140876] = 3,
		[138070] = "Unharnessed Power",
		[43930] = "Dragonflayer Metalworker",
		[51490] = 7,
		[106699] = "Flying Snow",
		[116783] = 6,
		[61336] = 10,
		[37019] = 7,
		[37275] = "Crimson Hand Inquisitor",
		[83245] = 3,
		[52408] = 1,
		[117960] = "Elegon",
		[23247] = 11,
		[70771] = 9,
		[47002] = "Felmyst",
		[38262] = "Coilfang Elite",
		[119593] = "Sha of Fear",
		[23364] = "Nefarian",
		[16104] = "Spire Spider",
		[121129] = 2,
		[110810] = 10,
		[105771] = 1,
		[114474] = "Candlestick Mage",
		[92043] = 3,
		[57753] = "Onyx Blaze Mistress",
		[124201] = 7,
		[113775] = "Jandice Barov",
		[108843] = 8,
		[76591] = "Twilight Zealot",
		[42651] = 6,
		[46924] = 1,
		[59545] = 6,
		[37282] = "Novice Astromancer",
		[12042] = 8,
		[43931] = "Enslaved Proto-Drake",
		[137808] = 7,
		[122413] = "Amber Monstrosity",
		[22981] = "Nefarian",
		[130404] = 7,
		[120047] = "Yang Guoshi",
		[37276] = "Crimson Hand Inquisitor",
		[116011] = 8,
		[127769] = 9,
		[75676] = "Twilight Zealot",
		[76592] = "Twilight Zealot",
		[39029] = "Greyheart Tidecaller",
		[77616] = 6,
		[75992] = "Naz'jar Tempest Witch",
		[81206] = "Lightwell",
		[101166] = "Unbound Pyrelord",
		[48027] = 2,
		[38585] = "Coilfang Priestess",
		[90621] = 6,
		[586] = 5,
		[120521] = "[*] Waterspout",
		[106797] = "Liu Flameheart",
		[27812] = "Shadow Fissure <Kel'Thuzad>",
		[75722] = "Lady Naz'jar",
		[123020] = "[*] Burning Amber",
		[122252] = "Riverpaw Shaman",
		[76593] = "Faceless Watcher",
		[111008] = "Scarlet Zealot",
		[124205] = 7,
		[10793] = 1,
		[37027] = "Master Engineer Telonicus",
		[96103] = 1,
		[89523] = 7,
		[137375] = "Lu'lin",
		[121644] = "Feng the Accursed",
		[76341] = "Mindbender Ghur'sha",
		[114390] = "Houndmaster Braun",
		[123180] = "Instructor Kli'thak",
		[126501] = 5,
		[15589] = "Bloodwarder Marshal",
		[22992] = "Nefarian",
		[62618] = 5,
		[76594] = "Twilight Zealot",
		[53148] = "Cryptik <Minmaxer>",
		[121949] = "Amber-Shaper Un'sok",
		[102703] = 10,
		[88611] = 4,
		[128300] = 7,
		[38306] = "Fathom-Guard Tidalvess",
		[112942] = 4,
		[132467] = 11,
		[38441] = "Fathom-Lord Karathress",
		[114020] = "Houndmaster Braun",
		[2484] = 7,
		[123693] = 6,
		[6229] = 9,
		[88423] = 10,
		[112944] = "Hoptallus",
		[125741] = "Set'thik Gale-Slicer",
		[83244] = 3,
		[117436] = "[*] Lightning Prison",
		[119086] = "Terror Spawn",
		[145162] = 10,
		[128301] = "Jin Warmkeg's Brew",
		[26064] = "Cryptik <Minmaxer>",
		[104235] = 5,
		[116008] = "Jade Guardian",
		[122158] = 6,
		[114479] = "Candlestick Mage",
		[48743] = 6,
		[8220] = 5,
		[13730] = "Skeletal Berserker",
		[48107] = 8,
		[54428] = 2,
		[125742] = "Set'thik Gale-Slicer",
		[13737] = "Onyx Brood General",
		[35873] = "Kael'thas Sunstrider",
		[139866] = "Frozen Head",
		[43935] = "Dragonflayer Bonecrusher",
		[55964] = "Randolph Moloch",
		[7744] = 4,
		[121135] = 5,
		[14185] = 4,
		[123184] = "Dissonance Field",
		[76584] = "Twilight Zealot",
		[13323] = "Spirestone Lord Magus",
		[28880] = 1,
		[116016] = "Scarlet Purifier",
		[38433] = "Fathom-Guard Sharkkis",
		[32592] = 5,
		[137650] = 2,
		[55709] = 2,
		[138317] = 8,
		[126554] = 7,
		[122161] = 6,
		[119862] = "Yang Guoshi",
		[70316] = "Unga Nibstabber",
		[112945] = "Hoptallus",
		[136797] = "Zandalari Dinomancer",
		[113969] = "Scarlet Defender",
		[118783] = "Feng the Accursed",
		[139869] = "Dark Animus",
		[107314] = "Krik'thik Protectorate",
		[17619] = 10,
		[97388] = 1,
		[117539] = "Undying Shadows",
		[23249] = 11,
		[51485] = 7,
		[23505] = 1,
		[122057] = 11,
		[63900] = "熊 <Cunabe>",
		[128304] = "Shado-Pan Disciple",
		[83243] = 3,
		[80182] = "Drunken Hozen Brawler",
		[102694] = 9,
		[105779] = 7,
		[8024] = 7,
		[13819] = 2,
		[123697] = "Unstable Sha",
		[116018] = "Feng the Accursed",
		[134752] = "Eye Sentry",
		[50334] = 10,
		[2139] = 8,
		[136431] = "[*] Shell Concussion",
		[34720] = 3,
		[34976] = 1,
		[76686] = "Twilight Obsidian Borer",
		[5176] = 10,
		[134753] = "Eye Sentry",
		[112947] = 4,
		[100150] = "Inferno Hawk",
		[113690] = "Flameweaver Koegler",
		[114483] = 10,
		[53406] = "Hadronox",
		[115507] = "Scarlet Flamethrower",
		[124210] = 11,
		[134754] = "Eye Sentry",
		[46239] = "Shadowsword Guardian",
		[90328] = "Spirit Beast <Foxy>",
		[70460] = "Frost Freeze Trap",
		[107753] = 2,
		[15407] = 5,
		[127794] = 7,
		[122121] = 5,
		[134755] = "[*] Eye Sore",
		[112948] = 8,
		[115745] = "Jade Guardian",
		[81208] = 5,
		[70447] = "Volatile Ooze",
		[30482] = 8,
		[7] = "Environment (Lava)",
		[124211] = 3,
		[33697] = 7,
		[108853] = 8,
		[118303] = "Undying Shadows",
		[53401] = "Cat <Brag>",
		[132117] = 6,
		[57759] = "Onyx Flight Captain",
		[127795] = 7,
		[28240] = "Grobbulus",
		[52127] = 7,
		[136892] = "Ice Tomb",
		[127797] = 10,
		[81209] = 5,
		[22482] = 4,
		[125866] = "Zar'thik Augurer",
		[115509] = "Shado-Pan Warden",
		[124212] = 4,
		[114207] = 1,
		[46240] = "Shadowsword Guardian",
		[23250] = 1,
		[126260] = 1,
		[54680] = 3,
		[76328] = "Twilight Flame Caller",
		[39329] = "High Astromancer Solarian",
		[106808] = "Ook-Ook",
		[134759] = "Iron Qon's Spear <Iron Qon>",
		[104759] = 9,
		[99618] = "Flamewaker Cauterizer",
		[127368] = 7,
		[112992] = "Hoptallus",
		[106807] = "Ook-Ook",
		[16595] = 1,
		[124213] = 5,
		[70461] = "Frost Freeze Trap",
		[16979] = 10,
		[117558] = "Undying Shadows",
		[17235] = "Nerub'enkan",
		[138856] = 5,
		[45182] = 4,
		[25810] = 3,
		[133737] = "Yellow Eye",
		[52128] = 7,
		[47541] = 6,
		[124656] = "Great Wall Explosion Caster Stalker",
		[60025] = 5,
		[38358] = "Fathom-Guard Caribdis",
		[114999] = "Taran Zhu",
		[115511] = "Scarlet Centurion",
		[104223] = 9,
		[48792] = 6,
		[117455] = 7,
		[76604] = "Faceless Watcher",
		[118071] = "Siphoning Shield",
		[115001] = 6,
		[127286] = 1,
		[119607] = 11,
		[133739] = "Yellow Eye",
		[126955] = "Mogu'shan Warden",
		[125644] = 1,
		[6648] = 4,
		[139758] = "Flaming Head",
		[26613] = "Instructor Razuvious",
		[115000] = 6,
		[6552] = 1,
		[124215] = 7,
		[114842] = 4,
		[125716] = "Set'thik Tempest",
		[126907] = "Kor'thik Fleshrender",
		[73510] = 5,
		[30094] = "Necro Knight",
		[117529] = "Undying Shadows",
		[121245] = "Cursed Mogu Sculpture",
		[61391] = 10,
		[76001] = "Lady Naz'jar",
		[140741] = "[*] Primal Nutriment",
		[71203] = "Sindragosa",
		[29858] = 9,
		[85790] = "Shan'ze Ancestor",
		[139885] = "Ancient Python",
		[37283] = "Tempest Falconer",
		[124216] = 4,
		[110617] = 10,
		[76094] = "Commander Ulthok",
		[23251] = 3,
		[122151] = "Gara'jal the Spiritbinder",
		[43927] = 3,
		[142912] = 7,
		[137669] = "[*] Storm Cloud",
		[137531] = "Lu'lin",
		[136739] = "Horridon",
		[45334] = 10,
		[24275] = 2,
		[115515] = 2,
		[126519] = 2,
		[115002] = "Taran Zhu",
		[123705] = "[*] Scary Fog",
		[41635] = 5,
		[124729] = 7,
		[117050] = 3,
		[117921] = "Qiang the Merciless",
		[17236] = "Thuzadin Acolyte",
		[138864] = 11,
		[139888] = "Ancient Python",
		[31821] = 2,
		[104414] = 9,
		[123408] = 11,
		[112955] = "Scarlet Defender",
		[136817] = "War-God Jalak",
		[770] = 10,
		[139298] = "Hatchling",
		[139889] = "Torrent of Ice",
		[107324] = "Krik'thik Protectorate",
		[124218] = 3,
		[115522] = 2,
		[110099] = "Minion of Doubt",
		[116705] = 11,
		[126266] = 10,
		[8394] = 10,
		[127290] = 1,
		[127802] = 9,
		[8362] = "Blindlight Oracle",
		[136722] = "Moon Lotus",
		[10799] = 3,
		[119488] = "Sha of Anger",
		[28499] = 5,
		[99647] = "Cinderweb Spinner",
		[59793] = 7,
		[123707] = "Grand Empress Shek'zeer",
		[124219] = 10,
		[114291] = "Hopper",
		[117052] = "Elder Regail",
		[124991] = 10,
		[69789] = "[*] Ooze Flood",
		[107357] = "Taran Zhu",
		[110909] = 8,
		[127803] = 3,
		[15976] = "Razorlash",
		[135145] = "Dam'ren",
		[121148] = 5,
		[136821] = "Horridon",
		[139895] = "Soul-Fed Construct",
		[114493] = "Reanimated Corpse",
		[131702] = "Slimy Fish-Getter",
		[124221] = 8,
		[124220] = 3,
		[116541] = 7,
		[5782] = 9,
		[23252] = 11,
		[33702] = 9,
		[138870] = 6,
		[39077] = "Crimson Hand Blood Knight",
		[53480] = 3,
		[580] = 4,
		[16172] = "Ghoul Ravener",
		[30091] = "Necro Knight",
		[75700] = "Geyser <Lady Naz'jar>",
		[46771] = "Grand Warlock Alythess",
		[15230] = "Spirestone Lord Magus",
		[115006] = "Grooka Grooka",
		[102165] = "Kkrissz",
		[41637] = 5,
		[6262] = 10,
		[49722] = "Enslaved Proto-Drake",
		[38580] = "Coilfang Priestess",
		[115547] = 2,
		[121951] = "Brewmaster Blanche",
		[127293] = 1,
		[38622] = "Water Elemental Totem <Greyheart Tidecaller>",
		[114011] = "Scarlet Hall Guardian",
		[79683] = 8,
		[136881] = "Zandalari Water-Binder",
		[123918] = "Scar-Shell",
		[116497] = 9,
		[46101] = "Shadowsword Fury Mage",
		[123198] = "[*] Volatile Amber",
		[45477] = 6,
		[6742] = "Spirestone Ogre Magus",
		[72292] = 6,
		[76100] = "Commander Ulthok",
		[125758] = "Apparition of Fear",
		[126270] = 5,
		[147065] = 5,
		[39078] = "Bloodwarder Squire",
		[78660] = "Zandalari Terror Rider",
		[133755] = 10,
		[34996] = "Bloodwarder Marshal",
		[110913] = 9,
		[32267] = 8,
		[134029] = "Durumu the Forgotten",
		[122687] = 8,
		[123199] = 7,
		[106470] = "[*] Ball of Fire",
		[139900] = "Stormbringer Draz'kil",
		[116550] = "Emperor's Strength",
		[115629] = "Commander Durand",
		[108294] = 10,
		[34471] = 3,
		[138927] = 10,
		[127295] = 1,
		[15869] = "Smolderthorn Witch Doctor",
		[76582] = "Twilight Zealot",
		[121177] = "Melz",
		[112961] = 4,
		[783] = 10,
		[20484] = 10,
		[122688] = 3,
		[139901] = "[*] Stormcloud",
		[123712] = 7,
		[116033] = 11,
		[75590] = "Twilight Sadist",
		[15659] = "Spirestone Mystic",
		[125760] = "Night Terror",
		[23381] = "Riverpaw Shaman",
		[123018] = "[*] Terrorize",
		[39079] = "Tempest Falconer",
		[15979] = "Spirestone Ogre Magus",
		[127320] = 8,
		[52752] = 7,
		[121153] = 4,
		[125195] = 11,
		[135855] = 4,
		[122689] = 6,
		[139903] = "Stormbringer Draz'kil",
		[123713] = 10,
		[8364] = "Blackfathom Sea Witch",
		[527] = 5,
		[119775] = "Sha of Fear",
		[117570] = "Figment of Doubt",
		[47633] = 6,
		[118594] = "Gio",
		[20243] = 1,
		[114192] = 1,
		[29879] = "Kel'Thuzad",
		[139992] = "Arcane Head",
		[49576] = 6,
		[105284] = 7,
		[46585] = 6,
		[43665] = "Dragonflayer Heartsplitter",
		[55694] = 1,
		[111961] = 11,
		[2457] = 1,
		[102746] = 11,
		[779] = 10,
		[94719] = 11,
		[603] = 9,
		[15580] = "Rage Talon Dragonspawn",
		[35570] = "Dragonflayer Overseer",
		[8213] = 1,
		[82192] = 11,
		[142978] = 3,
		[104773] = 9,
		[76719] = "Incendiary Spark",
		[635] = 2,
		[122691] = 2,
		[106841] = "Liu Flameheart",
		[115524] = "Frenzied Spirit",
		[120644] = 5,
		[69166] = "Festergut",
		[37289] = "Astromancer Lord",
		[76617] = "Conflagration",
		[139117] = 3,
		[14062] = 4,
		[10796] = 7,
		[126912] = "Kor'thik Fleshrender",
		[133765] = "Durumu the Forgotten",
		[104262] = 5,
		[691] = 9,
		[136837] = "Hidden Fog",
		[69649] = "Sindragosa",
		[703] = 4,
		[139909] = 10,
		[123716] = 7,
		[139550] = "Tormented Spirit",
		[139215] = "Ritual Guard",
		[74002] = 4,
		[76618] = "Conflagration",
		[77130] = 7,
		[133768] = "Durumu the Forgotten",
		[108359] = 9,
		[70475] = "Putricide's Trap",
		[133767] = "Durumu the Forgotten",
		[76307] = "Mindbender Ghur'sha",
		[755] = 9,
		[759] = 8,
		[46989] = 8,
		[122693] = 3,
		[106823] = "Liu Flameheart",
		[123717] = "Tsulong",
		[116038] = "Jasper Guardian",
		[25046] = 4,
		[136841] = "Quivering Blob",
		[35733] = 1,
		[21707] = "Noxxion",
		[102216] = 3,
		[86346] = 1,
		[119622] = "Sha of Anger",
		[129861] = 1,
		[104264] = 9,
		[134926] = "Iron Qon",
		[113479] = "Master Archer",
		[116768] = 11,
		[122694] = 6,
		[22539] = "Firemaw",
		[64431] = 2,
		[114182] = "Scarlet Scholar",
		[75596] = 3,
		[148135] = 11,
		[20217] = 2,
		[134691] = "Iron Qon",
		[137729] = "Flaming Head",
		[1776] = 4,
		[871] = 1,
		[74513] = 1,
		[879] = 2,
		[883] = 3,
		[61447] = 3,
		[96243] = "Water Elemental <Cyrez>",
		[122695] = 1,
		[117914] = "Celestial Protector",
		[13738] = "Fleshflayer Ghoul",
		[116040] = "Feng the Accursed",
		[97463] = 1,
		[125953] = 11,
		[80218] = "Raz the Crazed",
		[64430] = "Vestige of Hatred",
		[9672] = "Twilight Aquamancer",
		[124807] = "Kor'thik Reaver",
		[36983] = "Cosmic Infuser",
		[74001] = 4,
		[125736] = "Apparition of Fear",
		[2908] = 10,
		[118936] = "Glintrok Oracle",
		[16006] = "Smolderthorn Mystic",
		[118530] = "Feng the Accursed",
		[9256] = "High Inquisitor Whitemane",
		[116994] = "Elegon",
		[15532] = "Blackhand Summoner",
		[122708] = 1,
		[16166] = 7,
		[76622] = "Zandalari Terror Rider",
		[118089] = 8,
		[55209] = "Death Knight",
		[110120] = "Ethereal Sha",
		[129352] = 7,
		[104278] = 5,
		[104267] = 2,
		[80206] = "Raz the Crazed",
		[69179] = 1,
		[76813] = "Naz'jar Spiritmender",
		[138895] = 11,
		[115018] = 6,
		[1038] = 2,
		[113769] = "Treant <Hooten>",
		[59650] = 6,
		[118714] = "Wise Mari",
		[46480] = "Sunblade Protector",
		[55050] = 6,
		[106984] = "Gu Cloudstrike",
		[116995] = 11,
		[119626] = "Sha of Anger",
		[136990] = "Frost King Malakk",
		[125888] = "Set'thik Windblade",
		[44203] = 10,
		[117283] = "Cleansing Waters <Elder Asani>",
		[137891] = "High Priestess Mar'li",
		[30344] = "Tbomx",
		[37036] = "Master Engineer Telonicus",
		[38246] = "Hydross the Unstable",
		[136850] = "Lei Shen",
		[133795] = "Hungry Eye",
		[106932] = "Azure Serpent",
		[38316] = "Lady Vashj",
		[38572] = "Vashj'ir Honor Guard",
		[138898] = 7,
		[125440] = 8,
		[60424] = 3,
		[114808] = "Brother Korloff",
		[104269] = 10,
		[118529] = "Mogu'shan Secret-Keeper",
		[53418] = "Hadronox",
		[113996] = 10,
		[81744] = 11,
		[123211] = 7,
		[55543] = "Instructor Razuvious",
		[23493] = 1,
		[131968] = "Sik'thik Battle-Mender",
		[54954] = "Ticking Bomb <Dragonflayer Strategist>",
		[110413] = 7,
		[34477] = 3,
		[118604] = 11,
		[138234] = "[*] Lightning Storm",
		[117685] = "Zian of the Endless Shadow",
		[30167] = 10,
		[104270] = 8,
		[121164] = "Norths",
		[136853] = "[*] Lightning Bolt",
		[76560] = "Gilgoblin Aquamage",
		[120146] = 8,
		[106830] = 10,
		[108366] = 9,
		[118093] = "Metatrax",
		[124748] = "Bubbling Resin",
		[23128] = "Chromaggus",
		[1454] = 9,
		[68947] = "Apothecary Baxter",
		[18989] = 10,
		[112974] = 4,
		[78674] = 10,
		[47788] = 5,
		[104271] = 1,
		[121165] = "Harthak Flameseeker",
		[106659] = "Fire Flower <Shado-Pan Novice>",
		[76509] = "Crazed Mage",
		[32727] = 1,
		[131736] = 9,
		[123725] = 11,
		[90632] = 6,
		[116558] = "Empyreal Focus",
		[63468] = 3,
		[68948] = "Apothecary Baxter",
		[118094] = "Subetai the Swift",
		[2060] = 5,
		[131737] = 9,
		[78675] = 10,
		[120142] = "[*] Dart",
		[104272] = 1,
		[44461] = 8,
		[13165] = 3,
		[113999] = "Rattlegore",
		[122193] = "Zar'thik Battle-Mender",
		[133793] = "Durumu the Forgotten",
		[123647] = "Gurthan Iron Maw",
		[45741] = "Kil'jaeden",
		[104275] = 4,
		[6807] = 10,
		[76628] = "Lucky",
		[114000] = "Scarlet Hall Guardian",
		[55212] = "Death Knight",
		[127310] = 7,
		[132763] = 7,
		[19801] = 3,
		[104273] = 3,
		[1766] = 4,
		[14189] = 4,
		[105809] = 2,
		[81748] = 7,
		[131740] = 9,
		[115536] = 2,
		[136719] = "Farraki Wastewalker",
		[1822] = 10,
		[31601] = "Crypt Crawler",
		[136860] = "[*] Quicksand",
		[59052] = 6,
		[77799] = 9,
		[126462] = 10,
		[35412] = "Al'ar",
		[136857] = "[*] Entrapped",
		[104274] = 11,
		[96230] = 9,
		[46931] = "[*] Demonic Vapor",
		[117679] = 10,
		[45230] = "Grand Warlock Alythess",
		[123216] = 7,
		[123728] = 9,
		[62124] = 2,
		[134814] = "Eye Sentry",
		[49821] = 5,
		[1966] = 4,
		[54957] = 2,
		[48045] = 5,
		[117549] = 7,
		[57466] = "Sir Zeliek",
		[2006] = 5,
		[32216] = 1,
		[1742] = "Apex <Minmaxer>",
		[125774] = 7,
		[40623] = 5,
		[111758] = 5,
		[115026] = "Unstable Energy",
		[114917] = 2,
		[23228] = 3,
		[129250] = 5,
		[54757] = 3,
		[113866] = "Jandice Barov",
		[697] = 9,
		[138668] = "Drakkari Frost Warden",
		[102740] = 1,
		[123655] = "Haiyan the Unstoppable",
		[51886] = 7,
		[104276] = 10,
		[37133] = "Apprentice Star Scryer",
		[125878] = "Set'thik Windblade",
		[122194] = 7,
		[81751] = 5,
		[9080] = "Vicious Thug",
		[123730] = 9,
		[84745] = 4,
		[122389] = 2,
		[45960] = "Nether Vapor",
		[123646] = "Gurthan Iron Maw",
		[121900] = "Ookie",
		[118611] = 8,
		[102741] = 1,
		[46763] = "Shadowsword Commander",
		[27993] = "Spectral Horse",
		[104277] = 9,
		[46434] = "Shadowsword Soulbinder",
		[64977] = 11,
		[114004] = "Houndmaster Braun",
		[37018] = "Grand Astromancer Capernian",
		[123219] = 7,
		[123731] = 9,
		[106547] = "Shado-Pan Novice",
		[134820] = "Lei Shen",
		[9005] = 10,
		[117588] = "Primal Fire Elemental <Zadziorny>",
		[137905] = "[*] Lightning Diffusion",
		[138916] = 4,
		[46762] = "Shadowsword Commander",
		[136513] = "Amani'shi Beast Shaman",
		[128339] = "Ethereal Sha",
		[134821] = "[*] Discharged Energy",
		[115458] = "[*] Acid Bomb",
		[58505] = 6,
		[22570] = 10,
		[2812] = 2,
		[30809] = 7,
		[115238] = 4,
		[133798] = "Hungry Eye",
		[75610] = "Corla, Herald of Twilight",
		[106645] = "Flying Snow",
		[76634] = "Tainted Sentry",
		[124673] = "Sonic Pulse",
		[135678] = 3,
		[12167] = "Riverpaw Shaman",
		[24394] = 3,
		[140684] = "Mist Lurker",
		[104279] = 5,
		[121173] = "Kargesh Highguard",
		[36971] = "Grand Astromancer Capernian",
		[8232] = 7,
		[37135] = "Nether Scryer",
		[135680] = "Lei Shen",
		[28470] = "Guardian of Icecrown",
		[108447] = 9,
		[123651] = "Kargesh Ribcrusher",
		[136465] = "Amani'shi Flame Caster",
		[12654] = 8,
		[117945] = "Celestial Protector",
		[28135] = "Feugen",
		[102744] = 7,
		[70492] = "Volatile Ooze",
		[126690] = 3,
		[104280] = 7,
		[135683] = "Lei Shen",
		[139771] = "Shan'ze Celestial Shaper",
		[1126] = 10,
		[138264] = "Faded Image of Xuen",
		[5484] = 9,
		[120070] = "Sap Puddle",
		[33745] = 10,
		[112077] = "Starving Hound",
		[633] = 2,
		[69395] = 2,
		[118103] = 1,
		[118615] = 2,
		[132626] = 8,
		[127830] = 3,
		[114875] = "Fuel Tank",
		[104281] = 10,
		[121175] = 2,
		[107275] = "Krik'thik Engulfer",
		[122199] = "Elegon",
		[138923] = "Ji-Kun",
		[123223] = 11,
		[123735] = "Grand Empress Shek'zeer",
		[35025] = 5,
		[116014] = 8,
		[120517] = 5,
		[145067] = 2,
		[75842] = "Karsh Steelbender",
		[77661] = 7,
		[43186] = 2,
		[47248] = "Sunblade Cabalist",
		[128343] = "Unknown",
		[104282] = 10,
		[121176] = 1,
		[52751] = 6,
		[114009] = "[*] Soulflame",
		[138925] = 7,
		[115033] = "Unstable Energy",
		[21069] = "Vile Larva",
		[128180] = 3,
		[75614] = 9,
		[125081] = "Amber-Ridden Mushan",
		[79638] = 6,
		[118105] = "Subetai the Swift",
		[34936] = 9,
		[102747] = 10,
		[15982] = "Spirestone Mystic",
		[14873] = "Shifty Thief",
		[845] = 1,
		[129368] = 7,
		[6789] = 9,
		[9532] = "Unga Totemchipper",
		[122713] = "Imperial Vizier Zor'lok",
		[134563] = 11,
		[115546] = 11,
		[121190] = "Quilen Guardian",
		[331] = 7,
		[132118] = 5,
		[108968] = "Gio",
		[118106] = "Subetai the Swift",
		[2944] = 5,
		[59569] = 8,
		[1949] = 9,
		[108416] = 9,
		[16591] = 10,
		[9007] = 10,
		[129881] = 11,
		[130393] = "Apex <Minmaxer>",
		[122714] = "Lorewalker Stonestep",
		[45235] = "Grand Warlock Alythess",
		[107356] = "Taran Zhu",
		[77451] = 7,
		[123407] = 11,
		[48505] = 10,
		[125786] = "Sha of Fear",
		[54962] = "Dragonflayer Strategist",
		[114087] = "Houndmaster Braun",
		[100787] = 11,
		[127834] = "Imperial Vizier Zor'lok",
		[135695] = "Lei Shen",
		[37270] = "Crimson Hand Centurion",
		[36991] = "Warp Slicer",
		[50453] = "Bloodworm <Dankwarrior>",
		[6196] = 7,
		[110705] = 10,
		[20572] = 6,
		[123739] = "Tsulong",
		[116060] = "Amethyst Guardian",
		[139114] = "Zandalari Warlord",
		[103958] = 9,
		[19983] = "Sapphiron",
		[136548] = "Ball Lightning <Lei Shen>",
		[12169] = "Anvilrage Guardsman",
		[127323] = 11,
		[140816] = 5,
		[30043] = "Carrion Spinner",
		[120668] = 7,
		[30283] = 9,
		[38295] = "Lady Vashj",
		[130395] = "Jasper Guardian",
		[38551] = 3,
		[130577] = "Unknown",
		[115180] = 11,
		[27285] = 9,
		[136220] = "Primordius",
		[781] = 3,
		[118699] = 9,
		[76575] = 1,
		[31707] = "水元素 <Dreckit>",
		[139958] = 1,
		[110914] = 9,
		[137664] = "[*] Frozen Blood",
		[120669] = "Sha of Fear",
		[121181] = "Harthak Flameseeker",
		[102558] = 10,
		[114014] = 4,
		[6136] = "Blackfathom Sea Witch",
		[120087] = "Whilring Dervish <Ming the Cunning>",
		[33206] = 5,
		[124253] = "Sik'thik Bladedancer",
		[17105] = "Wailing Banshee",
		[35101] = 3,
		[123886] = 2,
		[103196] = 8,
		[51124] = 6,
		[59571] = 9,
		[115008] = 11,
		[12975] = 1,
		[120670] = "Zandalari Fire-Dancer",
		[121182] = "Harthak Flameseeker",
		[136889] = "[*] Violent Gale Winds",
		[15286] = 5,
		[122718] = "Imperial Vizier Zor'lok",
		[81326] = 6,
		[81292] = 5,
		[23248] = 10,
		[69159] = "Festergut",
		[43929] = "Dragonflayer Metalworker",
		[59542] = 2,
		[38582] = "Coilfang Priestess",
		[138938] = 7,
		[115519] = "Scarlet Centurion",
		[119647] = 11,
		[87395] = "Zeb'tula Stoneshield",
		[17877] = 9,
		[121183] = 2,
		[111720] = "[*] Swirling Sunfire",
		[1490] = 9,
		[69161] = "Festergut",
		[123231] = 11,
		[123743] = "[*] Dread Screech Waves",
		[124255] = 11,
		[126896] = 11,
		[138127] = 1,
		[50613] = 6,
		[7384] = 1,
		[140115] = "Zandalari Prophet",
		[110945] = "Gu Cloudstrike",
		[38310] = "Lady Vashj",
		[120160] = "Haiyan the Unstoppable",
		[120672] = "Sha of Fear",
		[112993] = "Hoptallus",
		[37122] = "Star Scryer",
		[114017] = "Houndmaster Braun",
		[138941] = 7,
		[123232] = 11,
		[15471] = "Crypt Crawler",
		[48400] = "Unknown",
		[69165] = "Festergut",
		[114214] = 5,
		[16168] = "Flame Buffet Totem <Smolderthorn Witch Doctor>",
		[54965] = "Dragonflayer Runecaster",
		[114859] = "Bored Student",
		[131775] = "Jungle Brewstealer",
		[7992] = "Venom Belcher",
		[79206] = 7,
		[8056] = 7,
		[121185] = "Kargesh Highguard",
		[113506] = 5,
		[114018] = 4,
		[12043] = 8,
		[106851] = "Stout Brew Alemental",
		[139205] = "Zandalari Prophet",
		[82362] = "Evolved Twilight Zealot",
		[136986] = "Zandalari Spear-Shaper",
		[76590] = "Faceless Watcher",
		[126498] = 2,
		[17364] = 7,
		[39647] = "Onyx Sanctum Guardian",
		[107047] = "Striker Ga'dok",
		[53801] = "Anub'ar Crusher",
		[119085] = 11,
		[52150] = 6,
		[57755] = 1,
		[120027] = "[*] Burn",
		[724] = 5,
		[59547] = 7,
		[123234] = 11,
		[123746] = "Felguard <Amalanar>",
		[131655] = "Sap Puddle",
		[122086] = "Shan'ze Serpentbinder",
		[125282] = 2,
		[54710] = 7,
		[54966] = "Dragonflayer Runecaster",
		[55222] = "Death Knight Captain",
		[47287] = "Volatile Fiend",
		[118312] = "Elder Asani",
		[60233] = 3,
		[124217] = 7,
		[129378] = "Sha of Fear",
		[43936] = "Dragonflayer Bonecrusher",
		[81256] = 6,
		[105709] = 5,
		[106853] = "Master Snowdrift",
		[115556] = "Doomguard <Caries>",
		[121601] = "Harthak Stormcaller",
		[115419] = "Krik'thik Wind Shaper",
		[122409] = "Kor'thik Elite Blademaster",
		[123969] = "Chagan Firehoof",
		[116267] = 8,
		[56222] = 6,
		[131781] = "Unga Keg-Blocker",
		[123981] = 6,
		[54309] = "Anub'ar Prime Guard",
		[120676] = 7,
		[112997] = 10,
		[107566] = 1,
		[114021] = "Houndmaster Braun",
		[139220] = "Zandalari Storm-Caller",
		[106854] = "Master Snowdrift",
		[123996] = "Xuen <Trekeenbak>",
		[98619] = 7,
		[46008] = "M'uru",
		[19632] = "Razorgore the Untamed <Wafty>",
		[101223] = "Blazing Talon Initiate",
		[126308] = 7,
		[31224] = 4,
		[11824] = "Twilight Elementalist",
		[528] = 5,
		[137596] = 11,
		[45470] = 6,
		[112998] = "Residual Hatred",
		[118308] = 10,
		[114022] = "Scarlet Treasurer",
		[72219] = "Festergut",
		[131784] = 8,
		[137494] = "Suen",
		[122510] = 1,
		[134856] = "Zandalari Warlord",
		[41172] = "Scout Captain Elsia",
		[136904] = "Frost King Malakk",
		[34490] = 3,
		[104756] = 9,
		[122349] = "Living Amber",
		[36990] = "Staff of Disintegration",
		[3355] = 3,
		[114206] = "Skull Banner <Warboar>",
		[112999] = "Residual Hatred",
		[57761] = 8,
		[44544] = 8,
		[111340] = 8,
		[106856] = "Liu Flameheart",
		[123750] = 1,
		[117215] = "Gara'jal the Spiritbinder",
		[46968] = 1,
		[37159] = "Phoenix-Hawk",
		[38330] = "Fathom-Guard Caribdis",
		[126310] = 7,
		[45517] = 1,
		[55480] = 8,
		[65601] = 1,
		[120167] = "Haiyan the Unstoppable",
		[120679] = 3,
		[64695] = 7,
		[17393] = "Lord Aurius Rivendare",
		[37160] = "Phoenix-Hawk Hatchling",
		[134244] = 7,
		[106857] = "[*] Blackout Drunk",
		[120629] = "Sha of Fear",
		[127352] = "Sergeant Verdone",
		[5697] = 9,
		[81022] = 10,
		[10060] = 5,
		[118779] = 1,
		[123505] = "Animated Protector",
		[110953] = "Scarlet Fanatic",
		[141004] = 3,
		[20165] = 2,
		[76561] = "Evolved Twilight Zealot",
		[135101] = "Vampiric Cave Bat",
		[71615] = "Professor Putricide",
		[81261] = 10,
		[101546] = 11,
		[131790] = "Feng the Accursed",
		[31661] = 8,
		[99691] = "Flamewaker Cauterizer",
		[49575] = "Zandalari Fire-Dancer",
		[102792] = 10,
		[15728] = "Firebrand Dreadweaver",
		[15792] = "Blackhand Summoner",
		[138958] = 2,
		[110954] = "Scarlet Fanatic",
		[8221] = 11,
		[54753] = 1,
		[138427] = "Gurubashi Berserker",
		[113002] = 10,
		[136911] = "Frost King Malakk",
		[81262] = 10,
		[136505] = 8,
		[131792] = "Feng the Accursed",
		[104510] = 7,
		[99692] = "Ancient Core Hound",
		[124777] = "Kor'thik Reaver",
		[32239] = 1,
		[114236] = 10,
		[136512] = "Amani'shi Beast Shaman",
		[138960] = 2,
		[118358] = 11,
		[119611] = 11,
		[125826] = "Bubbling Resin",
		[22677] = "Lord Victor Nefarius",
		[52410] = 1,
		[136913] = "Lei Shen",
		[123461] = "Lei Shi",
		[18400] = 11,
		[50842] = 6,
		[16511] = 4,
		[99693] = "Ancient Core Hound",
		[108396] = 9,
		[106434] = "Master Snowdrift",
		[136914] = "Lei Shen",
		[137668] = "[*] Burning Cinders",
		[118635] = 11,
		[110956] = "Scarlet Fanatic",
		[111722] = "Scholomance Neophyte",
		[120171] = 11,
		[115151] = 11,
		[113004] = 10,
		[113516] = 6,
		[114028] = 1,
		[138963] = 9,
		[118337] = "Primal Earth Elemental <Zadziorny>",
		[115010] = "Unknown <Taran Zhu>",
		[135103] = "Unknown",
		[134539] = "Rockfall",
		[46302] = 7,
		[115129] = 11,
		[109933] = 3,
		[118636] = 11,
		[59578] = 2,
		[15571] = 10,
		[120172] = 9,
		[15096] = "Firebrand Pyromancer",
		[2823] = 4,
		[136917] = "Frost King Malakk",
		[114029] = 1,
		[115013] = "Borokhula the Destroyer",
		[123244] = "Lei Shi",
		[61882] = 7,
		[99695] = "Flamewaker Sentinel",
		[119365] = "Sorcerer Mogu",
		[91724] = 5,
		[145109] = 10,
		[56908] = "Sartharion",
		[19740] = 2,
		[73975] = 6,
		[100094] = "Harbinger of Flame",
		[120173] = 3,
		[93337] = 4,
		[38449] = "Fathom-Guard Caribdis",
		[145110] = 10,
		[114030] = 1,
		[65466] = 1,
		[139991] = "Arcane Head",
		[6201] = 9,
		[22012] = "Horde Spirit Guide",
		[140102] = "Zeb'tula Raptor",
		[70829] = 7,
		[118903] = "Glintrok Hexxer",
		[47585] = 5,
		[66196] = 6,
		[127341] = "Celestial Protector",
		[66846] = 9,
		[128365] = 1,
		[122855] = "Tsulong",
		[139502] = "No'ku Stormsayer",
		[57819] = 2,
		[113642] = "Commander Lindon",
		[106352] = "Master Snowdrift",
		[106864] = "Liu Flameheart",
		[6713] = "Scarlet Defender",
		[118313] = "Elegon",
		[39015] = "Underbog Colossus",
		[77761] = 10,
		[28358] = "Patchwork Golem",
		[126318] = 11,
		[13809] = 3,
		[110960] = 8,
		[138187] = "Lightning Guardian",
		[120175] = 1,
		[120687] = 7,
		[35869] = "Kael'thas Sunstrider",
		[114051] = 7,
		[106421] = "Shado-Pan Disciple",
		[122735] = "Garalon",
		[20577] = 1,
		[28407] = "Shade of Naxxramas",
		[70598] = "Sindragosa",
		[124783] = "Blade Lord Ta'yak",
		[7321] = 8,
		[7353] = 2,
		[3567] = 8,
		[138610] = 8,
		[148187] = 11,
		[16636] = "Death Talon Flamescale",
		[120176] = 10,
		[30455] = 8,
		[642] = 2,
		[136925] = "Rushing Winds",
		[81269] = 10,
		[138973] = 11,
		[70343] = "Growing Ooze Puddle",
		[15473] = 5,
		[128988] = 6,
		[50769] = 10,
		[46270] = "Priestess of Torment",
		[26364] = 7,
		[38591] = "Coilfang Shatterer",
		[3589] = "Shrieking Banshee",
		[127344] = 6,
		[114637] = 2,
		[120177] = "Aquila",
		[31801] = 2,
		[136573] = "Frozen Orb <Drakkari Frozen Warlord>",
		[139316] = "Putrid Waste",
		[73079] = "Plague Scientist",
		[81782] = 5,
		[115058] = 1,
		[123761] = 11,
		[124273] = 11,
		[16866] = "Venom Belcher",
		[84342] = 6,
		[50622] = 1,
		[46916] = 1,
		[8690] = 9,
		[110963] = "Scarlet Purifier",
		[106966] = "Volatile Energy",
		[120178] = 10,
		[90096] = "[*] Explode",
		[36032] = 8,
		[106428] = "Shado-Pan Novice",
		[81298] = 2,
		[7870] = "Rhizabal <Thebigkiller>",
		[123250] = "Lei Shi",
		[55267] = "Dark Touched Warrior",
		[124274] = 11,
		[116595] = "Zandalari Infiltrator",
		[46271] = "Priestess of Torment",
		[137341] = "Beast of Nightmares",
		[22723] = 8,
		[98204] = 11,
		[39104] = 7,
		[127858] = 8,
		[126392] = 3,
		[27807] = "Bile Retcher",
		[20066] = 2,
		[136931] = 7,
		[127570] = 11,
		[114548] = "Yan-Zhu the Uncasked",
		[20578] = 1,
		[117187] = "Elder Regail",
		[124275] = 11,
		[116596] = "Zandalari Infiltrator",
		[2637] = 10,
		[125811] = "Kor'thik Silentwing",
		[52532] = "Anub'ar Warrior",
		[93830] = 1,
		[131813] = "Wind Lord Mel'jarak",
		[3248] = "Firebrand Legionnaire",
		[120180] = 1,
		[120692] = 5,
		[52415] = 1,
		[140759] = "Anima Golem",
		[127704] = 1,
		[122740] = "Imperial Vizier Zor'lok",
		[131814] = 7,
		[66427] = 1,
		[93821] = 10,
		[38366] = "Fathom-Guard Sharkkis",
		[139597] = 11,
		[38337] = "Fathom-Guard Caribdis",
		[104395] = 11,
		[132232] = "Celestial Protector",
		[123497] = "Set'thik Fanatic",
		[115032] = "Unstable Energy",
		[137162] = "Jin'rokh the Breaker",
		[22442] = "Death Talon Hatcher",
		[131842] = "[*] Wind Bomb",
		[121717] = 6,
		[114038] = "[*] Gravity Flux",
		[49088] = 6,
		[115062] = "Unga Spearscamp",
		[69770] = 2,
		[12466] = "Blackhand Summoner",
		[116598] = "Empyreal Focus",
		[125301] = "Blade Lord Ta'yak",
		[137647] = "[*] Lightning Strike",
		[123467] = "Lei Shi",
		[140106] = "Zeb'tula Spearanger",
		[100780] = 11,
		[86961] = 7,
		[53817] = 7,
		[135225] = "Dam'ren",
		[40505] = "Plague Ghoul",
		[136937] = "[*] Frostbite",
		[114039] = 2,
		[115290] = "Thalnos the Soulrender",
		[106872] = "Sha of Violence",
		[107384] = "Corrupted Scroll",
		[99705] = "Druid of the Flame",
		[102342] = 10,
		[108920] = 5,
		[119394] = "Greenstone Terror",
		[118135] = "[*] Pinned Down",
		[13810] = 3,
		[110968] = "Scarlet Purifier",
		[140763] = 9,
		[114807] = "Brother Korloff",
		[39261] = "Cyclone (Karathress) <Fathom-Guard Caribdis>",
		[6346] = 5,
		[100] = 1,
		[55428] = 7,
		[109964] = 5,
		[123255] = "Dissonance Field",
		[20707] = 9,
		[36988] = "Phaseshift Bulwark",
		[75645] = "Corla, Herald of Twilight",
		[108921] = 5,
		[114868] = 6,
		[46543] = "Sunblade Cabalist",
		[138733] = "Jin'rokh the Breaker",
		[127351] = 10,
		[140620] = "Fungal Growth",
		[126489] = 3,
		[120696] = 5,
		[113017] = "Zao Sunseeker",
		[113092] = 8,
		[81277] = "Bloodworm <Dankwarrior>",
		[38463] = "Grobbulus Cloud <Grobbulus>",
		[140013] = 5,
		[134912] = "Lei Shen",
		[124280] = 11,
		[85222] = 2,
		[22334] = "Blackwing Technician",
		[116472] = "Monkey Island Totem <Unga Totemchipper>",
		[15794] = "Blackhand Summoner",
		[55233] = 6,
		[140014] = 5,
		[69762] = 2,
		[107110] = "[*] Jade Fire",
		[120697] = 3,
		[139218] = "Zandalari Storm-Caller",
		[63544] = 5,
		[122233] = 4,
		[126434] = 2,
		[136646] = "Living Poison",
		[57562] = "Fire Cyclone",
		[33661] = "Soul-Fed Construct",
		[16868] = "Baroness Anastari",
		[135920] = 11,
		[136123] = "Amber Fog",
		[68992] = 3,
		[73685] = 7,
		[130] = 8,
		[6795] = 10,
		[18499] = 1,
		[128889] = "[*] Static Field",
		[8676] = 4,
		[137070] = "Zandalari Spear-Shaper",
		[139] = 5,
		[136225] = "Primordius",
		[123258] = 5,
		[99461] = "[*] Blazing Power",
		[28531] = "Sapphiron",
		[110698] = 10,
		[113770] = "Treant <Hooten>",
		[32835] = 9,
		[35779] = "Mindbender <Tellios>",
		[12468] = "Firebrand Invoker",
		[13748] = "Scarshield Spellbinder",
		[76665] = "Lucky",
		[65917] = 1,
		[104317] = 9,
		[113020] = "Vestige of Hatred",
		[129914] = 11,
		[81280] = 6,
		[32612] = 8,
		[123259] = "Gio",
		[136087] = 11,
		[124283] = "General Pa'valak",
		[19832] = 7,
		[355] = 1,
		[117628] = "Zian of the Endless Shadow",
		[137972] = 5,
		[125054] = "Coagulated Amber",
		[25771] = 2,
		[403] = 7,
		[100555] = 7,
		[104318] = "Wild Imp <Demontime>",
		[113021] = "Vestige of Hatred",
		[74196] = 8,
		[469] = 1,
		[36805] = "Kael'thas Sunstrider",
		[115069] = 11,
		[37317] = "Tempest Falconer",
		[11443] = "Thuzadin Shadowcaster",
		[116605] = "Emperor's Strength",
		[1044] = 2,
		[1064] = 7,
		[54739] = 2,
		[69507] = "Rotface",
		[127356] = 7,
		[16689] = 10,
		[38234] = "Fathom-Guard Tidalvess",
		[19506] = 3,
		[113022] = "Vestige of Hatred",
		[92069] = 11,
		[113312] = 2,
		[33758] = 3,
		[115070] = 11,
		[108199] = 6,
		[24932] = 10,
		[16869] = "Maleki the Pallid",
		[30451] = 8,
		[136952] = "Zandalari Water-Binder",
		[68996] = 6,
		[69508] = "Rotface",
		[72133] = "The Lich King",
		[119678] = 9,
		[83908] = "Sunblade Vindicator",
		[42730] = "Ingvar the Plunderer",
		[17466] = "Lord Aurius Rivendare",
		[86213] = 9,
		[81283] = "Wild Mushroom",
		[13299] = "Unknown <Nerub'enkan>",
		[123262] = 2,
		[115654] = 2,
		[116095] = 11,
		[116607] = "Zandalari Skullcharger",
		[125310] = "Blade Lord Ta'yak",
		[125822] = "Amber Trap",
		[13747] = "Spirestone Ogre Magus",
		[147193] = 5,
		[122316] = 10,
		[55748] = 2,
		[52338] = "Battleground Demolisher <Cryonix>",
		[105684] = 10,
		[15744] = "Searing Destroyer",
		[99800] = "Flamewaker Pathfinder",
		[105688] = 1,
		[44151] = 3,
		[115072] = 11,
		[123610] = "Corrupted Protector",
		[74221] = 11,
		[116608] = "Zandalari Skullcharger",
		[76165] = "Erunak Stonespeaker",
		[76677] = "Twilight Element Warden",
		[7386] = 1,
		[106736] = "Sha of Doubt",
		[43651] = "Skarvald the Constructor",
		[125422] = "Kor'thik Warsinger",
		[37254] = "Bloodwarder Squire",
		[50435] = 6,
		[95738] = 1,
		[126707] = 7,
		[114049] = 7,
		[104958] = 1,
	},
	["encounter_spell_pool"] = {
		{
			1412, -- [1]
			"Sodden Hozen Brawler", -- [2]
		}, -- [1]
		[134366] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[6136] = {
			220, -- [1]
			"Blackfathom Sea Witch", -- [2]
		},
		[122740] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[139228] = {
			1570, -- [1]
			"Zandalari High Priest", -- [2]
		},
		[114808] = {
			1424, -- [1]
			"Brother Korloff", -- [2]
		},
		[53390] = {
			1436, -- [1]
			7, -- [2]
		},
		[76171] = {
			1046, -- [1]
			"Erunak Stonespeaker", -- [2]
		},
		[119414] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[136670] = {
			1575, -- [1]
			"Drakkari Frozen Warlord", -- [2]
		},
		[111610] = {
			1426, -- [1]
			"Instructor Chillheart", -- [2]
		},
		[43667] = {
			571, -- [1]
			"Prince Keleseth", -- [2]
		},
		[118135] = {
			1436, -- [1]
			"[*] Pinned Down", -- [2]
		},
		[8398] = {
			226, -- [1]
			"Aku'mai Servant", -- [2]
		},
		[120438] = {
			1431, -- [1]
			"Dread Spawn <[*] Conjure Dread Spawn>", -- [2]
		},
		[122741] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[118903] = {
			1509, -- [1]
			"Glintrok Hexxer", -- [2]
		},
		[117752] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[56909] = {
			1090, -- [1]
			"Sartharion", -- [2]
		},
		[17236] = {
			479, -- [1]
			"Thuzadin Acolyte", -- [2]
		},
		[148187] = {
			1573, -- [1]
			"Fire Spirit <Derenter>", -- [2]
		},
		[134370] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[134626] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[125301] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[131813] = {
			1498, -- [1]
			"Wind Lord Mel'jarak", -- [2]
		},
		[134628] = {
			1559, -- [1]
			"Ro'shak", -- [2]
		},
		[69649] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[118905] = {
			1507, -- [1]
			"Lightning Surge Totem <Prismma>", -- [2]
		},
		[123255] = {
			1501, -- [1]
			"Dissonance Field", -- [2]
		},
		[138467] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[136932] = {
			1572, -- [1]
			"Mind's Eye", -- [2]
		},
		[52752] = {
			1436, -- [1]
			7, -- [2]
		},
		[119929] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[106112] = {
			1439, -- [1]
			"Figment of Doubt", -- [2]
		},
		[135142] = {
			1559, -- [1]
			"[*] Frozen Resilience", -- [2]
		},
		[76047] = {
			1045, -- [1]
			"Commander Ulthok", -- [2]
		},
		[53520] = {
			218, -- [1]
			"Anub'arak", -- [2]
		},
		[134375] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[80781] = {
			479, -- [1]
			"Rockwing Screecher", -- [2]
		},
		[119930] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[99844] = {
			1206, -- [1]
			"Alysrazor", -- [2]
		},
		[106113] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[136935] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[135144] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[117628] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[135145] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[119931] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[134122] = {
			1572, -- [1]
			"Blue Eye", -- [2]
		},
		[34650] = {
			1036, -- [1]
			"Unknown", -- [2]
		},
		[116605] = {
			1407, -- [1]
			"Emperor's Strength", -- [2]
		},
		[83981] = {
			1047, -- [1]
			"Unyielding Behemoth", -- [2]
		},
		[116989] = {
			1500, -- [1]
			"Empyreal Focus", -- [2]
		},
		[127352] = {
			1422, -- [1]
			"Sergeant Verdone", -- [2]
		},
		[134123] = {
			1572, -- [1]
			"Red Eye", -- [2]
		},
		[51730] = {
			1436, -- [1]
			7, -- [2]
		},
		[119932] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[128248] = {
			1303, -- [1]
			"Shado-Pan Ambusher", -- [2]
		},
		[134124] = {
			1572, -- [1]
			"Yellow Eye", -- [2]
		},
		[134380] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[116606] = {
			60009, -- [1]
			"Zandalari Skullcharger", -- [2]
		},
		[139498] = {
			1573, -- [1]
			"Corpse Spider", -- [2]
		},
		[28240] = {
			1111, -- [1]
			"Grobbulus", -- [2]
		},
		[134381] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[119933] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[124283] = {
			1447, -- [1]
			"General Pa'valak", -- [2]
		},
		[116223] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[138732] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[128889] = {
			1303, -- [1]
			"[*] Static Field", -- [2]
		},
		[135150] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[53330] = {
			216, -- [1]
			"Anub'ar Crypt Fiend", -- [2]
		},
		[137709] = {
			1559, -- [1]
			"[*] Shatter", -- [2]
		},
		[76307] = {
			1046, -- [1]
			"Mindbender Ghur'sha", -- [2]
		},
		[107140] = {
			1303, -- [1]
			"Azure Serpent", -- [2]
		},
		[138733] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[99464] = {
			1206, -- [1]
			"Alysrazor", -- [2]
		},
		[81297] = {
			1507, -- [1]
			"Consecration", -- [2]
		},
		[8399] = {
			224, -- [1]
			"Twilight Lord Kelris", -- [2]
		},
		[136431] = {
			1565, -- [1]
			"[*] Shell Concussion", -- [2]
		},
		[116608] = {
			60009, -- [1]
			"Zandalari Skullcharger", -- [2]
		},
		[118783] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[139758] = {
			1578, -- [1]
			"Flaming Head", -- [2]
		},
		[111107] = {
			1424, -- [1]
			"Scarlet Judicator", -- [2]
		},
		[135153] = {
			1579, -- [1]
			"[*] Crashing Thunder", -- [2]
		},
		[121982] = {
			1502, -- [1]
			"Sik'thik Demolisher", -- [2]
		},
		[136177] = {
			1572, -- [1]
			"Azure Fog", -- [2]
		},
		[138480] = {
			1576, -- [1]
			"Large Anima Golem", -- [2]
		},
		[110852] = {
			1303, -- [1]
			"Gu Cloudstrike", -- [2]
		},
		[27825] = {
			1109, -- [1]
			"Unrelenting Death Knight", -- [2]
		},
		[123646] = {
			1442, -- [1]
			"Gurthan Iron Maw", -- [2]
		},
		[117633] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[115842] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[137203] = {
			1570, -- [1]
			"High Priestess Mar'li", -- [2]
		},
		[116994] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[131830] = {
			1498, -- [1]
			"[*] Wind Bomb", -- [2]
		},
		[28305] = {
			1036, -- [1]
			"Unknown", -- [2]
		},
		[117506] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[125822] = {
			1501, -- [1]
			"Amber Trap", -- [2]
		},
		[115843] = {
			1395, -- [1]
			"Jasper Guardian", -- [2]
		},
		[137716] = {
			1560, -- [1]
			"[*] Tidal Force", -- [2]
		},
		[122496] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[118530] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[122752] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[138485] = {
			1576, -- [1]
			"Crimson Wake <Large Anima Golem>", -- [2]
		},
		[121601] = {
			1442, -- [1]
			"Harthak Stormcaller", -- [2]
		},
		[115844] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[16791] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[122497] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[128766] = {
			1303, -- [1]
			"Shado-Pan Ambusher", -- [2]
		},
		[122881] = {
			1505, -- [1]
			"Unstable Sha", -- [2]
		},
		[54356] = {
			1120, -- [1]
			"Stitched Colossus", -- [2]
		},
		[125312] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[15708] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[123649] = {
			1442, -- [1]
			"Kargesh Ribcrusher", -- [2]
		},
		[120195] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[122370] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[124673] = {
			1507, -- [1]
			"Sonic Pulse", -- [2]
		},
		[122754] = {
			1463, -- [1]
			"Garalon", -- [2]
		},
		[53333] = {
			217, -- [1]
			"Anub'ar Necromancer", -- [2]
		},
		[116997] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[76185] = {
			1040, -- [1]
			"Ascendant Lord Obsidius", -- [2]
		},
		[72219] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[107146] = {
			1419, -- [1]
			"Raigonn", -- [2]
		},
		[21749] = {
			423, -- [1]
			"Barbed Lasher", -- [2]
		},
		[74906] = {
			1036, -- [1]
			"Fire Cyclone", -- [2]
		},
		[120196] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[114183] = {
			1420, -- [1]
			"Scarlet Scholar", -- [2]
		},
		[123011] = {
			1505, -- [1]
			"Embodied Terror", -- [2]
		},
		[16172] = {
			479, -- [1]
			"Ghoul Ravener", -- [2]
		},
		[18103] = {
			1429, -- [1]
			"Doctor Theolen Krastinov", -- [2]
		},
		[123651] = {
			1442, -- [1]
			"Kargesh Ribcrusher", -- [2]
		},
		[125826] = {
			1501, -- [1]
			"Bubbling Resin", -- [2]
		},
		[119941] = {
			1465, -- [1]
			"Sap Puddle", -- [2]
		},
		[118022] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[122244] = {
			1464, -- [1]
			"Sik'thik Engineer", -- [2]
		},
		[18327] = {
			479, -- [1]
			"Baroness Anastari", -- [2]
		},
		[120453] = {
			1431, -- [1]
			"[*] Conjure Dread Spawn", -- [2]
		},
		[123012] = {
			1505, -- [1]
			"Embodied Terror", -- [2]
		},
		[127362] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[136190] = {
			1570, -- [1]
			"Sul the Sandcrawler", -- [2]
		},
		[120070] = {
			1465, -- [1]
			"Sap Puddle", -- [2]
		},
		[114185] = {
			1420, -- [1]
			"Scarlet Scholar", -- [2]
		},
		[43931] = {
			575, -- [1]
			"Enslaved Proto-Drake", -- [2]
		},
		[75676] = {
			1037, -- [1]
			"Twilight Zealot", -- [2]
		},
		[56405] = {
			1109, -- [1]
			"Gothik the Harvester", -- [2]
		},
		[137727] = {
			1572, -- [1]
			"Hungry Eye", -- [2]
		},
		[76188] = {
			1040, -- [1]
			"Ascendant Lord Obsidius", -- [2]
		},
		[136192] = {
			1559, -- [1]
			"Iron Qon", -- [2]
		},
		[76572] = {
			1036, -- [1]
			"Twilight Sadist", -- [2]
		},
		[122118] = {
			1434, -- [1]
			"Shadowy Minion", -- [2]
		},
		[122246] = {
			1464, -- [1]
			"Sik'thik Engineer", -- [2]
		},
		[136193] = {
			1559, -- [1]
			"[*] Arcing Lightning", -- [2]
		},
		[120455] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[75677] = {
			1037, -- [1]
			"Twilight Zealot", -- [2]
		},
		[546] = {
			1436, -- [1]
			7, -- [2]
		},
		[123014] = {
			1499, -- [1]
			"[*] Volatile Amber", -- [2]
		},
		[137729] = {
			1578, -- [1]
			"Flaming Head", -- [2]
		},
		[57557] = {
			1090, -- [1]
			"Sartharion", -- [2]
		},
		[123654] = {
			1442, -- [1]
			"Ming the Cunning", -- [2]
		},
		[135683] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[120200] = {
			1502, -- [1]
			"Sik'thik Amberwing", -- [2]
		},
		[134916] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[137731] = {
			1578, -- [1]
			"Flaming Head", -- [2]
		},
		[117514] = {
			1436, -- [1]
			"Undying Shadows", -- [2]
		},
		[28467] = {
			1114, -- [1]
			"Unstoppable Abomination", -- [2]
		},
		[28531] = {
			1119, -- [1]
			"Sapphiron", -- [2]
		},
		[116235] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[116363] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[55255] = {
			1121, -- [1]
			"Death Knight Captain", -- [2]
		},
		[9232] = {
			1425, -- [1]
			"High Inquisitor Whitemane", -- [2]
		},
		[114956] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[136710] = {
			1575, -- [1]
			"Risen Drakkari Champion", -- [2]
		},
		[119946] = {
			1442, -- [1]
			"Mu'Shiba", -- [2]
		},
		[114061] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[118283] = {
			1407, -- [1]
			"Emperor's Rage", -- [2]
		},
		[116364] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[134664] = {
			1559, -- [1]
			"Ro'shak", -- [2]
		},
		[134920] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[56407] = {
			1109, -- [1]
			"Spectral Trainee", -- [2]
		},
		[115213] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[111631] = {
			1426, -- [1]
			"Instructor Chillheart", -- [2]
		},
		[121994] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[114062] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[71203] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[116365] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[118540] = {
			1416, -- [1]
			"[*] Jade Serpent Wave", -- [2]
		},
		[124809] = {
			1507, -- [1]
			"Zar'thik Supplicant", -- [2]
		},
		[123018] = {
			1505, -- [1]
			"[*] Terrorize", -- [2]
		},
		[140296] = {
			1579, -- [1]
			"Thunder Lord", -- [2]
		},
		[21687] = {
			422, -- [1]
			"Noxxion", -- [2]
		},
		[119692] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[137226] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[121995] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[99606] = {
			1206, -- [1]
			"Alysrazor", -- [2]
		},
		[4962] = {
			479, -- [1]
			"Crypt Beast", -- [2]
		},
		[134668] = {
			1572, -- [1]
			"Roaming Fog", -- [2]
		},
		[137227] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[56408] = {
			1109, -- [1]
			"Spectral Death Knight", -- [2]
		},
		[137995] = {
			1576, -- [1]
			"Ritualist Xeron", -- [2]
		},
		[42463] = {
			1439, -- [1]
			2, -- [2]
		},
		[137228] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[119949] = {
			1442, -- [1]
			"Mu'Shiba", -- [2]
		},
		[71077] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[26613] = {
			1113, -- [1]
			"Instructor Razuvious", -- [2]
		},
		[137229] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[123020] = {
			1499, -- [1]
			"[*] Burning Amber", -- [2]
		},
		[125451] = {
			1501, -- [1]
			"Sha of Fear", -- [2]
		},
		[134415] = {
			1573, -- [1]
			"Gastropod", -- [2]
		},
		[117519] = {
			1409, -- [1]
			"Protector Kaolan", -- [2]
		},
		[123788] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[137230] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[111762] = {
			1427, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[122125] = {
			1498, -- [1]
			"[*] Corrosive Resin Pool", -- [2]
		},
		[137998] = {
			1576, -- [1]
			"Ritualist Malus", -- [2]
		},
		[69159] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[75428] = {
			1036, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[136719] = {
			1575, -- [1]
			"Farraki Wastewalker", -- [2]
		},
		[137231] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[113682] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[124173] = {
			1447, -- [1]
			"Sik'thik Vanguard", -- [2]
		},
		[120207] = {
			1436, -- [1]
			"Controller", -- [2]
		},
		[136209] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[136465] = {
			1575, -- [1]
			"Amani'shi Flame Caster", -- [2]
		},
		[75813] = {
			1044, -- [1]
			"Naz'jar Tempest Witch", -- [2]
		},
		[5394] = {
			1436, -- [1]
			7, -- [2]
		},
		[53467] = {
			218, -- [1]
			"Anub'arak", -- [2]
		},
		[136210] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[127628] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[57753] = {
			1090, -- [1]
			"Onyx Blaze Mistress", -- [2]
		},
		[123790] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[119952] = {
			1507, -- [1]
			"Light's Hammer <Smashval>", -- [2]
		},
		[69161] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[136723] = {
			1575, -- [1]
			"[*] Sand Trap", -- [2]
		},
		[137491] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[76070] = {
			1039, -- [1]
			"Beauty", -- [2]
		},
		[20153] = {
			1507, -- [1]
			"Infernal <Caries>", -- [2]
		},
		[50653] = {
			575, -- [1]
			"Enslaved Proto-Drake", -- [2]
		},
		[137492] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[118162] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[136725] = {
			1575, -- [1]
			"Farraki Wastewalker", -- [2]
		},
		[124815] = {
			1507, -- [1]
			"Sra'thik Shield Master", -- [2]
		},
		[69674] = {
			1104, -- [1]
			"Rotface", -- [2]
		},
		[57562] = {
			1090, -- [1]
			"Fire Cyclone", -- [2]
		},
		[127630] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[123792] = {
			1501, -- [1]
			"[*] Cry of Terror", -- [2]
		},
		[137494] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[135703] = {
			1579, -- [1]
			"[*] Static Shock", -- [2]
		},
		[138006] = {
			1577, -- [1]
			"[*] Electrified Waters", -- [2]
		},
		[136215] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[130701] = {
			1305, -- [1]
			"Sha of Violence", -- [2]
		},
		[112918] = {
			1303, -- [1]
			"Hateful Essence", -- [2]
		},
		[136216] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[115861] = {
			1395, -- [1]
			"Cobalt Guardian", -- [2]
		},
		[138264] = {
			1560, -- [1]
			"Faded Image of Xuen", -- [2]
		},
		[124817] = {
			1507, -- [1]
			"Sra'thik Shield Master", -- [2]
		},
		[11824] = {
			224, -- [1]
			"Twilight Elementalist", -- [2]
		},
		[136218] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[115350] = {
			1429, -- [1]
			"Lilian's Soul", -- [2]
		},
		[744] = {
			422, -- [1]
			"Vile Larva", -- [2]
		},
		[55964] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[122259] = {
			1464, -- [1]
			"Sik'thik Engineer", -- [2]
		},
		[69165] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[118421] = {
			1434, -- [1]
			"Shadowy Minion", -- [2]
		},
		[106651] = {
			1412, -- [1]
			"Ook-Ook", -- [2]
		},
		[138267] = {
			1560, -- [1]
			"Faded Image of Yu'lon", -- [2]
		},
		[119573] = {
			1441, -- [1]
			"[*] Ring of Fire", -- [2]
		},
		[121876] = {
			1498, -- [1]
			"Sra'thik Amber-Trapper", -- [2]
		},
		[117910] = {
			1436, -- [1]
			"Qiang the Merciless", -- [2]
		},
		[69166] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[124947] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[139548] = {
			1578, -- [1]
			"Megaera", -- [2]
		},
		[53406] = {
			216, -- [1]
			"Hadronox", -- [2]
		},
		[55645] = {
			1109, -- [1]
			"Unrelenting Trainee", -- [2]
		},
		[136990] = {
			1570, -- [1]
			"Frost King Malakk", -- [2]
		},
		[135199] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[139549] = {
			1578, -- [1]
			"Megaera", -- [2]
		},
		[52127] = {
			1436, -- [1]
			7, -- [2]
		},
		[136991] = {
			1570, -- [1]
			"[*] Biting Cold", -- [2]
		},
		[70063] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[136480] = {
			1575, -- [1]
			"Amani'shi Beast Shaman", -- [2]
		},
		[70447] = {
			1102, -- [1]
			"Volatile Ooze", -- [2]
		},
		[113690] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[117912] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[120087] = {
			1442, -- [1]
			"Whilring Dervish <Ming the Cunning>", -- [2]
		},
		[42724] = {
			575, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[136225] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[124821] = {
			1501, -- [1]
			"Kor'thik Reaver", -- [2]
		},
		[139296] = {
			1573, -- [1]
			"Hatchling", -- [2]
		},
		[139552] = {
			1578, -- [1]
			"Megaera", -- [2]
		},
		[134691] = {
			1559, -- [1]
			"Iron Qon", -- [2]
		},
		[113691] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[111772] = {
			1426, -- [1]
			"Scholomance Acolyte", -- [2]
		},
		[41637] = {
			1499, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[15039] = {
			224, -- [1]
			"Twilight Elementalist", -- [2]
		},
		[118297] = {
			1395, -- [1]
			"Primal Fire Elemental", -- [2]
		},
		[136739] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[136995] = {
			1574, -- [1]
			"Viscous Horror", -- [2]
		},
		[139298] = {
			1573, -- [1]
			"Hatchling", -- [2]
		},
		[137507] = {
			1577, -- [1]
			"[*] Implosion", -- [2]
		},
		[125206] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[136228] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[136740] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[28407] = {
			1120, -- [1]
			"Shade of Naxxramas", -- [2]
		},
		[87081] = {
			220, -- [1]
			"Blackfathom Myrmidon", -- [2]
		},
		[117914] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[136741] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[57374] = {
			1121, -- [1]
			"Lady Blaumeux", -- [2]
		},
		[16509] = {
			1429, -- [1]
			"Doctor Theolen Krastinov", -- [2]
		},
		[104993] = {
			1436, -- [1]
			"[*] Jade Spirit", -- [2]
		},
		[15471] = {
			482, -- [1]
			"Crypt Crawler", -- [2]
		},
		[118299] = {
			1500, -- [1]
			"Energy Charge", -- [2]
		},
		[136487] = {
			1575, -- [1]
			"Amani'shi Beast Shaman", -- [2]
		},
		[122777] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[121114] = {
			1465, -- [1]
			"Sik'thik Amber-Weaver", -- [2]
		},
		[123417] = {
			1507, -- [1]
			"Sra'thik Shield Master", -- [2]
		},
		[137000] = {
			1574, -- [1]
			"Viscous Horror", -- [2]
		},
		[111775] = {
			1429, -- [1]
			"Lilian Voss", -- [2]
		},
		[136489] = {
			1575, -- [1]
			"Lightning Nova Totem <Amani'shi Beast Shaman>", -- [2]
		},
		[75697] = {
			1037, -- [1]
			"Twilight Zealot", -- [2]
		},
		[118940] = {
			1509, -- [1]
			"Glintrok Oracle", -- [2]
		},
		[139816] = {
			1578, -- [1]
			"Frozen Head", -- [2]
		},
		[111008] = {
			1424, -- [1]
			"Scarlet Zealot", -- [2]
		},
		[136490] = {
			1575, -- [1]
			"Lightning Nova Totem <Amani'shi Beast Shaman>", -- [2]
		},
		[57759] = {
			1090, -- [1]
			"Onyx Flight Captain", -- [2]
		},
		[3490] = {
			225, -- [1]
			"Aku'mai", -- [2]
		},
		[139817] = {
			1578, -- [1]
			"Frozen Head", -- [2]
		},
		[54049] = {
			1507, -- [1]
			"Droodrom <Caries>", -- [2]
		},
		[879] = {
			1439, -- [1]
			2, -- [2]
		},
		[116510] = {
			60009, -- [1]
			"Troll Explosives", -- [2]
		},
		[139818] = {
			1578, -- [1]
			"Venomous Head", -- [2]
		},
		[111649] = {
			1429, -- [1]
			"Unknown", -- [2]
		},
		[117918] = {
			1436, -- [1]
			"Flanking Mogu", -- [2]
		},
		[139819] = {
			1578, -- [1]
			"Venomous Head", -- [2]
		},
		[122780] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[137261] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[123036] = {
			1505, -- [1]
			"Fright Spawn", -- [2]
		},
		[139820] = {
			1578, -- [1]
			"Arcane Head", -- [2]
		},
		[111010] = {
			1424, -- [1]
			"Scarlet Zealot", -- [2]
		},
		[3606] = {
			1507, -- [1]
			"Searing Totem <Jadamssham>", -- [2]
		},
		[139821] = {
			1578, -- [1]
			"Arcane Head", -- [2]
		},
		[118303] = {
			1436, -- [1]
			"Undying Shadows", -- [2]
		},
		[8435] = {
			220, -- [1]
			"Lady Sarevess", -- [2]
		},
		[77747] = {
			1436, -- [1]
			7, -- [2]
		},
		[129178] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[139822] = {
			1578, -- [1]
			"Flaming Head", -- [2]
		},
		[60639] = {
			1090, -- [1]
			"Vesperon", -- [2]
		},
		[123421] = {
			1507, -- [1]
			"Kor'thik Slicer", -- [2]
		},
		[136752] = {
			1560, -- [1]
			"Lu'lin", -- [2]
		},
		[115745] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[117920] = {
			1436, -- [1]
			"Qiang the Merciless", -- [2]
		},
		[118048] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[87471] = {
			1439, -- [1]
			"Brineshell Snapper", -- [2]
		},
		[122398] = {
			1499, -- [1]
			"Mutated Construct", -- [2]
		},
		[136753] = {
			1565, -- [1]
			"Greater Cave Bat", -- [2]
		},
		[57377] = {
			1121, -- [1]
			"Sir Zeliek", -- [2]
		},
		[133939] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[123422] = {
			1507, -- [1]
			"Kor'thik Slicer", -- [2]
		},
		[136498] = {
			1559, -- [1]
			"Iron Qon's Spear <Iron Qon>", -- [2]
		},
		[117665] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[117921] = {
			1436, -- [1]
			"Qiang the Merciless", -- [2]
		},
		[118049] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[28089] = {
			1120, -- [1]
			"Thaddius", -- [2]
		},
		[113188] = {
			1430, -- [1]
			"Failed Student <Darkmaster Gandling>", -- [2]
		},
		[72376] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[42729] = {
			575, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[136245] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[13281] = {
			224, -- [1]
			"Twilight Elementalist", -- [2]
		},
		[122784] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[136246] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[107176] = {
			1412, -- [1]
			"Inflamed Hozen Brawler", -- [2]
		},
		[117539] = {
			1436, -- [1]
			"Undying Shadows", -- [2]
		},
		[135223] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[135991] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[136247] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[80182] = {
			1412, -- [1]
			"Drunken Hozen Brawler", -- [2]
		},
		[121762] = {
			1464, -- [1]
			"Sik'thik Builder", -- [2]
		},
		[135225] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[137528] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[42730] = {
			575, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[122402] = {
			1499, -- [1]
			"Amber Monstrosity", -- [2]
		},
		[122786] = {
			1463, -- [1]
			"[*] Broken Leg", -- [2]
		},
		[102572] = {
			1303, -- [1]
			"Azure Serpent", -- [2]
		},
		[49575] = {
			571, -- [1]
			"Dragonflayer Runecaster", -- [2]
		},
		[11922] = {
			423, -- [1]
			"Constrictor Vine", -- [2]
		},
		[120100] = {
			1442, -- [1]
			"Ming the Cunning", -- [2]
		},
		[114087] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[136507] = {
			1570, -- [1]
			"Frost King Malakk", -- [2]
		},
		[137531] = {
			1560, -- [1]
			"Lu'lin", -- [2]
		},
		[106923] = {
			1303, -- [1]
			"Azure Serpent", -- [2]
		},
		[70461] = {
			1105, -- [1]
			"Frost Freeze Trap", -- [2]
		},
		[123811] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[120101] = {
			1442, -- [1]
			"Ming the Cunning", -- [2]
		},
		[53030] = {
			216, -- [1]
			"Hadronox", -- [2]
		},
		[122532] = {
			1499, -- [1]
			"Living Amber", -- [2]
		},
		[139836] = {
			1578, -- [1]
			"Cinders", -- [2]
		},
		[140092] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[119590] = {
			1441, -- [1]
			"Ring of Fire", -- [2]
		},
		[123812] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[122149] = {
			1498, -- [1]
			"Zar'thik Battle-Mender", -- [2]
		},
		[136767] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[106413] = {
			1304, -- [1]
			"[*] Ball of Fire", -- [2]
		},
		[139838] = {
			1578, -- [1]
			"Venomous Head", -- [2]
		},
		[29306] = {
			1108, -- [1]
			"Gluth", -- [2]
		},
		[12626] = {
			479, -- [1]
			"Patchwork Horror", -- [2]
		},
		[136512] = {
			1575, -- [1]
			"Amani'shi Beast Shaman", -- [2]
		},
		[139839] = {
			1578, -- [1]
			"Venomous Head", -- [2]
		},
		[128419] = {
			1431, -- [1]
			"Dread Spawn <[*] Conjure Dread Spawn>", -- [2]
		},
		[118312] = {
			1409, -- [1]
			"Elder Asani", -- [2]
		},
		[136513] = {
			1575, -- [1]
			"Amani'shi Beast Shaman", -- [2]
		},
		[136769] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[71615] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[57381] = {
			1121, -- [1]
			"Lady Blaumeux", -- [2]
		},
		[139840] = {
			1578, -- [1]
			"Venomous Head", -- [2]
		},
		[136770] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[122151] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[138306] = {
			1560, -- [1]
			"[*] Serpent's Vitality", -- [2]
		},
		[114859] = {
			1430, -- [1]
			"Bored Student", -- [2]
		},
		[139842] = {
			1578, -- [1]
			"Frozen Head", -- [2]
		},
		[32409] = {
			1406, -- [1]
			"[*] Shadow Word: Death", -- [2]
		},
		[119593] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[121896] = {
			1498, -- [1]
			"Wind Lord Mel'jarak", -- [2]
		},
		[131655] = {
			1465, -- [1]
			"Sap Puddle", -- [2]
		},
		[138052] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[122408] = {
			1499, -- [1]
			"Amber Monstrosity", -- [2]
		},
		[134470] = {
			1573, -- [1]
			"Bow Fly Swarm", -- [2]
		},
		[71617] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[124967] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[129189] = {
			1431, -- [1]
			"[*] Sha Globe", -- [2]
		},
		[117163] = {
			1409, -- [1]
			"Elder Asani", -- [2]
		},
		[119722] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[124072] = {
			1504, -- [1]
			"Set'thik Gustwing", -- [2]
		},
		[11443] = {
			481, -- [1]
			"Thuzadin Shadowcaster", -- [2]
		},
		[51945] = {
			1436, -- [1]
			7, -- [2]
		},
		[122409] = {
			1498, -- [1]
			"Kor'thik Elite Blademaster", -- [2]
		},
		[134472] = {
			1573, -- [1]
			"Bow Fly Swarm", -- [2]
		},
		[33778] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[29307] = {
			1108, -- [1]
			"Zombie Chow", -- [2]
		},
		[136520] = {
			1559, -- [1]
			"Iron Qon's Spear <Iron Qon>", -- [2]
		},
		[115629] = {
			1425, -- [1]
			"Commander Durand", -- [2]
		},
		[121898] = {
			1498, -- [1]
			"Wind Lord Mel'jarak", -- [2]
		},
		[136521] = {
			1570, -- [1]
			"Sul the Sandcrawler", -- [2]
		},
		[106546] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[123050] = {
			1395, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[136010] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[72259] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[138569] = {
			1576, -- [1]
			"Massive Anima Golem", -- [2]
		},
		[107314] = {
			1419, -- [1]
			"Krik'thik Protectorate", -- [2]
		},
		[125865] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[53801] = {
			217, -- [1]
			"Anub'ar Crusher", -- [2]
		},
		[11971] = {
			219, -- [1]
			"Blindlight Murloc", -- [2]
		},
		[134476] = {
			1565, -- [1]
			"Rockfall", -- [2]
		},
		[114479] = {
			1427, -- [1]
			"Candlestick Mage", -- [2]
		},
		[116782] = {
			1407, -- [1]
			"[*] Titan Gas", -- [2]
		},
		[123051] = {
			1395, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[112944] = {
			1413, -- [1]
			"Hoptallus", -- [2]
		},
		[70341] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[121644] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[125866] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[126122] = {
			1501, -- [1]
			"Dissonance Field", -- [2]
		},
		[122540] = {
			1499, -- [1]
			"Amber Monstrosity", -- [2]
		},
		[55209] = {
			1121, -- [1]
			"Death Knight", -- [2]
		},
		[134990] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[79937] = {
			1427, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[118958] = {
			1509, -- [1]
			"Glintrok Ironhide", -- [2]
		},
		[119086] = {
			1431, -- [1]
			"Terror Spawn", -- [2]
		},
		[106932] = {
			1303, -- [1]
			"Azure Serpent", -- [2]
		},
		[70342] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[116016] = {
			1423, -- [1]
			"Scarlet Purifier", -- [2]
		},
		[118191] = {
			1409, -- [1]
			"Minion of Fear", -- [2]
		},
		[138318] = {
			1560, -- [1]
			"[*] Crane Rush", -- [2]
		},
		[124844] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[79938] = {
			1427, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[76100] = {
			1045, -- [1]
			"Commander Ulthok", -- [2]
		},
		[123437] = {
			1507, -- [1]
			"Set'thik Swiftblade", -- [2]
		},
		[70343] = {
			1102, -- [1]
			"Growing Ooze Puddle", -- [2]
		},
		[124077] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[54954] = {
			571, -- [1]
			"Ticking Bomb <Dragonflayer Strategist>", -- [2]
		},
		[12739] = {
			479, -- [1]
			"Thuzadin Shadowcaster", -- [2]
		},
		[128555] = {
			1463, -- [1]
			"Garalon", -- [2]
		},
		[31707] = {
			1500, -- [1]
			"Water Elemental", -- [2]
		},
		[124845] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[118960] = {
			1442, -- [1]
			"Glintrok Ironhide", -- [2]
		},
		[136018] = {
			1579, -- [1]
			"Lesser Diffused Lightning <Ravenppc>", -- [2]
		},
		[115250] = {
			1423, -- [1]
			"Empowering Spirit", -- [2]
		},
		[78660] = {
			60009, -- [1]
			"Zandalari Terror Rider", -- [2]
		},
		[135251] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[116018] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[136019] = {
			1579, -- [1]
			"Diffused Lightning", -- [2]
		},
		[122415] = {
			1499, -- [1]
			"Amber Monstrosity", -- [2]
		},
		[54123] = {
			1116, -- [1]
			"Maexxna", -- [2]
		},
		[75590] = {
			1036, -- [1]
			"Twilight Torturer", -- [2]
		},
		[28157] = {
			1111, -- [1]
			"Grobbulus", -- [2]
		},
		[75846] = {
			1038, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[118961] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[106807] = {
			1412, -- [1]
			"Ook-Ook", -- [2]
		},
		[76230] = {
			1046, -- [1]
			"[*] Mind Fog", -- [2]
		},
		[140626] = {
			1573, -- [1]
			"Fungal Growth", -- [2]
		},
		[115507] = {
			1423, -- [1]
			"Scarlet Flamethrower", -- [2]
		},
		[125870] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[133974] = {
			1565, -- [1]
			"Whirl Turtle", -- [2]
		},
		[13299] = {
			480, -- [1]
			"Unknown <Nerub'enkan>", -- [2]
		},
		[137045] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[123184] = {
			1501, -- [1]
			"Dissonance Field", -- [2]
		},
		[76487] = {
			1036, -- [1]
			"Twilight Torturer", -- [2]
		},
		[125871] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[111670] = {
			1425, -- [1]
			"Scarlet Zealot", -- [2]
		},
		[124080] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[138070] = {
			1579, -- [1]
			"Unharnessed Power", -- [2]
		},
		[16867] = {
			479, -- [1]
			"Baroness Anastari", -- [2]
		},
		[137303] = {
			1570, -- [1]
			"Blessed Loa Spirit", -- [2]
		},
		[118963] = {
			1509, -- [1]
			"Glintrok Skulker", -- [2]
		},
		[123697] = {
			1505, -- [1]
			"Unstable Sha", -- [2]
		},
		[111671] = {
			1406, -- [1]
			"Raigonn", -- [2]
		},
		[122034] = {
			1464, -- [1]
			"Shek'zeer Clutch-Keeper", -- [2]
		},
		[55212] = {
			1121, -- [1]
			"Death Knight", -- [2]
		},
		[124849] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[17475] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[142423] = {
			1436, -- [1]
			"Wild Mushroom", -- [2]
		},
		[129711] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[117685] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[122547] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[75722] = {
			1044, -- [1]
			"Lady Naz'jar", -- [2]
		},
		[14099] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[114999] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[76234] = {
			1046, -- [1]
			"Mindbender Ghur'sha", -- [2]
		},
		[115511] = {
			1423, -- [1]
			"Scarlet Centurion", -- [2]
		},
		[28478] = {
			1114, -- [1]
			"Kel'Thuzad", -- [2]
		},
		[28542] = {
			1119, -- [1]
			"Sapphiron", -- [2]
		},
		[120629] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[75851] = {
			1038, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[114872] = {
			1430, -- [1]
			"Bored Student", -- [2]
		},
		[76363] = {
			1047, -- [1]
			"Unstable Corruption", -- [2]
		},
		[86726] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[107324] = {
			1419, -- [1]
			"Krik'thik Protectorate", -- [2]
		},
		[125875] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[119862] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[118071] = {
			1390, -- [1]
			"Siphoning Shield", -- [2]
		},
		[130609] = {
			1436, -- [1]
			7, -- [2]
		},
		[136543] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[134752] = {
			1572, -- [1]
			"Eye Sentry", -- [2]
		},
		[120758] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[115129] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[70351] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[134753] = {
			1572, -- [1]
			"Eye Sentry", -- [2]
		},
		[125876] = {
			1501, -- [1]
			"Zar'thik Augurer", -- [2]
		},
		[42740] = {
			571, -- [1]
			"Dragonflayer Runecaster", -- [2]
		},
		[116281] = {
			1395, -- [1]
			"Cobalt Mine", -- [2]
		},
		[134754] = {
			1572, -- [1]
			"Eye Sentry", -- [2]
		},
		[120759] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[137313] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[17476] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[112955] = {
			1421, -- [1]
			"Scarlet Defender", -- [2]
		},
		[140640] = {
			1573, -- [1]
			"Nest Guardian", -- [2]
		},
		[134755] = {
			1572, -- [1]
			"[*] Eye Sore", -- [2]
		},
		[125877] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[117945] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[140129] = {
			1573, -- [1]
			"Juvenile", -- [2]
		},
		[120760] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[115003] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[129460] = {
			1395, -- [1]
			"Cobalt Guardian", -- [2]
		},
		[136548] = {
			1579, -- [1]
			"Ball Lightning <Lei Shen>", -- [2]
		},
		[76622] = {
			60009, -- [1]
			"Zandalari Terror Rider", -- [2]
		},
		[139107] = {
			1572, -- [1]
			"Appraising Eye", -- [2]
		},
		[115771] = {
			1395, -- [1]
			"Cobalt Guardian", -- [2]
		},
		[28479] = {
			1114, -- [1]
			"Kel'Thuzad", -- [2]
		},
		[116027] = {
			1413, -- [1]
			"Hopper", -- [2]
		},
		[116155] = {
			1414, -- [1]
			"Yeasty Brew Alemental", -- [2]
		},
		[120761] = {
			1465, -- [1]
			"Vizier Jin'bak", -- [2]
		},
		[106560] = {
			1414, -- [1]
			"[*] Gushing Brew", -- [2]
		},
		[106944] = {
			1305, -- [1]
			"Destroying Sha", -- [2]
		},
		[136294] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[134759] = {
			1559, -- [1]
			"Iron Qon's Spear <Iron Qon>", -- [2]
		},
		[136295] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[15587] = {
			224, -- [1]
			"Twilight Lord Kelris", -- [2]
		},
		[114493] = {
			1427, -- [1]
			"Reanimated Corpse", -- [2]
		},
		[106433] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[133737] = {
			1572, -- [1]
			"Yellow Eye", -- [2]
		},
		[123705] = {
			1506, -- [1]
			"[*] Scary Fog", -- [2]
		},
		[123833] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[117948] = {
			1436, -- [1]
			"Qiang the Merciless", -- [2]
		},
		[106434] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[17477] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[133739] = {
			1572, -- [1]
			"Yellow Eye", -- [2]
		},
		[27808] = {
			1114, -- [1]
			"Kel'Thuzad", -- [2]
		},
		[107202] = {
			1303, -- [1]
			"[*] Invoke Lightning", -- [2]
		},
		[123962] = {
			1498, -- [1]
			"Kor'thik Elite Blademaster", -- [2]
		},
		[30111] = {
			1109, -- [1]
			"Plague Beast", -- [2]
		},
		[139114] = {
			1570, -- [1]
			"Gurubashi Berserker", -- [2]
		},
		[106563] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[121148] = {
			1500, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[140138] = {
			1578, -- [1]
			"Arcane Head", -- [2]
		},
		[123707] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[34299] = {
			1504, -- [1]
			10, -- [2]
		},
		[40504] = {
			423, -- [1]
			"Razorlash", -- [2]
		},
		[126266] = {
			1436, -- [1]
			7, -- [2]
		},
		[131951] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[122556] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[81744] = {
			1436, -- [1]
			7, -- [2]
		},
		[22595] = {
			423, -- [1]
			"Creeping Sludge", -- [2]
		},
		[3599] = {
			1436, -- [1]
			7, -- [2]
		},
		[131952] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[138349] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[132464] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[8391] = {
			226, -- [1]
			"Aku'mai Snapjaw", -- [2]
		},
		[134256] = {
			1573, -- [1]
			"[*] Slimed", -- [2]
		},
		[115009] = {
			1303, -- [1]
			"Shado-Pan Stormbringer", -- [2]
		},
		[132466] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[76628] = {
			1039, -- [1]
			"Lucky", -- [2]
		},
		[8599] = {
			479, -- [1]
			"Plague Ghoul", -- [2]
		},
		[31551] = {
			575, -- [1]
			"Dragonflayer Heartsplitter", -- [2]
		},
		[54962] = {
			571, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[139869] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[114242] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[132467] = {
			1390, -- [1]
			"Cursed Mogu Sculpture", -- [2]
		},
		[136817] = {
			1575, -- [1]
			"War-God Jalak", -- [2]
		},
		[76207] = {
			1046, -- [1]
			"Mindbender Ghur'sha", -- [2]
		},
		[139537] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[17478] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[123198] = {
			1499, -- [1]
			"[*] Volatile Amber", -- [2]
		},
		[136050] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[119360] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[138609] = {
			1576, -- [1]
			"Massive Anima Golem", -- [2]
		},
		[114182] = {
			1420, -- [1]
			"Scarlet Scholar", -- [2]
		},
		[117697] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[115139] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[113859] = {
			1426, -- [1]
			"[*] Arcane Bomb", -- [2]
		},
		[139889] = {
			1578, -- [1]
			"Torrent of Ice", -- [2]
		},
		[136751] = {
			1565, -- [1]
			"Greater Cave Bat", -- [2]
		},
		[10966] = {
			422, -- [1]
			"Noxxion", -- [2]
		},
		[70460] = {
			1105, -- [1]
			"Frost Freeze Trap", -- [2]
		},
		[115650] = {
			1414, -- [1]
			"Sudsy Brew Alemental", -- [2]
		},
		[124862] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[48400] = {
			571, -- [1]
			"Unknown", -- [2]
		},
		[140636] = {
			1570, -- [1]
			"Farraki Sand Conjurer", -- [2]
		},
		[106823] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[138099] = {
			1576, -- [1]
			"Ritualist Malus", -- [2]
		},
		[125502] = {
			1499, -- [1]
			"Amber Globule", -- [2]
		},
		[119489] = {
			1439, -- [1]
			"Sha of Anger", -- [2]
		},
		[117570] = {
			1439, -- [1]
			"Figment of Doubt", -- [2]
		},
		[125886] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[3815] = {
			225, -- [1]
			"Aku'mai", -- [2]
		},
		[117954] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[15284] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[42745] = {
			575, -- [1]
			"Savage Worg", -- [2]
		},
		[53472] = {
			218, -- [1]
			"Anub'arak", -- [2]
		},
		[114942] = {
			1507, -- [1]
			"Healing Tide Totem <Linzun>", -- [2]
		},
		[136821] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[119476] = {
			1447, -- [1]
			"General Pa'valak", -- [2]
		},
		[71769] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[116595] = {
			60009, -- [1]
			"Zandalari Infiltrator", -- [2]
		},
		[134007] = {
			1572, -- [1]
			"Wandering Eye", -- [2]
		},
		[115140] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[28833] = {
			1121, -- [1]
			"Lady Blaumeux", -- [2]
		},
		[28865] = {
			1121, -- [1]
			"Unknown", -- [2]
		},
		[115524] = {
			1423, -- [1]
			"Frenzied Spirit", -- [2]
		},
		[13445] = {
			227, -- [1]
			"Bloodhound", -- [2]
		},
		[117052] = {
			1409, -- [1]
			"Elder Regail", -- [2]
		},
		[117955] = {
			1409, -- [1]
			"[*] Expelled Corruption", -- [2]
		},
		[53617] = {
			218, -- [1]
			"Anub'ar Venomancer", -- [2]
		},
		[121981] = {
			1502, -- [1]
			"Sik'thik Demolisher", -- [2]
		},
		[116784] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[138300] = {
			1560, -- [1]
			"[*] Fortitude of the Ox", -- [2]
		},
		[69278] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[69789] = {
			1104, -- [1]
			"[*] Ooze Flood", -- [2]
		},
		[133946] = {
			1565, -- [1]
			"Tortos", -- [2]
		},
		[75992] = {
			1044, -- [1]
			"Naz'jar Tempest Witch", -- [2]
		},
		[117187] = {
			1409, -- [1]
			"Elder Regail", -- [2]
		},
		[52469] = {
			216, -- [1]
			"Watcher Silthik", -- [2]
		},
		[136154] = {
			1572, -- [1]
			"Crimson Fog", -- [2]
		},
		[48503] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[139992] = {
			1578, -- [1]
			"Arcane Head", -- [2]
		},
		[125888] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[119875] = {
			1447, -- [1]
			"General Pa'valak", -- [2]
		},
		[119983] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[113969] = {
			1421, -- [1]
			"Scarlet Defender", -- [2]
		},
		[134010] = {
			1572, -- [1]
			"Wandering Eye", -- [2]
		},
		[106808] = {
			1412, -- [1]
			"Ook-Ook", -- [2]
		},
		[106422] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[136413] = {
			1572, -- [1]
			"Mind's Eye", -- [2]
		},
		[70106] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[116805] = {
			1407, -- [1]
			"Titan Spark", -- [2]
		},
		[17479] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[8004] = {
			1436, -- [1]
			7, -- [2]
		},
		[134011] = {
			1565, -- [1]
			"[*] Spinning Shell", -- [2]
		},
		[27810] = {
			1114, -- [1]
			"Kel'Thuzad", -- [2]
		},
		[139991] = {
			1578, -- [1]
			"Arcane Head", -- [2]
		},
		[70492] = {
			1102, -- [1]
			"Volatile Ooze", -- [2]
		},
		[117701] = {
			1436, -- [1]
			"Zian of the Endless Shadow", -- [2]
		},
		[117829] = {
			1436, -- [1]
			"[*] Cowardice", -- [2]
		},
		[17235] = {
			480, -- [1]
			"Nerub'enkan", -- [2]
		},
		[116038] = {
			1395, -- [1]
			"Jasper Guardian", -- [2]
		},
		[111735] = {
			1419, -- [1]
			"Tar", -- [2]
		},
		[120388] = {
			1431, -- [1]
			"Dread Spawn <[*] Conjure Dread Spawn>", -- [2]
		},
		[52086] = {
			216, -- [1]
			"Watcher Silthik", -- [2]
		},
		[116550] = {
			1407, -- [1]
			"Emperor's Strength", -- [2]
		},
		[137176] = {
			1579, -- [1]
			"[*] Overloaded Circuits", -- [2]
		},
		[118853] = {
			1500, -- [1]
			"Empyreal Focus", -- [2]
		},
		[121284] = {
			1464, -- [1]
			"Wing Leader Ner'onok", -- [2]
		},
		[106827] = {
			1305, -- [1]
			"Sha of Violence", -- [2]
		},
		[70109] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[52534] = {
			216, -- [1]
			"Anub'ar Shadowcaster", -- [2]
		},
		[130078] = {
			1505, -- [1]
			"Unstable Sha", -- [2]
		},
		[76634] = {
			1047, -- [1]
			"Tainted Sentry", -- [2]
		},
		[140502] = {
			1572, -- [1]
			"[*] Eye Sore", -- [2]
		},
		[42739] = {
			575, -- [1]
			"[*] Woe Strike", -- [2]
		},
		[114474] = {
			1427, -- [1]
			"Candlestick Mage", -- [2]
		},
		[54965] = {
			571, -- [1]
			"Dragonflayer Runecaster", -- [2]
		},
		[129262] = {
			1509, -- [1]
			"Gekkan", -- [2]
		},
		[116295] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[136573] = {
			1575, -- [1]
			"Frozen Orb <Drakkari Frozen Warlord>", -- [2]
		},
		[118917] = {
			1509, -- [1]
			"Glintrok Hexxer", -- [2]
		},
		[41635] = {
			1499, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[137341] = {
			1560, -- [1]
			"Beast of Nightmares", -- [2]
		},
		[123504] = {
			1501, -- [1]
			"Dissonance Field", -- [2]
		},
		[124656] = {
			1405, -- [1]
			"Great Wall Explosion Caster Stalker", -- [2]
		},
		[131968] = {
			1447, -- [1]
			"Sik'thik Battle-Mender", -- [2]
		},
		[136021] = {
			1579, -- [1]
			"Greater Diffused Lightning", -- [2]
		},
		[136937] = {
			1570, -- [1]
			"[*] Frostbite", -- [2]
		},
		[122413] = {
			1499, -- [1]
			"Amber Monstrosity", -- [2]
		},
		[128238] = {
			1441, -- [1]
			"Gurthan Swiftblade", -- [2]
		},
		[119922] = {
			1442, -- [1]
			"Kuai the Brute", -- [2]
		},
		[76807] = {
			1044, -- [1]
			"Naz'jar Invader", -- [2]
		},
		[116040] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[106929] = {
			1305, -- [1]
			"Consuming Sha", -- [2]
		},
		[138032] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[138453] = {
			1576, -- [1]
			"Anima Golem", -- [2]
		},
		[117235] = {
			1409, -- [1]
			"Corrupted Waters <Elder Asani>", -- [2]
		},
		[116008] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[125310] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[82137] = {
			1036, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[123461] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[125508] = {
			1499, -- [1]
			"Amber Globule", -- [2]
		},
		[121414] = {
			1465, -- [1]
			"Vizier Jin'bak", -- [2]
		},
		[119495] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[123717] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[123845] = {
			1501, -- [1]
			"Heart of Fear", -- [2]
		},
		[38462] = {
			1111, -- [1]
			"Unknown", -- [2]
		},
		[113866] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[54966] = {
			571, -- [1]
			"Dragonflayer Runecaster", -- [2]
		},
		[114548] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[116297] = {
			1405, -- [1]
			"[*] Strafing Run", -- [2]
		},
		[120519] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[55222] = {
			1121, -- [1]
			"Death Knight Captain", -- [2]
		},
		[102352] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[106797] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[17480] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[379] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[131972] = {
			1447, -- [1]
			"Sik'thik Battle-Mender", -- [2]
		},
		[136322] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[76509] = {
			1036, -- [1]
			"Crazed Mage", -- [2]
		},
		[75683] = {
			1044, -- [1]
			"Lady Naz'jar", -- [2]
		},
		[106423] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[117833] = {
			1436, -- [1]
			"Meng the Demented", -- [2]
		},
		[91350] = {
			1044, -- [1]
			"Geyser", -- [2]
		},
		[43665] = {
			575, -- [1]
			"Proto-Drake Rider", -- [2]
		},
		[58953] = {
			1090, -- [1]
			"Onyx Flight Captain", -- [2]
		},
		[110125] = {
			1439, -- [1]
			"Minion of Doubt", -- [2]
		},
		[116272] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[28131] = {
			1118, -- [1]
			"Patchwerk", -- [2]
		},
		[125464] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[137347] = {
			1570, -- [1]
			"High Priestess Mar'li", -- [2]
		},
		[112844] = {
			1573, -- [1]
			"Corpse Spider", -- [2]
		},
		[133765] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[117194] = {
			1407, -- [1]
			"Jan-xi", -- [2]
		},
		[81748] = {
			1407, -- [1]
			7, -- [2]
		},
		[107215] = {
			1397, -- [1]
			"Mantid Munitions", -- [2]
		},
		[115147] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[106871] = {
			1305, -- [1]
			"Sha of Violence", -- [2]
		},
		[38463] = {
			1111, -- [1]
			"Grobbulus Cloud <Grobbulus>", -- [2]
		},
		[115458] = {
			1405, -- [1]
			"[*] Acid Bomb", -- [2]
		},
		[117961] = {
			1436, -- [1]
			"Qiang the Merciless", -- [2]
		},
		[75998] = {
			1044, -- [1]
			"Naz'jar Honor Guard", -- [2]
		},
		[55095] = {
			1579, -- [1]
			"Rune Weapon", -- [2]
		},
		[120521] = {
			1431, -- [1]
			"[*] Waterspout", -- [2]
		},
		[136837] = {
			1572, -- [1]
			"Hidden Fog", -- [2]
		},
		[117204] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[124999] = {
			1406, -- [1]
			"Great Wall Explosion Caster Stalker", -- [2]
		},
		[9256] = {
			1425, -- [1]
			"High Inquisitor Whitemane", -- [2]
		},
		[133767] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[55543] = {
			1113, -- [1]
			"Instructor Razuvious", -- [2]
		},
		[16553] = {
			479, -- [1]
			"Ghoul Ravener", -- [2]
		},
		[136189] = {
			1570, -- [1]
			"Sul the Sandcrawler", -- [2]
		},
		[122479] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[57846] = {
			571, -- [1]
			"Dragonflayer Ironhelm", -- [2]
		},
		[49722] = {
			575, -- [1]
			"Enslaved Proto-Drake", -- [2]
		},
		[16869] = {
			481, -- [1]
			"Maleki the Pallid", -- [2]
		},
		[133768] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[121245] = {
			1390, -- [1]
			"Cursed Mogu Sculpture", -- [2]
		},
		[120394] = {
			1431, -- [1]
			"Dread Spawn <[*] Conjure Dread Spawn>", -- [2]
		},
		[119354] = {
			1447, -- [1]
			"Sik'thik Bladedancer", -- [2]
		},
		[139841] = {
			1578, -- [1]
			"Frozen Head", -- [2]
		},
		[137095] = {
			1572, -- [1]
			"Pale Fog", -- [2]
		},
		[121247] = {
			1390, -- [1]
			"Cursed Mogu Sculpture", -- [2]
		},
		[55078] = {
			1579, -- [1]
			"Rune Weapon", -- [2]
		},
		[110968] = {
			1424, -- [1]
			"Scarlet Purifier", -- [2]
		},
		[131978] = {
			1439, -- [1]
			"Unknown", -- [2]
		},
		[120201] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[116661] = {
			1500, -- [1]
			"[*] Energy Conduit", -- [2]
		},
		[57463] = {
			1121, -- [1]
			"Lady Blaumeux", -- [2]
		},
		[117708] = {
			1436, -- [1]
			"Meng the Demented", -- [2]
		},
		[15228] = {
			60009, -- [1]
			"Zandalari Fire-Dancer", -- [2]
		},
		[19505] = {
			1507, -- [1]
			"Droodrom <Caries>", -- [2]
		},
		[113959] = {
			1421, -- [1]
			"Scarlet Defender", -- [2]
		},
		[131979] = {
			1439, -- [1]
			"Unknown", -- [2]
		},
		[108446] = {
			575, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[139551] = {
			1578, -- [1]
			"Megaera", -- [2]
		},
		[52535] = {
			216, -- [1]
			"Anub'ar Shadowcaster", -- [2]
		},
		[138319] = {
			1573, -- [1]
			"[*] Feed Pool", -- [2]
		},
		[129077] = {
			1431, -- [1]
			"Terror Spawn", -- [2]
		},
		[76001] = {
			1044, -- [1]
			"Lady Naz'jar", -- [2]
		},
		[27993] = {
			1109, -- [1]
			"Spectral Horse", -- [2]
		},
		[119611] = {
			1303, -- [1]
			11, -- [2]
		},
		[27812] = {
			1114, -- [1]
			"Shadow Fissure <Kel'Thuzad>", -- [2]
		},
		[134539] = {
			1565, -- [1]
			"Rockfall", -- [2]
		},
		[53652] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[118047] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[117837] = {
			1436, -- [1]
			"Meng the Demented", -- [2]
		},
		[16868] = {
			479, -- [1]
			"Baroness Anastari", -- [2]
		},
		[113999] = {
			1428, -- [1]
			"Rattlegore", -- [2]
		},
		[116174] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[138378] = {
			1576, -- [1]
			"Anima Golem", -- [2]
		},
		[136587] = {
			1575, -- [1]
			"Gurubashi Venom Priest", -- [2]
		},
		[116558] = {
			1500, -- [1]
			"Empyreal Focus", -- [2]
		},
		[83914] = {
			1047, -- [1]
			"Vicious Mindlasher", -- [2]
		},
		[122955] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[76002] = {
			1038, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[115739] = {
			1425, -- [1]
			"Commander Durand", -- [2]
		},
		[134029] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[52538] = {
			216, -- [1]
			"Anub'ar Skirmisher", -- [2]
		},
		[123735] = {
			1501, -- [1]
			"Grand Empress Shek'zeer", -- [2]
		},
		[122406] = {
			1498, -- [1]
			"Wind Lord Mel'jarak", -- [2]
		},
		[12167] = {
			222, -- [1]
			"Lorgus Jett", -- [2]
		},
		[139470] = {
			1573, -- [1]
			"[*] Choking Gas", -- [2]
		},
		[126154] = {
			1507, -- [1]
			"Lightwell <Eleny>", -- [2]
		},
		[118094] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[120269] = {
			1502, -- [1]
			"[*] Caustic Tar", -- [2]
		},
		[114465] = {
			1424, -- [1]
			"[*] Scorched Earth", -- [2]
		},
		[136911] = {
			1570, -- [1]
			"Frost King Malakk", -- [2]
		},
		[76339] = {
			1046, -- [1]
			"Mindbender Ghur'sha", -- [2]
		},
		[29879] = {
			1114, -- [1]
			"Kel'Thuzad", -- [2]
		},
		[54290] = {
			216, -- [1]
			"Anub'ar Webspinner", -- [2]
		},
		[107275] = {
			1419, -- [1]
			"Krik'thik Engulfer", -- [2]
		},
		[121165] = {
			1441, -- [1]
			"Harthak Flameseeker", -- [2]
		},
		[134031] = {
			1565, -- [1]
			"Whirl Turtle", -- [2]
		},
		[121421] = {
			1465, -- [1]
			"Sik'thik Guardian", -- [2]
		},
		[40505] = {
			479, -- [1]
			"Plague Ghoul", -- [2]
		},
		[3589] = {
			479, -- [1]
			"Shrieking Banshee", -- [2]
		},
		[111570] = {
			1429, -- [1]
			"Lilian Voss", -- [2]
		},
		[118105] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[137614] = {
			1570, -- [1]
			"Living Sand", -- [2]
		},
		[12471] = {
			222, -- [1]
			"Fallenroot Hellcaller", -- [2]
		},
		[125843] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[126928] = {
			1504, -- [1]
			"Kor'thik Swarmguard", -- [2]
		},
		[113143] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[35779] = {
			1395, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[137103] = {
			1572, -- [1]
			"Hidden Fog", -- [2]
		},
		[116816] = {
			1390, -- [1]
			"[*] Wildfire Infusion", -- [2]
		},
		[138189] = {
			1560, -- [1]
			"Faded Image of Chi-Ji", -- [2]
		},
		[131792] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[52532] = {
			216, -- [1]
			"Anub'ar Warrior", -- [2]
		},
		[121422] = {
			1465, -- [1]
			"Sik'thik Guardian", -- [2]
		},
		[53322] = {
			216, -- [1]
			"Anub'ar Crypt Fiend", -- [2]
		},
		[137237] = {
			1575, -- [1]
			"Zandalari Dinomancer", -- [2]
		},
		[137104] = {
			1572, -- [1]
			"Hidden Fog", -- [2]
		},
		[58936] = {
			1090, -- [1]
			"Onyx Blaze Mistress", -- [2]
		},
		[122774] = {
			1463, -- [1]
			"Garalon", -- [2]
		},
		[136653] = {
			1575, -- [1]
			"Gurubashi Bloodlord", -- [2]
		},
		[16793] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[70358] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[114386] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[56910] = {
			1090, -- [1]
			"Sartharion", -- [2]
		},
		[106454] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[137994] = {
			1576, -- [1]
			"Ritualist Malus", -- [2]
		},
		[57465] = {
			1121, -- [1]
			"Sir Zeliek", -- [2]
		},
		[115026] = {
			1303, -- [1]
			"Unstable Energy", -- [2]
		},
		[106966] = {
			1305, -- [1]
			"Lesser Volatile Energy <Sha of Violence>", -- [2]
		},
		[117870] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[42972] = {
			571, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[136850] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[136722] = {
			1560, -- [1]
			"Moon Lotus", -- [2]
		},
		[119888] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[13692] = {
			227, -- [1]
			"Bloodhound", -- [2]
		},
		[111217] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[116178] = {
			1414, -- [1]
			"Sudsy Brew Alemental", -- [2]
		},
		[114259] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[113136] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[28167] = {
			1120, -- [1]
			"Thaddius", -- [2]
		},
		[132232] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[122959] = {
			1441, -- [1]
			"Xin the Weaponmaster", -- [2]
		},
		[137419] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[125390] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[140178] = {
			1578, -- [1]
			"Nether Wyrm", -- [2]
		},
		[123471] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[107223] = {
			1417, -- [1]
			"Sun", -- [2]
		},
		[17466] = {
			481, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[125902] = {
			1501, -- [1]
			"Kor'thik Warsinger", -- [2]
		},
		[70853] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[122064] = {
			1498, -- [1]
			"Sra'thik Amber-Trapper", -- [2]
		},
		[114004] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[140179] = {
			1578, -- [1]
			"Nether Wyrm", -- [2]
		},
		[115002] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[138644] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[136853] = {
			1579, -- [1]
			"[*] Lightning Bolt", -- [2]
		},
		[120785] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[139412] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[57466] = {
			1121, -- [1]
			"Sir Zeliek", -- [2]
		},
		[115033] = {
			1303, -- [1]
			"Unstable Energy", -- [2]
		},
		[138133] = {
			1577, -- [1]
			"Lightning Fissure", -- [2]
		},
		[54096] = {
			1110, -- [1]
			"Naxxramas Worshipper", -- [2]
		},
		[117526] = {
			1502, -- [1]
			"Sik'thik Swarmer", -- [2]
		},
		[115982] = {
			1434, -- [1]
			"Shadowy Minion", -- [2]
		},
		[70084] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[107268] = {
			1397, -- [1]
			"Saboteur Kip'tilak", -- [2]
		},
		[43649] = {
			573, -- [1]
			"Dalronn the Controller", -- [2]
		},
		[122193] = {
			1498, -- [1]
			"Zar'thik Battle-Mender", -- [2]
		},
		[72451] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[111216] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[29125] = {
			1113, -- [1]
			"Instructor Razuvious", -- [2]
		},
		[119374] = {
			1441, -- [1]
			"[*] Whirlwind", -- [2]
		},
		[120786] = {
			1500, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[123791] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[76008] = {
			1044, -- [1]
			"Lady Naz'jar", -- [2]
		},
		[106841] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[70123] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[55609] = {
			1109, -- [1]
			"Unrelenting Rider", -- [2]
		},
		[116374] = {
			1390, -- [1]
			"Lightning Charge", -- [2]
		},
		[55264] = {
			1121, -- [1]
			"Death Knight Captain", -- [2]
		},
		[76776] = {
			1044, -- [1]
			"Noxious Mire", -- [2]
		},
		[17393] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[122768] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[111642] = {
			1429, -- [1]
			"Lilian's Soul", -- [2]
		},
		[28470] = {
			1114, -- [1]
			"Guardian of Icecrown", -- [2]
		},
		[114262] = {
			1429, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[114390] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[123474] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[7941] = {
			1507, -- [1]
			"Primal Earth Elemental", -- [2]
		},
		[122962] = {
			1441, -- [1]
			"Quilen Guardian", -- [2]
		},
		[43651] = {
			573, -- [1]
			"Skarvald the Constructor", -- [2]
		},
		[136326] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[131996] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[43330] = {
			216, -- [1]
			"Anub'ar Necromancer", -- [2]
		},
		[19658] = {
			1507, -- [1]
			"Droodrom <Caries>", -- [2]
		},
		[117975] = {
			1409, -- [1]
			"Protector Kaolan", -- [2]
		},
		[124748] = {
			1501, -- [1]
			"Bubbling Resin", -- [2]
		},
		[137370] = {
			1577, -- [1]
			"[*] Thundering Throw", -- [2]
		},
		[43650] = {
			573, -- [1]
			"Dalronn the Controller", -- [2]
		},
		[137221] = {
			1559, -- [1]
			"Ro'shak", -- [2]
		},
		[116182] = {
			1414, -- [1]
			"Sudsy Brew Alemental <Sudsy Brew Alemental>", -- [2]
		},
		[107121] = {
			1406, -- [1]
			"Commander Ri'mok", -- [2]
		},
		[114056] = {
			1422, -- [1]
			"[*] Bloody Mess", -- [2]
		},
		[28134] = {
			1120, -- [1]
			"Feugen", -- [2]
		},
		[139866] = {
			1578, -- [1]
			"Frozen Head", -- [2]
		},
		[117558] = {
			1436, -- [1]
			"Undying Shadows", -- [2]
		},
		[137360] = {
			1560, -- [1]
			"[*] Corrupted Healing", -- [2]
		},
		[122504] = {
			1499, -- [1]
			"[*] Burning Amber", -- [2]
		},
		[115157] = {
			1423, -- [1]
			"Empowering Spirit", -- [2]
		},
		[75993] = {
			1044, -- [1]
			"[*] Lightning Surge", -- [2]
		},
		[28358] = {
			1118, -- [1]
			"Patchwork Golem", -- [2]
		},
		[136860] = {
			1570, -- [1]
			"[*] Quicksand", -- [2]
		},
		[75441] = {
			1036, -- [1]
			"Unknown", -- [2]
		},
		[130756] = {
			1501, -- [1]
			"Dissonance Field", -- [2]
		},
		[123175] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[135682] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[137344] = {
			1570, -- [1]
			"High Priestess Mar'li", -- [2]
		},
		[121173] = {
			1441, -- [1]
			"Kargesh Highguard", -- [2]
		},
		[138652] = {
			1570, -- [1]
			"Amani'shi Flame Chanter", -- [2]
		},
		[134814] = {
			1572, -- [1]
			"Eye Sentry", -- [2]
		},
		[120789] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[54517] = {
			1120, -- [1]
			"Stalagg", -- [2]
		},
		[123092] = {
			1463, -- [1]
			"[*] Pheromones", -- [2]
		},
		[115032] = {
			1303, -- [1]
			"Unstable Energy", -- [2]
		},
		[132000] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[138693] = {
			1570, -- [1]
			"Gurubashi Berserker", -- [2]
		},
		[138651] = {
			1570, -- [1]
			"Amani'shi Flame Chanter", -- [2]
		},
		[107356] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[137118] = {
			1560, -- [1]
			"Lu'lin", -- [2]
		},
		[137374] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[135583] = {
			1559, -- [1]
			"[*] Rushing Winds", -- [2]
		},
		[114009] = {
			1428, -- [1]
			"[*] Soulflame", -- [2]
		},
		[118936] = {
			1509, -- [1]
			"Glintrok Oracle", -- [2]
		},
		[71278] = {
			1102, -- [1]
			"[*] Choking Gas", -- [2]
		},
		[52586] = {
			216, -- [1]
			"Krik'thir the Gatewatcher", -- [2]
		},
		[63619] = {
			1395, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[123420] = {
			1507, -- [1]
			"Sra'thik Shield Master", -- [2]
		},
		[137375] = {
			1560, -- [1]
			"Lu'lin", -- [2]
		},
		[136478] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[133793] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[70127] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[115289] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[125652] = {
			1506, -- [1]
			"Parasitoid Sha", -- [2]
		},
		[107357] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[113626] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[58940] = {
			1090, -- [1]
			"Onyx Blaze Mistress", -- [2]
		},
		[117911] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[135680] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[111024] = {
			1424, -- [1]
			"Spirit of Redemption", -- [2]
		},
		[71279] = {
			1102, -- [1]
			"[*] Choking Gas Explosion", -- [2]
		},
		[118310] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[34655] = {
			1572, -- [1]
			"Venomous Snake", -- [2]
		},
		[116140] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[20271] = {
			1439, -- [1]
			2, -- [2]
		},
		[137633] = {
			1565, -- [1]
			"Humming Crystal", -- [2]
		},
		[133795] = {
			1572, -- [1]
			"Hungry Eye", -- [2]
		},
		[116819] = {
			1407, -- [1]
			"Qin-xi", -- [2]
		},
		[115290] = {
			1423, -- [1]
			"Thalnos the Soulrender", -- [2]
		},
		[115418] = {
			1406, -- [1]
			"Krik'thik Wind Shaper", -- [2]
		},
		[136646] = {
			1575, -- [1]
			"Living Poison", -- [2]
		},
		[137122] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[123467] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[122005] = {
			1499, -- [1]
			"[*] Molten Amber", -- [2]
		},
		[122199] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[55608] = {
			1109, -- [1]
			"Unrelenting Rider", -- [2]
		},
		[134820] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[138658] = {
			1570, -- [1]
			"[*] Eruption", -- [2]
		},
		[28135] = {
			1120, -- [1]
			"Feugen", -- [2]
		},
		[126933] = {
			1504, -- [1]
			"Kor'thik Swarmguard", -- [2]
		},
		[70117] = {
			1105, -- [1]
			"Sindragosa", -- [2]
		},
		[52540] = {
			216, -- [1]
			"Anub'ar Skirmisher", -- [2]
		},
		[137891] = {
			1570, -- [1]
			"High Priestess Mar'li", -- [2]
		},
		[139202] = {
			1572, -- [1]
			"[*] Blue Ray Tracking", -- [2]
		},
		[115291] = {
			1423, -- [1]
			"[*] Spirit Gale", -- [2]
		},
		[115419] = {
			1406, -- [1]
			"Krik'thik Wind Shaper", -- [2]
		},
		[134821] = {
			1579, -- [1]
			"[*] Discharged Energy", -- [2]
		},
		[132222] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[116821] = {
			1390, -- [1]
			"Wildfire Spark", -- [2]
		},
		[118106] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[133798] = {
			1572, -- [1]
			"Hungry Eye", -- [2]
		},
		[132007] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[138659] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[107046] = {
			1412, -- [1]
			"Sodden Hozen Brawler", -- [2]
		},
		[28747] = {
			216, -- [1]
			"Krik'thir the Gatewatcher", -- [2]
		},
		[77768] = {
			1036, -- [1]
			"Conflagration", -- [2]
		},
		[16429] = {
			481, -- [1]
			"Thuzadin Shadowcaster", -- [2]
		},
		[19645] = {
			479, -- [1]
			"Wailing Banshee", -- [2]
		},
		[125900] = {
			1501, -- [1]
			"Kor'thik Warsinger", -- [2]
		},
		[110099] = {
			1439, -- [1]
			"Minion of Doubt", -- [2]
		},
		[136577] = {
			1559, -- [1]
			"[*] Wind Storm", -- [2]
		},
		[28460] = {
			1114, -- [1]
			"Soul Weaver", -- [2]
		},
		[114219] = {
			1420, -- [1]
			"Scarlet Scholar", -- [2]
		},
		[137382] = {
			1560, -- [1]
			"Lurker in the Night", -- [2]
		},
		[131241] = {
			1305, -- [1]
			"Shado-Pan Fire Archer", -- [2]
		},
		[134912] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[116060] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[114141] = {
			1429, -- [1]
			"Krastinovian Carver", -- [2]
		},
		[120458] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[114184] = {
			1420, -- [1]
			"Scarlet Pupil", -- [2]
		},
		[122713] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[138688] = {
			1560, -- [1]
			"[*] Tidal Force", -- [2]
		},
		[125907] = {
			1501, -- [1]
			"Kor'thik Warsinger", -- [2]
		},
		[116956] = {
			1436, -- [1]
			7, -- [2]
		},
		[134926] = {
			1559, -- [1]
			"Iron Qon", -- [2]
		},
		[117960] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[119387] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[80564] = {
			1044, -- [1]
			"Lady Naz'jar", -- [2]
		},
		[137408] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[124998] = {
			1406, -- [1]
			"Great Wall Explosion Caster Stalker", -- [2]
		},
		[58942] = {
			1090, -- [1]
			"Onyx Brood General", -- [2]
		},
		[120027] = {
			1426, -- [1]
			"[*] Burn", -- [2]
		},
		[26662] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[111723] = {
			1419, -- [1]
			"Raigonn", -- [2]
		},
		[136361] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[130774] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[114654] = {
			1507, -- [1]
			"Kor'thik Slicer", -- [2]
		},
		[137129] = {
			1560, -- [1]
			"Star", -- [2]
		},
		[122970] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[137641] = {
			1570, -- [1]
			"[*] Soul Fragment", -- [2]
		},
		[72262] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[121190] = {
			1441, -- [1]
			"Quilen Guardian", -- [2]
		},
		[137663] = {
			1572, -- [1]
			"[*] Acidic Splash", -- [2]
		},
		[123610] = {
			62442, -- [1]
			"Corrupted Protector", -- [2]
		},
		[115010] = {
			1306, -- [1]
			"Unknown <Taran Zhu>", -- [2]
		},
		[137151] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[107279] = {
			1419, -- [1]
			"[*] Engulfing Winds", -- [2]
		},
		[12548] = {
			224, -- [1]
			"Twilight Elementalist", -- [2]
		},
		[68981] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[118163] = {
			1436, -- [1]
			"Subetai the Swift", -- [2]
		},
		[136175] = {
			1572, -- [1]
			"Amber Fog", -- [2]
		},
		[113620] = {
			1420, -- [1]
			"Book Case", -- [2]
		},
		[8364] = {
			220, -- [1]
			"Blackfathom Sea Witch", -- [2]
		},
		[126937] = {
			1504, -- [1]
			"Sra'thik Ambercaller", -- [2]
		},
		[111752] = {
			1427, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[113641] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[106851] = {
			1414, -- [1]
			"Yan-Zhu the Uncasked", -- [2]
		},
		[130008] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[146599] = {
			1407, -- [1]
			"Emperor's Rage", -- [2]
		},
		[136620] = {
			1579, -- [1]
			"Ball Lightning <Lei Shen>", -- [2]
		},
		[138923] = {
			1573, -- [1]
			"Ji-Kun", -- [2]
		},
		[111585] = {
			1429, -- [1]
			"Lilian Voss", -- [2]
		},
		[115840] = {
			1395, -- [1]
			"Cobalt Guardian", -- [2]
		},
		[75823] = {
			1037, -- [1]
			"Corla, Herald of Twilight", -- [2]
		},
		[123739] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[16430] = {
			479, -- [1]
			"Thuzadin Necromancer", -- [2]
		},
		[123655] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[138668] = {
			1570, -- [1]
			"Drakkari Frost Warden", -- [2]
		},
		[120669] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[137133] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[69750] = {
			1104, -- [1]
			"Unknown", -- [2]
		},
		[137645] = {
			1570, -- [1]
			"Gara'jal's Soul", -- [2]
		},
		[121181] = {
			1441, -- [1]
			"Harthak Flameseeker", -- [2]
		},
		[117215] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[136366] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[137405] = {
			1560, -- [1]
			"[*] Tears of the Sun", -- [2]
		},
		[127834] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[122852] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[121949] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[57984] = {
			1507, -- [1]
			"Set'thik Fanatic", -- [2]
		},
		[68983] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[120778] = {
			1502, -- [1]
			"Sik'thik Swarmer", -- [2]
		},
		[137390] = {
			1570, -- [1]
			"Shadowed Loa Spirit", -- [2]
		},
		[134397] = {
			1573, -- [1]
			"Gastropod", -- [2]
		},
		[120670] = {
			60009, -- [1]
			"Zandalari Fire-Dancer", -- [2]
		},
		[126939] = {
			1504, -- [1]
			"Sra'thik Ambercaller", -- [2]
		},
		[116711] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[137647] = {
			1577, -- [1]
			"[*] Lightning Strike", -- [2]
		},
		[121182] = {
			1441, -- [1]
			"Harthak Flameseeker", -- [2]
		},
		[122855] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[134321] = {
			1573, -- [1]
			"Hatchling", -- [2]
		},
		[119519] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[119647] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[119775] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[111715] = {
			1426, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[55821] = {
			1120, -- [1]
			"Stitched Colossus", -- [2]
		},
		[124253] = {
			1447, -- [1]
			"Sik'thik Bladedancer", -- [2]
		},
		[137404] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[69240] = {
			1097, -- [1]
			"Festergut", -- [2]
		},
		[136954] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[122718] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[106470] = {
			1304, -- [1]
			"[*] Ball of Fire", -- [2]
		},
		[106853] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[137905] = {
			1577, -- [1]
			"[*] Lightning Diffusion", -- [2]
		},
		[106854] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[124827] = {
			1501, -- [1]
			"Kor'thik Reaver", -- [2]
		},
		[107110] = {
			1416, -- [1]
			"[*] Jade Fire", -- [2]
		},
		[84721] = {
			1507, -- [1]
			"Frozen Orb <Pasta>", -- [2]
		},
		[117222] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[76031] = {
			1039, -- [1]
			"Beauty", -- [2]
		},
		[120160] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[120032] = {
			1507, -- [1]
			"[*] Dancing Steel", -- [2]
		},
		[130395] = {
			1395, -- [1]
			"Jasper Guardian", -- [2]
		},
		[134322] = {
			1573, -- [1]
			"Hatchling", -- [2]
		},
		[114646] = {
			1417, -- [1]
			"Haunting Sha", -- [2]
		},
		[116942] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[120672] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[28169] = {
			1111, -- [1]
			"Grobbulus", -- [2]
		},
		[120800] = {
			1502, -- [1]
			"Commander Vo'jak", -- [2]
		},
		[125638] = {
			1501, -- [1]
			"Heart of Fear", -- [2]
		},
		[28741] = {
			1116, -- [1]
			"Maexxna", -- [2]
		},
		[140210] = {
			1579, -- [1]
			"[*] Overloaded Circuits", -- [2]
		},
		[136372] = {
			1579, -- [1]
			"Unknown", -- [2]
		},
		[76618] = {
			1038, -- [1]
			"Conflagration", -- [2]
		},
		[123743] = {
			1501, -- [1]
			"[*] Dread Screech Waves", -- [2]
		},
		[31601] = {
			479, -- [1]
			"Crypt Crawler", -- [2]
		},
		[28457] = {
			1114, -- [1]
			"Soldier of the Frozen Wastes", -- [2]
		},
		[117986] = {
			1409, -- [1]
			"Protector Kaolan", -- [2]
		},
		[114020] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[122336] = {
			1507, -- [1]
			"Sonic Ring", -- [2]
		},
		[69242] = {
			1106, -- [1]
			"Raging Spirit", -- [2]
		},
		[114404] = {
			1507, -- [1]
			"Void Tendril <Tellios>", -- [2]
		},
		[61632] = {
			1090, -- [1]
			"Sartharion", -- [2]
		},
		[121185] = {
			1441, -- [1]
			"Kargesh Highguard", -- [2]
		},
		[116835] = {
			1407, -- [1]
			"[*] Devastating Arc", -- [2]
		},
		[135095] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[106856] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[117219] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[134587] = {
			1572, -- [1]
			"Blue Eye", -- [2]
		},
		[121443] = {
			1464, -- [1]
			"Wing Leader Ner'onok", -- [2]
		},
		[136122] = {
			1572, -- [1]
			"Crimson Fog", -- [2]
		},
		[130013] = {
			1505, -- [1]
			"The Dark of Night", -- [2]
		},
		[113765] = {
			1428, -- [1]
			"Rattlegore", -- [2]
		},
		[137654] = {
			1559, -- [1]
			"[*] Rushing Winds", -- [2]
		},
		[81269] = {
			1507, -- [1]
			"Wild Mushroom <Nnydruid>", -- [2]
		},
		[113764] = {
			1424, -- [1]
			"Brother Korloff", -- [2]
		},
		[117218] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[138678] = {
			1570, -- [1]
			"Glacial Freeze Totem", -- [2]
		},
		[118988] = {
			1509, -- [1]
			"Gekkan", -- [2]
		},
		[135096] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[137399] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[21069] = {
			422, -- [1]
			"Vile Larva", -- [2]
		},
		[114021] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[246] = {
			220, -- [1]
			"Lady Sarevess", -- [2]
		},
		[121442] = {
			1464, -- [1]
			"Wing Leader Ner'onok", -- [2]
		},
		[119523] = {
			1436, -- [1]
			7, -- [2]
		},
		[48583] = {
			573, -- [1]
			"Skarvald the Constructor", -- [2]
		},
		[13737] = {
			1090, -- [1]
			"Onyx Brood General", -- [2]
		},
		[113766] = {
			1424, -- [1]
			"Brother Korloff", -- [2]
		},
		[117988] = {
			1409, -- [1]
			"[*] Defiled Ground", -- [2]
		},
		[114022] = {
			1420, -- [1]
			"Scarlet Treasurer", -- [2]
		},
		[122760] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[58947] = {
			1090, -- [1]
			"Onyx Sanctum Guardian", -- [2]
		},
		[21707] = {
			422, -- [1]
			"Noxxion", -- [2]
		},
		[136889] = {
			1579, -- [1]
			"[*] Violent Gale Winds", -- [2]
		},
		[53418] = {
			216, -- [1]
			"Hadronox", -- [2]
		},
		[53317] = {
			216, -- [1]
			"Anub'ar Champion", -- [2]
		},
		[114918] = {
			1507, -- [1]
			"Light's Hammer <Smashval>", -- [2]
		},
		[112999] = {
			1306, -- [1]
			"Residual Hatred", -- [2]
		},
		[53509] = {
			218, -- [1]
			"Anub'arak", -- [2]
		},
		[123490] = {
			1507, -- [1]
			"Enslaved Bonesmasher", -- [2]
		},
		[15976] = {
			423, -- [1]
			"Razorlash", -- [2]
		},
		[76665] = {
			1039, -- [1]
			"Lucky", -- [2]
		},
		[106984] = {
			1303, -- [1]
			"Gu Cloudstrike", -- [2]
		},
		[111720] = {
			1417, -- [1]
			"[*] Swirling Sunfire", -- [2]
		},
		[117756] = {
			1436, -- [1]
			"Meng the Demented", -- [2]
		},
		[49863] = {
			60009, -- [1]
			"Zandalari Terror Rider", -- [2]
		},
		[136123] = {
			1572, -- [1]
			"Amber Fog", -- [2]
		},
		[76341] = {
			1046, -- [1]
			"Mindbender Ghur'sha", -- [2]
		},
		[119948] = {
			1442, -- [1]
			"Mu'Shiba", -- [2]
		},
		[120676] = {
			1436, -- [1]
			"Stormlash Totem <Prismma>", -- [2]
		},
		[75842] = {
			1038, -- [1]
			"Karsh Steelbender", -- [2]
		},
		[137403] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[114919] = {
			1507, -- [1]
			"Light's Hammer <Smashval>", -- [2]
		},
		[110953] = {
			1424, -- [1]
			"Scarlet Fanatic", -- [2]
		},
		[136124] = {
			1572, -- [1]
			"Azure Fog", -- [2]
		},
		[135102] = {
			1565, -- [1]
			"Vampiric Cave Bat", -- [2]
		},
		[114017] = {
			1422, -- [1]
			"Houndmaster Braun", -- [2]
		},
		[136892] = {
			1559, -- [1]
			"Ice Tomb", -- [2]
		},
		[135101] = {
			1565, -- [1]
			"Vampiric Cave Bat", -- [2]
		},
		[28458] = {
			1114, -- [1]
			"Soldier of the Frozen Wastes", -- [2]
		},
		[119693] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[99695] = {
			1206, -- [1]
			"Flamewaker Sentinel", -- [2]
		},
		[126434] = {
			1436, -- [1]
			7, -- [2]
		},
		[114000] = {
			1420, -- [1]
			"Scarlet Hall Guardian", -- [2]
		},
		[137458] = {
			1575, -- [1]
			"Horridon", -- [2]
		},
		[111668] = {
			1406, -- [1]
			"Raigonn", -- [2]
		},
		[137149] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[53318] = {
			217, -- [1]
			"Anub'ar Crusher", -- [2]
		},
		[112993] = {
			1413, -- [1]
			"Hoptallus", -- [2]
		},
		[110954] = {
			1424, -- [1]
			"Scarlet Fanatic", -- [2]
		},
		[6940] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[135681] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[111594] = {
			1426, -- [1]
			"Scholomance Acolyte", -- [2]
		},
		[125786] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[135103] = {
			1565, -- [1]
			"Unknown", -- [2]
		},
		[111722] = {
			1427, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[111850] = {
			1409, -- [1]
			"Elder Regail", -- [2]
		},
		[110945] = {
			1303, -- [1]
			"Gu Cloudstrike", -- [2]
		},
		[112992] = {
			1413, -- [1]
			"Hoptallus", -- [2]
		},
		[131521] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[124317] = {
			1447, -- [1]
			"General Pa'valak", -- [2]
		},
		[124807] = {
			1501, -- [1]
			"Kor'thik Reaver", -- [2]
		},
		[122853] = {
			1504, -- [1]
			"[*] Tempest Slash", -- [2]
		},
		[134398] = {
			1573, -- [1]
			"[*] Slime Trail", -- [2]
		},
		[131522] = {
			1306, -- [1]
			"Taran Zhu", -- [2]
		},
		[129378] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[76508] = {
			1036, -- [1]
			"Crazed Mage", -- [2]
		},
		[122407] = {
			1498, -- [1]
			"Wind Lord Mel'jarak", -- [2]
		},
		[138687] = {
			1570, -- [1]
			"Glacial Freeze Totem <Drakkari Frost Warden>", -- [2]
		},
		[53454] = {
			218, -- [1]
			"Impale Target", -- [2]
		},
		[137152] = {
			1572, -- [1]
			"Hidden Fog", -- [2]
		},
		[135361] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[137664] = {
			1559, -- [1]
			"[*] Frozen Blood", -- [2]
		},
		[120167] = {
			1442, -- [1]
			"Haiyan the Unstoppable", -- [2]
		},
		[113616] = {
			1420, -- [1]
			"Book Case", -- [2]
		},
		[114451] = {
			1414, -- [1]
			"Yeasty Brew Alemental", -- [2]
		},
		[114410] = {
			1424, -- [1]
			"Brother Korloff", -- [2]
		},
		[119887] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[122960] = {
			1499, -- [1]
			"Amber-Shaper Un'sok", -- [2]
		},
		[113809] = {
			1426, -- [1]
			"Wander's Colossal Book of Shadow Puppets", -- [2]
		},
		[116969] = {
			1407, -- [1]
			"Qin-xi", -- [2]
		},
		[110956] = {
			1424, -- [1]
			"Scarlet Fanatic", -- [2]
		},
		[136925] = {
			1559, -- [1]
			"Rushing Winds", -- [2]
		},
		[121447] = {
			1464, -- [1]
			"Wing Leader Ner'onok", -- [2]
		},
		[115630] = {
			1303, -- [1]
			"Shado-Pan Warden", -- [2]
		},
		[134510] = {
			1573, -- [1]
			"Corpse Spider", -- [2]
		},
		[117737] = {
			1436, -- [1]
			"Meng the Demented", -- [2]
		},
		[137410] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[122761] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[131994] = {
			1431, -- [1]
			"Sha of Fear", -- [2]
		},
		[138178] = {
			1579, -- [1]
			"Thunder Trap", -- [2]
		},
		[119684] = {
			1441, -- [1]
			"Xin the Weaponmaster", -- [2]
		},
		[138690] = {
			1570, -- [1]
			"Drakkari Frost Warden", -- [2]
		},
		[32233] = {
			1395, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[19983] = {
			1119, -- [1]
			"Sapphiron", -- [2]
		},
		[86727] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[16427] = {
			479, -- [1]
			"Crypt Beast", -- [2]
		},
		[121282] = {
			1464, -- [1]
			"Wing Leader Ner'onok", -- [2]
		},
		[28299] = {
			1120, -- [1]
			"Stalagg", -- [2]
		},
		[123495] = {
			1463, -- [1]
			"Garalon", -- [2]
		},
		[138691] = {
			1576, -- [1]
			"Dark Animus", -- [2]
		},
		[106736] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[54791] = {
			481, -- [1]
			"Maleki the Pallid", -- [2]
		},
		[28459] = {
			1114, -- [1]
			"Soul Weaver", -- [2]
		},
		[137668] = {
			1559, -- [1]
			"[*] Burning Cinders", -- [2]
		},
		[102573] = {
			1303, -- [1]
			"Azure Serpent", -- [2]
		},
		[131842] = {
			1498, -- [1]
			"[*] Wind Bomb", -- [2]
		},
		[134367] = {
			1573, -- [1]
			"Hatchling", -- [2]
		},
		[111801] = {
			1427, -- [1]
			"Risen Guard", -- [2]
		},
		[106352] = {
			1304, -- [1]
			"Master Snowdrift", -- [2]
		},
		[139204] = {
			1572, -- [1]
			"[*] Infrared Tracking", -- [2]
		},
		[136797] = {
			1575, -- [1]
			"Zandalari Dinomancer", -- [2]
		},
		[137669] = {
			1559, -- [1]
			"[*] Storm Cloud", -- [2]
		},
		[106864] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[117227] = {
			1409, -- [1]
			"Elder Asani", -- [2]
		},
		[107120] = {
			1406, -- [1]
			"Commander Ri'mok", -- [2]
		},
		[115436] = {
			1406, -- [1]
			"Krik'thik Rager", -- [2]
		},
		[113364] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[117905] = {
			1409, -- [1]
			"Minion of Fear", -- [2]
		},
		[137414] = {
			1560, -- [1]
			"Suen", -- [2]
		},
		[111854] = {
			1426, -- [1]
			"Instructor Chillheart", -- [2]
		},
		[31602] = {
			480, -- [1]
			"Nerub'enkan", -- [2]
		},
		[122252] = {
			220, -- [1]
			"Blackfathom Myrmidon", -- [2]
		},
		[137730] = {
			1578, -- [1]
			"Flaming Head", -- [2]
		},
		[140741] = {
			1573, -- [1]
			"[*] Primal Nutriment", -- [2]
		},
		[69507] = {
			1104, -- [1]
			"Rotface", -- [2]
		},
		[120142] = {
			1441, -- [1]
			"[*] Dart", -- [2]
		},
		[120938] = {
			1465, -- [1]
			"Resin Flake", -- [2]
		},
		[76032] = {
			1039, -- [1]
			"Beauty", -- [2]
		},
		[31803] = {
			1439, -- [1]
			2, -- [2]
		},
		[124172] = {
			1447, -- [1]
			"Sik'thik Vanguard", -- [2]
		},
		[123497] = {
			1507, -- [1]
			"Set'thik Fanatic", -- [2]
		},
		[17105] = {
			479, -- [1]
			"Wailing Banshee", -- [2]
		},
		[136904] = {
			1570, -- [1]
			"Frost King Malakk", -- [2]
		},
		[111599] = {
			1426, -- [1]
			"Scholomance Acolyte", -- [2]
		},
		[137350] = {
			1570, -- [1]
			"High Priestess Mar'li", -- [2]
		},
		[13738] = {
			479, -- [1]
			"Fleshflayer Ghoul", -- [2]
		},
		[42702] = {
			571, -- [1]
			"Vrykul Skeleton", -- [2]
		},
		[120593] = {
			1465, -- [1]
			"Sap Puddle", -- [2]
		},
		[122474] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[107047] = {
			1405, -- [1]
			"Striker Ga'dok", -- [2]
		},
		[124777] = {
			1501, -- [1]
			"Kor'thik Reaver", -- [2]
		},
		[122858] = {
			1505, -- [1]
			"Tsulong", -- [2]
		},
		[137417] = {
			1560, -- [1]
			"[*] Flames of Passion", -- [2]
		},
		[69508] = {
			1104, -- [1]
			"Rotface", -- [2]
		},
		[131788] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[134091] = {
			1565, -- [1]
			"Whirl Turtle", -- [2]
		},
		[107122] = {
			1406, -- [1]
			"[*] Viscous Fluid", -- [2]
		},
		[117485] = {
			1407, -- [1]
			"Emperor's Courage", -- [2]
		},
		[76094] = {
			1045, -- [1]
			"Commander Ulthok", -- [2]
		},
		[137162] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[113775] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[118313] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[138739] = {
			1570, -- [1]
			"Farraki Sand Conjurer", -- [2]
		},
		[134092] = {
			1565, -- [1]
			"Whirl Turtle", -- [2]
		},
		[52042] = {
			1507, -- [1]
			"Healing Stream Totem <Water>", -- [2]
		},
		[120199] = {
			1502, -- [1]
			"Sik'thik Amberwing", -- [2]
		},
		[8433] = {
			222, -- [1]
			"Old Serra'kis", -- [2]
		},
		[135695] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[110705] = {
			1436, -- [1]
			"Consecration", -- [2]
		},
		[114927] = {
			1303, -- [1]
			"Gu Cloudstrike", -- [2]
		},
		[131790] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[138187] = {
			1579, -- [1]
			"Lightning Guardian", -- [2]
		},
		[123499] = {
			1507, -- [1]
			"Set'thik Fanatic", -- [2]
		},
		[126926] = {
			1504, -- [1]
			"Kor'thik Swarmguard", -- [2]
		},
		[136463] = {
			1575, -- [1]
			"Amani Warbear", -- [2]
		},
		[114011] = {
			1420, -- [1]
			"Scarlet Hall Guardian", -- [2]
		},
		[139467] = {
			1577, -- [1]
			"[*] Lightning Fissure", -- [2]
		},
		[111129] = {
			1303, -- [1]
			"Gu Cloudstrike", -- [2]
		},
		[65220] = {
			1507, -- [1]
			"Primal Earth Elemental", -- [2]
		},
		[122348] = {
			1499, -- [1]
			"Living Amber", -- [2]
		},
		[39647] = {
			1090, -- [1]
			"Onyx Sanctum Guardian", -- [2]
		},
		[106228] = {
			1439, -- [1]
			"[*] Nothingness", -- [2]
		},
		[72133] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[133971] = {
			1565, -- [1]
			"Whirl Turtle", -- [2]
		},
		[75907] = {
			1044, -- [1]
			"Naz'jar Honor Guard", -- [2]
		},
		[117529] = {
			1436, -- [1]
			"Undying Shadows", -- [2]
		},
		[123244] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[8269] = {
			1429, -- [1]
			"Doctor Theolen Krastinov", -- [2]
		},
		[111218] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[136654] = {
			1575, -- [1]
			"Gurubashi Bloodlord", -- [2]
		},
		[136211] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[137166] = {
			1570, -- [1]
			"Kazra'jin", -- [2]
		},
		[137747] = {
			1572, -- [1]
			"Durumu the Forgotten", -- [2]
		},
		[134647] = {
			1559, -- [1]
			"Ro'shak", -- [2]
		},
		[112929] = {
			1306, -- [1]
			"Unknown", -- [2]
		},
		[122349] = {
			1499, -- [1]
			"Living Amber", -- [2]
		},
		[136220] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[70346] = {
			1102, -- [1]
			"Growing Ooze Puddle <Professor Putricide>", -- [2]
		},
		[116592] = {
			60009, -- [1]
			"Zandalari Fire-Dancer", -- [2]
		},
		[55697] = {
			1119, -- [1]
			"Sapphiron", -- [2]
		},
		[137423] = {
			1577, -- [1]
			"[*] Focused Lightning", -- [2]
		},
		[117309] = {
			1409, -- [1]
			"Elder Asani", -- [2]
		},
		[110963] = {
			1424, -- [1]
			"Scarlet Purifier", -- [2]
		},
		[2645] = {
			1407, -- [1]
			7, -- [2]
		},
		[117283] = {
			1409, -- [1]
			"Cleansing Waters <Elder Asani>", -- [2]
		},
		[71893] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[128531] = {
			1573, -- [1]
			"Fire Spirit <Derenter>", -- [2]
		},
		[139215] = {
			1576, -- [1]
			"Ritual Guard", -- [2]
		},
		[76189] = {
			1040, -- [1]
			"Shadow of Obsidius", -- [2]
		},
		[120047] = {
			1431, -- [1]
			"Yang Guoshi", -- [2]
		},
		[118469] = {
			1434, -- [1]
			"Gara'jal the Spiritbinder", -- [2]
		},
		[107187] = {
			1397, -- [1]
			"Saboteur Kip'tilak", -- [2]
		},
		[140495] = {
			1572, -- [1]
			"[*] Lingering Gaze", -- [2]
		},
		[114466] = {
			1414, -- [1]
			"Wall of Suds", -- [2]
		},
		[136913] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[111813] = {
			1427, -- [1]
			"Risen Guard", -- [2]
		},
		[25646] = {
			1108, -- [1]
			"Gluth", -- [2]
		},
		[69200] = {
			1106, -- [1]
			"The Lich King", -- [2]
		},
		[76165] = {
			1046, -- [1]
			"Erunak Stonespeaker", -- [2]
		},
		[114864] = {
			1430, -- [1]
			"Bored Student", -- [2]
		},
		[111220] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[136564] = {
			1575, -- [1]
			"Drakkari Frozen Warlord", -- [2]
		},
		[136914] = {
			1579, -- [1]
			"Lei Shen", -- [2]
		},
		[106925] = {
			1305, -- [1]
			"Consuming Sha", -- [2]
		},
		[114848] = {
			1425, -- [1]
			"High Inquisitor Whitemane", -- [2]
		},
		[135146] = {
			1559, -- [1]
			"Dam'ren", -- [2]
		},
		[61295] = {
			1436, -- [1]
			7, -- [2]
		},
		[136147] = {
			1559, -- [1]
			"Iron Qon", -- [2]
		},
		[114291] = {
			1413, -- [1]
			"Hopper", -- [2]
		},
		[120560] = {
			1442, -- [1]
			"Gurthan Iron Maw", -- [2]
		},
		[122735] = {
			1463, -- [1]
			"Garalon", -- [2]
		},
		[116224] = {
			1422, -- [1]
			"Obedient Hound", -- [2]
		},
		[123250] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[31616] = {
			1436, -- [1]
			7, -- [2]
		},
		[127341] = {
			1500, -- [1]
			"Celestial Protector", -- [2]
		},
		[125422] = {
			1501, -- [1]
			"Set'thik Windblade", -- [2]
		},
		[111221] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[348] = {
			1439, -- [1]
			"Adictoxd", -- [2]
		},
		[5568] = {
			219, -- [1]
			"Ghamoo-Ra", -- [2]
		},
		[28835] = {
			1121, -- [1]
			"Sir Zeliek", -- [2]
		},
		[115827] = {
			1395, -- [1]
			"Jade Guardian", -- [2]
		},
		[123180] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[42705] = {
			575, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[53400] = {
			216, -- [1]
			"Hadronox", -- [2]
		},
		[5672] = {
			1436, -- [1]
			"Healing Stream Totem <Madawng>", -- [2]
		},
		[114886] = {
			1426, -- [1]
			"[*] Frigid Grasp", -- [2]
		},
		[136917] = {
			1570, -- [1]
			"Frost King Malakk", -- [2]
		},
		[123647] = {
			1442, -- [1]
			"Gurthan Iron Maw", -- [2]
		},
		[71255] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[123120] = {
			1463, -- [1]
			"[*] Pheromone Trail", -- [2]
		},
		[106872] = {
			1305, -- [1]
			"Sha of Violence", -- [2]
		},
		[113141] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[33110] = {
			1499, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[138607] = {
			1570, -- [1]
			"Amani'shi Flame Chanter", -- [2]
		},
		[105284] = {
			1436, -- [1]
			7, -- [2]
		},
		[113653] = {
			1420, -- [1]
			"Flameweaver Koegler", -- [2]
		},
		[115828] = {
			1395, -- [1]
			"Jasper Guardian", -- [2]
		},
		[49806] = {
			216, -- [1]
			"Anub'ar Warrior", -- [2]
		},
		[80780] = {
			479, -- [1]
			"Shrieking Banshee", -- [2]
		},
		[111215] = {
			1421, -- [1]
			"Armsmaster Harlan", -- [2]
		},
		[136708] = {
			1575, -- [1]
			"Sul'lithuz Stonegazer", -- [2]
		},
		[120562] = {
			1442, -- [1]
			"Harthak Stormcaller", -- [2]
		},
		[116596] = {
			60009, -- [1]
			"Zandalari Infiltrator", -- [2]
		},
		[59604] = {
			575, -- [1]
			"Dragonflayer Heartsplitter", -- [2]
		},
		[120946] = {
			1465, -- [1]
			"Sik'thik Amber-Weaver", -- [2]
		},
		[123121] = {
			1506, -- [1]
			"Lei Shi", -- [2]
		},
		[75539] = {
			1036, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[52493] = {
			216, -- [1]
			"Watcher Silthik", -- [2]
		},
		[123505] = {
			1506, -- [1]
			"Animated Protector", -- [2]
		},
		[71603] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[52470] = {
			216, -- [1]
			"Watcher Silthik", -- [2]
		},
		[9613] = {
			224, -- [1]
			"Twilight Shadowmage", -- [2]
		},
		[115829] = {
			1395, -- [1]
			"Amethyst Guardian", -- [2]
		},
		[128239] = {
			1441, -- [1]
			"Gurthan Swiftblade", -- [2]
		},
		[114038] = {
			1427, -- [1]
			"[*] Gravity Flux", -- [2]
		},
		[138254] = {
			1560, -- [1]
			"Faded Image of Niuzao", -- [2]
		},
		[122482] = {
			1426, -- [1]
			"Ice Wall", -- [2]
		},
		[119358] = {
			1500, -- [1]
			"Elegon", -- [2]
		},
		[145109] = {
			1504, -- [1]
			10, -- [2]
		},
		[112945] = {
			1413, -- [1]
			"Hoptallus", -- [2]
		},
		[122994] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[117230] = {
			1409, -- [1]
			"Corrupted Waters <Elder Asani>", -- [2]
		},
		[106874] = {
			1405, -- [1]
			"[*] Fire Bomb", -- [2]
		},
		[138201] = {
			1579, -- [1]
			"Thunder Lord", -- [2]
		},
		[75543] = {
			1036, -- [1]
			"Rom'ogg Bonecrusher", -- [2]
		},
		[138742] = {
			1570, -- [1]
			"Farraki Sand Conjurer", -- [2]
		},
		[145110] = {
			1504, -- [1]
			10, -- [2]
		},
		[119981] = {
			1442, -- [1]
			"Ming the Cunning", -- [2]
		},
		[124018] = {
			1507, -- [1]
			"Imperial Vizier Zor'lok", -- [2]
		},
		[130287] = {
			1500, -- [1]
			"Mindbender <Tellios>", -- [2]
		},
		[136037] = {
			1574, -- [1]
			"Primordius", -- [2]
		},
		[116793] = {
			1390, -- [1]
			"[*] Wildfire", -- [2]
		},
		[71621] = {
			1102, -- [1]
			"Professor Putricide", -- [2]
		},
		[138740] = {
			1570, -- [1]
			"Farraki Sand Conjurer", -- [2]
		},
		[116598] = {
			1500, -- [1]
			"Empyreal Focus", -- [2]
		},
		[115509] = {
			1303, -- [1]
			"Shado-Pan Warden", -- [2]
		},
		[114807] = {
			1424, -- [1]
			"Brother Korloff", -- [2]
		},
		[133597] = {
			1572, -- [1]
			"Evil Eye", -- [2]
		},
		[124783] = {
			1504, -- [1]
			"Blade Lord Ta'yak", -- [2]
		},
		[113144] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[115519] = {
			1423, -- [1]
			"Scarlet Centurion", -- [2]
		},
		[116607] = {
			60009, -- [1]
			"Zandalari Skullcharger", -- [2]
		},
		[116417] = {
			1390, -- [1]
			"Feng the Accursed", -- [2]
		},
		[137180] = {
			1577, -- [1]
			"Jin'rokh the Breaker", -- [2]
		},
		[56908] = {
			1090, -- [1]
			"Sartharion", -- [2]
		},
		[121602] = {
			1464, -- [1]
			"Sapfly", -- [2]
		},
		[134005] = {
			1572, -- [1]
			"Wandering Eye", -- [2]
		},
		[75700] = {
			1044, -- [1]
			"Geyser <Lady Naz'jar>", -- [2]
		},
	},
	["npcid_ignored"] = {
	},
	["report_where"] = "RAID",
	["got_first_run"] = true,
	["report_pos"] = {
		1, -- [1]
		1.000091552734375, -- [2]
	},
	["latest_report_table"] = {
		{
			1, -- [1]
			1, -- [2]
			1, -- [3]
			20, -- [4]
			"RAID", -- [5]
		}, -- [1]
	},
	["__profiles"] = {
		["Lotusprep-[EN] Evermoon"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = false,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["numerical_system"] = 1,
			["use_scroll"] = false,
			["report_heal_links"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["minimum_overall_combat_time"] = 10,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["report_to_who"] = "",
			["instances_segments_locked"] = false,
			["clear_ungrouped"] = true,
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 6,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 12,
				["background"] = {
					0.196078431372549, -- [1]
					0.196078431372549, -- [2]
					0.196078431372549, -- [3]
					0.8, -- [4]
				},
				["submenu_wallpaper"] = false,
				["fontsize_title"] = 10,
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "Arial Narrow",
				["border_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0, -- [4]
				},
				["border_texture"] = "None",
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["maximize_method"] = 1,
				["fontshadow"] = true,
				["border_size"] = 16,
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.31, -- [1]
					0.9240000152587891, -- [2]
					0.2130000114440918, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.7999982237815857, -- [1]
					0.7999982237815857, -- [2]
					0.7999982237815857, -- [3]
					0.2000000178813934, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = true,
			["update_speed"] = 3,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["overall_clear_newboss"] = true,
			["overall_clear_newchallenge"] = true,
			["time_type"] = 1,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["standard_skin"] = {
				["hide_in_combat_type"] = 1,
				["switch_healer_in_combat"] = false,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menu_anchor"] = {
					16, -- [1]
					2, -- [2]
					["side"] = 2,
				},
				["bars_inverted"] = false,
				["bg_r"] = 0.3294117647058824,
				["version"] = 3,
				["name"] = "",
				["hide_out_of_combat"] = false,
				["attribute_text"] = {
					["enabled"] = true,
					["shadow"] = true,
					["side"] = 1,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0.7, -- [4]
					},
					["custom_text"] = "{name}",
					["text_face"] = "Friz Quadrata TT",
					["anchor"] = {
						-20, -- [1]
						4, -- [2]
					},
					["enable_custom_text"] = false,
					["show_timer"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["text_size"] = 12,
				},
				["following"] = {
					["bar_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["enabled"] = true,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["color_buttons"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["switch_healer"] = false,
				["skin_custom"] = "",
				["stretch_button_side"] = 1,
				["bars_sort_direction"] = 1,
				["skin"] = "ElvUI Frame Style",
				["switch_damager"] = false,
				["tooltip"] = {
					["n_abilities"] = 3,
					["n_enemies"] = 3,
				},
				["micro_displays_side"] = 2,
				["clickthrough_window"] = false,
				["switch_all_roles_in_combat"] = false,
				["switch_tank_in_combat"] = false,
				["bg_alpha"] = 0.5,
				["row_info"] = {
					["textR_outline"] = true,
					["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
					["textL_outline"] = true,
					["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
					["textR_show_data"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["percent_type"] = 1,
					["fixed_text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["space"] = {
						["right"] = -2,
						["left"] = 1,
						["between"] = 1,
					},
					["texture_background_class_color"] = false,
					["start_after_icon"] = false,
					["font_face_file"] = "Fonts\\ARIALN.TTF",
					["textL_custom_text"] = "{data1}. {data3}{data2}",
					["models"] = {
						["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
						["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
						["upper_alpha"] = 0.5,
						["lower_enabled"] = false,
						["lower_alpha"] = 0.1,
						["upper_enabled"] = false,
					},
					["textL_translit_text"] = false,
					["height"] = 18,
					["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
					["texture_background_file"] = "Interface\\TargetingFrame\\UI-StatusBar",
					["font_size"] = 12,
					["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
					["icon_grayscale"] = false,
					["backdrop"] = {
						["enabled"] = true,
						["size"] = 4,
						["color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture"] = "Details BarBorder 2",
					},
					["textR_bracket"] = "(",
					["texture_custom"] = "",
					["fixed_texture_background_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.471, -- [4]
					},
					["fixed_texture_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["textL_show_number"] = true,
					["textR_enable_custom_text"] = true,
					["textR_outline_small"] = true,
					["textR_custom_text"] = "{data1} ({data2})",
					["texture"] = "DGround",
					["textL_outline_small"] = true,
					["textL_outline_small_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["textL_class_colors"] = false,
					["textR_outline_small_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["textR_class_colors"] = false,
					["texture_background"] = "Minimalist",
					["alpha"] = 0.8,
					["no_icon"] = false,
					["icon_offset"] = {
						0, -- [1]
						0, -- [2]
					},
					["use_spec_icons"] = false,
					["font_face"] = "Arial Narrow",
					["texture_class_colors"] = true,
					["textL_enable_custom_text"] = false,
					["fast_ps_update"] = false,
					["textR_separator"] = ",",
					["texture_custom_file"] = "Interface\\",
				},
				["show_statusbar"] = false,
				["menu_alpha"] = {
					["enabled"] = false,
					["onenter"] = 1,
					["iconstoo"] = true,
					["ignorebars"] = false,
					["onleave"] = 1,
				},
				["switch_all_roles_after_wipe"] = false,
				["libwindow"] = {
					["y"] = 91.18972778320313,
					["x"] = -333.42529296875,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1,
				},
				["statusbar_info"] = {
					["alpha"] = 1,
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["strata"] = "LOW",
				["clickthrough_incombatonly"] = true,
				["window_scale"] = 1,
				["ignore_mass_showhide"] = false,
				["hide_in_combat_alpha"] = 1,
				["plugins_grow_direction"] = 1,
				["menu_icons"] = {
					false, -- [1]
					true, -- [2]
					false, -- [3]
					true, -- [4]
					true, -- [5]
					true, -- [6]
					["space"] = -4,
					["shadow"] = false,
				},
				["desaturated_menu"] = true,
				["show_sidebars"] = true,
				["bars_grow_direction"] = 1,
				["row_show_animation"] = {
					["anim"] = "Fade",
					["options"] = {
					},
				},
				["grab_on_top"] = false,
				["clickthrough_rows"] = false,
				["micro_displays_locked"] = true,
				["hide_icon"] = true,
				["switch_damager_in_combat"] = false,
				["menu_anchor_down"] = {
					16, -- [1]
					-2, -- [2]
				},
				["auto_current"] = true,
				["toolbar_side"] = 1,
				["bg_g"] = 0.3294117647058824,
				["switch_tank"] = false,
				["hide_in_combat"] = false,
				["auto_hide_menu"] = {
					["left"] = false,
					["right"] = false,
				},
				["backdrop_texture"] = "Details Ground",
				["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
				["wallpaper"] = {
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
					["texcoord"] = {
						0.0478515625, -- [1]
						0.2978515625, -- [2]
						0.630859375, -- [3]
						0.755859375, -- [4]
					},
					["enabled"] = true,
					["anchor"] = "all",
					["height"] = 128,
					["alpha"] = 0.8,
					["width"] = 256,
				},
				["total_bar"] = {
					["enabled"] = false,
					["only_in_group"] = true,
					["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["menu_icons_size"] = 0.899999976158142,
				["clickthrough_toolbaricons"] = false,
				["instance_button_anchor"] = {
					-27, -- [1]
					1, -- [2]
				},
				["bg_b"] = 0.3294117647058824,
			},
			["disable_lock_ungroup_buttons"] = true,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["instances_no_libwindow"] = false,
			["default_bg_alpha"] = 0.5,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["deny_score_messages"] = false,
			["use_row_animations"] = false,
			["animate_scroll"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -399.1045532226563,
							["x"] = 705.7781372070313,
							["w"] = 194.7185516357422,
							["h"] = 105.3203125,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["clickthrough_window"] = false,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["micro_displays_locked"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						["space"] = -4,
						["shadow"] = false,
					},
					["switch_damager"] = false,
					["auto_hide_menu"] = {
						["left"] = true,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bg_b"] = 0.09411764705882353,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PATTRIBUTE"] = {
								["isHidden"] = false,
								["textStyle"] = 2,
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textStyle"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textXMod"] = 6,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PATTRIBUTE",
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["bg_alpha"] = 0,
					["__snapV"] = false,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["__snapH"] = false,
					["hide_in_combat_type"] = 1,
					["__was_opened"] = true,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["menu_icons_size"] = 0.8500000238418579,
					["hide_in_combat_alpha"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["stretch_button_side"] = 1,
					["libwindow"] = {
						["y"] = 0,
						["x"] = 0,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["grab_on_top"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["show_sidebars"] = false,
					["skin_custom"] = "",
					["backdrop_texture"] = "Details Ground",
					["switch_damager_in_combat"] = false,
					["switch_tank_in_combat"] = false,
					["bars_sort_direction"] = 1,
					["auto_current"] = true,
					["version"] = 3,
					["attribute_text"] = {
						["enabled"] = false,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							false, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["bars_inverted"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -399.1045532226563,
							["x"] = 705.7781372070313,
							["w"] = 194.7185516357422,
							["h"] = 105.3203125,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0, -- [4]
							},
							["texture"] = "None",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = true,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_custom_file"] = "Interface\\",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_bracket"] = "NONE",
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "DGround",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_background"] = "DGround",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["use_spec_icons"] = true,
					},
					["bars_grow_direction"] = 1,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["micro_displays_side"] = 2,
					["ignore_mass_showhide"] = false,
					["plugins_grow_direction"] = 1,
					["desaturated_menu"] = true,
				}, -- [1]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -312.1207733154297,
							["x"] = 450.1370239257813,
							["w"] = 150.0001373291016,
							["h"] = 95.23551177978516,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.8500000238418579,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["attribute_text"] = {
						["enabled"] = false,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							false, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						["space"] = -4,
						["shadow"] = false,
					},
					["desaturated_menu"] = true,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bars_inverted"] = false,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textStyle"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textXMod"] = 6,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0,
					["__snapV"] = false,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["__snapH"] = false,
					["hide_in_combat_type"] = 1,
					["__was_opened"] = false,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["clickthrough_window"] = false,
					["hide_in_combat_alpha"] = 1,
					["switch_healer_in_combat"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = 92.02618408203125,
						["x"] = -278.000244140625,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["skin_custom"] = "",
					["plugins_grow_direction"] = 1,
					["grab_on_top"] = false,
					["bg_b"] = 0.09411764705882353,
					["ignore_mass_showhide"] = false,
					["auto_current"] = true,
					["micro_displays_locked"] = true,
					["version"] = 3,
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0, -- [4]
							},
							["texture"] = "None",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = true,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_custom_file"] = "Interface\\",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_bracket"] = "NONE",
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "DGround",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_background"] = "DGround",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["use_spec_icons"] = true,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -312.1207733154297,
							["x"] = 450.1370239257813,
							["w"] = 150.0001373291016,
							["h"] = 95.23551177978516,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["switch_damager"] = false,
					["show_sidebars"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["clickthrough_rows"] = false,
				}, -- [2]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 6.103515625e-005,
							["x"] = 6.103515625e-005,
							["w"] = 320,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300.0000610351563,
							["h"] = 299.9999694824219,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.8500000238418579,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["attribute_text"] = {
						["enabled"] = false,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							false, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						["space"] = -4,
						["shadow"] = false,
					},
					["desaturated_menu"] = true,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bars_inverted"] = false,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["timeType"] = 1,
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0,
					["__snapV"] = false,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["__snapH"] = false,
					["hide_in_combat_type"] = 1,
					["__was_opened"] = false,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["clickthrough_window"] = false,
					["hide_in_combat_alpha"] = 1,
					["switch_healer_in_combat"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = 4.57763671875e-005,
						["x"] = 9.1552734375e-005,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["skin_custom"] = "",
					["plugins_grow_direction"] = 1,
					["grab_on_top"] = false,
					["bg_b"] = 0.09411764705882353,
					["ignore_mass_showhide"] = false,
					["auto_current"] = true,
					["micro_displays_locked"] = true,
					["version"] = 3,
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0, -- [4]
							},
							["texture"] = "None",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = true,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_custom_file"] = "Interface\\",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_bracket"] = "NONE",
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "DGround",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_background"] = "DGround",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["use_spec_icons"] = true,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 6.103515625e-005,
							["x"] = 6.103515625e-005,
							["w"] = 320,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300.0000610351563,
							["h"] = 299.9999694824219,
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["switch_damager"] = false,
					["show_sidebars"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["clickthrough_rows"] = false,
				}, -- [3]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 6.103515625e-005,
							["x"] = 6.103515625e-005,
							["w"] = 320,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.8500000238418579,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["attribute_text"] = {
						["enabled"] = false,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							false, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						["space"] = -4,
						["shadow"] = false,
					},
					["desaturated_menu"] = true,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bars_inverted"] = false,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["timeType"] = 1,
								["textXMod"] = 6,
								["textAlign"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0,
					["__snapV"] = false,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["__snapH"] = false,
					["hide_in_combat_type"] = 1,
					["__was_opened"] = false,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["clickthrough_window"] = false,
					["hide_in_combat_alpha"] = 1,
					["switch_healer_in_combat"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = 4.57763671875e-005,
						["x"] = 9.1552734375e-005,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["skin_custom"] = "",
					["plugins_grow_direction"] = 1,
					["grab_on_top"] = false,
					["bg_b"] = 0.09411764705882353,
					["ignore_mass_showhide"] = false,
					["auto_current"] = true,
					["micro_displays_locked"] = true,
					["version"] = 3,
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0, -- [4]
							},
							["texture"] = "None",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = true,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_custom_file"] = "Interface\\",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_bracket"] = "NONE",
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "DGround",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_background"] = "DGround",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["use_spec_icons"] = true,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 6.103515625e-005,
							["x"] = 6.103515625e-005,
							["w"] = 320,
							["h"] = 129.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["switch_damager"] = false,
					["show_sidebars"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["clickthrough_rows"] = false,
				}, -- [4]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -398.8954658508301,
							["x"] = 524.9684448242188,
							["w"] = 170.2482299804688,
							["h"] = 105.7384872436523,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["clickthrough_window"] = false,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						false, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						["space"] = -4,
						["shadow"] = false,
					},
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bg_b"] = 0.09411764705882353,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 0,
								["timeType"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["bg_alpha"] = 0,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["show_statusbar"] = false,
					["__was_opened"] = true,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["menu_icons_size"] = 0.8500000238418579,
					["hide_in_combat_alpha"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_inverted"] = false,
					["libwindow"] = {
						["y"] = 0,
						["x"] = -193.044677734375,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["stretch_button_side"] = 1,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["switch_damager_in_combat"] = false,
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0, -- [4]
							},
							["texture"] = "None",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = true,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_custom_file"] = "Interface\\",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textR_bracket"] = "NONE",
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "DGround",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["texture_background"] = "DGround",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["use_spec_icons"] = true,
					},
					["skin_custom"] = "",
					["grab_on_top"] = false,
					["show_sidebars"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["auto_current"] = true,
					["bars_grow_direction"] = 1,
					["version"] = 3,
					["attribute_text"] = {
						["enabled"] = false,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							false, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -398.8954658508301,
							["x"] = 524.9684448242188,
							["w"] = 170.2482299804688,
							["h"] = 105.7384872436523,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["micro_displays_locked"] = true,
					["desaturated_menu"] = true,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["ignore_mass_showhide"] = false,
					["switch_all_roles_after_wipe"] = false,
					["auto_hide_menu"] = {
						["left"] = true,
						["right"] = false,
					},
					["switch_healer_in_combat"] = false,
				}, -- [5]
			},
			["report_lines"] = 20,
			["overall_flag"] = 13,
			["all_players_are_group"] = false,
			["skin"] = "Default Skin",
			["override_spellids"] = true,
			["ps_abbreviation"] = 6,
			["report_schema"] = 1,
			["death_tooltip_width"] = 350,
			["minimum_combat_time"] = 5,
			["overall_clear_logout"] = true,
			["memory_threshold"] = 3,
			["cloud_capture"] = false,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
			},
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.7382812600000001, -- [1]
					1, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["disable_alldisplays_window"] = false,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["total_abbreviation"] = 2,
			["segments_auto_erase"] = 1,
			["segments_amount_to_save"] = 18,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_ALLY"] = {
					0.2, -- [1]
					1, -- [2]
					0.2, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ARENA_GREEN"] = {
					0.4, -- [1]
					1, -- [2]
					0.4, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_ENEMY"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 291.4916609447588,
				["text_format"] = 3,
				["hide"] = true,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["instances_menu_click_to_open"] = false,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = true,
			["remove_realm_from_name"] = true,
			["trash_auto_remove"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_panic_mode"] = true,
			["segments_amount"] = 18,
			["profile_save_pos"] = true,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["font_sizes"] = {
				["menus"] = 10,
			},
			["new_window_size"] = {
				["height"] = 130,
				["width"] = 320,
			},
			["numerical_system_symbols"] = "auto",
			["force_activity_time_pvp"] = true,
			["use_battleground_server_parser"] = false,
			["time_type_original"] = 1,
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
			},
			["disable_stretch_from_toolbar"] = false,
			["deadlog_limit"] = 12,
			["pvp_as_group"] = false,
		},
	},
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
			["-6870"] = {
				"Iron Qon", -- [1]
				"-6870", -- [2]
				"Unleashed Flame", -- [3]
				6, -- [4]
				"INTERFACE\\ICONS\\SPELL_FIRE_BURNINGSPEED.BLP", -- [5]
				["id"] = 1559,
			},
			["-6905"] = {
				"Durumu the Forgotten", -- [1]
				"-6905", -- [2]
				"Force of Will", -- [3]
				33, -- [4]
				"INTERFACE\\ICONS\\ABILITY_MONK_FORCESPHERE.BLP", -- [5]
				["id"] = 1572,
			},
			["136741"] = {
				"Horridon", -- [1]
				"136741", -- [2]
				"Double Swipe", -- [3]
				15.5, -- [4]
				"Interface\\Icons\\inv_misc_monsterhorn_07", -- [5]
				["id"] = 1575,
			},
			["140138"] = {
				"Megaera", -- [1]
				"140138", -- [2]
				"<Cast: Arcane adds>", -- [3]
				6, -- [4]
				"INTERFACE\\ICONS\\spell_arcane_invocation", -- [5]
				["id"] = 1578,
			},
			["venom_bolt_volley"] = {
				"Horridon", -- [1]
				"venom_bolt_volley", -- [2]
				"Focus: Volley", -- [3]
				16, -- [4]
				"Interface\\Icons\\Ability_Creature_Poison_02", -- [5]
				["id"] = 1575,
			},
			["133798"] = {
				"Durumu the Forgotten", -- [1]
				"133798", -- [2]
				"Life Drain", -- [3]
				86, -- [4]
				"Interface\\Icons\\Spell_Shadow_LifeDrain02", -- [5]
				["id"] = 1572,
			},
			["-7631"] = {
				"Twin Consorts", -- [1]
				"-7631", -- [2]
				"[1] Cosmic Barrage", -- [3]
				16.8, -- [4]
				"INTERFACE\\ICONS\\SPELL_FIRE_BLUEPYROBLAST.BLP", -- [5]
				["id"] = 1560,
			},
			["133939"] = {
				"Tortos", -- [1]
				"133939", -- [2]
				"Furious Stone Breath", -- [3]
				46, -- [4]
				"Interface\\Icons\\inv_misc_dust", -- [5]
				["id"] = 1565,
			},
			["-6882"] = {
				"Durumu the Forgotten", -- [1]
				"-6882", -- [2]
				"Death beam", -- [3]
				136, -- [4]
				"INTERFACE\\ICONS\\INV_MISC_DUST.BLP", -- [5]
				["id"] = 1572,
			},
			["-7134"] = {
				"Tortos", -- [1]
				"-7134", -- [2]
				"Shell Concussion", -- [3]
				15, -- [4]
				"INTERFACE\\ICONS\\PRIEST_ICON_CHAKRA_GREEN.BLP", -- [5]
				["id"] = 1565,
			},
			["storm_duration"] = {
				"Jin'rokh the Breaker", -- [1]
				"storm_duration", -- [2]
				"<Cast: Storm>", -- [3]
				15, -- [4]
				"Interface\\Icons\\Spell_Shaman_ThunderStorm", -- [5]
				["id"] = 1577,
			},
			["138609"] = {
				"Dark Animus", -- [1]
				"138609", -- [2]
				"Matter Swap on YOU!", -- [3]
				12, -- [4]
				"Interface\\Icons\\Spell_Nature_MassTeleport", -- [5]
				["id"] = 1576,
			},
			["137458"] = {
				"Horridon", -- [1]
				"137458", -- [2]
				"Dire Call", -- [3]
				61, -- [4]
				"Interface\\Icons\\Ability_Physical_Taunt", -- [5]
				["id"] = 1575,
			},
			["134370"] = {
				"Ji-Kun", -- [1]
				"134370", -- [2]
				"Down Draft", -- [3]
				91, -- [4]
				"Interface\\Icons\\Ability_Druid_GaleWinds", -- [5]
				["id"] = 1573,
			},
			["-7086"] = {
				"Horridon", -- [1]
				"-7086", -- [2]
				"Zandalari Dinomancer", -- [3]
				58, -- [4]
				"Interface\\Icons\\ability_hunter_beastwithin", -- [5]
				["id"] = 1575,
			},
			["casting_barrage"] = {
				"Twin Consorts", -- [1]
				"casting_barrage", -- [2]
				"<Cast: Cosmic Barrage>", -- [3]
				5.5, -- [4]
				"Interface\\Icons\\ability_druid_starfall", -- [5]
				["id"] = 1560,
			},
			["breaths"] = {
				"Megaera", -- [1]
				"breaths", -- [2]
				"Breaths", -- [3]
				5, -- [4]
				"Interface\\Icons\\INV_Misc_Head_Dragon_Black", -- [5]
				["id"] = 1578,
			},
			["137175"] = {
				"Jin'rokh the Breaker", -- [1]
				"137175", -- [2]
				"Thundering Throw", -- [3]
				31, -- [4]
				"Interface\\Icons\\ability_warrior_throwdown", -- [5]
				["id"] = 1577,
			},
			["134380"] = {
				"Ji-Kun", -- [1]
				"134380", -- [2]
				"Quills", -- [3]
				42.3, -- [4]
				"Interface\\Icons\\Ability_Hunter_Pet_DragonHawk", -- [5]
				["id"] = 1573,
			},
			["139822"] = {
				"Megaera", -- [1]
				"139822", -- [2]
				"Cinders on YOU!", -- [3]
				30, -- [4]
				"INTERFACE\\ICONS\\inv_misc_volatilefire", -- [5]
				["id"] = 1578,
			},
			["77333"] = {
				"Iron Qon", -- [1]
				"77333", -- [2]
				"Whirling Winds", -- [3]
				19, -- [4]
				"Interface\\Icons\\Spell_Nature_Cyclone", -- [5]
				["id"] = 1559,
			},
			["conduit_abilities"] = {
				"Lei Shen", -- [1]
				"conduit_abilities", -- [2]
				"Next Conduit Ability", -- [3]
				16.3, -- [4]
				"Interface\\Icons\\spell_mage_runeofpower", -- [5]
				["id"] = 1579,
			},
			["-7741"] = {
				"Jin'rokh the Breaker", -- [1]
				"-7741", -- [2]
				"Focused Lightning", -- [3]
				8, -- [4]
				"INTERFACE\\ICONS\\ABILITY_VEHICLE_ELECTROCHARGE.BLP", -- [5]
				["id"] = 1577,
			},
			["136294"] = {
				"Tortos", -- [1]
				"136294", -- [2]
				"Call of Tortos", -- [3]
				21, -- [4]
				"Interface\\Icons\\achievement_boss_tortos", -- [5]
				["id"] = 1565,
			},
			["-7080"] = {
				"Horridon", -- [1]
				"-7080", -- [2]
				"Charge", -- [3]
				31, -- [4]
				"INTERFACE\\ICONS\\ABILITY_WARRIOR_BULLRUSH.BLP", -- [5]
				["id"] = 1575,
			},
			["nests"] = {
				"Ji-Kun", -- [1]
				"nests", -- [2]
				"[2] |cFF0080FFDown|r[#]", -- [3]
				27, -- [4]
				"Interface\\Icons\\ability_eyeoftheowl", -- [5]
				["id"] = 1573,
			},
			["135150"] = {
				"Lei Shen", -- [1]
				"135150", -- [2]
				"Crashing Thunder", -- [3]
				6, -- [4]
				"INTERFACE\\ICONS\\spell_shaman_measuredinsight", -- [5]
				["id"] = 1579,
			},
			["137531"] = {
				"Twin Consorts", -- [1]
				"137531", -- [2]
				"Tidal Force", -- [3]
				19, -- [4]
				"Interface\\Icons\\Spell_Frost_SummonWaterElemental", -- [5]
				["id"] = 1560,
			},
			["135991"] = {
				"Lei Shen", -- [1]
				"135991", -- [2]
				"Diffusion Chain", -- [3]
				10, -- [4]
				"Interface\\Icons\\Spell_Nature_LightningBolt", -- [5]
				["id"] = 1579,
			},
			["136442"] = {
				"Council of Elders", -- [1]
				"136442", -- [2]
				"Full power", -- [3]
				66, -- [4]
				"Interface\\Icons\\achievement_moguraid_03", -- [5]
				["id"] = 1570,
			},
			["stages"] = {
				"Twin Consorts", -- [1]
				"stages", -- [2]
				"Phase 2", -- [3]
				183, -- [4]
				"Interface\\Icons\\inv_enchant_shardshadowfrostlarge", -- [5]
				["id"] = 1560,
			},
			["138923"] = {
				"Ji-Kun", -- [1]
				"138923", -- [2]
				"Caw", -- [3]
				18, -- [4]
				"Interface\\Icons\\Ability_Hunter_AnimalHandler", -- [5]
				["id"] = 1573,
			},
			["140296"] = {
				"Throne of Thunder Trash", -- [1]
				"140296", -- [2]
				"Conductive Shield", -- [3]
				20.5, -- [4]
				"Interface\\Icons\\Spell_Nature_LightningShield", -- [5]
				["id"] = 1579,
			},
			["137491"] = {
				"Twin Consorts", -- [1]
				"137491", -- [2]
				"[1] Nuclear Inferno", -- [3]
				45.1, -- [4]
				"Interface\\Icons\\spell_mage_flameorb", -- [5]
				["id"] = 1560,
			},
			["-6891"] = {
				"Durumu the Forgotten", -- [1]
				"-6891", -- [2]
				"Light Spectrum", -- [3]
				39, -- [4]
				"INTERFACE\\ICONS\\INV_MISC_GEM_VARIETY_02.BLP", -- [5]
				["id"] = 1572,
			},
			["135695"] = {
				"Lei Shen", -- [1]
				"135695", -- [2]
				"Static Shock", -- [3]
				18.9, -- [4]
				"Interface\\Icons\\Spell_Shaman_StaticShock", -- [5]
				["id"] = 1579,
			},
			["136192"] = {
				"Iron Qon", -- [1]
				"136192", -- [2]
				"Lightning Storm", -- [3]
				18.5, -- [4]
				"Interface\\Icons\\INV_Rod_EnchantedAdamantite", -- [5]
				["id"] = 1559,
			},
			["138732"] = {
				"Jin'rokh the Breaker", -- [1]
				"138732", -- [2]
				"Ionization", -- [3]
				61, -- [4]
				"Interface\\Icons\\Spell_Nature_CallStorm", -- [5]
				["id"] = 1577,
			},
			["138306"] = {
				"Twin Consorts", -- [1]
				"138306", -- [2]
				"Serpent's Vitality", -- [3]
				30, -- [4]
				"Interface\\Icons\\ability_monk_summonserpentstatue", -- [5]
				["id"] = 1560,
			},
			["136216"] = {
				"Primordius", -- [1]
				"136216", -- [2]
				"Caustic Gas", -- [3]
				13, -- [4]
				"Interface\\Icons\\Ability_Rogue_DeviousPoisons", -- [5]
				["id"] = 1574,
			},
			["berserk"] = {
				"Council of Elders", -- [1]
				"berserk", -- [2]
				"Berserk", -- [3]
				600, -- [4]
				"Interface\\Icons\\Spell_Shadow_UnholyFrenzy", -- [5]
				["id"] = 1570,
			},
			["134926"] = {
				"Iron Qon", -- [1]
				"134926", -- [2]
				"Throw Spear", -- [3]
				31, -- [4]
				"Interface\\Icons\\inv_shield_73", -- [5]
				["id"] = 1559,
			},
			["-7643"] = {
				"Twin Consorts", -- [1]
				"-7643", -- [2]
				"[1] Tears of the Sun", -- [3]
				29, -- [4]
				"INTERFACE\\ICONS\\PALADIN_HOLY.BLP", -- [5]
				["id"] = 1560,
			},
			["bwcbTaintedbrewbreak"] = {
				"Bars", -- [1]
				"bwcbTaintedbrewbreak", -- [2]
				"Taintedbrew: break", -- [3]
				480, -- [4]
				"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
				["id"] = 1574,
			},
			["-7062"] = {
				"Council of Elders", -- [1]
				"-7062", -- [2]
				"Quicksand", -- [3]
				8, -- [4]
				"INTERFACE\\ICONS\\SPELL_QUICKSAND.BLP", -- [5]
				["id"] = 1570,
			},
			["136037"] = {
				"Primordius", -- [1]
				"136037", -- [2]
				"Primordial Strike", -- [3]
				3, -- [4]
				"Interface\\Icons\\inv_hand_1h_bwdraid_d_01", -- [5]
				["id"] = 1574,
			},
			["139869"] = {
				"Dark Animus", -- [1]
				"139869", -- [2]
				"[2] Interrupting Jolt", -- [3]
				21.8, -- [4]
				"Interface\\Icons\\Spell_Nature_LightningOverload", -- [5]
				["id"] = 1576,
			},
			["135095"] = {
				"Lei Shen", -- [1]
				"135095", -- [2]
				"Thunderstruck", -- [3]
				25, -- [4]
				"Interface\\Icons\\ability_thunderking_thunderstruck", -- [5]
				["id"] = 1579,
			},
			["adds"] = {
				"Horridon", -- [1]
				"adds", -- [2]
				"Next door (1)", -- [3]
				22, -- [4]
				"Interface\\Icons\\inv_shield_11", -- [5]
				["id"] = 1575,
			},
			["bats"] = {
				"Tortos", -- [1]
				"bats", -- [2]
				"Summon Bats", -- [3]
				46, -- [4]
				"Interface\\Icons\\Ability_Hunter_Pet_Bat", -- [5]
				["id"] = 1565,
			},
			["142028"] = {
				"Primordius", -- [1]
				"142028", -- [2]
				"Living Fluid", -- [3]
				15, -- [4]
				"Interface\\Icons\\spell_deathknight_bloodboil", -- [5]
				["id"] = 1574,
			},
			["136889"] = {
				"Lei Shen", -- [1]
				"136889", -- [2]
				"Violent Gale Winds", -- [3]
				20, -- [4]
				"Interface\\Icons\\Ability_Druid_GaleWinds", -- [5]
				["id"] = 1579,
			},
			["-7649"] = {
				"Twin Consorts", -- [1]
				"-7649", -- [2]
				"Ice Comet", -- [3]
				18, -- [4]
				"INTERFACE\\ICONS\\SPELL_FROST_ICE SHARDS.BLP", -- [5]
				["id"] = 1560,
			},
			["136990"] = {
				"Council of Elders", -- [1]
				"136990", -- [2]
				"Frostbite", -- [3]
				17, -- [4]
				"Interface\\Icons\\spell_mage_frostbomb", -- [5]
				["id"] = 1570,
			},
			["-7090"] = {
				"Horridon", -- [1]
				"-7090", -- [2]
				"Dino-Mending", -- [3]
				8, -- [4]
				"INTERFACE\\ICONS\\SPELL_NATURE_HEALINGWAVELESSER.BLP", -- [5]
				["id"] = 1575,
			},
			["-6917"] = {
				"Iron Qon", -- [1]
				"-6917", -- [2]
				"Fist Smash", -- [3]
				23, -- [4]
				"INTERFACE\\ICONS\\SPELL_NATURE_EARTHQUAKE.BLP", -- [5]
				["id"] = 1559,
			},
			["139180"] = {
				"Iron Qon", -- [1]
				"139180", -- [2]
				"Frost Spike", -- [3]
				15, -- [4]
				"Interface\\Icons\\Spell_Frost_Frostbolt", -- [5]
				["id"] = 1559,
			},
			["134626"] = {
				"Durumu the Forgotten", -- [1]
				"134626", -- [2]
				"Lingering Gaze", -- [3]
				15, -- [4]
				"Interface\\Icons\\inv_misc_eye_02", -- [5]
				["id"] = 1572,
			},
			["nil"] = {
				"Bars", -- [1]
				"nil", -- [2]
				"Pull", -- [3]
				15, -- [4]
				"Interface\\Icons\\ability_warrior_charge", -- [5]
				["id"] = 1570,
			},
			["-7638"] = {
				"Twin Consorts", -- [1]
				"-7638", -- [2]
				"Flames of Passion", -- [3]
				20.3, -- [4]
				"INTERFACE\\ICONS\\SPELL_FIRE_BURNINGSPEED.BLP", -- [5]
				["id"] = 1560,
			},
			["135145"] = {
				"Iron Qon", -- [1]
				"135145", -- [2]
				"Freeze", -- [3]
				4, -- [4]
				"Interface\\Icons\\Spell_Frost_ColdHearted", -- [5]
				["id"] = 1559,
			},
			["137528"] = {
				"Ji-Kun", -- [1]
				"137528", -- [2]
				"Feed Young", -- [3]
				40, -- [4]
				"Interface\\Icons\\INV_Misc_Slime_01", -- [5]
				["id"] = 1573,
			},
			["136992"] = {
				"Council of Elders", -- [1]
				"136992", -- [2]
				"Biting Cold", -- [3]
				29.98800000001211, -- [4]
				"Interface\\Icons\\ability_deathknight_remorselesswinters2", -- [5]
				["id"] = 1570,
			},
			["-7830"] = {
				"Primordius", -- [1]
				"-7830", -- [2]
				"Fully Mutated", -- [3]
				120, -- [4]
				"Interface\\Icons\\achievement_boss_primordius", -- [5]
				["id"] = 1574,
			},
			["136228"] = {
				"Primordius", -- [1]
				"136228", -- [2]
				"Volatile Pathogen", -- [3]
				25, -- [4]
				"Interface\\Icons\\Spell_Shadow_LifeDrain", -- [5]
				["id"] = 1574,
			},
			["136543"] = {
				"Lei Shen", -- [1]
				"136543", -- [2]
				"Ball Lightning", -- [3]
				13, -- [4]
				"Interface\\Icons\\ability_thunderking_balllightning", -- [5]
				["id"] = 1579,
			},
			["-6914"] = {
				"Iron Qon", -- [1]
				"-6914", -- [2]
				"Dead Zone", -- [3]
				17, -- [4]
				"INTERFACE\\ICONS\\SPELL_ARCANE_ARCANE01.BLP", -- [5]
				["id"] = 1559,
			},
			["-7242"] = {
				"Lei Shen", -- [1]
				"-7242", -- [2]
				"Bouncing Bolt", -- [3]
				40, -- [4]
				"Interface\\Icons\\SPELL_SHAMAN_MEASUREDINSIGHT", -- [5]
				["id"] = 1579,
			},
			["133597"] = {
				"Durumu the Forgotten", -- [1]
				"133597", -- [2]
				"Dark Parasite", -- [3]
				62, -- [4]
				"Interface\\Icons\\Spell_Shadow_CurseOfMannoroth", -- [5]
				["id"] = 1572,
			},
			["priestess_adds"] = {
				"Council of Elders", -- [1]
				"priestess_adds", -- [2]
				"Priestess add", -- [3]
				26, -- [4]
				"Interface\\Icons\\inv_misc_tournaments_banner_troll", -- [5]
				["id"] = 1570,
			},
			["137313"] = {
				"Jin'rokh the Breaker", -- [1]
				"137313", -- [2]
				"Storm", -- [3]
				92, -- [4]
				"Interface\\Icons\\Spell_Shaman_ThunderStorm", -- [5]
				["id"] = 1577,
			},
			["-6889"] = {
				"Durumu the Forgotten", -- [1]
				"-6889", -- [2]
				"Walls of Ice", -- [3]
				127, -- [4]
				"INTERFACE\\ICONS\\CREATUREPORTRAIT_CREATURE_ICEBLOCK.BLP", -- [5]
				["id"] = 1572,
			},
			["137122"] = {
				"Council of Elders", -- [1]
				"137122", -- [2]
				"Reckless Charge", -- [3]
				26, -- [4]
				"INTERFACE\\ICONS\\warrior_talent_icon_blitz", -- [5]
				["id"] = 1570,
			},
			["134920"] = {
				"Tortos", -- [1]
				"134920", -- [2]
				"Quake Stomp (1)", -- [3]
				28, -- [4]
				"Interface\\Icons\\Spell_Nature_Earthquake", -- [5]
				["id"] = 1565,
			},
			["136295"] = {
				"Lei Shen", -- [1]
				"136295", -- [2]
				"Overcharged", -- [3]
				40, -- [4]
				"Interface\\Icons\\ability_thunderking_overcharge", -- [5]
				["id"] = 1579,
			},
			["138300"] = {
				"Twin Consorts", -- [1]
				"138300", -- [2]
				"Fortitude of the Ox", -- [3]
				30, -- [4]
				"Interface\\Icons\\monk_stance_drunkenox", -- [5]
				["id"] = 1560,
			},
			["138855"] = {
				"Twin Consorts", -- [1]
				"138855", -- [2]
				"Xuen's Blessed Alacrity", -- [3]
				20, -- [4]
				"Interface\\Icons\\ability_monk_summontigerstatue", -- [5]
				["id"] = 1560,
			},
			["139458"] = {
				"Megaera", -- [1]
				"139458", -- [2]
				"Rampage Incoming!", -- [3]
				8, -- [4]
				"INTERFACE\\ICONS\\trade_archaeology_whitehydrafigurine", -- [5]
				["id"] = 1578,
			},
			["136850"] = {
				"Lei Shen", -- [1]
				"136850", -- [2]
				"Lightning Whip", -- [3]
				29, -- [4]
				"Interface\\Icons\\ability_thunderking_lightningwhip", -- [5]
				["id"] = 1579,
			},
			["137350"] = {
				"Council of Elders", -- [1]
				"137350", -- [2]
				"Fixated: Dizna", -- [3]
				20, -- [4]
				"Interface\\Icons\\spell_priest_divinestar_shadow2", -- [5]
				["id"] = 1570,
			},
			["136817"] = {
				"Horridon", -- [1]
				"136817", -- [2]
				"Bestial Cry", -- [3]
				5, -- [4]
				"Interface\\Icons\\Ability_Hunter_MastersCall", -- [5]
				["id"] = 1575,
			},
			["-6877"] = {
				"Iron Qon", -- [1]
				"-6877", -- [2]
				"Windstorm", -- [3]
				54, -- [4]
				"INTERFACE\\ICONS\\ABILITY_DRUID_GALEWINDS.BLP", -- [5]
				["id"] = 1559,
			},
		},
		["encounter_timers_dbm"] = {
			["nil"] = {
				"nil", -- [1]
				"Record Victory", -- [2]
				"Record Victory", -- [3]
				"76.335999999894sec", -- [4]
				["id"] = 1412,
			},
		},
	},
	["spell_school_cache"] = {
		["Feed Pool"] = 8,
		["Shadow Word: Pain"] = 32,
		["Rune Strike"] = 1,
		["Crush"] = 1,
		["Smoke Blades"] = 1,
		["Fire Bolt"] = 4,
		["Soulflame"] = 4,
		["Blind"] = 1,
		["Lightning Diffusion"] = 8,
		["Jab"] = 1,
		["Twirling Blades"] = 1,
		["Cry of the Sky"] = 8,
		["Wound Poison"] = 8,
		["Barrage"] = 1,
		["Fireball"] = 4,
		["Frost Strike Off-Hand"] = 16,
		["Sha Spine"] = 32,
		["Opportunity Strike"] = 1,
		["Static Shock"] = 8,
		["Avert Harm"] = 1,
		["Hex"] = 8,
		["Jade Fire"] = 4,
		["Spell Reflection"] = 1,
		["Charge Stun"] = 1,
		["Eye Sore"] = 64,
		["Plague Strike"] = 1,
		["Death and Decay"] = 32,
		["Violent Gale Winds"] = 8,
		["Eye Gouge"] = 1,
		["Seethe"] = 32,
		["Wildfire Infusion"] = 4,
		["Dark Bolt"] = 32,
		["Banshee Wail"] = 32,
		["Obliterate"] = 1,
		["Lay on Hands"] = 2,
		["Purifying Flames"] = 4,
		["Waterbolt"] = 16,
		["Scary Fog"] = 32,
		["Disable"] = 1,
		["Swift Reflexes"] = 1,
		["Binding Shot"] = 64,
		["Dispatch"] = 1,
		["Titan Gas"] = 16,
		["Fireball Volley"] = 4,
		["Fan of Knives"] = 1,
		["Volatile Amber"] = 8,
		["Blackout Kick"] = 1,
		["Soul Fragment"] = 32,
		["Ferment"] = 1,
		["Energizing Smash"] = 1,
		["Discharged Energy"] = 8,
		["Envenom"] = 8,
		["Leg Sweep"] = 1,
		["Sha Spike"] = 32,
		["Biting Cold"] = 16,
		["Touch of Karma"] = 8,
		["Mangle"] = 1,
		["Overpower"] = 1,
		["Corrosive Resin Pool"] = 8,
		["Amber Strike"] = 8,
		["Essence of Fear"] = 32,
		["Pierce the Veil"] = 32,
		["Mind Flay"] = 32,
		["Spirit Light"] = 4,
		["Psychic Scream"] = 32,
		["Waterspout"] = 16,
		["Deep Wounds"] = 1,
		["Concussive Shot"] = 1,
		["Chain Lightning"] = 8,
		["Inferno Blast"] = 4,
		["Hurl Brick"] = 1,
		["Woe Strike"] = 32,
		["Hammer of Wrath"] = 2,
		["Thunder Clap"] = 1,
		["Lightning Fissure"] = 8,
		["Rushing Winds"] = 8,
		["Sweeping Kick"] = 32,
		["Ignite Flesh"] = 4,
		["Colossus Smash"] = 1,
		["Compy Venom"] = 8,
		["Furious Stone Breath"] = 8,
		["Exhilaration"] = 1,
		["Throw"] = 8,
		["Flaming Spear"] = 4,
		["Deadly Poison"] = 8,
		["Implosion"] = 8,
		["Whirlwind"] = 1,
		["Gushing Brew"] = 16,
		["Mortal Strike"] = 1,
		["Blood Plague"] = 32,
		["Tidal Force"] = 16,
		["Piercing Roar"] = 1,
		["Mutilate"] = 1,
		["Smash"] = 1,
		["Ground Rupture"] = 1,
		["Tears of the Sun"] = 4,
		["Chain Heal"] = 8,
		["Meteor Burn"] = 4,
		["Searing Touch"] = 4,
		["Pheromone Trail"] = 8,
		["Shadowfury"] = 32,
		["Cobra Shot"] = 8,
		["Slash Armor"] = 1,
		["Ground Stomp"] = 1,
		["Shoot"] = 1,
		["Storm Cloud"] = 8,
		["Hex of Confusion"] = 1,
		["Frost Spike"] = 16,
		["Crystal Barbs"] = 1,
		["Crashing Star"] = 64,
		["Spirit Gale"] = 32,
		["Blood Boil"] = 32,
		["Slice Bone"] = 1,
		["Thunder"] = 8,
		["Corrupted Healing"] = 32,
		["Whirling Winds"] = 8,
		["Mind Fog"] = 32,
		["Skin Like Wax"] = 4,
		["Fel Flame"] = 36,
		["Leaping Cleave"] = 1,
		["Crashing Thunder"] = 8,
		["Immolate"] = 4,
		["Exploding Oil Barrel"] = 4,
		["Unleashed Wrath"] = 32,
		["Broken Leg"] = 1,
		["Invoke Lightning"] = 8,
		["Devastating Arc"] = 1,
		["Hold the Line"] = 1,
		["Lightning Strike"] = 8,
		["Drain Life"] = 32,
		["Curse of Vitality"] = 32,
		["Shadowburn"] = 32,
		["Torrent of Ice"] = 16,
		["Thundering Throw"] = 1,
		["Fulmination"] = 8,
		["Arcing Lightning"] = 8,
		["Censure"] = 2,
		["Darkness"] = 32,
		["Discharge"] = 8,
		["Amber Explosion"] = 8,
		["Quicksand"] = 8,
		["Corrupted Waters"] = 16,
		["Sha Corruption"] = 32,
		["Sundering Bite"] = 1,
		["Chilled"] = 16,
		["Unrelenting Agony"] = 32,
		["Bloody Mess"] = 1,
		["Cleansing Waters"] = 1,
		["Cone of Cold"] = 16,
		["Exorcism"] = 2,
		["Dark Plague"] = 8,
		["Slam"] = 1,
		["Entangling Roots"] = 8,
		["Chi Wave"] = 8,
		["Hammer of the Righteous"] = 1,
		["Venomous Wound"] = 8,
		["Crypt Scarabs"] = 1,
		["Curse of Agony"] = 32,
		["Greater Healing Wave"] = 8,
		["Hand of Light"] = 2,
		["Slime Trail"] = 8,
		["Stomp"] = 1,
		["Spiritfire Beam"] = 4,
		["Pheromones"] = 8,
		["Bloodbath"] = 1,
		["Scorched Earth"] = 4,
		["Dizzying Haze"] = 1,
		["Soul Link"] = 32,
		["Sha Screech"] = 32,
		["Impale"] = 1,
		["Mend Pet"] = 8,
		["Lightning Surge"] = 8,
		["Bladestorm"] = 1,
		["Rupture"] = 1,
		["Earth Shock"] = 8,
		["Choking Gas"] = 8,
		["Fire Nova"] = 4,
		["Cry of Terror"] = 32,
		["Living Poison"] = 8,
		["Pestilence"] = 32,
		["Rending Charge"] = 1,
		["Frost Nova"] = 16,
		["Void Shift"] = 32,
		["Scorch"] = 4,
		["Eviscerate"] = 1,
		["Conflagrate"] = 4,
		["Arcane Shot"] = 64,
		["Nothingness"] = 32,
		["Corpo-a-Corpo"] = 1,
		["Carrot Breath"] = 1,
		["Right Cross"] = 32,
		["Swipe"] = 1,
		["Dart"] = 1,
		["Energy Conduit"] = 64,
		["Lightning Storm"] = 8,
		["Pound"] = 1,
		["Incinerate"] = 4,
		["Shadow Word: Death"] = 32,
		["Lightning Bolt"] = 8,
		["Shadow Bolt"] = 32,
		["Cannon Barrage"] = 4,
		["Double Swipe"] = 1,
		["Frozen Resilience"] = 16,
		["Frost Strike"] = 16,
		["Spinning Crane Kick"] = 1,
		["Wind Blast"] = 8,
		["Rend"] = 1,
		["Crane Rush"] = 1,
		["Terrorize"] = 32,
		["Hurricane"] = 8,
		["Seal of Righteousness"] = 2,
		["Gale Force"] = 8,
		["Void Tendrils"] = 32,
		["Rushing Jade Wind"] = 1,
		["Torment"] = 32,
		["Defiled Ground"] = 32,
		["Sear Beam"] = 4,
		["Infected Talons"] = 8,
		["Lingering Gaze"] = 32,
		["Frost Aura"] = 16,
		["Shale Shards"] = 1,
		["Frigid Assault"] = 16,
		["Multi-Shot"] = 1,
		["Cinders"] = 4,
		["Storm Surge"] = 8,
		["Lightning Burst"] = 8,
		["Gaseous Eruption"] = 32,
		["Stormlash"] = 8,
		["Sik'thik Strike"] = 8,
		["Kill Shot"] = 1,
		["Thunderstorm"] = 8,
		["Malleable Resin"] = 8,
		["Burning Pitch"] = 4,
		["Amassing Darkness"] = 32,
		["Frost Fever"] = 16,
		["Deadly Plague"] = 32,
		["Dive"] = 1,
		["Claw"] = 1,
		["Dark Power"] = 32,
		["Pheromones of Zeal"] = 8,
		["Dread Screech Waves"] = 1,
		["Spray"] = 16,
		["Ring of Fire"] = 4,
		["Backstab"] = 1,
		["Dashing Strike"] = 1,
		["Shadows of Destruction"] = 32,
		["Healing Sphere"] = 8,
		["Shatter"] = 16,
		["Left Hook"] = 32,
		["Overload"] = 8,
		["Wildfire"] = 4,
		["Death Siphon"] = 48,
		["Ice Lance"] = 16,
		["Arterial Bleeding"] = 1,
		["Glaive Toss"] = 1,
		["Chilled to the Bone"] = 16,
		["Cheep"] = 1,
		["Sand Trap"] = 8,
		["Cowardice"] = 32,
		["Astral Storm"] = 64,
		["Icy Touch"] = 16,
		["Heart Strike"] = 1,
		["Amethyst Pool"] = 32,
		["Intimidating Shout"] = 1,
		["Skin Flay"] = 1,
		["Frozen Blood"] = 16,
		["Wrath"] = 8,
		["Razor Frost"] = 16,
		["Heroic Leap"] = 1,
		["Rain of Blades"] = 1,
		["Fire Breath Potion"] = 4,
		["Rain of Fire"] = 4,
		["Seal of Truth"] = 2,
		["Fading Light"] = 1,
		["Frostbite"] = 16,
		["Judgment"] = 2,
		["Obliterate Off-Hand"] = 1,
		["Shadow Blade Off-hand"] = 32,
		["Sweeping Strikes"] = 1,
		["Rake"] = 1,
		["Focused Lightning"] = 8,
		["Arcing Light"] = 2,
		["Death Blossom"] = 1,
		["Shadow Blade"] = 32,
		["Pinned Down"] = 1,
		["Electrified Waters"] = 8,
		["Lightning Lash"] = 8,
		["Throw Axe"] = 1,
		["Mind Sear"] = 32,
		["Ambush"] = 1,
		["Hand of Sacrifice"] = 2,
		["Arcane Bomb"] = 64,
		["Wind Storm"] = 8,
		["Toxic Slime"] = 8,
		["Gravity Flux"] = 32,
		["Gorefiend's Grasp"] = 32,
		["Geyser"] = 16,
		["Engulfing Winds"] = 8,
		["Crushing Charge"] = 1,
		["Megaera's Rage"] = 8,
		["Devour"] = 1,
		["Mace Smash"] = 1,
		["Consumption"] = 32,
		["Vicious Rend"] = 1,
		["Hammer Fist"] = 32,
		["Lava Burst"] = 4,
		["Divine Storm"] = 2,
		["Will of the Empress"] = 1,
		["Execute"] = 1,
		["Arc Nova"] = 8,
		["Arcane Explosion"] = 64,
		["Poison Blast"] = 1,
		["Fists of Fury"] = 1,
		["Slice"] = 1,
		["Sunfire"] = 8,
		["Burning Cinders"] = 4,
		["Frostbolt Volley"] = 16,
		["Ursol's Vortex"] = 8,
		["Thunder Trap"] = 8,
		["Death Strike"] = 1,
		["Jade Serpent Wave"] = 4,
		["Soul Reaper"] = 32,
		["Light of Day"] = 4,
		["Crimson Tempest"] = 1,
		["Restorative Mists"] = 8,
		["Overloaded Circuits"] = 8,
		["Flames of Passion"] = 4,
		["Strike from the Shadows"] = 1,
		["Typhoon"] = 8,
		["Wind Bomb"] = 8,
		["Sha Blast"] = 32,
		["Dread Shadows"] = 32,
		["Rising Sun Kick"] = 1,
		["Magma Blast"] = 4,
		["Serpent's Vitality"] = 8,
		["Shadow Nova"] = 32,
	},
	["deathlog_healingdone_min"] = 1,
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["damage_taken_shadow"] = true,
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_size"] = 12,
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["run_code"] = {
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--use the role icon in the player bar when inside an arena (default false)\nDetails.show_arena_role_icon = false;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_groupchange"] = "\n-- this code runs when the player enter or leave a group",
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
	["spellid_ignored"] = {
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["show_totalhitdamage_on_overkill"] = false,
	["createauraframe"] = {
	},
	["switchSaved"] = {
		["slots"] = 10,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
			{
				["atributo"] = 1,
				["sub_atributo"] = 3,
			}, -- [5]
			{
				["atributo"] = 1,
				["sub_atributo"] = 4,
			}, -- [6]
			{
				["atributo"] = 4,
				["sub_atributo"] = 1,
			}, -- [7]
			{
				["atributo"] = 4,
				["sub_atributo"] = 3,
			}, -- [8]
			{
				["atributo"] = 4,
				["sub_atributo"] = 4,
			}, -- [9]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [10]
			{
				["atributo"] = 4,
				["sub_atributo"] = 6,
			}, -- [11]
			{
				["atributo"] = 5,
				["sub_atributo"] = 2,
			}, -- [12]
		},
	},
	["item_level_pool"] = {
		["0x010200000007DC7F"] = {
			["name"] = "News",
			["time"] = 1660852767,
			["ilvl"] = 126.375,
		},
		["0x010200000007B6D9"] = {
			["name"] = "Sargera",
			["time"] = 1660853568,
			["ilvl"] = 519.3333333333334,
		},
		["0x010200000004096C"] = {
			["name"] = "News",
			["time"] = 1660852767,
			["ilvl"] = 220.5625,
		},
		["0x01020000000876E3"] = {
			["time"] = 1660937620,
			["name"] = "Wafty",
			["ilvl"] = 528.375,
		},
	},
	["savedCustomSpells"] = {
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\AddOns\\Details\\images\\melee.tga", -- [3]
		}, -- [1]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\AddOns\\Details\\images\\autoshot.tga", -- [3]
		}, -- [2]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [3]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [4]
		{
			140816, -- [1]
			"Power Word: Solace (critical)", -- [2]
			"Interface\\Icons\\ability_priest_flashoflight", -- [3]
		}, -- [5]
		{
			77451, -- [1]
			"Lava Burst (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shaman_LavaBurst", -- [3]
		}, -- [6]
		{
			94472, -- [1]
			"Atonement (critical)", -- [2]
			"Interface\\Icons\\Spell_Holy_CircleOfRenewal", -- [3]
		}, -- [7]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [8]
		{
			131079, -- [1]
			"Frostbolt (Icy Veins)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBolt02", -- [3]
		}, -- [9]
		{
			124465, -- [1]
			"Vampiric Touch (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Holy_Stoicism", -- [3]
		}, -- [10]
		{
			114654, -- [1]
			"Incinerate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\spell_fire_ragnaros_lavabolt", -- [3]
		}, -- [11]
		{
			3, -- [1]
			"Environment (falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [12]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [13]
		{
			131080, -- [1]
			"Ice Lance (Icy Veins)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBlast", -- [3]
		}, -- [14]
		{
			45297, -- [1]
			"Chain Lightning (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Nature_ChainLightning", -- [3]
		}, -- [15]
		{
			108685, -- [1]
			"Conflagrate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\spell_fire_ragnaros_molteninferno", -- [3]
		}, -- [16]
		{
			108686, -- [1]
			"Immolate (Fire and Brimstone)", -- [2]
			"Interface\\Icons\\Ability_Mage_WorldInFlames", -- [3]
		}, -- [17]
		{
			120761, -- [1]
			"Glaive Toss (Glaive #2)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [18]
		{
			121414, -- [1]
			"Glaive Toss (Glaive #1)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [19]
		{
			45284, -- [1]
			"Lightning Bolt (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Nature_Lightning", -- [3]
		}, -- [20]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [21]
		{
			131081, -- [1]
			"Frostfire Bolt (Icy Veins)", -- [2]
			"Interface\\Icons\\Ability_Mage_FrostFireBolt", -- [3]
		}, -- [22]
		{
			33778, -- [1]
			"Lifebloom (bloom)", -- [2]
			"Interface\\Icons\\Spell_Nature_HealingTouch", -- [3]
		}, -- [23]
		{
			124469, -- [1]
			"Mind Sear (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_MindShear", -- [3]
		}, -- [24]
		{
			124464, -- [1]
			"Shadow Word: Pain (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_ShadowWordPain", -- [3]
		}, -- [25]
		{
			124468, -- [1]
			"Mind Flay (Mastery)", -- [2]
			"Interface\\Icons\\Spell_Shadow_SiphonMana", -- [3]
		}, -- [26]
		{
			55090, -- [1]
			"Scourge Strike (Physical)", -- [2]
			"Interface\\Icons\\Spell_DeathKnight_ScourgeStrike", -- [3]
		}, -- [27]
		{
			70890, -- [1]
			"Scourge Strike (Shadow)", -- [2]
			"Interface\\Icons\\Spell_Shadow_ShadowBolt", -- [3]
		}, -- [28]
		{
			44461, -- [1]
			"Living Bomb (explosion)", -- [2]
			"Interface\\Icons\\Ability_Mage_LivingBomb", -- [3]
		}, -- [29]
		{
			59638, -- [1]
			"Frostbolt (Mirror Image)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBolt02", -- [3]
		}, -- [30]
	},
	["dungeon_data"] = {
	},
	["tutorial"] = {
		["bookmark_tutorial"] = true,
		["main_help_button"] = 584,
		["FULL_DELETE_WINDOW"] = true,
		["unlock_button"] = 4,
		["version_announce"] = 0,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["DETAILS_INFO_TUTORIAL2"] = 10,
		["feedback_window1"] = true,
		["TIME_ATTACK_TUTORIAL1"] = true,
		["logons"] = 584,
		["STREAMER_FEATURES_POPUP1"] = true,
		["MIN_COMBAT_TIME"] = true,
		["ctrl_click_close_tutorial"] = false,
		["DISABLE_ONDEATH_PANEL"] = true,
		["ATTRIBUTE_SELECT_TUTORIAL1"] = true,
	},
	["raid_data"] = {
		[3] = {
			[1407] = {
				["longest"] = 574.3299999999581,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9008458364558658, -- [1]
						171.4379999999655, -- [2]
					}, -- [1]
					{
						0.7799025767337927, -- [1]
						223.0320000000065, -- [2]
					}, -- [2]
					{
						0.002188659994892532, -- [1]
						574.3299999999581, -- [2]
					}, -- [3]
					{
						0.002179545885787972, -- [1]
						378.8530000001192, -- [2]
					}, -- [4]
				},
				["wipes"] = 6,
				["best_try"] = 0.002179545885787972,
			},
			[1434] = {
				["longest"] = 281.814000000013,
				["kills"] = 0,
				["try_history"] = {
					{
						0.002563661107353089, -- [1]
						281.814000000013, -- [2]
					}, -- [1]
				},
				["wipes"] = 2,
				["best_try"] = 0.002563661107353089,
			},
			[1206] = {
				["longest"] = 131.0780000002123,
				["kills"] = 0,
				["try_history"] = {
					{
						0.005945502620862375, -- [1]
						131.0780000002123, -- [2]
					}, -- [1]
				},
				["wipes"] = 1,
				["best_try"] = 0.005945502620862375,
			},
			[1390] = {
				["longest"] = 341.0559999999823,
				["kills"] = 0,
				["try_history"] = {
					{
						0.739427706177152, -- [1]
						75.72800000000279, -- [2]
					}, -- [1]
					{
						0.7200972601322552, -- [1]
						87.16399999998976, -- [2]
					}, -- [2]
					{
						0.118435496599391, -- [1]
						339.7800000000279, -- [2]
					}, -- [3]
					{
						0.001047010444005171, -- [1]
						341.0559999999823, -- [2]
					}, -- [4]
				},
				["wipes"] = 5,
				["best_try"] = 0.001047010444005171,
			},
			[1499] = {
				["longest"] = 329.0039999999572,
				["kills"] = 0,
				["try_history"] = {
					{
						0.7514561617373653, -- [1]
						116.8870000001043, -- [2]
					}, -- [1]
					{
						0.6878055920558098, -- [1]
						256.3449999999721, -- [2]
					}, -- [2]
					{
						0.6778587494820894, -- [1]
						216.6499999999069, -- [2]
					}, -- [3]
				},
				["wipes"] = 12,
				["best_try"] = 0.6778587494820894,
			},
			[1559] = {
				["longest"] = 524.0310000001919,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9930602454915083, -- [1]
						321.8629999998957, -- [2]
					}, -- [1]
					{
						0.002168676410527628, -- [1]
						524.0310000001919, -- [2]
					}, -- [2]
				},
				["wipes"] = 3,
				["best_try"] = 0.002168676410527628,
			},
			[1395] = {
				["longest"] = 266.359999999986,
				["kills"] = 0,
				["try_history"] = {
					{
						0.6030958971425371, -- [1]
						85.38000000000466, -- [2]
					}, -- [1]
					{
						0.0001944954545782494, -- [1]
						266.359999999986, -- [2]
					}, -- [2]
				},
				["wipes"] = 6,
				["best_try"] = 0.0001944954545782494,
			},
			[1436] = {
				["longest"] = 419.7760000000708,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9997181160965476, -- [1]
						11.07000000006519, -- [2]
					}, -- [1]
					{
						0.002670170152956525, -- [1]
						419.7760000000708, -- [2]
					}, -- [2]
					{
						0.0008408367095660309, -- [1]
						380.2770000000019, -- [2]
					}, -- [3]
				},
				["wipes"] = 8,
				["best_try"] = 0.0008408367095660309,
			},
			[1560] = {
				["longest"] = 446.3700000001118,
				["kills"] = 0,
				["try_history"] = {
					{
						0.002903654253381716, -- [1]
						446.3700000001118, -- [2]
					}, -- [1]
				},
				["wipes"] = 1,
				["best_try"] = 0.002903654253381716,
			},
			[1579] = {
				["longest"] = 490.9420000000391,
				["kills"] = 0,
				["try_history"] = {
					{
						0.6518798741597147, -- [1]
						177.096000000136, -- [2]
					}, -- [1]
					{
						0.6427226200126005, -- [1]
						247.2469999999739, -- [2]
					}, -- [2]
					{
						0.635944805408729, -- [1]
						205.5220000001136, -- [2]
					}, -- [3]
					{
						0.5856626205393199, -- [1]
						235.185999999987, -- [2]
					}, -- [4]
					{
						0.4599150031919007, -- [1]
						282.9429999999702, -- [2]
					}, -- [5]
					{
						0.4489604493422663, -- [1]
						305.2419999998529, -- [2]
					}, -- [6]
					{
						0.32418972295429, -- [1]
						356.7590000000782, -- [2]
					}, -- [7]
					{
						0.001689887675609204, -- [1]
						490.9420000000391, -- [2]
					}, -- [8]
				},
				["wipes"] = 9,
				["best_try"] = 0.001689887675609204,
			},
			[1500] = {
				["longest"] = 539.3260000000009,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9044370766535884, -- [1]
						28.00899999996182, -- [2]
					}, -- [1]
					{
						0.8935423078741686, -- [1]
						32.12100000004284, -- [2]
					}, -- [2]
					{
						0.8897507470299513, -- [1]
						56.19999999995343, -- [2]
					}, -- [3]
					{
						0.1409777247027506, -- [1]
						469.3170000000391, -- [2]
					}, -- [4]
					{
						0.1122614137426336, -- [1]
						539.3260000000009, -- [2]
					}, -- [5]
					{
						0.002586944476299123, -- [1]
						521.2700000000186, -- [2]
					}, -- [6]
					{
						0.002193374640547884, -- [1]
						464.7069999999367, -- [2]
					}, -- [7]
				},
				["wipes"] = 16,
				["best_try"] = 0.002193374640547884,
			},
			[1197] = {
				["longest"] = 80.82799999974668,
				["kills"] = 0,
				["try_history"] = {
					{
						0.001905531398880238, -- [1]
						80.82799999974668, -- [2]
					}, -- [1]
				},
				["wipes"] = 1,
				["best_try"] = 0.001905531398880238,
			},
		},
		[4] = {
			[1572] = {
				["longest"] = 427.4350000000013,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9986064750663869, -- [1]
						22.67900000000009, -- [2]
					}, -- [1]
					{
						0.6755780591937147, -- [1]
						83.29800000000068, -- [2]
					}, -- [2]
					{
						0.3322128274394191, -- [1]
						267.2669999999998, -- [2]
					}, -- [3]
					{
						0.001838481963628472, -- [1]
						427.4350000000013, -- [2]
					}, -- [4]
					{
						0.0004218361093146431, -- [1]
						356.3600000000001, -- [2]
					}, -- [5]
				},
				["wipes"] = 11,
				["best_try"] = 0.0004218361093146431,
			},
			[1573] = {
				["longest"] = 362.0380000000005,
				["kills"] = 0,
				["try_history"] = {
					{
						0.3447600747288139, -- [1]
						248.6340000000782, -- [2]
					}, -- [1]
					{
						0.1268899874818711, -- [1]
						337.2710000000661, -- [2]
					}, -- [2]
					{
						0.001237305102739236, -- [1]
						362.0380000000005, -- [2]
					}, -- [3]
					{
						3.963641043845027e-005, -- [1]
						307.3330000000133, -- [2]
					}, -- [4]
				},
				["wipes"] = 11,
				["best_try"] = 3.963641043845027e-005,
			},
			[1574] = {
				["longest"] = 400.0249999999942,
				["kills"] = 0,
				["try_history"] = {
					{
						0.001570041819764329, -- [1]
						391.0360000000001, -- [2]
					}, -- [1]
					{
						0.0001946743022204839, -- [1]
						304.6830000000773, -- [2]
					}, -- [2]
				},
				["wipes"] = 5,
				["best_try"] = 0.0001946743022204839,
			},
			[1575] = {
				["longest"] = 412.0670000000391,
				["kills"] = 0,
				["try_history"] = {
					{
						0.003069930658554865, -- [1]
						412.0670000000391, -- [2]
					}, -- [1]
					{
						0.001622022580196342, -- [1]
						393.297, -- [2]
					}, -- [2]
					{
						0.000700549484144432, -- [1]
						393.5760000000009, -- [2]
					}, -- [3]
				},
				["wipes"] = 3,
				["best_try"] = 0.000700549484144432,
			},
			[1390] = {
				["longest"] = 306.6699999999255,
				["kills"] = 0,
				["try_history"] = {
					{
						0.0001581001722831341, -- [1]
						306.6699999999255, -- [2]
					}, -- [1]
				},
				["wipes"] = 1,
				["best_try"] = 0.0001581001722831341,
			},
			[1577] = {
				["longest"] = 224.1179999999999,
				["kills"] = 0,
				["try_history"] = {
					{
						0.1483255827043582, -- [1]
						179.2189999999246, -- [2]
					}, -- [1]
					{
						0.00572689323746543, -- [1]
						155.5439999999944, -- [2]
					}, -- [2]
					{
						0.004892985148346466, -- [1]
						155.3130000000001, -- [2]
					}, -- [3]
					{
						0.004717814369642228, -- [1]
						153.323000000004, -- [2]
					}, -- [4]
				},
				["wipes"] = 7,
				["best_try"] = 0.004717814369642228,
			},
			[1578] = {
				["longest"] = 364.1359999999995,
				["kills"] = 0,
				["try_history"] = {
					{
						0.1000000060763097, -- [1]
						351.9469999999274, -- [2]
					}, -- [1]
				},
				["wipes"] = 5,
				["best_try"] = 0.1000000060763097,
			},
			[1579] = {
				["longest"] = 564.5300000000279,
				["kills"] = 0,
				["try_history"] = {
					{
						0.6441761202025259, -- [1]
						209.9959999999846, -- [2]
					}, -- [1]
					{
						0.3614876975324053, -- [1]
						407.5029999999679, -- [2]
					}, -- [2]
					{
						0.2828954990192145, -- [1]
						465.2260000000242, -- [2]
					}, -- [3]
					{
						0.0003205879489572657, -- [1]
						517.5119999999879, -- [2]
					}, -- [4]
					{
						5.86314988188814e-005, -- [1]
						564.5300000000279, -- [2]
					}, -- [5]
				},
				["wipes"] = 21,
				["best_try"] = 5.86314988188814e-005,
			},
			[1395] = {
				["longest"] = 217.3129999998491,
				["kills"] = 0,
				["try_history"] = {
					{
						0.001042202030711888, -- [1]
						217.3129999998491, -- [2]
					}, -- [1]
				},
				["wipes"] = 1,
				["best_try"] = 0.001042202030711888,
			},
			[1431] = {
				["longest"] = 482.2939999999944,
				["kills"] = 0,
				["try_history"] = {
					{
						0.004260059494784862, -- [1]
						210.4839999999385, -- [2]
					}, -- [1]
					{
						0.001314502072673573, -- [1]
						406.5650000000605, -- [2]
					}, -- [2]
				},
				["wipes"] = 12,
				["best_try"] = 0.001314502072673573,
			},
			[1463] = {
				["longest"] = 479.7719999998808,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9998704703652264, -- [1]
						9.93100000009872, -- [2]
					}, -- [1]
					{
						0.007589817347903543, -- [1]
						59.34000000008382, -- [2]
					}, -- [2]
					{
						0.0006780606358212481, -- [1]
						479.7719999998808, -- [2]
					}, -- [3]
				},
				["wipes"] = 30,
				["best_try"] = 0.0006780606358212481,
			},
			[1576] = {
				["longest"] = 214.2269999999553,
				["kills"] = 0,
				["try_history"] = {
					{
						0.01503113938157326, -- [1]
						214.2269999999553, -- [2]
					}, -- [1]
					{
						0.01213106400978393, -- [1]
						201.9749999999995, -- [2]
					}, -- [2]
					{
						0.009932739907652817, -- [1]
						155.3030000000144, -- [2]
					}, -- [3]
				},
				["wipes"] = 15,
				["best_try"] = 0.009932739907652817,
			},
			[1436] = {
				["longest"] = 387.2560000000522,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9998944292001694, -- [1]
						11.16499999980442, -- [2]
					}, -- [1]
					{
						0.002204773509095429, -- [1]
						387.2560000000522, -- [2]
					}, -- [2]
					{
						0.0004978710665724741, -- [1]
						372.6280000000261, -- [2]
					}, -- [3]
				},
				["wipes"] = 5,
				["best_try"] = 0.0004978710665724741,
			},
			[1559] = {
				["longest"] = 626.3899999999994,
				["kills"] = 0,
				["try_history"] = {
					{
						0.003267110753611854, -- [1]
						602.4280000000144, -- [2]
					}, -- [1]
					{
						0.002426629782028124, -- [1]
						423.7030000000959, -- [2]
					}, -- [2]
				},
				["wipes"] = 7,
				["best_try"] = 0.002426629782028124,
			},
			[1498] = {
				["longest"] = 445.5590000001248,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9159352363250343, -- [1]
						109.1390000001993, -- [2]
					}, -- [1]
					{
						0.0005938437196236371, -- [1]
						445.5590000001248, -- [2]
					}, -- [2]
					{
						0.0003841378362670396, -- [1]
						402.5449999999983, -- [2]
					}, -- [3]
				},
				["wipes"] = 13,
				["best_try"] = 0.0003841378362670396,
			},
			[1499] = {
				["longest"] = 439.4919999999693,
				["kills"] = 0,
				["try_history"] = {
					{
						0.6929507428907232, -- [1]
						152.065000000177, -- [2]
					}, -- [1]
					{
						0.2737124755220647, -- [1]
						439.4919999999693, -- [2]
					}, -- [2]
					{
						0.0006711010490061545, -- [1]
						417.1510000000126, -- [2]
					}, -- [3]
				},
				["wipes"] = 13,
				["best_try"] = 0.0006711010490061545,
			},
			[1407] = {
				["longest"] = 550.9499999999534,
				["kills"] = 0,
				["try_history"] = {
					{
						0.002995755250681611, -- [1]
						550.9499999999534, -- [2]
					}, -- [1]
					{
						0.001036661773727453, -- [1]
						518.0550000001676, -- [2]
					}, -- [2]
					{
						3.095121848302127e-005, -- [1]
						395.8769999999786, -- [2]
					}, -- [3]
				},
				["wipes"] = 4,
				["best_try"] = 3.095121848302127e-005,
			},
			[1501] = {
				["longest"] = 625.0149999999558,
				["kills"] = 0,
				["try_history"] = {
					{
						0.7674779449382982, -- [1]
						210.2750000000233, -- [2]
					}, -- [1]
					{
						0.1886786663210522, -- [1]
						488.6639999999898, -- [2]
					}, -- [2]
					{
						0.0001458159098000869, -- [1]
						625.0149999999558, -- [2]
					}, -- [3]
				},
				["wipes"] = 14,
				["best_try"] = 0.0001458159098000869,
			},
			[1409] = {
				["longest"] = 384.408000000054,
				["kills"] = 0,
				["try_history"] = {
					{
						0.002837217720578625, -- [1]
						384.408000000054, -- [2]
					}, -- [1]
					{
						0.002015460512328922, -- [1]
						332.4830000000075, -- [2]
					}, -- [2]
				},
				["wipes"] = 3,
				["best_try"] = 0.002015460512328922,
			},
			[1565] = {
				["longest"] = 291.7399999999998,
				["kills"] = 0,
				["try_history"] = {
					{
						0.7675940048441761, -- [1]
						77.82200000004377, -- [2]
					}, -- [1]
					{
						0.003174123829102795, -- [1]
						250.5200000000186, -- [2]
					}, -- [2]
					{
						0.002650382097263468, -- [1]
						235.1039999999921, -- [2]
					}, -- [3]
					{
						3.548011732092127e-005, -- [1]
						210.1629999999987, -- [2]
					}, -- [4]
				},
				["wipes"] = 15,
				["best_try"] = 3.548011732092127e-005,
			},
			[1504] = {
				["longest"] = 445.8229999998584,
				["kills"] = 0,
				["try_history"] = {
					{
						0.0006859631607310943, -- [1]
						445.8229999998584, -- [2]
					}, -- [1]
				},
				["wipes"] = 5,
				["best_try"] = 0.0006859631607310943,
			},
			[1505] = {
				["longest"] = 496.563000000082,
				["kills"] = 0,
				["try_history"] = {
					{
						0.008135469972399318, -- [1]
						496.563000000082, -- [2]
					}, -- [1]
					{
						0.005808476669533452, -- [1]
						371.4160000000848, -- [2]
					}, -- [2]
					{
						0.003246487434101748, -- [1]
						336.9250000000011, -- [2]
					}, -- [3]
					{
						0.0006782019779831847, -- [1]
						318.7770000000019, -- [2]
					}, -- [4]
					{
						1.910714541204116e-009, -- [1]
						305.0999999999767, -- [2]
					}, -- [5]
				},
				["wipes"] = 7,
				["best_try"] = 1.910714541204116e-009,
			},
			[1506] = {
				["longest"] = 334.0880000000016,
				["kills"] = 0,
				["try_history"] = {
					{
						0.01470468680164386, -- [1]
						316.984999999986, -- [2]
					}, -- [1]
					{
						0.01117127987675451, -- [1]
						334.0880000000016, -- [2]
					}, -- [2]
				},
				["wipes"] = 3,
				["best_try"] = 0.01117127987675451,
			},
			[1507] = {
				["longest"] = 352.8889999999665,
				["kills"] = 0,
				["try_history"] = {
					{
						0.9999494012193306, -- [1]
						21.16099999984726, -- [2]
					}, -- [1]
					{
						0.001406005478205343, -- [1]
						352.8889999999665, -- [2]
					}, -- [2]
					{
						0.0008178278993587409, -- [1]
						289.4259999999922, -- [2]
					}, -- [3]
				},
				["wipes"] = 9,
				["best_try"] = 0.0008178278993587409,
			},
			[1570] = {
				["longest"] = 299.4890000000014,
				["kills"] = 0,
				["try_history"] = {
					{
						0.007065723504057761, -- [1]
						281.9969999999739, -- [2]
					}, -- [1]
					{
						0.006287932769531959, -- [1]
						267.5419999999999, -- [2]
					}, -- [2]
					{
						0.003554650577757383, -- [1]
						238.5580000000191, -- [2]
					}, -- [3]
					{
						0.001149669981655002, -- [1]
						229.6229999999996, -- [2]
					}, -- [4]
				},
				["wipes"] = 9,
				["best_try"] = 0.001149669981655002,
			},
			[1500] = {
				["longest"] = 501.6800000001676,
				["kills"] = 0,
				["try_history"] = {
					{
						0.0003890837751139576, -- [1]
						501.6800000001676, -- [2]
					}, -- [1]
				},
				["wipes"] = 3,
				["best_try"] = 0.0003890837751139576,
			},
			[1560] = {
				["longest"] = 445.2580000000307,
				["kills"] = 0,
				["try_history"] = {
					{
						0.0005765712482065942, -- [1]
						445.2580000000307, -- [2]
					}, -- [1]
					{
						0.0002122959195606945, -- [1]
						436.3260000000009, -- [2]
					}, -- [2]
				},
				["wipes"] = 7,
				["best_try"] = 0.0002122959195606945,
			},
		},
	},
	["realm_sync"] = true,
	["always_use_profile_name"] = "Lotusprep-[EN] Evermoon",
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["details_auras"] = {
	},
	["latest_news_saw"] = "v4.3.4.8048",
	["savedTimeCaptures"] = {
		{
			"Player Damage Done", -- [1]
			"\n	-- the goal of this script is get the current combat then get your character and extract your damage done.\n	-- the first thing to do is get the combat, so, we use here the command \"_detalhes:GetCombat ( \"overall\" \"current\" or \"segment number\")\"\n\n	local current_combat = _detalhes:GetCombat (\"current\") --> getting the current combat\n\n	-- the next step is request your character from the combat\n	-- to do this, we take the combat which here we named \"current_combat\" and tells what we want inside parentheses.\n\n	local my_self = current_combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n\n	-- _detalhes.playername holds the name of your character.\n	-- DETAILS_ATTRIBUTE_DAMAGE means we want the damage table, _HEAL _ENERGY _MISC is the other 3 tables.\n\n	-- before we proceed, the result needs to be checked to make sure its a valid result.\n\n	if (not my_self) then\n		return 0 -- the combat doesnt have *you*, this happens when you didn't deal any damage in the combat yet.\n	end\n\n	-- now its time to get the total damage.\n\n	local my_damage = my_self.total\n\n	-- then finally return the amount to the capture.\n\n	return my_damage\n\n", -- [2]
			{
				["max_value"] = 0,
				["last_value"] = 0,
			}, -- [3]
			"Chart Viewer", -- [4]
			"1.0", -- [5]
			"Interface\\ICONS\\Ability_MeleeDamage", -- [6]
			true, -- [7]
		}, -- [1]
	},
	["plugin_window_pos"] = {
		["y"] = 25.09849548339844,
		["x"] = -121.3070373535156,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["custom"] = {
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["tooltip"] = "		--init:\n		local player, combat, instance = ...\n\n		--get the debuff container for potion of focus\n		local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n		if(debuff_uptime_container) then\n			local focus_potion = debuff_uptime_container[DETAILS_FOCUS_POTION_ID]\n			if(focus_potion) then\n			local name, _, icon = GetSpellInfo(DETAILS_FOCUS_POTION_ID)\n			GameCooltip:AddLine(name, 1) --> can use only 1 focus potion(can't be pre-potion)\n			_detalhes:AddTooltipBackgroundStatusbar()\n			GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n		end\n\n		--get the misc actor container\n		local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n		if(buff_uptime_container) then\n			for spellId, _ in pairs(DetailsFramework.PotionIDs) do\n				local potionUsed = buff_uptime_container[spellId]\n\n				if(potionUsed) then\n					local name, _, icon = GetSpellInfo(spellId)\n					GameCooltip:AddLine(name, potionUsed.activedamt)\n					_detalhes:AddTooltipBackgroundStatusbar()\n					GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n			end\n		end\n		",
			["attribute"] = false,
			["name"] = "Potion Used",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the misc actor container\n			local misc_container = combat:GetActorList( DETAILS_ATTRIBUTE_MISC )\n\n			--do the loop:\n			for _, player in ipairs( misc_container ) do\n\n				--only player in group\n				if(player:IsGroupPlayer()) then\n\n					local found_potion = false\n\n					--get the spell debuff uptime container\n					local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n					if(debuff_uptime_container) then\n						--potion of focus(can't use as pre-potion, so, its amount is always 1\n						local focus_potion = debuff_uptime_container[DETAILS_FOCUS_POTION_ID]\n\n						if(focus_potion) then\n							total = total + 1\n							found_potion = true\n							if(top < 1) then\n								top = 1\n							end\n							--add amount to the player\n							instance_container:AddValue(player, 1)\n						end\n					end\n\n					--get the spell buff uptime container\n					local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n					if(buff_uptime_container) then\n						for spellId, _ in pairs(DetailsFramework.PotionIDs) do\n							local potionUsed = buff_uptime_container[spellId]\n\n							if(potionUsed) then\n								local used = potionUsed.activedamt\n								if(used and used > 0) then\n									total = total + used\n									found_potion = true\n									if(used > top) then\n										top = used\n									end\n\n									--add amount to the player\n									instance_container:AddValue(player, used)\n								end\n							end\n						end\n					end\n\n					if(found_potion) then\n						amount = amount + 1\n					end\n				end\n			end\n\n			--return:\n			return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Potion_03",
			["script_version"] = 6,
		}, -- [1]
		{
			["source"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["author"] = "Details! Team",
			["percent_script"] = false,
			["total_script"] = false,
			["attribute"] = false,
			["tooltip"] = "		--get the parameters passed\n		local actor, combat, instance = ...\n\n		--get the cooltip object(we dont use the convencional GameTooltip here)\n		local GameCooltip = GameCooltip\n		local R, G, B, A = 0, 0, 0, 0.75\n\n		local hs = actor:GetSpell(6262)\n		if(hs) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(6262)),  _detalhes:ToK(hs.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(6262)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		local pot = actor:GetSpell(DETAILS_HEALTH_POTION_ID)\n		if(pot) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(DETAILS_HEALTH_POTION_ID)),  _detalhes:ToK(pot.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(DETAILS_HEALTH_POTION_ID)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		local pot = actor:GetSpell(DETAILS_REJU_POTION_ID)\n		if(pot) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(DETAILS_REJU_POTION_ID)),  _detalhes:ToK(pot.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(DETAILS_REJU_POTION_ID)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		--Cooltip code\n		",
			["name"] = "Health Potion & Stone",
			["script"] = "		--get the parameters passed\n		local combat, instance_container, instance = ...\n		--declade the values to return\n		local total, top, amount = 0, 0, 0\n\n		--do the loop\n		local AllHealCharacters = combat:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n		for index, character in ipairs(AllHealCharacters) do\n			local AllSpells = character:GetSpellList()\n			local found = false\n			for spellid, spell in pairs(AllSpells) do\n				if(DETAILS_HEALTH_POTION_LIST[spellid]) then\n					instance_container:AddValue(character, spell.total)\n					total = total + spell.total\n					if(top < spell.total) then\n						top = spell.total\n					end\n					found = true\n				end\n			end\n\n			if(found) then\n				amount = amount + 1\n			end\n		end\n		--loop end\n		--return the values\n		return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Stone_04",
			["script_version"] = 15,
		}, -- [2]
		{
			["source"] = false,
			["tooltip"] = "\n		",
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			return string.format(\"%.1f\", value/top*100)\n		",
			["desc"] = "Tells how much time each character spent doing damage.",
			["attribute"] = false,
			["total_script"] = "			local value, top, total, combat, instance = ...\n			local minutos, segundos = math.floor(value/60), math.floor(value%60)\n			return minutos .. \"m \" .. segundos .. \"s\"\n		",
			["name"] = "Damage Activity Time",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, amount = 0, 0\n\n			--get the misc actor container\n			local damage_container = combat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n\n			--do the loop:\n			for _, player in ipairs( damage_container ) do\n				if(player.grupo) then\n					local activity = player:Tempo()\n					total = total + activity\n					amount = amount + 1\n					--add amount to the player\n					instance_container:AddValue(player, activity)\n				end\n			end\n\n			--return:\n			return total, combat:GetCombatTime(), amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Red",
			["script_version"] = 3,
		}, -- [3]
		{
			["source"] = false,
			["tooltip"] = "\n		",
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			return string.format(\"%.1f\", value/top*100)\n		",
			["desc"] = "Tells how much time each character spent doing healing.",
			["attribute"] = false,
			["total_script"] = "			local value, top, total, combat, instance = ...\n			local minutos, segundos = math.floor(value/60), math.floor(value%60)\n			return minutos .. \"m \" .. segundos .. \"s\"\n		",
			["name"] = "Healing Activity Time",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the misc actor container\n			local damage_container = combat:GetActorList( DETAILS_ATTRIBUTE_HEAL )\n\n			--do the loop:\n			for _, player in ipairs( damage_container ) do\n				if(player.grupo) then\n					local activity = player:Tempo()\n					total = total + activity\n					amount = amount + 1\n					--add amount to the player\n					instance_container:AddValue(player, activity)\n				end\n			end\n\n			--return:\n			return total, combat:GetCombatTime(), amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Green",
			["script_version"] = 2,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n			return floor(value)\n		",
			["desc"] = "Show the crowd control amount for each player.",
			["attribute"] = false,
			["script"] = "			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n					local cc_done = floor(character.cc_done)\n					instance_container:AddValue(character, cc_done)\n					total = total + cc_done\n					if(cc_done > top) then\n						top = cc_done\n					end\n					amount = amount + 1\n				end\n			end\n\n			return total, top, amount\n		",
			["name"] = "Crowd Control Done",
			["tooltip"] = "			local actor, combat, instance = ...\n			local spells = {}\n			for spellid, spell in pairs(actor.cc_done_spells._ActorTable) do\n				tinsert(spells, {spellid, spell.counter})\n			end\n\n			table.sort(spells, _detalhes.Sort2)\n\n			for index, spell in ipairs(spells) do\n				local name, _, icon = GetSpellInfo(spell[1])\n				GameCooltip:AddLine(name, spell[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n\n			local targets = {}\n			for playername, amount in pairs(actor.cc_done_targets) do\n				tinsert(targets, {playername, amount})\n			end\n\n			table.sort(targets, _detalhes.Sort2)\n\n			_detalhes:AddTooltipSpellHeaderText(\"Targets\", \"yellow\", #targets)\n			local class, _, _, _, _, r, g, b = _detalhes:GetClass(actor.nome)\n			_detalhes:AddTooltipHeaderStatusbar(1, 1, 1, 0.6)\n\n			for index, target in ipairs(targets) do\n				GameCooltip:AddLine(target[1], target[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(target[1])\n				if(class and class ~= \"UNKNOW\") then\n				local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n				GameCooltip:AddIcon(\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				else\n				GameCooltip:AddIcon(\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n				--\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["script_version"] = 11,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n			return floor(value)\n		",
			["desc"] = "Show the amount of crowd control received for each player.",
			["attribute"] = false,
			["script"] = "			local combat, instance_container, instance = ...\n			local total, top, amt = 0, 0, 0\n\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n			DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n			wipe(DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n\n				for player_name, amount in pairs(character.cc_done_targets) do\n					local target = combat(1, player_name) or combat(2, player_name)\n					if(target and target:IsPlayer()) then\n					instance_container:AddValue(target, amount)\n					total = total + amount\n					if(amount > top) then\n						top = amount\n					end\n					if(not DETAILS_CUSTOM_CC_RECEIVED_CACHE[player_name]) then\n						DETAILS_CUSTOM_CC_RECEIVED_CACHE[player_name] = true\n						amt = amt + 1\n					end\n					end\n				end\n\n				end\n			end\n\n			return total, top, amt\n		",
			["name"] = "Crowd Control Received",
			["tooltip"] = "			local actor, combat, instance = ...\n			local name = actor:name()\n			local spells, from = {}, {}\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n				local on_actor = character.cc_done_targets[name]\n				if(on_actor) then\n					tinsert(from, {character:name(), on_actor})\n\n					for spellid, spell in pairs(character.cc_done_spells._ActorTable) do\n\n					local spell_on_actor = spell.targets[name]\n					if(spell_on_actor) then\n						local has_spell\n						for index, spell_table in ipairs(spells) do\n						if(spell_table[1] == spellid) then\n							spell_table[2] = spell_table[2] + spell_on_actor\n							has_spell = true\n						end\n						end\n						if(not has_spell) then\n						tinsert(spells, {spellid, spell_on_actor})\n						end\n					end\n\n					end\n				end\n				end\n			end\n\n			table.sort(from, _detalhes.Sort2)\n			table.sort(spells, _detalhes.Sort2)\n\n			for index, spell in ipairs(spells) do\n				local name, _, icon = GetSpellInfo(spell[1])\n				GameCooltip:AddLine(name, spell[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n\n			_detalhes:AddTooltipSpellHeaderText(\"From\", \"yellow\", #from)\n			_detalhes:AddTooltipHeaderStatusbar(1, 1, 1, 0.6)\n\n			for index, t in ipairs(from) do\n				GameCooltip:AddLine(t[1], t[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(t[1])\n				if(class and class ~= \"UNKNOW\") then\n				local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n				GameCooltip:AddIcon(\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				else\n				GameCooltip:AddIcon(\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_ChainsOfIce",
			["script_version"] = 3,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			local dps = _detalhes:ToK(floor(value) / combat:GetCombatTime())\n			local percent = string.format(\"%.1f\", value/total*100)\n			return dps .. \", \" .. percent\n		",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "		--config:\n		--Background RBG and Alpha:\n		local R, G, B, A = 0, 0, 0, 0.75\n		local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n		--get the parameters passed\n		local spell, combat, instance = ...\n\n		--get the cooltip object(we dont use the convencional GameTooltip here)\n		local GC = GameCooltip\n		GC:SetOption(\"YSpacingMod\", 0)\n\n		local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n\n		if(spell.n_dmg) then\n\n			local spellschool, schooltext = spell.spellschool, \"\"\n			if(spellschool) then\n			local t = _detalhes.spells_school[spellschool]\n			if(t and t.name) then\n				schooltext = t.formated\n			end\n			end\n\n			local total_hits = spell.counter\n			local combat_time = instance.showing:GetCombatTime()\n\n			local debuff_uptime_total, cast_string = \"\", \"\"\n			local misc_actor = instance.showing(4, _detalhes.playername)\n			if(misc_actor) then\n			local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable[spell.id] and misc_actor.debuff_uptime_spells._ActorTable[spell.id].uptime\n			if(debuff_uptime) then\n				debuff_uptime_total = floor(debuff_uptime / instance.showing:GetCombatTime() * 100)\n			end\n\n			local spell_cast = misc_actor.spell_cast and misc_actor.spell_cast[spell.id]\n\n			if(not spell_cast and misc_actor.spell_cast) then\n				local spellname = GetSpellInfo(spell.id)\n				for casted_spellid, amount in pairs(misc_actor.spell_cast) do\n				local casted_spellname = GetSpellInfo(casted_spellid)\n				if(casted_spellname == spellname) then\n					spell_cast = amount .. \"(|cFFFFFF00?|r)\"\n				end\n				end\n			end\n			if(not spell_cast) then\n				spell_cast = \"(|cFFFFFF00?|r)\"\n			end\n			cast_string = cast_string .. spell_cast\n			end\n\n			--Cooltip code\n			GC:AddLine(\"Casts:\", cast_string or \"?\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(debuff_uptime_total ~= \"\") then\n			GC:AddLine(\"Uptime:\",(debuff_uptime_total or \"?\") .. \"%\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n			end\n\n			GC:AddLine(\"Hits:\", spell.counter)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local average = spell.total / total_hits\n			GC:AddLine(\"Average:\", _detalhes:ToK(average))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"E-Dps:\", _detalhes:ToK(spell.total / combat_time))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"School:\", schooltext)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Normal Hits: \", spell.n_amt .. \"(\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local n_average = spell.n_dmg / spell.n_amt\n			local T =(combat_time*spell.n_dmg)/spell.total\n			local P = average/n_average*100\n			T = P*T/100\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(n_average) .. \" / \" .. format(\"%.1f\",spell.n_dmg / T ))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Critical Hits: \", spell.c_amt .. \"(\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(spell.c_amt > 0) then\n			local c_average = spell.c_dmg/spell.c_amt\n			local T =(combat_time*spell.c_dmg)/spell.total\n			local P = average/c_average*100\n			T = P*T/100\n			local crit_dps = spell.c_dmg / T\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(c_average) .. \" / \" .. _detalhes:comma_value(crit_dps))\n			else\n			GC:AddLine(\"Average / E-Dps: \",  \"0 / 0\")\n			end\n\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			--GC:AddLine(\"Multistrike: \", spell.m_amt .. \"(\" ..floor( spell.m_amt/total_hits*100) .. \"%)\")\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n		elseif(spell.n_curado) then\n\n			local spellschool, schooltext = spell.spellschool, \"\"\n			if(spellschool) then\n			local t = _detalhes.spells_school[spellschool]\n			if(t and t.name) then\n				schooltext = t.formated\n			end\n			end\n\n			local total_hits = spell.counter\n			local combat_time = instance.showing:GetCombatTime()\n\n			--Cooltip code\n			GC:AddLine(\"Hits:\", spell.counter)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local average = spell.total / total_hits\n			GC:AddLine(\"Average:\", _detalhes:ToK(average))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"E-Hps:\", _detalhes:ToK(spell.total / combat_time))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"School:\", schooltext)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Normal Hits: \", spell.n_amt .. \"(\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local n_average = spell.n_curado / spell.n_amt\n			local T =(combat_time*spell.n_curado)/spell.total\n			local P = average/n_average*100\n			T = P*T/100\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(n_average) .. \" / \" .. format(\"%.1f\",spell.n_curado / T ))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Critical Hits: \", spell.c_amt .. \"(\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(spell.c_amt > 0) then\n			local c_average = spell.c_curado/spell.c_amt\n			local T =(combat_time*spell.c_curado)/spell.total\n			local P = average/c_average*100\n			T = P*T/100\n			local crit_dps = spell.c_curado / T\n\n			GC:AddLine(\"Average / E-Hps: \",  _detalhes:ToK(c_average) .. \" / \" .. _detalhes:comma_value(crit_dps))\n			else\n			GC:AddLine(\"Average / E-Hps: \",  \"0 / 0\")\n			end\n\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			--GC:AddLine(\"Multistrike: \", spell.m_amt .. \"(\" ..floor( spell.m_amt/total_hits*100) .. \"%)\")\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n		end\n		",
			["attribute"] = false,
			["name"] = "My Spells",
			["script"] = "			--get the parameters passed\n			local combat, instance_container, instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			local player\n			local pet_attribute\n\n			local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n			local spec = DetailsFramework.GetSpecialization()\n			role = spec and DetailsFramework.GetSpecializationRole(spec) or role\n\n			if(role == \"DAMAGER\") then\n				player = combat(DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n			elseif(role == \"HEALER\") then\n				player = combat(DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_HEAL\n			else\n				player = combat(DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n			end\n\n			--do the loop\n\n			if(player) then\n				local spells = player:GetSpellList()\n				for spellid, spell in pairs(spells) do\n					instance_container:AddValue(spell, spell.total)\n					total = total + spell.total\n					if(top < spell.total) then\n						top = spell.total\n					end\n					amount = amount + 1\n				end\n\n				for _, PetName in ipairs(player.pets) do\n					local pet = combat(pet_attribute, PetName)\n					if(pet) then\n						for spellid, spell in pairs(pet:GetSpellList()) do\n							instance_container:AddValue(spell, spell.total, nil, \"(\" .. PetName:gsub((\" <.*\"), \"\") .. \")\")\n							total = total + spell.total\n							if(top < spell.total) then\n								top = spell.total\n							end\n							amount = amount + 1\n						end\n					end\n				end\n			end\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\CHATFRAME\\UI-ChatIcon-WoW",
			["script_version"] = 7,
		}, -- [7]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip\n\n			--Cooltip code\n			local format_func = Details:GetCurrentToKFunction()\n\n			--Cooltip code\n			local RaidTargets = actor.raid_targets\n\n			local DamageOnStar = RaidTargets[128]\n			if(DamageOnStar) then\n				--RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				GameCooltip:AddLine(RAID_TARGET_8 .. \":\", format_func(_, DamageOnStar))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage On Skull Marked Targets",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--raid target flags:\n			-- 128: skull\n			-- 64: cross\n			-- 32: square\n			-- 16: moon\n			-- 8: triangle\n			-- 4: diamond\n			-- 2: circle\n			-- 1: star\n\n			--do the loop\n			for _, actor in ipairs(Combat:GetActorList(DETAILS_ATTRIBUTE_DAMAGE)) do\n				if(actor:IsPlayer()) then\n				if(actor.raid_targets[128]) then\n					CustomContainer:AddValue(actor, actor.raid_targets[128])\n				end\n				end\n			end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["script_version"] = 3,
		}, -- [8]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object\n			local GameCooltip = GameCooltip\n\n			local format_func = Details:GetCurrentToKFunction()\n\n			--Cooltip code\n			local RaidTargets = actor.raid_targets\n\n			local DamageOnStar = RaidTargets[1]\n			if(DamageOnStar) then\n				GameCooltip:AddLine(RAID_TARGET_1 .. \":\", format_func(_, DamageOnStar))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnCircle = RaidTargets[2]\n			if(DamageOnCircle) then\n				GameCooltip:AddLine(RAID_TARGET_2 .. \":\", format_func(_, DamageOnCircle))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnDiamond = RaidTargets[4]\n			if(DamageOnDiamond) then\n				GameCooltip:AddLine(RAID_TARGET_3 .. \":\", format_func(_, DamageOnDiamond))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnTriangle = RaidTargets[8]\n			if(DamageOnTriangle) then\n				GameCooltip:AddLine(RAID_TARGET_4 .. \":\", format_func(_, DamageOnTriangle))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnMoon = RaidTargets[16]\n			if(DamageOnMoon) then\n				GameCooltip:AddLine(RAID_TARGET_5 .. \":\", format_func(_, DamageOnMoon))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnSquare = RaidTargets[32]\n			if(DamageOnSquare) then\n				GameCooltip:AddLine(RAID_TARGET_6 .. \":\", format_func(_, DamageOnSquare))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnCross = RaidTargets[64]\n			if(DamageOnCross) then\n				GameCooltip:AddLine(RAID_TARGET_7 .. \":\", format_func(_, DamageOnCross))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage On Other Marked Targets",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--do the loop\n			for _, actor in ipairs(Combat:GetActorList(DETAILS_ATTRIBUTE_DAMAGE)) do\n				if(actor:IsPlayer()) then\n				local total =(actor.raid_targets[1] or 0) --star\n				total = total +(actor.raid_targets[2] or 0) --circle\n				total = total +(actor.raid_targets[4] or 0) --diamond\n				total = total +(actor.raid_targets[8] or 0) --tiangle\n				total = total +(actor.raid_targets[16] or 0) --moon\n				total = total +(actor.raid_targets[32] or 0) --square\n				total = total +(actor.raid_targets[64] or 0) --cross\n\n				if(total > 0) then\n					CustomContainer:AddValue(actor, total)\n				end\n				end\n			end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["script_version"] = 3,
		}, -- [9]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n\n			--get the time of overall combat\n			local OverallCombatTime = Details:GetCombat(-1):GetCombatTime()\n\n			--get the time of current combat if the player is in combat\n			if(Details.in_combat) then\n				local CurrentCombatTime = Details:GetCombat(0):GetCombatTime()\n				OverallCombatTime = OverallCombatTime + CurrentCombatTime\n			end\n\n			--build the string\n			local ToK = Details:GetCurrentToKFunction()\n			local s = ToK(_, value / OverallCombatTime)\n\n			if(instance.row_info.textR_show_data[3]) then\n				s = ToK(_, value) .. \"(\" .. s .. \", \"\n			else\n				s = ToK(_, value) .. \"(\" .. s\n			end\n\n			return s\n		",
			["desc"] = "Show overall damage done on the fly.",
			["attribute"] = false,
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the overall combat\n			local OverallCombat = Details:GetCombat(-1)\n			--get the current combat\n			local CurrentCombat = Details:GetCombat(0)\n\n			if(not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n				return 0, 0, 0\n			end\n\n			--get the damage actor container for overall\n			local damage_container_overall = OverallCombat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n			--get the damage actor container for current\n			local damage_container_current = CurrentCombat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n\n			--do the loop:\n			for _, player in ipairs( damage_container_overall ) do\n				--only player in group\n				if(player:IsGroupPlayer()) then\n				instance_container:AddValue(player, player.total)\n				end\n			end\n\n			if(Details.in_combat) then\n				for _, player in ipairs( damage_container_current ) do\n				--only player in group\n				if(player:IsGroupPlayer()) then\n					instance_container:AddValue(player, player.total)\n				end\n				end\n			end\n\n			total, top =  instance_container:GetTotalAndHighestValue()\n			amount =  instance_container:GetNumActors()\n\n			--return:\n			return total, top, amount\n		",
			["name"] = "Dynamic Overall Damage",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip2\n\n			--Cooltip code\n			--get the overall combat\n			local OverallCombat = Details:GetCombat(-1)\n			--get the current combat\n			local CurrentCombat = Details:GetCombat(0)\n\n			local AllSpells = {}\n\n			--overall\n			local player = OverallCombat[1]:GetActor(actor.nome)\n			local playerSpells = player:GetSpellList()\n			for spellID, spellTable in pairs(playerSpells) do\n				AllSpells[spellID] = spellTable.total\n			end\n\n			--current\n			local player = CurrentCombat[1]:GetActor(actor.nome)\n			if(player) then\n				local playerSpells = player:GetSpellList()\n				for spellID, spellTable in pairs(playerSpells) do\n					AllSpells[spellID] =(AllSpells[spellID] or 0) +(spellTable.total or 0)\n				end\n			end\n\n			local sortedList = {}\n			for spellID, total in pairs(AllSpells) do\n				tinsert(sortedList, {spellID, total})\n			end\n			table.sort(sortedList, Details.Sort2)\n\n			local format_func = Details:GetCurrentToKFunction()\n\n			--build the tooltip\n			for i, t in ipairs(sortedList) do\n				local spellID, total = unpack(t)\n				if(total > 1) then\n				local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n\n				GameCooltip:AddLine(spellName, format_func(_, total))\n				Details:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\Spell-Reset",
			["script_version"] = 5,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "			--get the parameters passed\n			local actor, Combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip\n\n			--Cooltip code\n			--get the actor total damage absorbed\n			local totalAbsorb = actor.totalabsorbed\n			local format_func = Details:GetCurrentToKFunction()\n\n			--get the damage absorbed by all the actor pets\n			for petIndex, petName in ipairs(actor.pets) do\n				local pet = Combat :GetActor(1, petName)\n				if(pet) then\n				totalAbsorb = totalAbsorb + pet.totalabsorbed\n				end\n			end\n\n			GameCooltip:AddLine(actor:Name(), format_func(_, actor.totalabsorbed))\n			Details:AddTooltipBackgroundStatusbar()\n\n			for petIndex, petName in ipairs(actor.pets) do\n				local pet = Combat :GetActor(1, petName)\n				if(pet) then\n				totalAbsorb = totalAbsorb + pet.totalabsorbed\n\n				GameCooltip:AddLine(petName, format_func(_, pet.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				end\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage on Shields",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--do the loop\n			for index, actor in ipairs(Combat:GetActorList(1)) do\n				if(actor:IsPlayer()) then\n\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs(actor.pets) do\n					local pet = Combat :GetActor(1, petName)\n					if(pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n					end\n				end\n\n				--add the value to the actor on the custom container\n				CustomContainer:AddValue(actor, totalAbsorb)\n\n				end\n			end\n			--loop end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["script_version"] = 1,
		}, -- [11]
	},
	["performance_profiles"] = {
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid25"] = {
			["enabled"] = true,
			["update_speed"] = 3,
			["miscdata"] = true,
			["aura"] = false,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Janela Info.", -- [1]
		"2 - Clearing user place from instances.", -- [2]
		"4 - Reversing switches.", -- [3]
		"6 - Saving Config.", -- [4]
		"7 - Saving Profiles.", -- [5]
		"8 - Saving nicktag cache.", -- [6]
	},
	["update_warning_timeout"] = 10,
	["lastUpdateWarning"] = 1660938186,
	["always_use_profile"] = true,
}
