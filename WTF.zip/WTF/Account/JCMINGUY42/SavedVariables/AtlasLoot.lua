
AtlasLootDB = {
	["namespaces"] = {
		["DefaultFrame"] = {
			["profiles"] = {
				["Dmgur - Lotus"] = {
					["module"] = "AtlasLootMoP",
					["NEWpoint"] = {
						"BOTTOM", -- [1]
						nil, -- [2]
						"BOTTOM", -- [3]
						-113.7776870727539, -- [4]
						-0, -- [5]
					},
					["instance"] = "HeartofFear",
				},
				["Wafty - Mistblade"] = {
					["instance"] = "ThroneofThunder",
					["NEWpoint"] = {
						nil, -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						30.58478546142578, -- [4]
						64.57847595214844, -- [5]
					},
					["module"] = "AtlasLootMoP",
				},
			},
		},
		["AtlasLootPanel"] = {
		},
		["WishList"] = {
		},
		["Filter"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["filterSlots"] = {
						["Stats"] = {
							["PARRY_RATING"] = false,
							["DODGE_RATING"] = false,
							["INTELLECT"] = false,
							["SPELL_POWER"] = false,
							["STRENGTH"] = false,
							["SPIRIT"] = false,
						},
						["Armor"] = {
							["#a2#"] = false,
							["#a4#"] = false,
							["#a1#"] = false,
						},
						["WeaponsMeeleTwoHand"] = {
							["#w6#"] = false,
							["#w1#"] = false,
							["#w10#"] = false,
						},
						["WeaponsRanged"] = {
							["#w3#"] = false,
							["#w2#"] = false,
							["#w5#"] = false,
							["#w12#"] = false,
						},
						["WeaponsMeele"] = {
							["#w9#"] = false,
							["#w8#"] = false,
							["#w7#"] = false,
							["#s15#"] = false,
							["#w10#"] = false,
						},
					},
					["enable"] = true,
				},
			},
		},
	},
	["showWarning"] = true,
	["profileKeys"] = {
		["Dmgurx - Lotus"] = "Dmgurx - Lotus",
		["Lotusprep - [EN] Evermoon"] = "Lotusprep - [EN] Evermoon",
		["Dmgur - Lotus"] = "Dmgur - Lotus",
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["profiles"] = {
		["Dmgurx - Lotus"] = {
		},
		["Lotusprep - [EN] Evermoon"] = {
		},
		["Dmgur - Lotus"] = {
			["EquipCompare"] = true,
		},
		["Wafty - Mistblade"] = {
			["LastSearch"] = "darkmoon",
			["LootTableType"] = "25Man",
		},
	},
}
