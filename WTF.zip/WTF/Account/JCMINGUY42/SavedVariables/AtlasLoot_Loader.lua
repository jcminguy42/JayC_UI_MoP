
AtlasLootLoaderDB = {
	["MiniMapButton"] = {
		["minimapPos"] = 322.0122003135292,
		["hide"] = false,
	},
}
