
BigWigs3DB = {
	["namespaces"] = {
		["BigWigs_Plugins_Alt Power"] = {
			["profiles"] = {
				["Default"] = {
					["posx"] = 943.0279571493375,
					["fontSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["font"] = "Friz Quadrata TT",
					["posy"] = 239.0668737916294,
				},
			},
		},
		["LibDualSpec-1.0"] = {
		},
		["BigWigs_Plugins_Sounds"] = {
		},
		["BigWigs_Plugins_Statistics"] = {
			["profiles"] = {
				["Default"] = {
					["showBar"] = false,
				},
			},
		},
		["BigWigs_Plugins_Colors"] = {
			["profiles"] = {
				["Default"] = {
					["Important"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								nil, -- [1]
								nil, -- [2]
								nil, -- [3]
								1, -- [4]
							},
						},
					},
				},
			},
		},
		["BigWigs_Plugins_Raid Icons"] = {
		},
		["BigWigs_Plugins_Bars"] = {
			["profiles"] = {
				["Default"] = {
					["outline"] = "OUTLINE",
					["font"] = "Friz Quadrata TT",
					["BigWigsAnchor_x"] = 1143.088916749577,
					["BigWigsEmphasizeAnchor_y"] = 243.8727405938225,
					["BigWigsAnchor_width"] = 173.2288513183594,
					["BigWigsAnchor_y"] = 365.877670152986,
					["BigWigsEmphasizeAnchor_x"] = 587.1666836696495,
					["BigWigsEmphasizeAnchor_width"] = 226.3790283203125,
				},
			},
		},
		["BigWigs_Plugins_Super Emphasize"] = {
			["profiles"] = {
				["Default"] = {
					["font"] = "Friz Quadrata TT",
				},
			},
		},
		["BigWigs_Plugins_Messages"] = {
			["profiles"] = {
				["Default"] = {
					["BWMessageAnchor_x"] = 595.5337151779677,
					["fontSize"] = 20,
					["font"] = "Friz Quadrata TT",
					["BWMessageAnchor_y"] = 482.1005351360873,
				},
			},
		},
		["BigWigs_Plugins_Proximity"] = {
			["profiles"] = {
				["Default"] = {
					["posx"] = 1055.611137226981,
					["fontSize"] = 20,
					["posy"] = 193.9336992684375,
					["font"] = "Friz Quadrata TT",
				},
			},
		},
	},
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
BigWigs3IconDB = {
	["hide"] = true,
}
BigWigsStatisticsDB = {
	[930] = {
		[818] = {
			["25h"] = {
				["kills"] = 3,
				["wipes"] = 5,
				["best"] = 396.5380000000005,
			},
			["lfr"] = {
				["best"] = 445.0610000001034,
				["kills"] = 1,
			},
		},
		[820] = {
			["25"] = {
				["best"] = 341.9220000000205,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 1,
				["wipes"] = 7,
				["best"] = 362.2309999999707,
			},
			["lfr"] = {
				["best"] = 256.1439999999711,
				["kills"] = 1,
			},
		},
		[824] = {
			["25"] = {
				["best"] = 155.1579999999958,
				["kills"] = 2,
			},
			["lfr"] = {
				["best"] = 69.98100000002887,
				["kills"] = 1,
			},
		},
		[828] = {
			["25"] = {
				["kills"] = 1,
				["best"] = 230.0100000000093,
				["wipes"] = 1,
			},
			["25h"] = {
				["wipes"] = 1,
			},
		},
		[817] = {
			["25"] = {
				["best"] = 431.810999999987,
				["kills"] = 1,
			},
			["25h"] = {
				["best"] = 484.9859999999753,
				["kills"] = 1,
			},
			["lfr"] = {
				["best"] = 377.1900000000605,
				["kills"] = 1,
			},
		},
		[819] = {
			["25h"] = {
				["kills"] = 3,
				["wipes"] = 2,
				["best"] = 527.9579999999842,
			},
			["lfr"] = {
				["best"] = 347.3260000000009,
				["kills"] = 1,
			},
		},
		[821] = {
			["25"] = {
			},
			["25h"] = {
				["kills"] = 2,
				["wipes"] = 14,
				["best"] = 366.5029999999097,
			},
		},
		[825] = {
			["25"] = {
				["best"] = 184.5960000000196,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 2,
				["wipes"] = 12,
				["best"] = 296.2459999999264,
			},
		},
		[827] = {
			["25h"] = {
				["kills"] = 3,
				["wipes"] = 3,
				["best"] = 235.6159999999218,
			},
			["lfr"] = {
				["best"] = 248.2049999999581,
				["kills"] = 1,
			},
		},
		[829] = {
			["25"] = {
				["best"] = 411.4089999999851,
				["kills"] = 1,
			},
			["25h"] = {
				["best"] = 474.0690000000177,
				["kills"] = 1,
			},
			["lfr"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 479.3839999999618,
			},
		},
		[816] = {
			["25"] = {
				["best"] = 262.3930000000401,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 2,
				["best"] = 396.6260000000002,
				["wipes"] = 3,
			},
			["lfr"] = {
				["best"] = 357.4259999999777,
				["kills"] = 1,
			},
		},
		[832] = {
			["25"] = {
				["kills"] = 2,
				["wipes"] = 1,
				["best"] = 454.0410000000265,
			},
			["lfr"] = {
				["best"] = 531.8349999999628,
				["kills"] = 1,
			},
		},
	},
}
