
AffDotsOptions110 = nil
AffDotsDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Wafty - Mistblade"] = "Wafty - Mistblade",
	},
	["profiles"] = {
		["Wafty - Mistblade"] = {
			["color6"] = {
				0.07058823529411765, -- [1]
				0.07843137254901961, -- [2]
				0.06666666666666667, -- [3]
			},
			["locked"] = true,
			["p"] = "TOPLEFT",
			["y"] = -605.77734375,
			["font"] = "Friz Quadrata TT",
			["x"] = 644.3391723632813,
			["hide"] = true,
			["rp"] = "TOPLEFT",
			["color7"] = {
				1, -- [1]
				nil, -- [2]
				0.00392156862745098, -- [3]
			},
			["shaman"] = {
				["lb_order"] = 2,
				["fs_ticks"] = false,
				["fs_show"] = true,
				["enhancement"] = true,
				["ms_show"] = false,
				["msls_order"] = 1,
				["elemental"] = false,
				["fs_order"] = 0,
				["ls_show"] = false,
			},
			["boxes_v"] = {
				["h"] = 34,
				["icon_size"] = 25,
			},
			["color1"] = {
				nil, -- [1]
				1, -- [2]
			},
			["transparency"] = 0.8,
			["hide_text"] = true,
			["color3"] = {
				0.07843137254901961, -- [1]
				0.08235294117647059, -- [2]
				0.08235294117647059, -- [3]
			},
			["color5"] = {
				0.08235294117647059, -- [1]
				0.08235294117647059, -- [2]
				0.07843137254901961, -- [3]
			},
			["color2"] = {
				0.05882352941176471, -- [1]
				0.06274509803921569, -- [2]
				0.06274509803921569, -- [3]
			},
		},
	},
}
