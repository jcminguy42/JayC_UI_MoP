
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = -205.0000228881836,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -189.4999389648438,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -151.5,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -113.5,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -75.49993896484375,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -37.50003051757813,
								["x"] = -231.4999389648438,
								["point"] = "CENTER",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["Dmgur - Lotus"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -189.4999084472656,
								["x"] = -231.5001831054688,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["Default"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["hidehotkey"] = true,
							["position"] = {
								["y"] = 48,
								["x"] = -398,
								["point"] = "BOTTOM",
								["scale"] = 1.100000023841858,
							},
							["states"] = {
								["actionbar"] = true,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
							["padding"] = 6,
						}, -- [2]
						{
							["rows"] = 12,
							["fadeout"] = true,
							["version"] = 3,
							["fadeoutalpha"] = 0,
							["position"] = {
								["y"] = 210,
								["x"] = -42,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
						}, -- [3]
						{
							["rows"] = 12,
							["fadeout"] = true,
							["version"] = 3,
							["fadeoutalpha"] = 0,
							["position"] = {
								["y"] = 210,
								["x"] = -82,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
						}, -- [4]
						{
							["rows"] = 2,
							["hidehotkey"] = true,
							["version"] = 3,
							["position"] = {
								["y"] = 88,
								["x"] = 123,
								["point"] = "BOTTOM",
								["scale"] = 1.100000023841858,
							},
						}, -- [5]
						{
							["hidehotkey"] = true,
							["version"] = 3,
							["position"] = {
								["y"] = 88,
								["x"] = -398,
								["point"] = "BOTTOM",
								["scale"] = 1.100000023841858,
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
							["buttons"] = 1,
							["version"] = 3,
							["position"] = {
								["y"] = 44.99998474121094,
								["x"] = -87.05902099609375,
								["point"] = "CENTER",
								["scale"] = 2,
							},
						}, -- [10]
					},
				},
				["Dmgurx - Lotus"] = {
					["actionbars"] = {
						{
							["hideequipped"] = true,
							["hidehotkey"] = true,
							["position"] = {
								["y"] = 95,
								["x"] = -254.1500175476074,
								["point"] = "BOTTOM",
								["scale"] = 1.15,
							},
							["padding"] = 0,
							["version"] = 3,
						}, -- [1]
						{
							["enabled"] = false,
							["visibility"] = {
								["always"] = false,
							},
							["version"] = 3,
							["position"] = {
								["y"] = -145.3221130371094,
								["x"] = 228.9443359375,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["fadeout"] = true,
							["position"] = {
								["y"] = 248.5,
								["x"] = -43.4998779296875,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["fadeoutalpha"] = 0,
						}, -- [3]
						{
							["fadeout"] = true,
							["position"] = {
								["y"] = 248.5,
								["x"] = -80,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["fadeoutalpha"] = 0,
						}, -- [4]
						{
							["version"] = 3,
							["buttons"] = 9,
							["padding"] = 0,
							["position"] = {
								["y"] = 51,
								["x"] = -167.0000305175781,
								["point"] = "BOTTOM",
							},
							["hidehotkey"] = true,
						}, -- [5]
						{
							["hideequipped"] = true,
							["version"] = 3,
							["position"] = {
								["y"] = 136,
								["x"] = -254.1500122785565,
								["point"] = "BOTTOM",
								["scale"] = 1.149999976158142,
							},
							["padding"] = 0,
							["hidehotkey"] = true,
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
			},
		},
		["LibDualSpec-1.0"] = {
		},
		["ExtraActionBar"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 223.0000305175781,
						["x"] = -31.4998779296875,
						["point"] = "BOTTOM",
					},
				},
				["Dmgur - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 223.0000152587891,
						["x"] = -31.50006103515625,
						["point"] = "BOTTOM",
					},
				},
				["Default"] = {
					["position"] = {
						["y"] = 265,
						["x"] = -34,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 223.0000152587891,
						["x"] = -31.50006103515625,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.39999515659656,
						["x"] = -208.8000277647789,
						["point"] = "CENTER",
						["scale"] = 0.800000011920929,
					},
				},
				["Dmgur - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 37.5,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["Default"] = {
					["position"] = {
						["y"] = 144.4665182660001,
						["x"] = -245.1997111637174,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.800000011920929,
					},
					["fadeout"] = true,
					["fadeoutalpha"] = 0,
					["version"] = 3,
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["fadeout"] = true,
					["fadeoutalpha"] = 0,
					["position"] = {
						["y"] = 148.2732410058761,
						["x"] = -260.5246570769523,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.8500000238418579,
					},
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["Default"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = -4.99981689453125,
						["x"] = -519,
						["point"] = "TOP",
					},
					["version"] = 3,
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 57,
						["x"] = -516,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["Dmgur - Lotus"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["Default"] = {
					["artLayout"] = "TWOBAR",
					["leftCap"] = "NONE",
					["position"] = {
						["y"] = 52,
						["x"] = -400,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
					["rightCap"] = "NONE",
				},
				["Dmgurx - Lotus"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 1.49993896484375,
						["x"] = 58.5001220703125,
						["point"] = "CENTER",
					},
				},
				["Dmgur - Lotus"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
				["Default"] = {
					["enabled"] = false,
					["version"] = 3,
					["position"] = {
						["y"] = 1.49993896484375,
						["x"] = 58.5001220703125,
						["point"] = "CENTER",
					},
				},
				["Dmgurx - Lotus"] = {
					["enabled"] = false,
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 47.5,
						["x"] = 99.49993896484375,
						["point"] = "CENTER",
					},
				},
				["Dmgur - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 47.50003051757813,
						["x"] = 99.5,
						["point"] = "CENTER",
					},
				},
				["Default"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 47.5,
						["x"] = 99.49993896484375,
						["point"] = "CENTER",
					},
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 47.50003051757813,
						["x"] = 99.5,
						["point"] = "CENTER",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15.00000762939453,
						["x"] = -82.49996948242188,
						["point"] = "CENTER",
					},
				},
				["Dmgur - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 116,
						["x"] = -460,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["Default"] = {
					["position"] = {
						["y"] = -15.00000762939453,
						["x"] = -82.49996948242188,
						["point"] = "CENTER",
					},
					["version"] = 3,
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 169,
						["x"] = -253.4999773405616,
						["point"] = "BOTTOM",
						["scale"] = 1.149999976158142,
					},
					["padding"] = -2,
					["fadeout"] = true,
					["fadeoutalpha"] = 0,
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Wafty - Mistblade"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 89.50006103515625,
						["x"] = -163.4998779296875,
						["point"] = "CENTER",
					},
				},
				["Dmgur - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 116,
						["x"] = -120,
						["point"] = "BOTTOM",
					},
				},
				["Default"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 197.8014068603516,
						["x"] = -2.999994993209839,
						["point"] = "BOTTOMLEFT",
					},
				},
				["Dmgurx - Lotus"] = {
					["hidehotkey"] = false,
					["version"] = 3,
					["position"] = {
						["y"] = -215.3444366455078,
						["x"] = -2.999993324279785,
						["point"] = "LEFT",
					},
				},
			},
		},
		["RepBar"] = {
			["profiles"] = {
				["Default"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 3.9998779296875,
						["x"] = -516.5000610351563,
						["point"] = "TOP",
					},
					["version"] = 3,
				},
				["Dmgurx - Lotus"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 65,
						["x"] = -516,
						["point"] = "BOTTOM",
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["Dmgurx - Lotus"] = "Default",
		["Wafty - Mistblade"] = "Default",
	},
	["profiles"] = {
		["Dmgur - Lotus"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["Dmgurx - Lotus"] = {
			["snapping"] = 1,
			["minimapIcon"] = {
				["minimapPos"] = 293.0256124265467,
			},
			["onkeydown"] = true,
			["blizzardVehicle"] = true,
			["focuscastmodifier"] = false,
		},
		["Default"] = {
			["blizzardVehicle"] = true,
			["focuscastmodifier"] = false,
			["onkeydown"] = false,
			["minimapIcon"] = {
				["minimapPos"] = 322.1559777454847,
			},
		},
		["Wafty - Mistblade"] = {
			["minimapIcon"] = {
				["minimapPos"] = 322.1085207355957,
			},
		},
	},
}
