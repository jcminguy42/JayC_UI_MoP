
LootCouncil_minRank = 2
LootCouncil_sawFirstMessage = 0
LootCouncil_privateVoting = false
LootCouncil_singleVote = false
LootCouncil_LinkWhisper = true
LootCouncil_LinkOfficer = true
LootCouncil_LinkGuild = true
LootCouncil_LinkRaid = true
LootCouncil_displaySpec = true
LootCouncil_selfVoting = false
LootCouncil_scale = 1
LootCouncil_confirmEnding = true
LootCouncil_masterLootIntegration = true
LootCouncil_Enchanters = ""
LootCouncil_Channel = "OFFICER"
LootCouncil_SplitRaids = false
LootCouncil_Lite_CacheGUID = {
	["0x0102000000000D90"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Smashval",
		["score"] = false,
		["target"] = "raid8",
		["class"] = "PALADIN",
		["level"] = 90,
		["realm"] = "",
	},
	["0x0102000000005EC5"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Nydan",
		["score"] = false,
		["target"] = "raid7",
		["class"] = "HUNTER",
		["level"] = 90,
		["realm"] = "Mistblade",
	},
	["0x0102000000012B8B"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Jaeh",
		["score"] = false,
		["target"] = "raid4",
		["class"] = "WARRIOR",
		["level"] = 90,
		["realm"] = "",
	},
	["0x010200000000BAFE"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Ravenppc",
		["score"] = false,
		["target"] = "raid5",
		["class"] = "WARLOCK",
		["level"] = 90,
		["realm"] = "Mistblade",
	},
	["0x0102000000005459"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Caries",
		["score"] = false,
		["target"] = "raid6",
		["class"] = "WARLOCK",
		["level"] = 90,
		["realm"] = "Mistblade",
	},
	["0x010200000000216B"] = {
		["items"] = false,
		["name"] = "Wafty",
		["time"] = false,
		["class"] = "SHAMAN",
		["target"] = "raid1",
		["level"] = 90,
		["score"] = false,
		["realm"] = "Mistblade",
	},
	["0x010200000000FEE4"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Smokeppc",
		["score"] = false,
		["target"] = "raid2",
		["class"] = "DEATHKNIGHT",
		["level"] = 90,
		["realm"] = "Mistblade",
	},
	["0x01020000000140E9"] = {
		["items"] = false,
		["time"] = false,
		["name"] = "Cryptik",
		["score"] = false,
		["target"] = "raid3",
		["class"] = "PALADIN",
		["level"] = 90,
		["realm"] = "Mistblade",
	},
}
