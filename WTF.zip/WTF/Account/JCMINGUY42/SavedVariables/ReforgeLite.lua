
ReforgeLiteDB = {
	["windowHeight"] = 564,
	["activeWindowTitle"] = {
		0.8, -- [1]
		0, -- [2]
		0, -- [3]
	},
	["windowY"] = 819.0982666015625,
	["reforgeCheat"] = 5,
	["profiles"] = {
		["Dmgur - Mistblade"] = {
			["method"] = {
				["items"] = {
					{
					}, -- [1]
					{
						["dst"] = 5,
						["src"] = 6,
						["amount"] = 120,
						["reforge"] = 40,
					}, -- [2]
					{
						["dst"] = 5,
						["src"] = 4,
						["amount"] = 142,
						["reforge"] = 25,
					}, -- [3]
					{
						["dst"] = 7,
						["src"] = 6,
						["amount"] = 136,
						["reforge"] = 41,
					}, -- [4]
					{
						["dst"] = 7,
						["src"] = 8,
						["amount"] = 191,
						["reforge"] = 56,
					}, -- [5]
					{
						["dst"] = 5,
						["src"] = 8,
						["amount"] = 104,
						["reforge"] = 54,
					}, -- [6]
					{
						["dst"] = 5,
						["src"] = 4,
						["amount"] = 167,
						["reforge"] = 25,
					}, -- [7]
					{
						["dst"] = 5,
						["src"] = 4,
						["amount"] = 160,
						["reforge"] = 25,
					}, -- [8]
					{
					}, -- [9]
					{
					}, -- [10]
					{
						["dst"] = 7,
						["src"] = 6,
						["amount"] = 112,
						["reforge"] = 41,
					}, -- [11]
					{
						["dst"] = 8,
						["src"] = 6,
						["amount"] = 141,
						["reforge"] = 42,
					}, -- [12]
					{
					}, -- [13]
					{
					}, -- [14]
					{
						["dst"] = 7,
						["src"] = 8,
						["amount"] = 250,
						["reforge"] = 56,
					}, -- [15]
					{
					}, -- [16]
				},
				["stats"] = {
					69, -- [1]
					0, -- [2]
					0, -- [3]
					1023, -- [4]
					5229, -- [5]
					766, -- [6]
					689, -- [7]
					4029, -- [8]
				},
			},
			["weights"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				200, -- [4]
				160, -- [5]
				120, -- [6]
				180, -- [7]
				140, -- [8]
			},
			["caps"] = {
				{
					["stat"] = 4,
					["points"] = {
						{
							["value"] = 1020,
							["preset"] = 2,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [1]
				{
					["stat"] = 7,
					["points"] = {
						{
							["value"] = 681,
							["preset"] = 5,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [2]
			},
			["ilvlCap"] = 0,
			["targetLevel"] = 0,
			["prio"] = {
				{
					["value"] = 1020,
					["preset"] = 2,
					["stat"] = 4,
					["capped"] = true,
				}, -- [1]
				{
					["value"] = 680,
					["preset"] = 5,
					["stat"] = 7,
					["capped"] = true,
				}, -- [2]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 5,
				}, -- [3]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 8,
				}, -- [4]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 6,
				}, -- [5]
			},
			["buffs"] = {
			},
			["itemsLocked"] = {
			},
			["customMethodPresets"] = {
			},
		},
		["Dmgurx - Lotus"] = {
			["method"] = {
				["items"] = {
					{
						["dst"] = 6,
						["src"] = 7,
						["reforge"] = 48,
						["amount"] = 262,
					}, -- [1]
					{
					}, -- [2]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 260,
					}, -- [3]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 187,
					}, -- [4]
					{
						["dst"] = 4,
						["src"] = 7,
						["reforge"] = 46,
						["amount"] = 254,
					}, -- [5]
					{
					}, -- [6]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 218,
					}, -- [7]
					{
						["dst"] = 8,
						["src"] = 7,
						["reforge"] = 49,
						["amount"] = 214,
					}, -- [8]
					{
						["dst"] = 8,
						["src"] = 6,
						["reforge"] = 42,
						["amount"] = 356,
					}, -- [9]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 223,
					}, -- [10]
					{
						["dst"] = 4,
						["src"] = 7,
						["reforge"] = 46,
						["amount"] = 155,
					}, -- [11]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 189,
					}, -- [12]
					{
					}, -- [13]
					{
					}, -- [14]
					{
						["dst"] = 8,
						["src"] = 5,
						["reforge"] = 35,
						["amount"] = 157,
					}, -- [15]
					{
					}, -- [16]
				},
				["stats"] = {
					251, -- [1]
					0, -- [2]
					0, -- [3]
					2564, -- [4]
					1450, -- [5]
					4077, -- [6]
					2274, -- [7]
					9631, -- [8]
				},
			},
			["weights"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				200, -- [4]
				120, -- [5]
				140, -- [6]
				180, -- [7]
				160, -- [8]
			},
			["caps"] = {
				{
					["stat"] = 4,
					["points"] = {
						{
							["value"] = 2550,
							["preset"] = 2,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [1]
				{
					["stat"] = 7,
					["points"] = {
						{
							["value"] = 2210,
							["preset"] = 5,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [2]
			},
			["ilvlCap"] = 0,
			["targetLevel"] = 3,
			["prio"] = {
				{
					["value"] = 2550,
					["preset"] = 2,
					["stat"] = 4,
					["capped"] = true,
				}, -- [1]
				{
					["value"] = 2210,
					["preset"] = 5,
					["stat"] = 7,
					["capped"] = true,
				}, -- [2]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 8,
				}, -- [3]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 6,
				}, -- [4]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 5,
				}, -- [5]
			},
			["buffs"] = {
			},
			["itemsLocked"] = {
			},
			["customMethodPresets"] = {
			},
		},
		["Wafty - Mistblade"] = {
			["method"] = {
				["items"] = {
					{
						["src"] = 4,
						["reforge"] = 28,
						["dst"] = 8,
						["amount"] = 367,
					}, -- [1]
					{
						["src"] = 6,
						["reforge"] = 42,
						["dst"] = 8,
						["amount"] = 272,
					}, -- [2]
					{
					}, -- [3]
					{
						["src"] = 5,
						["reforge"] = 33,
						["dst"] = 6,
						["amount"] = 222,
					}, -- [4]
					{
						["src"] = 7,
						["reforge"] = 48,
						["dst"] = 6,
						["amount"] = 374,
					}, -- [5]
					{
						["src"] = 6,
						["reforge"] = 41,
						["dst"] = 7,
						["amount"] = 203,
					}, -- [6]
					{
					}, -- [7]
					{
						["src"] = 5,
						["reforge"] = 35,
						["dst"] = 8,
						["amount"] = 358,
					}, -- [8]
					{
						["src"] = 6,
						["reforge"] = 41,
						["dst"] = 7,
						["amount"] = 389,
					}, -- [9]
					{
						["src"] = 4,
						["reforge"] = 26,
						["dst"] = 6,
						["amount"] = 261,
					}, -- [10]
					{
						["src"] = 6,
						["reforge"] = 41,
						["dst"] = 7,
						["amount"] = 261,
					}, -- [11]
					{
						["src"] = 5,
						["reforge"] = 34,
						["dst"] = 7,
						["amount"] = 197,
					}, -- [12]
					{
						["src"] = 4,
						["reforge"] = 28,
						["dst"] = 8,
						["amount"] = 586,
					}, -- [13]
					{
					}, -- [14]
					{
						["src"] = 5,
						["reforge"] = 34,
						["dst"] = 7,
						["amount"] = 185,
					}, -- [15]
					{
						["src"] = 5,
						["reforge"] = 34,
						["dst"] = 7,
						["amount"] = 162,
					}, -- [16]
				},
				["stats"] = {
					250, -- [1]
					0, -- [2]
					0, -- [3]
					2945, -- [4]
					2135, -- [5]
					5732, -- [6]
					2563, -- [7]
					14742, -- [8]
				},
			},
			["weights"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				200, -- [4]
				120, -- [5]
				140, -- [6]
				180, -- [7]
				160, -- [8]
			},
			["caps"] = {
				{
					["stat"] = 4,
					["points"] = {
						{
							["value"] = 2550,
							["preset"] = 2,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [1]
				{
					["stat"] = 7,
					["points"] = {
						{
							["value"] = 2550,
							["preset"] = 5,
							["method"] = 1,
							["after"] = 0,
						}, -- [1]
					},
				}, -- [2]
			},
			["ilvlCap"] = 0,
			["targetLevel"] = 3,
			["customMethodPresets"] = {
			},
			["buffs"] = {
			},
			["itemsLocked"] = {
			},
			["prio"] = {
				{
					["value"] = 2550,
					["preset"] = 2,
					["stat"] = 4,
					["capped"] = true,
				}, -- [1]
				{
					["value"] = 2550,
					["preset"] = 5,
					["stat"] = 7,
					["capped"] = true,
				}, -- [2]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 8,
				}, -- [3]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 6,
				}, -- [4]
				{
					["value"] = 0,
					["preset"] = 1,
					["capped"] = false,
					["stat"] = 5,
				}, -- [5]
			},
		},
	},
	["windowWidth"] = 800,
	["itemSize"] = 24,
	["methodWindowY"] = 702.61083984375,
	["methodWindowX"] = 340.2479248046875,
	["openOnReforge"] = true,
	["windowX"] = 115.3462982177734,
	["customPresets"] = {
	},
	["inactiveWindowTitle"] = {
		0.5, -- [1]
		0.5, -- [2]
		0.5, -- [3]
	},
}
