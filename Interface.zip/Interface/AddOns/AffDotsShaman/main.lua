--[[ TODO

-localization
-Totem support?

]]



local dmg_buff = 1
local protect = 0
local o
local me, spec
local timer, throttle		= 0, 0.1
local dot_damage, targets	= AffDots.dot_damage, AffDots.targets
local dot_damage_ext = { }
local durSaved = { }
local dot_tiks = { }
local MSFrame
local LSFrame
local LBFrame

function onUpdate(self,elapsed)
    timer = timer + elapsed;
    if timer >= throttle then
		for k,v in pairs(AffDots.track) do
			AffDots.track[k].update(AffDots.track[k])
			AffDots:FrameDraw(AffDots.track[k])
		end
       if o.tidyplates.enable and TidyPlates then AffDots:Tidy() end
		timer = 0    
    end
end

local spells = {
	fluidity		= GetSpellInfo(138002), --Fluidity +40%
	nutriment		= GetSpellInfo(140741), --Primal Nutriment +100% +10% per stack
	fearless		= GetSpellInfo(118977), --Fearless + 60%
	titans			= GetSpellInfo(144364), --Power of the Titans
	tricks			= GetSpellInfo(57934),	--Tricks of the Trade + 15%
	--LMG				= GetSpellInfo(137590), -- Caster Meta (ele)
	ue			    = GetSpellInfo(73683),	--Unleash Elements

}

local function GetDmgBuffsUpdate()
	dmg_buff = 1 
	local fluidity 			= UnitAura("player",	spells.fluidity, nil, "HARMFUL")
	local ue 			    = UnitAura("player",	spells.ue)
	local nutriment 		= UnitAura("player",    spells.nutriment)
	local tricks 			= UnitAura("player",	spells.tricks)
	local fearless 			= UnitAura("player",	spells.fearless)
	local titans			= UnitAura("player",	spells.titans) 
	if fluidity 	then dmg_buff = 1.4 					end
	if nutriment 	then dmg_buff = 2					 	end
	if fearless 	then dmg_buff = 1.6 					end
	if tricks 		then dmg_buff = dmg_buff * 1.15			end
	if titans		then dmg_buff = dmg_buff * 1.15			end
	if ue			then dmg_buff = dmg_buff * 1.30			end
	dmg_buff=dmg_buff*1.07--Flametongue not implemented yet
	return dmg_buff
end

local function Round(num) return math.floor(num+.5) end
local function SecondsRound(num)
	if num > 2 then return math.floor(num+.5)
	else return math.floor(num*10+.5)/10 end
end

function AffDots:FindColor(GUID,time_left,spell,pandemic)
	if not targets[GUID..spell] or not dot_damage[spell] then
		return 7
	end
	local current 		= dot_damage[spell][1]
	local on_target 	= targets[GUID..spell][1]
	if		on_target  < current then color = 1
	elseif 	on_target == current then color = 2
	elseif	on_target  > current then color = 6
	end
	return color
end

AffDots.Update = {
	dot	= function(f)
		local guid = UnitGUID(f.target)
		local _,_,_,_,_,duration,expires = UnitDebuff(f.target,f.name,f.rank,"player")
		if duration and guid and targets[guid..f.spell] then
			if(math.abs(expires-f.timer)>1) then
				f.datanew.expires = expires
				f.datanew.duration = duration
				f.datanew.setcd = true
				f.timer = expires
			end
			f.datanew.color = o["color"..AffDots:FindColor(guid,expires - GetTime(),f.spell,f.pandemic)]
			f.datanew.tick = targets[guid..f.spell][3]
			f.datanew.t2 = SecondsRound(f.timer-GetTime())
			if o.reltext then
				if o.shaman.fs_ticks then
					f.datanew.t1 = Round(dot_damage[f.spell][1]*100/targets[guid..f.spell][1]).."\n("..select(2, GetDotTicks(f.spell, guid))..")"
				else
					f.datanew.t1 = Round(dot_damage[f.spell][1]*100/targets[guid..f.spell][1])
				end
			elseif o.layout == "bars" then
				f.datanew.t1 = dot_damage[f.spell][1].."/"..targets[guid..f.spell][1]
			else
				f.datanew.t1 = dot_damage[f.spell][1].."\n"..targets[guid..f.spell][1]
			end
		else
			f.datanew.color = o.color7
			f.datanew.t1 = 0
			f.datanew.t2 = ""
			f.datanew.tick = 0
			f.timer = 0
			f.datanew.hidecd = true
		end
	end,
	
	ms = function(f)
		
		local color
		local id = 53817
		local name = GetSpellInfo(id) 
		local _,_,_,stacks,_,duration,expires = UnitAura("player", name) 
		local glowenable = false
		
		
		if duration then
		
			if(math.abs(expires-f.timer)>1) then
				f.datanew.expires = expires
				f.datanew.duration = duration
				f.datanew.setcd = true
				f.timer = expires
			end
			
			if stacks == 5 then color = 6
			elseif stacks <= 4 then color = 4
		
			elseif stacks == 0 or stacks == nil then --not sure about nil
				f.datanew.setw = o.bars.w*0.01/5 -- try stacks/3
			else
				f.datanew.setw = o.bars.w*stacks/5
			end
			
			f.datanew.t1 = stacks
			f.datanew.color = o["color"..color]			
			f.datanew.t2 = SecondsRound(f.timer-GetTime())
			
		else
			f.datanew.color = o.color7
			f.datanew.t1 = 0
			f.datanew.t2 = ""
			f.timer = 0
			f.datanew.hidecd = true
			
		end
		
		if not glowenable and stacks==5 then		
			ActionButton_ShowOverlayGlow(MSFrame)
			glowenable = true
		else
			ActionButton_HideOverlayGlow(MSFrame)
			glowenable = false
		end
		
		
	end,
	
	ls = function(f)
		
		local color
		local id = 324
		local name = GetSpellInfo(id) 
		local _,_,_,stacks,_,duration,expires = UnitAura("player", name) 
		local glowenable = false
		
		
		if duration then
		
			-- if(math.abs(expires-f.timer)>1) then
				-- f.datanew.expires = expires
				-- f.datanew.duration = duration
				-- f.datanew.setcd = true
				-- f.timer = expires
			-- end
			
			if stacks == 7 then color = 6
			elseif stacks <= 6 then color = 4
		
			elseif stacks == 0 or stacks == nil then --not sure about nil
				f.datanew.setw = o.bars.w*0.01/7 -- try stacks/3
			else
				f.datanew.setw = o.bars.w*stacks/7
			end
			
			f.datanew.t1 = stacks
			f.datanew.color = o["color"..color]			
			f.datanew.t2 = SecondsRound(f.timer-GetTime())
			
		else
			f.datanew.color = o.color7
			f.datanew.t1 = 0
			f.datanew.t2 = ""
			f.timer = 0
			f.datanew.hidecd = true
			
		end
		
		if not glowenable and stacks==7 then		
			ActionButton_ShowOverlayGlow(LSFrame)
			glowenable = true
		else
			ActionButton_HideOverlayGlow(LSFrame)
			glowenable = false
		end
		
		
	end,
	
	lb = function(f)
		
		local color
		local id = 51505
		local surgeid = 77762
		local start,duration = GetSpellCooldown(id)
		local surge = UnitBuff("player", select(1, GetSpellInfo(surgeid))) 
		local glow = false
		
		
		if start > 0 and duration > 7 then 
			
			f.datanew.t1 = ""
			f.datanew.timer = duration
			f.datanew.expires = start + duration
			f.datanew.duration = duration
			f.datanew.setcd = true
			f.datanew.color = o.color6
			f.datanew.t2 = SecondsRound(start + duration - GetTime())
		else
			
			f.datanew.t1 = ""
			f.datanew.t2 = ""
			f.datanew.hidecd = true
			f.datanew.color = o.color1
		end
		
		if not glowenable and surge then		
			ActionButton_ShowOverlayGlow(LBFrame)
			glow = true
		else
			ActionButton_HideOverlayGlow(LBFrame)
			glow = false
		end
		
		
	end,
}

local GetDotDmg = {

	function()
		
		haste, crit, spd, mastery = UnitSpellHaste("player"), GetSpellCritChance(6), GetSpellBonusDamage(6), GetMasteryEffect()
		if crit > 100 then crit = 100 end
		damage_bonus 		= (1+crit/100)
		tick_every 			= 3/(1+(haste/100))
		ticks 				= Round(30/tick_every)
		duration 			= ticks * tick_every		
		damage				= ticks*(291+spd*0.21)*damage_bonus*GetDmgBuffsUpdate()*(1+(mastery/100))
		dps					= Round(damage/duration)
		dot_damage[8050]	= {Round(dps/100)/10, tick_every, duration, ticks}		
	end,
}
	


local function GetDotDur(arg1)
	local spellname = GetSpellInfo(arg1)
	local duration =	select(6, UnitAura("target", spellname, nil, "PLAYER|HARMFUL")) or 0
	local expiration = 	select(7, UnitAura("target", spellname, nil, "PLAYER|HARMFUL")) or GetTime()
			
	local testtime = expiration-duration
	
	return duration, expiration, testtime
end

function GetDotTicks(spellID, destGUID)
	
	if dot_tiks[destGUID..spellID] and dot_tiks[destGUID..spellID] == 0 then
		return true, dot_tiks[destGUID..spellID]
	else
		return false, dot_tiks[destGUID..spellID]
	end
end

local function RemoveDotTic(spellID, destGUID)
	if dot_tiks[destGUID..""..spellID] and dot_tiks[destGUID..""..spellID] > 0 then
		dot_tiks[destGUID..""..spellID] = dot_tiks[destGUID..""..spellID] - 1
	end
end

local CombatLog = 
	function(_,_,_,event_type,_,source_GUID,_,_,_,dest_GUID,_,_,_, ...)		
		if dest_GUID == UnitGUID("player") and select(1, ...) == 137590 then
			AffDots:GetDotDmg()
		end
		if source_GUID ~= me then return end
			spell = select(1, ...)
		if event_type == "SPELL_AURA_APPLIED" then
			if spell == 8050 then
			
					if UnitGUID("target") ==  dest_GUID then
						durSaved[dest_GUID.."8050"] = { select(2, GetDotDur(8050)), GetSpellBonusDamage(6), GetDmgBuffsUpdate() }
					else
						durSaved[dest_GUID.."8050"] = { dot_damage[8050][2] , GetSpellBonusDamage(6), GetDmgBuffsUpdate() }
					end
					
				targets[dest_GUID.."8050"] = {dot_damage[8050][1],GetTime(),dot_damage[8050][2]}
				dot_tiks[dest_GUID.."8050"] = dot_damage[8050][4]
			end
		elseif event_type == "SPELL_AURA_REFRESH" then
			if spell == 8050 then --and (GetTime() - protect) >= 0.5 then
					if UnitGUID("target") ==  dest_GUID then
						durSaved[dest_GUID.."8050"] = { select(2, GetDotDur(8050)), GetSpellBonusDamage(6), GetDmgBuffsUpdate() }
					else
						durSaved[dest_GUID.."8050"] = { dot_damage[8050][2] , GetSpellBonusDamage(6), GetDmgBuffsUpdate() }
					end
		
				targets[dest_GUID.."8050"] = {dot_damage[8050][1],GetTime(),dot_damage[8050][2]}
				dot_tiks[dest_GUID.."8050"] = dot_damage[8050][4]
				--print("got here")
			end
		--elseif event_type == "SPELL_SUMMON" then
		--	saGUID[dest_GUID] = me
		elseif event_type == "SPELL_DAMAGE" then
			if (spell == 8050) then
				protect = GetTime()
			end
		elseif event_type == "SPELL_PERIODIC_DAMAGE" then
			if (spell == 8050) then
				RemoveDotTic(spell, dest_GUID)
			end
			end
		end 


function AffDots:InitSpec()
	AffDots:ReleaseFrames()
	o = self.db.profile
	wipe(AffDots.track)
	
		AffDots.execute_percent = 0 
		AffDots:Track(  8050,	  AffDots.Update.dot, "target",   30,  0, o.shaman.fs_order,  o.shaman.fs_show)
		
		if (spec == 2 and o.shaman.enhancement) then
			AffDots:Track(  53817,	  AffDots.Update.ms, "target",   0,  0, o.shaman.msls_order,  o.shaman.ms_show)
		
		elseif (spec == 1 and o.shaman.elemental) then
			AffDots:Track(  324,	  AffDots.Update.ls, "target",   0,  0, o.shaman.msls_order,  o.shaman.ls_show)
			AffDots:Track(  51505,	  AffDots.Update.lb, "target",   0,  0, o.shaman.lb_order,  o.shaman.lb_show)
		end
		
		--if o.focus then
		--	AffDots:Track(  8050,	  AffDots.Update.dot,  "focus",	  30,  0, 0,  true)

		--end
		
		AffDots.tidyspells = {   ["Interface\\Icons\\Spell_Fire_FlameShock"] = {spell = 8050, pandemic = 0},

	}	
	AffDots:InitFrames()
	
	for k,v in pairs(AffDots.track) do
	
		if AffDots.track[k].spell == 53817 then
			MSFrame = AffDots.track[k].f.icon
		elseif AffDots.track[k].spell == 324 then
			LSFrame = AffDots.track[k].f.icon
		elseif AffDots.track[k].spell == 51505 then
			LBFrame = AffDots.track[k].f.icon
		end
	end
	
end

function AffDots:InitClass()
	AffDots:RegisterEvent("PLAYER_TALENT_UPDATE", "InitClass")
	me = UnitGUID("player")	
	o = self.db.profile
	AffDots:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	AffDots:UnregisterEvent("COMBAT_RATING_UPDATE")
	AffDots:UnregisterEvent("SPELL_POWER_CHANGED")
	AffDots:UnregisterEvent("UNIT_STATS")
	AffDots:UnregisterEvent("PLAYER_DAMAGE_DONE_MODS")
	AffDots:UnregisterEvent("PLAYER_REGEN_ENABLED")
	AffDots:UnregisterEvent("PLAYER_REGEN_DISABLED")
	AffDots:UnregisterEvent("PLAYER_FOCUS_CHANGED")
	AffDots:UnregisterEvent("MODIFIER_STATE_CHANGED")
	AffDotsTarget:SetScript("OnUpdate", nil)
	AffDotsTarget:Hide(); AffDotsFocus:Hide(); AffDotsBurst:Hide()
	
	o.shaman 		  				= o.shaman 					or { }

	if 	o.shaman.elemental==nil or o.shaman.enhancement==nil then
			o.shaman.elemental				= o.shaman.elemental		or true
			o.shaman.enhancement			= o.shaman.enhancement		or true		
	end
	
	o.shaman.fs_order				= o.shaman.fs_order			or 0
	o.shaman.msls_order				= o.shaman.msls_order		or 1
	o.shaman.lb_order				= o.shaman.lb_order			or 2

	
	spec = GetSpecialization() or ""
	if (spec == 1 and o.shaman.elemental) or (spec == 2 and o.shaman.enhancement) then
		o = self.db.profile
		AffDots.GetDotDmg = GetDotDmg[1]
		AffDots.CombatLog = CombatLog
		AffDots:GetDotDmg()
		AffDots:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "CombatLog")
		AffDots:RegisterEvent("COMBAT_RATING_UPDATE", "GetDotDmg")
		AffDots:RegisterEvent("SPELL_POWER_CHANGED", "GetDotDmg")
		AffDots:RegisterEvent("UNIT_STATS", "GetDotDmg")
		AffDots:RegisterEvent("PLAYER_DAMAGE_DONE_MODS", "GetDotDmg")
		AffDots:RegisterEvent("UNIT_SPELL_HASTE", "GetDotDmg")
		AffDots:RegisterEvent("PLAYER_AURAS_CHANGED", "GetDotDmg")		
		AffDots:RegisterEvent("PLAYER_REGEN_ENABLED")
		AffDots:RegisterEvent("PLAYER_REGEN_DISABLED")
		AffDots:RegisterEvent("PLAYER_FOCUS_CHANGED")
		AffDots:RegisterEvent("MODIFIER_STATE_CHANGED")
		AffDotsTarget:SetScript("OnUpdate", onUpdate)
		AffDots:InitSpec()
	end
end

AffDots.InitializeClass = AffDots.InitClass

function AffDots:GetSpecOptions(spec)
	if spec == "SHAMAN1" then self.options.args.spec.name = "Elemental"
	elseif spec == "SHAMAN2" then self.options.args.spec.name = "Enhancement" end

	if spec == "SHAMAN1" or spec == "SHAMAN2" then	

			self.options.args.spec.args = {
			--spacer1 = {order = 1,type = "description",name="You are in Elemental spec and ready to go!", width="full",},
			elemental = {
				order = 1,name = "Enable Elemental",type = "toggle",
				set = function(info,val) o.shaman.elemental = not o.shaman.elemental; AffDots:InitClass() end,
				get = function() return o.shaman.elemental end
			},
			enhancement = {
				order = 1,name = "Enable Enhancement",type = "toggle",
				set = function(info,val) o.shaman.enhancement = not o.shaman.enhancement; AffDots:InitClass() end,
				get = function() return o.shaman.enhancement end
			},
			
			--desc1 = {order = 2,type = "description",name="Spec specific Options:", fontSize="medium"},
			fs = {
				order = 2,name = "Enable Flame Shock tracking",type = "toggle",
				set = function(info,val) o.shaman.fs_show = not o.shaman.fs_show; AffDots:InitClass() end, 
				get = function() return o.shaman.fs_show end
			},
			
			fs_ticks = {
				order = 2,name = "Show Flame Shock Ticks",type = "toggle",
				set = function(info,val) o.shaman.fs_ticks = not o.shaman.fs_ticks; AffDots:InitClass() end, 
				get = function() return o.shaman.fs_ticks end
			},
				
			ls = {
				order = 3,name = "Lightning Shield Stacks",type = "toggle",
				set = function(info,val) o.shaman.ls_show = not o.shaman.ls_show; AffDots:InitClass() end, 
				get = function() return o.shaman.ls_show end
			},
			
			lb = {
				order = 3,name = "Track Lava Burst",type = "toggle",
				set = function(info,val) o.shaman.lb_show = not o.shaman.lb_show; AffDots:InitClass() end, 
				get = function() return o.shaman.lb_show end
			},

			ms = {
				order = 4,name = "Maelstrom Stacks",type = "toggle",
				set = function(info,val) o.shaman.ms_show = not o.shaman.ms_show; AffDots:InitClass() end, 
				get = function() return o.shaman.ms_show end
			},
			
			order = {order = 5,type = "description",name="Order:", fontSize="medium"},
			
			fs_order = {
				order = 6,name = "Flame Shock",type = "range",
				min = 1,max = 3,step = 1,softMin = 1,softMax=3,
				set = function(info,val) o.shaman.fs_order=val-1;AffDots:InitSpec() end,
				get = function(info) return o.shaman.fs_order+1 end
			},
			
			msls_order = {
				order = 6,name = "Maelstrom/Lightning Shield",type = "range",
				min = 1,max = 3,step = 1,softMin = 1,softMax=3,
				set = function(info,val) o.shaman.msls_order=val-1;AffDots:InitSpec() end,
				get = function(info) return o.shaman.msls_order+1 end
			},
			
			lb_order = {
				order = 7,name = "Lava Burst",type = "range",
				min = 1,max = 3,step = 1,softMin = 1,softMax=3,
				set = function(info,val) o.shaman.lb_order=val-1;AffDots:InitSpec() end,
				get = function(info) return o.shaman.lb_order+1 end
			},
		}		
			
		AffDots:InitClass()
	--[[elseif spec == "SHAMAN2" then	
			self.options.args.spec.name = "Enhancement"
			self.options.args.spec.args = {
			--spacer1 = {order = 1,type = "description",name="You are in Enhancement spec and ready to go!", width="full",},
			enhancement = {
				order = 1,name = "Enable",type = "toggle",
				set = function(info,val) o.enhancement.enabled = not o.enhancement.enabled; AffDots:InitClass() end,
				get = function() return o.enhancement.enabled end
			},
		}
		AffDots:InitClass()]]
	else	
		self.options.args.spec.name = "Specialization"
		self.options.args.spec.args = {
			spacer1 = {
				order = 1,type = "description",name="You are not in Enhancement or Elemental spec!", width="full",
			},
		}
	end
end


-- function AffDots:OnEnable() 
	-- AffDots:InitClass()
-- end